# Project-local Appium

Appium and its XCUITest driver are installed **inside this directory only**. Nothing is installed globally, and `APPIUM_HOME` points at `tools/appium/.appium` so drivers do not land in `~/.appium`.

| Component | Pinned version | Why |
|---|---|---|
| `appium` | 3.8.0 | Latest released Appium 3 at resolution time (npm `latest`, 2026-09-24). Engines: Node `^20.19.0 \|\| ^22.12.0 \|\| >=24.0.0`, npm `>=10` |
| `appium-xcuitest-driver` | 12.14.0 | npm `latest` (published 2026-10-03). `peerDependencies.appium: ^3.0.0-rc.2`. Driver ≥ 11.1.2 supports Xcode 16.0+; iOS 18.x and iOS ≥ 26.4 are supported per the driver's compatibility table |

Versions were resolved with `npm view` on 2026-10-03 and recorded in `configs/runtime_manifest.json` (written by `uv run mobilelab doctor --write-manifest`). Change the pins only together with a new doctor run and an Appium/Simulator smoke test.

## Install (from the repository root)

```sh
cd tools/appium
npm ci                                           # uses package-lock.json, installs appium 3.8.0 locally
export APPIUM_HOME="$PWD/.appium"
./node_modules/.bin/appium driver install --source=npm appium-xcuitest-driver@12.14.0
./node_modules/.bin/appium driver list --installed
```

`node_modules/` and `.appium/` are ignored by `tools/appium/.gitignore`.

## Run (later tasks)

Always start the server with the same `APPIUM_HOME` and bind to loopback only (the spec forbids exposing Appium administrative ports to the LAN):

```sh
APPIUM_HOME="$PWD/tools/appium/.appium" tools/appium/node_modules/.bin/appium --address 127.0.0.1 --port 4723
```

If `xcode-select -p` still points at Command Line Tools, export `DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer` for the Appium process (or switch it yourself with `sudo xcode-select -s ...`; mobilelab never does).

## What is not done here

- No WebDriverAgent build, signing, or real-device provisioning.
- No Simulator runtime download, licence acceptance or `xcodebuild -runFirstLaunch`.
- Installing the driver is not a smoke test: no Appium session has been run yet (T03).

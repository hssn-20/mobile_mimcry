"""Live-control hooks (pause/takeover/resume, emergency stop) through the full JourneyRun with the
MOCK adapter (evidence_source=mock) and the real worker subprocess + fixture service.

Mock waits are instant, so ``execute:wait`` gets a labelled mock delay to keep a dwell in flight.
These tests check the hooks' plumbing and the invariants; the device evidence comes from
``tests/device/test_controls_device.py``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mobilelab.domain.enums import ActionKind, RunStatus
from mobilelab.journey import JourneyRun, MockDeviceEnvironment, load_plan
from mobilelab.journey.controls import emergency_stop_hook, pause_resume_hook
from mobilelab.store import Store


class SlowWaitMock(MockDeviceEnvironment):
    def __init__(self, wait_ms: int = 1500) -> None:
        super().__init__()
        self.wait_ms = wait_ms

    def adapter_options(self, **kw: Any) -> dict[str, Any]:
        return {**super().adapter_options(**kw), "delays_ms": {"execute:wait": self.wait_ms}}


def _run(tmp_path: Path, hook: Any, **kw: Any) -> JourneyRun:
    return JourneyRun(
        load_plan("default", dwell_mode="median"), SlowWaitMock(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        loop_hook=hook, **kw,
    )  # fmt: skip


async def test_pause_takeover_resume_completes_with_new_epochs(tmp_path: Path) -> None:
    run = _run(tmp_path, pause_resume_hook(pause_after_s=0.3, hold_paused_s=0.5, takeover=True))
    result = await run.execute()
    ev = result.journey["control_experiment"]
    assert "loop_hook_error" not in result.journey, result.journey.get("loop_hook_error")
    p = ev["pause"]
    assert p["ok"] and p["run_status"] == "PAUSED" and p["fence_confirmed"] and p["in_flight_settled"]
    assert p["fence_acknowledged_in_flight_state"] == "executing"  # the dwell was still running
    assert p["paused_after_in_flight_settled"]
    assert ev["takeover"]["ok"] and ev["takeover"]["active_lease"]["kind"] == "operator"
    assert ev["ui_commands_while_paused"] == 0
    r = ev["resume"]
    assert r["new_lease_epoch"] > ev["lease_before_pause"]["epoch"]
    assert r["new_control_epoch"] > ev["epoch_before_pause"] and r["active_lease_kind"] == "automation"
    assert result.journey["loop"]["completed"], result.journey["loop"]["stop_reason"]
    assert result.status == "COMPLETED" and result.integrity_ok
    assert result.journey["evaluation"]["census"]["stored_outbound_messages"] == 1


async def test_emergency_stop_during_dwell_fences_and_aborts(tmp_path: Path) -> None:
    run = _run(tmp_path, emergency_stop_hook(stop_after_s=0.3, watch_s=1.0))
    result = await run.execute()
    ev = result.journey["control_experiment"]
    assert "loop_hook_error" not in result.journey, result.journey.get("loop_hook_error")
    es = ev["emergency_stop"]
    assert es["fully_fenced"] and es["gate_persisted_at"] <= es["fence_acknowledged_at"]
    assert es["in_flight_at_fence"] == ["executing"]
    assert ev["post_fence_watch"]["new_ui_commands_after_fence"] == 0
    assert ev["journal_attempts_started_after_fence"] == []
    assert ev["gate_after"]["open"] is False
    assert ev["stop_after_emergency"]["ok"] and result.status == RunStatus.ABORTED.value
    assert result.integrity_ok
    with Store.open(tmp_path / "lab.db").reader() as r:
        assert not r.get_gate().gate_open


async def test_emergency_stop_with_injected_worker_delay(tmp_path: Path) -> None:
    """TEST-ONLY worker driver delay on a scroll (swipe) keeps the driver lane busy after the adapter call."""
    delay = {"kinds": ["scroll"], "delay_ms": 2000, "position": "after", "max_commands": 1}
    run = _run(tmp_path, emergency_stop_hook(target_kinds={ActionKind.SCROLL}, stop_after_s=0.3, watch_s=1.0),
               worker_config_overrides={"test_driver_delay": delay})  # fmt: skip
    result = await run.execute()
    ev = result.journey["control_experiment"]
    assert "loop_hook_error" not in result.journey, result.journey.get("loop_hook_error")
    assert ev["worker_before"]["test_driver_delay"]["delay_ms"] == 2000
    assert ev["emergency_stop"]["fully_fenced"] and ev["emergency_stop"]["in_flight_at_fence"] == ["executing"]
    assert ev["post_fence_watch"]["new_ui_commands_after_fence"] == 0
    assert result.status == RunStatus.ABORTED.value

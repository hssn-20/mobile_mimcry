"""The real ``LunaProvider`` (prompt, strict schema, local validation, budget ledger) wired through the
full ``JourneyRun`` with the MOCK adapter and a LABELLED FAKE policy backend.

NOT AN AI TEST: ``HeuristicFakeBackend`` answers from fixed rules over the prompt's candidate list
(no model, no network). It exists to prove the harness plumbing for ``--provider luna``: provider
labels, ledger/usage in the report, persona dwell with decision latency, invalid model output never
reaching the worker, the resend guard against a repeated Send, and a pause while a slow decision
is in flight (late result discarded by control epoch). Real-model evidence comes only from runs
against the OpenAI API (see docs/PROGRESS.md).
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import pytest

from mobilelab.budget import BudgetLedger, TokenUsage
from mobilelab.domain.enums import ActionKind
from mobilelab.journey import JourneyRun, MockDeviceEnvironment, load_plan
from mobilelab.journey.controls import pause_during_decision_hook
from mobilelab.journey.providers import resolve_provider_factory
from mobilelab.providers.openai_backend import BackendResult
from mobilelab.store import Store

USAGE = TokenUsage(input_tokens=900, output_tokens=60, cached_input_tokens=0, reasoning_tokens=20, cache_write_tokens=0)
OK = ("ACKNOWLEDGED", "VERIFIED", "UNKNOWN", "UNRESOLVED")


class HeuristicFakeBackend:
    """LABELLED FAKE policy backend (no model). Picks candidates by semantic-key rules.

    ``mode``:
    * ``normal``: browse, read once, scroll twice, open Messenger, reply, return to Safari.
    * ``hostile``: every *first* answer of a decision is invalid (invented index, off-origin URL,
      unpermitted text), so each decision needs the one schema repair; the repair is valid.
    * ``resend``: after the Send, propose Send again once (whenever it is offered).
    """

    model = "gpt-6-luna"

    def __init__(self, mode: str = "normal", *, slow_call: int | None = None, slow_s: float = 0.0) -> None:
        self.mode = mode
        self.slow_call = slow_call
        self.slow_s = slow_s
        self.calls = 0
        self.cancelled = 0
        self.invalid_sent: list[dict[str, Any]] = []
        self.resend_proposed = 0
        self._hostile_toggle = False

    async def complete(self, *, instructions: str, user_input: str, schema: dict[str, Any], schema_name: str,
                       max_output_tokens: int, timeout_s: float) -> BackendResult:  # fmt: skip
        self.calls += 1
        if self.slow_call is not None and self.calls == self.slow_call:
            try:
                await asyncio.sleep(self.slow_s)
            except asyncio.CancelledError:
                self.cancelled += 1
                raise
        doc = _doc(user_input)
        out = self._answer(doc)
        return BackendResult(output_text=json.dumps(out), usage=USAGE, request_id=f"req_fake_{self.calls}",
                             response_id=f"resp_fake_{self.calls}", model=self.model, latency_ms=1.0)  # fmt: skip

    def _answer(self, doc: dict[str, Any]) -> dict[str, Any]:
        if self.mode == "hostile":
            self._hostile_toggle = not self._hostile_toggle
            if self._hostile_toggle:
                bad = self._hostile(doc)
                self.invalid_sent.append(bad)
                return bad
        return self._choose(doc)

    @staticmethod
    def _hostile(doc: dict[str, Any]) -> dict[str, Any]:
        cands = doc["candidates"]
        for c in cands:
            if c["kind"] == "navigate_url":
                return {"choice": {"candidate_index": c["index"], "url": "http://127.0.0.1:9999/admin"},
                        "reason_code": "OTHER", "completion": False}  # fmt: skip
            if c["kind"] == "type_text":
                return {"choice": {"candidate_index": c["index"], "text": "Sam Operator, call me", "typing_mode": "field_set"},
                        "reason_code": "OTHER", "completion": True}  # fmt: skip
        return {"choice": {"candidate_index": len(cands) + 7}, "reason_code": "GOAL_COMPLETE", "completion": True}

    def _choose(self, doc: dict[str, Any]) -> dict[str, Any]:
        cands = doc["candidates"]
        done = [h["semantic_key"] for h in doc["history"] if h["status"] in OK]

        def has(prefix: str) -> bool:
            return any(k.startswith(prefix) for k in done)

        def count(prefix: str) -> int:
            return sum(k.startswith(prefix) for k in done)

        def pick(prefix: str) -> dict[str, Any] | None:
            return next((c for c in cands if c["semantic_key"].startswith(prefix)), None)

        def answer(c: dict[str, Any], reason: str, completion: bool = False, **params: Any) -> dict[str, Any]:
            return {"choice": {"candidate_index": c["index"], **params}, "reason_code": reason, "completion": completion}

        wait = pick("wait:")
        if has("messenger.send:"):
            send = pick("messenger.send:")
            if self.mode == "resend" and self.resend_proposed == 0:
                if send is not None:
                    self.resend_proposed += 1
                    return answer(send, "SEND_REPLY")
                comp = pick("messenger.composer:")
                if comp is not None and count("messenger.composer:") < 2:
                    spec = comp["parameters"]
                    text = spec["text"]["one_of"][0] if isinstance(spec["text"], dict) else "Done reading, thanks."
                    return answer(comp, "COMPOSE_REPLY", text=text, typing_mode=spec["typing_mode"][0])
            back = pick("app.open:com.apple.mobilesafari")
            if back is not None:
                return answer(back, "GOAL_COMPLETE", completion=True, app_id="com.apple.mobilesafari")
        elif has("messenger.composer:") and (c := pick("messenger.send:")):
            return answer(c, "SEND_REPLY")
        elif has("messenger.conversation:") and (c := pick("messenger.composer:")):
            spec = c["parameters"]
            text = spec["text"]["one_of"][0] if isinstance(spec["text"], dict) else "Done reading, thanks."
            return answer(c, "COMPOSE_REPLY", text=text, typing_mode=spec["typing_mode"][0])
        elif (c := pick("messenger.conversation:fixture-conversation-01")) is not None:
            return answer(c, "OPEN_CONVERSATION")
        elif count("safari.scroll:") >= 2 and (c := pick("app.open:org.mobilelab")):
            return answer(c, "OPEN_APP", app_id=c["parameters"]["app_id"][0])
        elif has("url.open:") and not has("wait:") and wait is not None:
            return answer(wait, "READ_CONTENT", duration_ms=1000)
        elif has("url.open:") and (c := pick("safari.scroll:")):
            return answer(c, "SCROLL_CONTENT", direction="down")
        elif (c := pick("url.open:")) is not None:
            url = next(p for p in doc["scenario"]["goal"].split() if p.startswith("http"))
            return answer(c, "NAVIGATE_TO_START", url=url)
        if wait is not None:
            return answer(wait, "WAIT_FOR_STATE", duration_ms=500)
        return {"choice": {"candidate_index": 0}, "reason_code": "OTHER", "completion": False}


def _doc(user_input: str) -> dict[str, Any]:
    start = user_input.index("{")
    return json.loads(user_input[start:])


def _run(tmp_path: Path, backend: HeuristicFakeBackend, variant: str = "default", **kw: Any) -> tuple[JourneyRun, BudgetLedger]:
    ledger = BudgetLedger.open(tmp_path / "ledger.db", global_cap_usd=5.0, run_cap_usd=0.25)
    run = JourneyRun(
        load_plan(variant, dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        provider_factory=resolve_provider_factory("luna"), provider_options={"backend": backend, "ledger": ledger}, **kw,
    )  # fmt: skip
    return run, ledger


def _actions(tmp_path: Path, run: JourneyRun) -> list[Any]:
    with Store.open(tmp_path / "lab.db").reader() as r:
        return r.list_actions(run_id=run.run_id)


async def test_luna_wiring_completes_mock_journey_with_labels_usage_and_dwell(tmp_path: Path) -> None:
    backend = HeuristicFakeBackend("normal")
    run, ledger = _run(tmp_path, backend)
    result = await run.execute()
    assert result.journey["loop"]["completed"], result.journey["loop"]["stop_reason"]
    assert result.status == "COMPLETED" and result.integrity_ok
    report = json.loads((result.report_dir / "report.json").read_text())
    labels = report["labels"]
    assert labels["provider_label"] == "LunaProvider" and labels["provider_kind"] == "openai"
    assert labels["model_identifier"] == "gpt-6-luna"
    usage = report["provider_usage"]
    assert usage["usage_reported"] and usage["requests"] == backend.calls
    assert usage["confirmed_cost_usd"] > 0 and usage["unresolved_cost_usd"] == 0
    s = ledger.summary(str(run.run_id))
    assert s.confirmed_usd == pytest.approx(usage["confirmed_cost_usd"])
    # mock evidence is never a PASS
    assert result.verdict != "PASS"
    acts = _actions(tmp_path, run)
    dwell = [a for a in acts if a.kind is ActionKind.WAIT]
    assert dwell, "the fake reads once"
    d = dwell[0]
    # harness-sampled persona dwell (median task_focused reading), not the model's 1000 ms; latency counted
    assert d.sampled_delay_ms is not None and d.sampled_delay_ms != 1000
    assert d.payload.duration_ms <= d.sampled_delay_ms and d.decision_latency_ms is not None
    # executed wait = sampled dwell minus the time already elapsed since the decision observation
    assert d.sampled_delay_ms - 3000 < d.payload.duration_ms
    assert d.timing_overrun_ms is not None
    sends = [a for a in acts if a.kind is ActionKind.SEND_MESSAGE]
    assert len(sends) == 1 and sends[0].payload.contact_id == "fixture-contact-01"
    spec = json.loads((result.report_dir / "manifest.json").read_text())
    assert spec["provider_kind"] == "openai" and spec["model_identifier"] == "gpt-6-luna"


async def test_hostile_model_output_never_reaches_the_worker(tmp_path: Path) -> None:
    backend = HeuristicFakeBackend("hostile")
    run, _ = _run(tmp_path, backend)
    result = await run.execute()
    assert backend.invalid_sent, "the fake sent invalid answers"
    acts = _actions(tmp_path, run)
    for a in acts:
        p = a.payload
        if a.kind is ActionKind.NAVIGATE_URL:
            assert "9999" not in p.url and "/admin" not in p.url
        if a.kind is ActionKind.TYPE_TEXT:
            assert p.text == "I have finished reading the article."
        if a.kind is ActionKind.SEND_MESSAGE:
            assert p.contact_id == "fixture-contact-01"
    decisions = result.journey["provider_usage"]["decisions"]
    # each invalid answer was either repaired (retry_count 1) or refused as a provider error
    refused = [d for d in decisions if d["outcome"] == "provider_error" or (d["retry_count"] or 0) >= 1]
    assert refused and len(refused) <= len(backend.invalid_sent)
    assert result.journey["loop"]["completed"], result.journey["loop"]["stop_reason"]


async def test_repeated_send_is_blocked_by_the_resend_guard(tmp_path: Path) -> None:
    backend = HeuristicFakeBackend("resend")
    run, _ = _run(tmp_path, backend, variant="suppressed_ack")
    result = await run.execute()
    acts = _actions(tmp_path, run)
    sends = [a for a in acts if a.kind is ActionKind.SEND_MESSAGE]
    dispatched = [a for a in sends if a.status.value not in ("REJECTED", "CANCELLED")]
    assert len(dispatched) == 1
    assert backend.resend_proposed == 1, "the fake re-proposed Send"
    if backend.resend_proposed:
        rejected = [a for a in sends if a.status.value == "REJECTED"]
        assert rejected and all(a.reject_code is not None and a.reject_code.value == "IDEMPOTENCY_CONFLICT" for a in rejected)
    assert result.journey["evaluation"]["census"]["stored_outbound_messages"] == 1
    assert result.verdict == "INCONCLUSIVE"


async def test_pause_while_slow_decision_in_flight_discards_the_late_result(tmp_path: Path) -> None:
    backend = HeuristicFakeBackend("normal", slow_call=3, slow_s=3.0)
    run, ledger = _run(tmp_path, backend, loop_hook=pause_during_decision_hook(min_in_flight_s=0.5, hold_paused_s=0.5))
    result = await run.execute()
    assert "loop_hook_error" not in result.journey, result.journey.get("loop_hook_error")
    ev = result.journey["control_experiment"]
    assert ev["pause"]["ok"] and ev["pause"]["run_status"] == "PAUSED"
    assert ev["discarded_decisions_old_epoch"], ev
    assert ev["actions_journaled_during_pause"] == 0
    assert ev["resume"]["new_control_epoch"] > ev["pause"]["epoch_before"]
    acts = _actions(tmp_path, run)
    assert all(a.decision_id not in {d["decision_id"] for d in ev["discarded_decisions_old_epoch"]} for a in acts)
    rows = ledger.rows(str(run.run_id))
    assert any(r["status"] == "unresolved" for r in rows), [r["status"] for r in rows]
    assert result.journey["loop"]["completed"], result.journey["loop"]["stop_reason"]

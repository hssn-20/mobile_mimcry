"""Journey-level review fixes for ``--provider luna`` (MOCK adapter; LABELLED FAKE model backends).

NOT AI TESTS: every model answer here is produced by test code (no model, no network).

* A completion hint never completes a run by itself: the harness end condition (send executed and
  acknowledged, Safari back in front) decides; repeated premature hints end INCONCLUSIVE.
* A provider error retrying cannot fix (HTTP 401) stops the loop at once: FAILED / ENVIRONMENT_FAILURE,
  not 13 retries ending COMPLETED / HARNESS_FAILURE.
* Secret canary, end to end: the real key lookup (``OPENAI_API_KEY``) and the real Agents SDK backend
  talk to a local fake Responses API (httpx ``MockTransport``); the key value and its prefix appear
  nowhere in the run's files (work dir, artifacts, report, DB and WAL), logs or captured output.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import httpx
import pytest

from mobilelab.budget import BudgetLedger
from mobilelab.journey import JourneyRun, MockDeviceEnvironment, load_plan
from mobilelab.journey.providers import resolve_provider_factory
from mobilelab.providers.openai_backend import BackendError
from mobilelab.store import Store

from test_journey_luna_fake_backend import HeuristicFakeBackend, _doc  # noqa: I001 - sibling test module

CANARY = "sk-proj-MLCANARY" + "Zq7Xw3Vb9Tn2Lk5Hd8Gf4Jp6" + "Rs1Ue0Yc3Ma7Ob2Pi9Qt"


def _run(tmp_path: Path, options: dict[str, Any], variant: str = "default") -> tuple[JourneyRun, BudgetLedger]:
    ledger = BudgetLedger.open(tmp_path / "ledger.db", global_cap_usd=5.0, run_cap_usd=0.25)
    run = JourneyRun(
        load_plan(variant, dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        provider_factory=resolve_provider_factory("luna"), provider_options={**options, "ledger": ledger},
    )  # fmt: skip
    return run, ledger


class EarlyHintBackend(HeuristicFakeBackend):
    """LABELLED FAKE: the first ``early`` answers are a wait/scroll/open with completion=true; then normal."""

    def __init__(self, early: int, *, always: bool = False) -> None:
        super().__init__("normal")
        self.early = early
        self.always = always

    def _answer(self, doc: dict[str, Any]) -> dict[str, Any]:
        out = self._choose(doc)
        if self.always or self.calls <= self.early:
            out = {**out, "completion": True}
        return out


async def test_early_completion_hint_does_not_end_the_run(tmp_path: Path) -> None:
    backend = EarlyHintBackend(early=2)
    run, _ = _run(tmp_path, {"backend": backend})
    result = await run.execute()
    loop = result.journey["loop"]
    assert loop["premature_completion_hints"], loop
    assert all("no send_message" in h["unmet"] for h in loop["premature_completion_hints"])
    # the loop kept stepping: the reply was sent, then the hint on returning to Safari met the condition
    assert loop["completed"], loop["stop_reason"]
    assert "harness end condition met" in loop["stop_reason"]
    with Store.open(tmp_path / "lab.db").reader() as r:
        sends = [a for a in r.list_actions(run_id=run.run_id) if a.kind.value == "send_message"]
    assert len(sends) == 1


async def test_repeated_premature_completion_is_inconclusive_not_harness_failure(tmp_path: Path) -> None:
    """A model that keeps declaring completion before sending: INCONCLUSIVE, never COMPLETED-verified."""

    class AlwaysEarly(EarlyHintBackend):
        def _choose(self, doc: dict[str, Any]) -> dict[str, Any]:
            cands = doc["candidates"]
            for prefix in ("safari.scroll:", "url.open:"):
                c = next((c for c in cands if c["semantic_key"].startswith(prefix)), None)
                if c is not None and prefix == "safari.scroll:":
                    return {"choice": {"candidate_index": c["index"], "direction": "down"},
                            "reason_code": "SCROLL_CONTENT", "completion": True}  # fmt: skip
                if c is not None:
                    url = next(p for p in doc["scenario"]["goal"].split() if p.startswith("http"))
                    return {"choice": {"candidate_index": c["index"], "url": url},
                            "reason_code": "NAVIGATE_TO_START", "completion": True}  # fmt: skip
            return super()._choose(doc)

    backend = AlwaysEarly(early=0, always=True)
    run, _ = _run(tmp_path, {"backend": backend})
    result = await run.execute()
    loop = result.journey["loop"]
    assert not loop["completed"] and loop["stop_class"] == "premature_completion", loop["stop_reason"]
    assert len(loop["premature_completion_hints"]) == 3
    assert result.verdict == "INCONCLUSIVE" and "prematurely" in (result.reason or "")
    assert backend.calls <= 4


async def test_unrecoverable_provider_rejection_is_environment_failure(tmp_path: Path) -> None:
    class Rejecting:
        """LABELLED FAKE backend: every call is rejected like an HTTP 401 (not billed)."""

        model = "gpt-6-luna"
        calls = 0

        async def complete(self, **kw: Any) -> Any:
            type(self).calls += 1
            raise BackendError("rejected", error_class="AuthenticationError", status_code=401, billed=False)

    run, ledger = _run(tmp_path, {"backend": Rejecting()})
    result = await run.execute()
    loop = result.journey["loop"]
    assert Rejecting.calls == 1, "a 401 is not retried"
    assert loop["stop_class"] == "provider_unavailable"
    assert result.status == "FAILED" and result.verdict == "ENVIRONMENT_FAILURE", (result.status, result.verdict, result.reason)
    assert all(r["status"] == "released" for r in ledger.rows(str(run.run_id)))


async def test_pause_cancelled_decision_is_recorded_cancelled_and_left_out_of_latency(tmp_path: Path) -> None:
    from mobilelab.journey.controls import pause_during_decision_hook
    from mobilelab.reporting.latency import stats, summarize

    backend = HeuristicFakeBackend("normal", slow_call=3, slow_s=3.0)
    ledger = BudgetLedger.open(tmp_path / "ledger.db", global_cap_usd=5.0, run_cap_usd=0.25)
    run = JourneyRun(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        provider_factory=resolve_provider_factory("luna"), provider_options={"backend": backend, "ledger": ledger},
        loop_hook=pause_during_decision_hook(min_in_flight_s=0.5, hold_paused_s=0.5),
    )  # fmt: skip
    result = await run.execute()
    ev = result.journey["control_experiment"]
    assert [d["outcome"] for d in ev["discarded_decisions_old_epoch"]] == ["cancelled"]
    summary = summarize(tmp_path / "lab.db", [str(run.run_id)])
    per = summary["per_run"][0]
    assert per["decision_outcomes"].get("cancelled") == 1
    assert [x["outcome"] for x in per["excluded_from_latency"]] == ["cancelled"]
    assert per["excluded_from_latency"][0]["error_class"] == "DecisionCancelled"
    assert per["decision_latency_ms"]["n"] == per["decision_outcomes"]["accepted"]
    assert stats([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0])["p90"] == 9.0


# ---------------------------------------------------------------- secret canary, end to end
def _fake_responses_api(seen: dict[str, Any]) -> httpx.MockTransport:
    """LABELLED FAKE Responses API: answers with the heuristic fake's choice for the prompt it gets."""
    chooser = HeuristicFakeBackend("normal")

    def handler(request: httpx.Request) -> httpx.Response:
        seen["requests"] = seen.get("requests", 0) + 1
        seen["auth_ok"] = seen.get("auth_ok", True) and request.headers.get("authorization") == f"Bearer {CANARY}"
        body = json.loads(request.content)
        seen["store_false"] = seen.get("store_false", True) and body.get("store") is False
        seen["no_tools"] = seen.get("no_tools", True) and not body.get("tools")
        text = json.dumps(body)
        user = next(s for s in _strings(body) if '"candidates"' in s)
        assert CANARY not in text
        out = chooser._answer(_doc(user))  # noqa: SLF001
        n = seen["requests"]
        payload = {
            "id": f"resp_fake_{n}", "object": "response", "created_at": 0, "status": "completed",
            "model": "gpt-6-luna", "parallel_tool_calls": False, "tool_choice": "auto", "tools": [],
            "output": [{"type": "message", "id": f"msg_fake_{n}", "status": "completed", "role": "assistant",
                        "content": [{"type": "output_text", "text": json.dumps(out), "annotations": []}]}],
            "usage": {"input_tokens": 900, "input_tokens_details": {"cached_tokens": 0}, "output_tokens": 60,
                      "output_tokens_details": {"reasoning_tokens": 20}, "total_tokens": 960},
        }  # fmt: skip
        return httpx.Response(200, json=payload, headers={"x-request-id": f"req_fake_{n}"})

    return httpx.MockTransport(handler)


def _strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [s for v in value.values() for s in _strings(v)]
    if isinstance(value, list):
        return [s for v in value for s in _strings(v)]
    return []


async def test_secret_canary_never_reaches_artifacts_logs_db_or_report(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", CANARY)
    caplog.set_level(logging.DEBUG)
    seen: dict[str, Any] = {}
    client = httpx.AsyncClient(transport=_fake_responses_api(seen))
    run, _ = _run(tmp_path, {"base_url": "http://fake-openai.invalid/v1", "http_client": client})
    result = await run.execute()
    await client.aclose()
    assert seen.get("requests", 0) >= 5 and seen["auth_ok"], "the real SDK path used the env key"
    assert seen["store_false"] and seen["no_tools"]
    assert result.journey["loop"]["completed"], result.journey["loop"]["stop_reason"]
    assert result.report_dir is not None and (result.report_dir / "report.json").exists()

    needles = [CANARY.encode(), CANARY[:12].encode(), CANARY[-12:].encode()]
    scanned = 0
    for path in tmp_path.rglob("*"):
        if path.is_file():
            data = path.read_bytes()
            scanned += 1
            for n in needles:
                assert n not in data, f"secret material in {path.relative_to(tmp_path)}"
    names = {p.name for p in tmp_path.rglob("*") if p.is_file()}
    assert "report.json" in names and "lab.db" in names and scanned > 5
    out = capsys.readouterr()
    for n in needles:
        s = n.decode()
        assert s not in caplog.text and s not in out.out and s not in out.err

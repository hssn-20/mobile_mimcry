"""Luna on recorded REAL Simulator observations (no device).

* Offline part (always): the recorded REAL Simulator observations, committed as a fixture export under
  ``tests/fixtures/recorded/``, build a prompt that fits the budget and leaks no IDs/selectors. When the
  local run DB is present, the export is also checked against it.
* Live part: opt-in with ``MOBILELAB_LUNA_LIVE=1`` (spends real money from the ledger-capped budget).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from uuid import UUID

import pytest

from mobilelab.domain.decisions import DecisionContext
from mobilelab.domain.observations import Observation
from mobilelab.personas import get_persona
from mobilelab.providers import load_luna_config
from mobilelab.providers.luna_smoke import DEFAULT_PICKS, DEFAULT_RUN, load_recorded_observations, main
from mobilelab.providers.policy_io import build_policy_request

ROOT = Path(__file__).resolve().parents[2]
DB = ROOT / "artifacts" / "mobilelab.db"
EXPORT = ROOT / "tests" / "fixtures" / "recorded" / "luna_smoke_observations.json"


def _observations() -> list[Observation]:
    data = json.loads(EXPORT.read_text())
    assert data["source"]["run_id"] == DEFAULT_RUN
    return [Observation.model_validate(o) for o in data["observations"]]


def test_export_matches_local_recorded_run_when_present() -> None:
    if not DB.exists():
        pytest.skip("local run database not on this host (the committed export is still tested)")
    try:
        live = load_recorded_observations(DB, DEFAULT_RUN, [p for p, _ in DEFAULT_PICKS])
    except SystemExit:
        pytest.skip("recorded run not in the local database")
    exported = _observations()
    assert [o.observation_id for o in live] == [o.observation_id for o in exported]
    assert [o.candidates for o in live] == [o.candidates for o in exported]


def test_recorded_observations_build_bounded_prompts() -> None:
    cfg = load_luna_config()
    assert len(_observations()) == len(DEFAULT_PICKS)
    for obs, (_, stage) in zip(_observations(), DEFAULT_PICKS, strict=True):
        ctx = DecisionContext(run_id=UUID(int=1), persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
                              scenario_version=1, scenario_stage=stage, goal="g", control_epoch=0)  # fmt: skip
        req = build_policy_request(ctx, obs, list(obs.candidates), reason_codes=cfg.reason_codes,
                                   max_elements=cfg.max_elements, text_limit=cfg.max_element_text,
                                   max_input_tokens=cfg.max_input_tokens)  # fmt: skip
        assert req.input_token_bound <= cfg.max_input_tokens
        blob = req.user_input + json.dumps(req.schema)
        assert all(str(c.candidate_id) not in blob for c in obs.candidates)
        assert all(f'"{c.target_ref}"' not in blob for c in obs.candidates if c.target_ref)


@pytest.mark.skipif(os.environ.get("MOBILELAB_LUNA_LIVE") != "1" or not DB.exists(), reason="live model call is opt-in")
def test_live_luna_smoke(tmp_path: Path) -> None:
    assert main(["--max-calls", "2", "--out", str(ROOT / "artifacts" / "provider")]) == 0

"""Coordinator + real worker subprocess (MOCK adapter): journal, artifacts, emergency stop.

Real IPC/process behaviour; all device-side output is ``evidence_source=mock`` (not device evidence).
"""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from pathlib import Path
from uuid import uuid4

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "unit"))

from test_coordinator_support import (  # noqa: E402
    CONV1,
    CONVERSATIONS,
    REPLY,
    RecordingReconciler,
    ScriptedProvider,
    actions,
    budget,
    context,
    make_controller,
    ready_run,
)

from mobilelab.adapters.mock import MESSENGER_APP  # noqa: E402
from mobilelab.coordinator import OutcomeKind  # noqa: E402
from mobilelab.domain.enums import ActionStatus, CommandStatus, EvidenceSource  # noqa: E402
from mobilelab.store import Store  # noqa: E402
from mobilelab.store.artifacts import ArtifactStore  # noqa: E402
from mobilelab.workers import WorkerConfig, WorkerHandle  # noqa: E402

STEPS = [
    (f"messenger.conversation:{CONV1}", {}),
    (f"messenger.composer:{CONV1}", {"text": REPLY}),
    (f"messenger.send:{CONV1}", {}),
]


async def spawn(tmp_path: Path, **opts: object) -> WorkerHandle:
    cfg = WorkerConfig(
        device_id=uuid4(),
        adapter_options={"foreground_app": MESSENGER_APP, "conversations": CONVERSATIONS, **opts},
    )
    return await WorkerHandle.spawn("mock", cfg, stderr=tmp_path / "worker.log")


async def test_send_journey_through_subprocess_worker(tmp_path: Path) -> None:
    store, artifacts = Store.open(tmp_path / "lab.db"), ArtifactStore(tmp_path / "artifacts")
    worker = await spawn(tmp_path)
    try:
        ctrl = make_controller(store, artifacts, ScriptedProvider(STEPS), RecordingReconciler())
        ctrl.attach_worker(worker)
        run = ready_run(store, worker.device_id)
        await ctrl.start(run.run_id)
        outcomes = [await ctrl.step(run.run_id, context(run.run_id), budget()) for _ in STEPS]
        assert [o.kind for o in outcomes] == [OutcomeKind.ACKNOWLEDGED] * 3
        send = actions(store, run.run_id)[-1]
        assert send.status is ActionStatus.ACKNOWLEDGED and send.correlation_id is not None
        with store.reader() as r:
            metas = r.list_artifacts(run_id=run.run_id)
            (attempt,) = r.list_attempts(send.action_id)
        assert len(metas) == 6  # decision + dispatch observation per step
        assert {m.evidence_source for m in metas} == {EvidenceSource.MOCK}
        assert all(artifacts.read_bytes(m).startswith(b"MOCK SCREENSHOT") for m in metas)
        assert attempt.result is not None and attempt.result.evidence_source is EvidenceSource.MOCK
        health = await worker.health()
        assert str(send.correlation_id) in health.device.detail  # type: ignore[union-attr]
    finally:
        await worker.close()


async def test_emergency_stop_confirmed_and_pending_across_processes(tmp_path: Path) -> None:
    store, artifacts = Store.open(tmp_path / "lab.db"), ArtifactStore(tmp_path / "artifacts")
    slow = await spawn(tmp_path, delays_ms={"execute": 2500})
    stuck = await spawn(tmp_path)
    try:
        ctrl = make_controller(store, artifacts, ScriptedProvider(STEPS[:1]), RecordingReconciler())
        ctrl.attach_worker(slow)
        ctrl.attach_worker(stuck)
        run = ready_run(store, slow.device_id)
        await ctrl.start(run.run_id)
        step = asyncio.ensure_future(ctrl.step(run.run_id, context(run.run_id), budget()))
        while (await slow.health()).in_flight_state != "executing":  # slow execute is running
            await asyncio.sleep(0.05)
        os.kill(stuck.pid, signal.SIGSTOP)  # second worker wedged: its fence cannot be confirmed
        res = await ctrl.emergency_stop()
        by_dev = {d.device_id: d for d in res.devices}
        assert by_dev[slow.device_id].fenced and by_dev[slow.device_id].in_flight_state == "executing"
        assert not by_dev[stuck.device_id].fenced
        assert not res.fully_fenced and res.fence_acknowledged_at is None
        with store.reader() as r:
            assert r.get_command(res.command_id).status is CommandStatus.FAILED
            assert not r.get_gate().gate_open
        out = await step
        assert out.kind is OutcomeKind.ACKNOWLEDGED  # in-flight command completes; nothing new starts
        assert '"execute": 1' in (await slow.health()).device.detail  # type: ignore[union-attr]
    finally:
        os.kill(stuck.pid, signal.SIGCONT)
        await stuck.kill()
        await slow.close()

"""Coordinator restart after a send was dispatched, with the MOCK adapter (evidence_source=mock).

A real child coordinator process (JourneyRun + worker subprocess) is SIGKILLed right after its
send_message action was journaled DISPATCHED/ACKNOWLEDGED; this process restarts the coordinator on
the same database, reconciles by fixture receipt and never resends. Device evidence for the same
flow comes from ``tests/device/test_controls_device.py``.
"""

from __future__ import annotations

from pathlib import Path

from mobilelab.journey.restart import run_restart_experiment


async def test_restart_after_send_dispatch_reconciles_without_resend(tmp_path: Path) -> None:
    out = await run_restart_experiment(
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        adapter="mock", child_timeout_s=120,
    )  # fmt: skip
    ev = out.evidence
    assert "error" not in ev, ev.get("error")
    assert ev["send_status_at_kill"] in ("DISPATCHED", "ACKNOWLEDGED")
    assert ev["child_exit_code"] == -9
    assert ev["orphans"]["worker_exited_on_stdin_eof"]
    assert ev["before_recovery"]["run_status"] == "RUNNING" and ev["before_recovery"]["send_attempts"] == 1
    assert ev["recovery"]["gate_closed"] and str(out.run_id) in ev["recovery"]["recovered_run_ids"]
    assert str(out.run_id) in ev["recovery"]["paused_run_ids"]
    (rec,) = ev["send_reconciliation"]
    assert rec["resolution"] == "VERIFIED" and rec["reason_code"].startswith("RECEIPT_")
    assert rec["client_message_id"] == ev["client_message_id"] and rec["resend_permitted"] is False
    after = ev["after_recovery"]
    assert after["run_status"] == "PAUSED" and after["send_status"] == "VERIFIED"
    assert after["send_attempts"] == 1 and after["gate_open"] is False and after["active_lease"] is None
    assert after["stored_outbound_messages"] == 1 and after["stored_client_message_ids"] == [ev["client_message_id"]]
    assert after["fixture_message_posts"] == 1
    assert ev["final_run_status"] == "ABORTED" and ev["final_gate_open"] is False
    assert out.integrity_ok
    assert "parent-fixture/fixture-state/admin_secret" in ev["raw_log_redaction"]["files_removed"]

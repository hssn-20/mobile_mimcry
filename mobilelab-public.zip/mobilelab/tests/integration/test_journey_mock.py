"""browse_then_reply runner end to end with the MOCK adapter (evidence_source=mock).

Real fixture service subprocess (with scripted receiver), real worker subprocess, real store,
RulesProvider, receipt oracle and report bundle. The fake Lab Messenger posts the sent draft to the
fixture like the real app's transport. NOT device evidence: the run verdict can never be PASS.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

import pytest

from mobilelab.journey import JourneyRun, MockDeviceEnvironment, load_plan, run_journey
from mobilelab.domain.enums import ActionStatus, RunStatus
from mobilelab.store import Store

PRE_DISPATCH = {ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED, ActionStatus.PREPARED}


async def _run(tmp_path: Path, variant: str):  # type: ignore[no-untyped-def]
    return await run_journey(
        load_plan(variant, dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
    )  # fmt: skip


async def test_mock_journey_completes_but_is_never_device_pass(tmp_path: Path) -> None:
    result = await _run(tmp_path, "default")
    assert result.status == "COMPLETED"
    assert result.verdict == "INCONCLUSIVE" and "not device evidence" in result.reason
    assert result.integrity_ok
    j = result.journey
    assert j["loop"]["completed"] and j["loop"]["verification_foreground_app"] == "com.apple.mobilesafari"
    stages = [s["stage"] for s in j["loop"]["steps"] if s["outcome"] == "acknowledged"]
    assert stages.count("send_reply") == 1 and stages[-1] == "return_to_browser"
    (send,) = j["evaluation"]["sends"]
    assert send["receipt_verdict"] == "PASS" and send["draft_identity_matches"] and send["post_send_ui_row_seen"]
    assert send["status_after"] == "VERIFIED"
    assert j["evaluation"]["census"]["stored_outbound_messages"] == 1
    report = json.loads((result.report_dir / "report.json").read_text())
    assert report["labels"]["provider_label"] == "RulesProvider"
    assert report["labels"]["observation_evidence_sources"] == {"mock": len(report["observations"])}
    assert report["run"]["recorded_verdict"] == "INCONCLUSIVE"
    # the stored oracle result is capped: a mock run never counts as a PASS anywhere
    manifest = json.loads((result.report_dir / "manifest.json").read_text())
    for counts in (report["verdict_counts"], report["result_counts"], manifest["verdict_counts"]):
        assert counts["counts"]["PASS"] == 0
    assert send["oracle_verdict"] == "INCONCLUSIVE" and send["oracle_reason"] == "NOT_DEVICE_EVIDENCE"
    assert report["labels"]["no_device"] and manifest["no_device"]
    assert report["labels"]["messaging_disclaimer"].startswith("MOCK, no device")
    for name in ("report.html", "manifest.json"):
        assert (result.report_dir / name).is_file()
    assert result.journey["gate_admission"]["problems"] == []
    with Store.open(tmp_path / "lab.db").reader() as r:
        assert not r.get_gate().gate_open  # closed again when the run finished


async def test_mock_suppressed_ack_keeps_delivery_unknown_without_resend(tmp_path: Path) -> None:
    result = await _run(tmp_path, "suppressed_ack")
    assert result.status == "COMPLETED" and result.verdict == "INCONCLUSIVE"
    j = result.journey
    (send,) = j["evaluation"]["sends"]
    assert send["oracle_reason"] == "DELIVERY_UNCONFIRMED" and send["receiver_delivered_at"] is None
    assert j["evaluation"]["census"]["stored_outbound_messages"] == 1
    assert j["fixture_requests"]["message_posts"] == 1 and j["fixture_requests"]["acknowledgement_posts"] == 0
    assert result.integrity_ok


async def test_fixture_credentials_never_reach_stored_evidence(tmp_path: Path) -> None:
    run = JourneyRun(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
    )  # fmt: skip
    result = await run.execute()
    assert len([x for x in run.secrets if x]) == 4  # admin secret + sender/receiver/oracle tokens
    stored = b"".join(p.read_bytes() for p in result.report_dir.rglob("*") if p.is_file())
    assert stored  # report, manifest, journey.json, logs, observations
    for secret in run.secrets:
        assert secret.encode() not in stored


async def test_interrupted_run_is_stopped_torn_down_and_reported(tmp_path: Path) -> None:
    progress: list[str] = []
    run = JourneyRun(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work",
        progress=progress.append,
    )  # fmt: skip
    task = asyncio.ensure_future(run.execute())
    while "running the decision loop" not in progress:
        await asyncio.sleep(0.05)
    await asyncio.sleep(0.5)
    fixture_pid = run.fixture.proc.pid if run.fixture.proc else None
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert fixture_pid is not None and run.fixture.proc is None
    with pytest.raises(ProcessLookupError):  # fixture service stopped (reaped), not orphaned
        os.kill(fixture_pid, 0)
    assert run.worker is not None and run.worker.returncode is not None
    with Store.open(tmp_path / "lab.db").reader() as r:
        stored = r.get_run(run.run_id)
        assert stored.status is RunStatus.ABORTED
        assert r.get_active_lease(stored.spec.device_id) is None
        assert not r.get_gate().gate_open
        assert not [a for a in r.list_actions(run_id=run.run_id) if a.status in PRE_DISPATCH]
    report_dir = tmp_path / "artifacts" / "runs" / str(run.run_id)
    report = json.loads((report_dir / "report.json").read_text())
    assert report["run"]["interrupted"] and report["verdict_counts"]["counts"]["PASS"] == 0
    assert run.journey["interrupted"] and run.journey["report_integrity"]["ok"]
    assert (report_dir / "manifest.json").is_file()


async def test_gate_stays_closed_after_an_emergency_stop_unless_the_operator_reopens(tmp_path: Path) -> None:
    store = Store.open(tmp_path / "lab.db")
    with store.unit_of_work() as uow:
        uow.close_gate("emergency stop: operator")
    store.close()
    refused = await _run(tmp_path, "default")
    assert refused.status == "FAILED" and refused.verdict == "ENVIRONMENT_FAILURE"
    assert "emergency stop" in refused.reason and refused.integrity_ok
    assert refused.journey["fixture_requests"]["message_posts"] == 0  # no device work at all
    reopened = await run_journey(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work2",
        reopen_gate=True,
    )  # fmt: skip
    assert reopened.status == "COMPLETED"


async def test_unreconciled_crashed_run_blocks_the_gate_until_the_operator_abandons_it(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    progress: list[str] = []
    crashed = JourneyRun(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "w1",
        progress=progress.append,
    )  # fmt: skip

    async def hard_crash() -> None:  # simulate a coordinator that died without recording anything
        return None

    monkeypatch.setattr(crashed, "_abort_interrupted", hard_crash)
    monkeypatch.setattr(crashed, "_close_gate", lambda: None)
    task = asyncio.ensure_future(crashed.execute())
    while "running the decision loop" not in progress:
        await asyncio.sleep(0.05)
    await asyncio.sleep(1.0)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    with Store.open(tmp_path / "lab.db").reader() as r:
        assert r.get_run(crashed.run_id).status is RunStatus.RUNNING

    refused = await _run(tmp_path, "default")
    assert refused.verdict == "ENVIRONMENT_FAILURE" and str(crashed.run_id) in refused.reason
    with Store.open(tmp_path / "lab.db").reader() as r:
        assert r.get_run(crashed.run_id).status is RunStatus.PAUSING  # recovery, still unreconciled

    reopened = await run_journey(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "w3",
        reopen_gate=True,
    )  # fmt: skip
    assert reopened.status == "COMPLETED"
    assert reopened.journey["gate_admission"]["abandoned_runs"] == [str(crashed.run_id)]
    with Store.open(tmp_path / "lab.db").reader() as r:
        old = r.get_run(crashed.run_id)
        assert old.status is RunStatus.ABORTED and old.verdict is not None and old.verdict.value == "INCONCLUSIVE"
        left = {a.status for a in r.list_actions(run_id=crashed.run_id)}
    assert not left & {ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED, ActionStatus.UNKNOWN}

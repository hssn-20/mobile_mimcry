"""Real worker subprocess over framed stdin/stdout IPC, driven by the MOCK adapter.

These spawn ``python -m mobilelab.workers.entry --adapter mock``: real process/IPC/fencing
behaviour, but every observation/result is ``evidence_source=mock`` (no device involved).
"""

from __future__ import annotations

import asyncio
import os
import signal
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import pytest

from mobilelab.adapters.mock import MESSENGER_APP
from mobilelab.domain.actions import Wait
from mobilelab.domain.dispatch import DispatchCommand
from mobilelab.domain.enums import EvidenceSource, ExecutionStatus
from mobilelab.domain.errors import ErrorCode
from mobilelab.domain.observations import Observation, ObserveRequest
from mobilelab.workers import WorkerConfig, WorkerHandle
from mobilelab.workers.errors import WorkerTimeout

LEASE, EPOCH, CTRL = uuid4(), 1, 0


async def spawn(tmp_path: Path, **adapter_options: Any) -> WorkerHandle:
    cfg = WorkerConfig(
        device_id=uuid4(),
        adapter_options={"foreground_app": MESSENGER_APP, **adapter_options},
        observe_timeout_ms=5_000,
    )
    return await WorkerHandle.spawn("mock", cfg, stderr=tmp_path / "worker.log")


@pytest.fixture
async def worker(tmp_path: Path) -> AsyncIterator[WorkerHandle]:
    h = await spawn(tmp_path)
    yield h
    if h.alive:
        await h.close()


def req(device_id: UUID) -> ObserveRequest:
    return ObserveRequest(request_id=uuid4(), device_id=device_id, session_id=uuid4(), lease_id=LEASE, lease_epoch=EPOCH)


def cmd(device_id: UUID, obs: Observation, *, lease_id: UUID = LEASE, max_duration_ms: int = 5_000) -> DispatchCommand:
    return DispatchCommand(
        command_id=uuid4(), action_id=uuid4(), run_id=uuid4(), device_id=device_id, session_id=uuid4(),
        lease_id=lease_id, lease_epoch=EPOCH, control_epoch=CTRL, dispatch_observation_id=obs.observation_id,
        dispatch_candidate_id=uuid4(), payload=Wait(kind="wait", duration_ms=5), max_duration_ms=max_duration_ms,
        trace_id="it",
    )  # fmt: skip


async def test_hello_observe_artifacts_and_execute(worker: WorkerHandle) -> None:
    assert worker.evidence_source is EvidenceSource.MOCK and worker.adapter == "mock"
    assert worker.pid != os.getpid()
    await worker.authorize(LEASE, EPOCH, CTRL)
    obs = await worker.observe(req(worker.device_id))
    assert obs.evidence_source is EvidenceSource.MOCK and obs.foreground_app == MESSENGER_APP
    (blob,) = worker.take_artifacts(obs.observation_id)
    assert blob.artifact_id == obs.screenshot_artifact_id and blob.evidence_source is EvidenceSource.MOCK
    result = await worker.execute(cmd(worker.device_id, obs))
    assert result.status is ExecutionStatus.ACKNOWLEDGED and result.evidence_source is EvidenceSource.MOCK
    health = await worker.health()
    assert health.gate_open and health.lease_id == LEASE and health.device is not None
    assert '"execute": 1' in health.device.detail


async def test_stale_lease_rejected_over_ipc(worker: WorkerHandle) -> None:
    await worker.authorize(LEASE, EPOCH, CTRL)
    obs = await worker.observe(req(worker.device_id))
    result = await worker.execute(cmd(worker.device_id, obs, lease_id=uuid4()))
    assert result.status is ExecutionStatus.REJECTED and result.rejection_code is ErrorCode.STALE_LEASE
    assert '"execute": 0' in (await worker.health()).device.detail  # type: ignore[union-attr]


async def test_fence_on_priority_lane_during_slow_driver_op(tmp_path: Path) -> None:
    w = await spawn(tmp_path, delays_ms={"execute": 3000})
    try:
        await w.authorize(LEASE, EPOCH, CTRL)
        obs = await w.observe(req(w.device_id))
        slow = cmd(w.device_id, obs)
        running = asyncio.ensure_future(w.execute(slow))
        await asyncio.sleep(0.3)
        t0 = time.monotonic()
        fence = await w.fence(CTRL)
        elapsed = time.monotonic() - t0
        assert fence.fenced and elapsed < 0.5, elapsed
        assert fence.in_flight_command_id == slow.command_id and fence.in_flight_state == "executing"
        late = await w.execute(cmd(w.device_id, obs))
        assert late.rejection_code is ErrorCode.DISPATCH_GATE_CLOSED
        assert (await running).status is ExecutionStatus.ACKNOWLEDGED
        assert '"execute": 1' in (await w.health()).device.detail  # type: ignore[union-attr]
    finally:
        await w.close()


async def test_driver_timeout_returns_unknown_over_ipc(tmp_path: Path) -> None:
    w = await spawn(tmp_path, hang=["execute"])
    try:
        await w.authorize(LEASE, EPOCH, CTRL)
        obs = await w.observe(req(w.device_id))
        result = await w.execute(cmd(w.device_id, obs, max_duration_ms=300))
        assert result.status is ExecutionStatus.UNKNOWN and "not retried" in result.detail
    finally:
        await w.close()


async def test_stopped_worker_fence_times_out_as_pending(tmp_path: Path) -> None:
    w = await spawn(tmp_path)
    try:
        await w.authorize(LEASE, EPOCH, CTRL)
        os.kill(w.pid, signal.SIGSTOP)
        t0 = time.monotonic()
        with pytest.raises(WorkerTimeout):
            await w.fence(CTRL, timeout_s=0.5)
        assert time.monotonic() - t0 < 1.0
    finally:
        os.kill(w.pid, signal.SIGCONT)
        await w.kill()


async def test_worker_fences_and_exits_when_coordinator_pipe_closes(tmp_path: Path) -> None:
    w = await spawn(tmp_path)
    await w.authorize(LEASE, EPOCH, CTRL)
    w._stdin.close()  # noqa: SLF001 - simulate coordinator death
    code = await asyncio.wait_for(w._proc.wait(), 10)  # noqa: SLF001
    assert code == 0

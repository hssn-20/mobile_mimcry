"""Provider injection (provider_factory / registry hook), provider usage in the report, and the
raw-log secret canary, through the full JourneyRun with the MOCK adapter (never device evidence).

The fake provider below is a labelled test double wrapping RulesProvider: it is NOT an AI test.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from mobilelab.journey import JourneyRun, MockDeviceEnvironment, load_plan
from mobilelab.journey.providers import ProviderBuild, rules_factory
from mobilelab.providers.base import ProviderInfo

CANARY = "CANARY-sk-test-0123456789abcdefghijklmnop"


class LabelledFakeProvider:
    """TEST DOUBLE (local, no model): RulesProvider decisions under another label, with usage."""

    provider_info = ProviderInfo(name="FakeUsageProvider", kind="local", version="test", model="fake-model-0",
                                 deployment="local", supports_images=False)  # fmt: skip

    def __init__(self, build: ProviderBuild, frozen: dict[str, Any] | None = None) -> None:
        self.inner = rules_factory(build)
        self._frozen = frozen if frozen is not None else {"rate_card_id": "test-card", "note": "test double"}
        self.decisions = 0
        self.closed = False

    @property
    def stage(self) -> str:
        return self.inner.stage

    @property
    def outcomes(self) -> Any:
        return self.inner.outcomes

    async def decide(self, *args: Any) -> Any:
        self.decisions += 1
        return await self.inner.decide(*args)

    def frozen_config(self) -> dict[str, Any]:
        return self._frozen

    def usage_snapshot(self) -> dict[str, Any]:
        return {"requests": self.decisions, "input_tokens": 10 * self.decisions, "output_tokens": 2 * self.decisions,
                "estimated_cost_usd": 0.0, "confirmed_cost_usd": 0.000123, "unresolved_cost_usd": 0.0,
                "rate_card_source": "test"}  # fmt: skip

    async def aclose(self) -> None:
        self.closed = True


def _run(tmp_path: Path, **kw: Any) -> JourneyRun:
    return JourneyRun(
        load_plan("default", dwell_mode="median"), MockDeviceEnvironment(),
        db_path=tmp_path / "lab.db", artifacts_root=tmp_path / "artifacts", work_dir=tmp_path / "work", **kw,
    )  # fmt: skip


async def test_injected_provider_is_used_and_its_usage_reaches_the_report(tmp_path: Path) -> None:
    made: list[LabelledFakeProvider] = []

    def factory(build: ProviderBuild) -> LabelledFakeProvider:
        made.append(LabelledFakeProvider(build))
        return made[-1]

    run = _run(tmp_path, provider_factory=factory)
    result = await run.execute()
    (provider,) = made
    assert provider.decisions > 0 and provider.closed
    assert result.status == "COMPLETED" and result.integrity_ok
    report = json.loads((result.report_dir / "report.json").read_text())
    labels = report["labels"]
    assert labels["provider_label"] == "FakeUsageProvider" and labels["provider_kind"] == "local"
    assert labels["provider_id"] == "local" and labels["model_identifier"] == "fake-model-0"
    usage = report["provider_usage"]
    assert usage["usage_reported"] and usage["requests"] == provider.decisions
    assert usage["confirmed_cost_usd"] == pytest.approx(0.000123) and usage["unresolved_cost_usd"] == 0.0
    assert usage["detail"]["rate_card_source"] == "test" and usage["source"].endswith("(provider_usage.json)")
    manifest = json.loads((result.report_dir / "manifest.json").read_text())
    assert manifest["provider_kind"] == "local" and manifest["model_identifier"] == "fake-model-0"
    html = (result.report_dir / "report.html").read_text()
    assert "Decision provider and usage" in html and "$0.000123" in html
    # timing records (CONTRACTS §8) on dispatched actions
    acts = [a["action"] for a in report["actions"] if a["action"]["actual_dispatch_at"]]
    assert acts and all(a["decision_latency_ms"] is not None and a["scheduled_at"] for a in acts)
    waits = [a for a in acts if a["kind"] == "wait"]
    assert waits and all(a["timing_overrun_ms"] is not None and a["sampled_delay_ms"] for a in waits)


async def test_default_rules_provider_report_is_unchanged(tmp_path: Path) -> None:
    result = await _run(tmp_path).execute()
    report = json.loads((result.report_dir / "report.json").read_text())
    assert report["labels"]["provider_label"] == "RulesProvider" and report["labels"]["provider_id"] == "rules"
    assert report["provider_usage"]["usage_reported"] is False and report["provider_usage"]["deployment"] == "local"
    assert any("deterministic RulesProvider" in lim for lim in report["limitations"])


async def test_provider_frozen_config_with_secret_keys_is_refused(tmp_path: Path) -> None:
    def factory(build: ProviderBuild) -> LabelledFakeProvider:
        return LabelledFakeProvider(build, frozen={"nested": {"api_key": CANARY}})

    result = await _run(tmp_path, provider_factory=factory).execute()
    assert result.status == "NOT_CREATED" and "must not carry secrets" in result.reason
    assert CANARY not in result.reason
    blobs = b"".join(p.read_bytes() for p in tmp_path.rglob("*") if p.is_file())
    assert CANARY.encode() not in blobs


async def test_raw_run_directory_and_database_hold_no_fixture_secrets(tmp_path: Path) -> None:
    run = _run(tmp_path)
    result = await run.execute()
    secrets = [s for s in run.secrets if s]
    assert len(secrets) == 4
    raw_files = [p for p in (tmp_path / "work").rglob("*") if p.is_file()]
    assert raw_files and not (tmp_path / "work" / "fixture-state" / "admin_secret").exists()
    everything = [*raw_files, *[p for p in (tmp_path / "artifacts").rglob("*") if p.is_file()],
                  *tmp_path.glob("lab.db*")]  # fmt: skip
    for path in everything:
        data = path.read_bytes()
        for s in secrets:
            assert s.encode() not in data, f"secret found in {path.relative_to(tmp_path)}"
    red = result.journey["raw_log_redaction"]
    assert "fixture-state/admin_secret" in red["files_removed"]

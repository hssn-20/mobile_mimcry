"""Real uvicorn listeners on ephemeral loopback ports with the scripted receiver.

These exercise real sockets and HTTP. They are fixture-service tests, not
device or Simulator evidence.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from collections.abc import AsyncIterator
from pathlib import Path
from uuid import UUID, uuid4

import httpx
import pytest

from mobilelab.fixtures.clients import FixtureAdminClient, FixtureOracleClient
from mobilelab.fixtures.config import ADMIN_SECRET_ENV, FixtureConfig
from mobilelab.fixtures.models import FaultSpec, Receipt
from mobilelab.fixtures.receiver import ReceiverEvent
from mobilelab.fixtures.service import FixtureService, bind_socket

SECRET = "integration-admin-secret-0123456789"


@pytest.fixture
async def service(tmp_path: Path) -> AsyncIterator[FixtureService]:
    data_sock = bind_socket("127.0.0.1", 0)
    admin_sock = bind_socket("127.0.0.1", 0)
    port = data_sock.getsockname()[1]
    config = FixtureConfig(
        bind_host="127.0.0.1",
        data_port=port,
        admin_port=admin_sock.getsockname()[1],
        public_base_url=f"http://127.0.0.1:{port}",
        state_dir=tmp_path,
    )
    svc = FixtureService(config, admin_secret=SECRET, with_receiver=True)
    await svc.start(data_socket=data_sock, admin_socket=admin_sock)
    try:
        yield svc
    finally:
        await svc.stop()


async def _wait_for_status(oracle: FixtureOracleClient, cmid: UUID, run_id: UUID, status: str) -> Receipt:
    receipt: Receipt | None = None
    for _ in range(100):
        receipt = await oracle.get_receipt(cmid, run_id)
        if receipt is not None and receipt.status == status:
            return receipt
        await asyncio.sleep(0.05)
    raise AssertionError(f"receipt never reached {status}: {receipt}")


def _payload(run_id: UUID, cmid: UUID, body: str) -> dict[str, object]:
    return {
        "schema_version": 1,
        "run_id": str(run_id),
        "conversation_id": "fixture-conversation-01",
        "client_message_id": str(cmid),
        "sequence": 1,
        "body": body,
    }


async def test_end_to_end_over_real_listeners(service: FixtureService) -> None:
    data_url = service.config.public_base_url
    assert service.admin_url != data_url
    async with (
        FixtureAdminClient(service.admin_url, SECRET) as admin,
        httpx.AsyncClient(base_url=data_url) as http,
    ):
        assert (await http.get("/fixture/v1/health")).json()["status"] == "ok"
        # The admin API is not served on the data port.
        assert (await http.post(f"/fixture-admin/v1/runs/{uuid4()}/reset")).status_code == 404

        reset = await admin.reset(uuid4())
        assert reset.data_base_url == data_url
        sender = {"Authorization": f"Bearer {reset.sender.token}"}
        async with FixtureOracleClient(data_url, reset.oracle.token) as oracle:
            # 1. Normal send: accepted by the server, then delivered by the independent receiver.
            cmid = uuid4()
            resp = await http.post("/fixture/v1/messages", json=_payload(reset.run_id, cmid, "hello"), headers=sender)
            assert resp.status_code == 201 and resp.json()["status"] == "accepted"
            delivered = await _wait_for_status(oracle, cmid, reset.run_id, "delivered")
            assert delivered.receiver_type == "scripted_receiver"
            assert delivered.receiver_displayed_at is None  # a scripted peer never claims display

            # 2. Response dropped after durable accept: transport failure, retry gives the original.
            await admin.set_faults(
                reset.run_id,
                [FaultSpec.model_validate_json(json.dumps({
                    "fault_id": "drop-1", "mode": "accepted_response_dropped", "layer": "fixture_server",
                    "match": {"route": "post_message", "nth": 1},
                }))],
            )
            cmid2 = uuid4()
            with pytest.raises(httpx.TransportError):
                await http.post("/fixture/v1/messages", json=_payload(reset.run_id, cmid2, "retry me"), headers=sender)
            retry = await http.post(
                "/fixture/v1/messages", json=_payload(reset.run_id, cmid2, "retry me"), headers=sender
            )
            assert retry.status_code == 200 and retry.headers["fixture-duplicate"] == "true"
            await _wait_for_status(oracle, cmid2, reset.run_id, "delivered")

            # 3. Suppressed receiver ack: accepted forever, delivery unknown, suppression recorded.
            await admin.set_faults(
                reset.run_id,
                [FaultSpec.model_validate_json(json.dumps({
                    "fault_id": "suppress-1", "mode": "suppress_receiver_ack", "layer": "receiver",
                    "match": {"route": "acknowledge", "nth": None},
                }))],
            )
            cmid3 = uuid4()
            resp = await http.post("/fixture/v1/messages", json=_payload(reset.run_id, cmid3, "lost?"), headers=sender)
            assert resp.status_code == 201
            receiver = service.supervisor.receivers[reset.run_id]  # type: ignore[union-attr]
            for _ in range(100):
                if any(e.event is ReceiverEvent.ACK_SUPPRESSED for e in receiver.log):
                    break
                await asyncio.sleep(0.05)
            await asyncio.sleep(0.6)  # at least one more receiver poll cycle
            receipt = await oracle.require_receipt(cmid3, reset.run_id)
            assert receipt.status == "accepted" and receipt.receiver_delivered_at is None

        truth = await admin.ground_truth(reset.run_id)
        assert {(t.fault_id, t.reporter) for t in truth} == {
            ("drop-1", "fixture_server"),
            ("suppress-1", "receiver"),
        }
        log_file = service.config.state_dir / "receiver" / f"receiver-{reset.run_id}.jsonl"
        events = [json.loads(line)["event"] for line in log_file.read_text().splitlines()]
        assert "acknowledged" in events and "ack_suppressed" in events


def test_cli_launches_and_reports_ready(tmp_path: Path) -> None:
    env = {**os.environ, ADMIN_SECRET_ENV: SECRET}
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "mobilelab.fixtures.service",
            "--bind-host", "127.0.0.1", "--data-port", "0", "--admin-port", "0",
            "--state-dir", str(tmp_path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )
    try:
        assert proc.stdout is not None
        ready = json.loads(proc.stdout.readline())
        assert ready["event"] == "fixture_ready"
        assert ready["public_url_is_loopback"] is True and ready["loopback_note"]
        assert SECRET not in json.dumps(ready)
        with httpx.Client() as client:
            health = client.get(f"{ready['public_base_url']}/fixture/v1/health")
            assert health.status_code == 200
            reset = client.post(
                f"{ready['admin_url']}/fixture-admin/v1/runs/{uuid4()}/reset",
                headers={"Authorization": f"Bearer {SECRET}"},
            )
            assert reset.status_code == 200
            assert reset.json()["data_base_url"] == ready["public_base_url"]
    finally:
        proc.terminate()
        proc.wait(timeout=10)
    assert proc.returncode == 0

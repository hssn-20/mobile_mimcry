"""Receipt oracle and reconciliation against the real fixture service.

Most tests use FixtureTestBed (the real data/admin apps and store over in-process ASGI); the outage
test uses real uvicorn listeners on loopback and then stops them. Messages are posted directly as
the sender identity (standing in for the Lab Messenger transport). This is fixture-service evidence
only, not device or Simulator evidence.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from pathlib import Path
from uuid import UUID, uuid4

import httpx
import pytest

from mobilelab.domain.actions import SendMessage
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus, SideEffectClass, Verdict
from mobilelab.domain.scenarios import OracleDefinition
from mobilelab.fixtures.clients import FixtureOracleClient
from mobilelab.fixtures.faults import ResponseDroppedError
from mobilelab.fixtures.models import FaultSpec, MessagesPage
from mobilelab.fixtures.receiver import AdminReceiverFaultSource, ScriptedReceiver
from mobilelab.fixtures.config import FixtureConfig
from mobilelab.fixtures.service import FixtureService, bind_socket
from mobilelab.fixtures.testing import FixtureTestBed
from mobilelab.oracles import FixtureMessageReceiptOracle, PollSettings, reconcile_unknown_send

DEFN = OracleDefinition(kind="fixture_message_receipt", required_status="delivered", timeout_seconds=4)


class FakeTime:
    """Deterministic monotonic clock; each sleep optionally lets the scripted receiver poll."""

    def __init__(self, receiver: ScriptedReceiver | None = None) -> None:
        self.t = 0.0
        self.receiver = receiver

    def monotonic(self) -> float:
        return self.t

    async def sleep(self, s: float) -> None:
        self.t += s
        if self.receiver is not None:
            await self.receiver.poll_once()

    def settings(self) -> PollSettings:
        return PollSettings(poll_interval_s=1.0, monotonic=self.monotonic, sleep=self.sleep)


def fault(fault_id: str, mode: str, layer: str, route: str, nth: int | None = None) -> FaultSpec:
    return FaultSpec.model_validate_json(
        json.dumps({"fault_id": fault_id, "mode": mode, "layer": layer, "match": {"route": route, "nth": nth}})
    )


def send_action(run_id: UUID, cmid: UUID, status: ActionStatus) -> ActionRecord:
    payload = SendMessage(kind="send_message", element_ref="composer.send", contact_id="fixture-contact-01", client_message_id=cmid)
    return ActionRecord(
        action_id=uuid4(), run_id=run_id, device_id=uuid4(), kind=ActionKind.SEND_MESSAGE, semantic_key="messenger.send",
        side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT, status=status, decision_observation_id=uuid4(),
        original_candidate_id=uuid4(), dispatch_observation_id=uuid4(), dispatch_candidate_id=uuid4(),
        payload=payload, correlation_id=cmid,
    )  # fmt: skip


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def test_delivered_by_scripted_receiver_passes(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    receiver = bed.receiver(reset)
    cmid = uuid4()
    assert (await bed.send(reset, client_message_id=cmid)).status_code == 201
    ft = FakeTime(receiver)  # receiver acknowledges during the oracle's first wait
    oracle = FixtureMessageReceiptOracle(bed.oracle(reset.oracle.token), settings=ft.settings())
    res = await oracle.evaluate(reset.run_id, cmid, DEFN, scenario_id="browse_then_reply")
    assert (res.verdict, res.reason_code) == (Verdict.PASS, "RECEIPT_DELIVERED")
    assert res.observed["polls"] == 2
    receipt = res.observed["receipt"]
    assert isinstance(receipt, dict) and receipt["receiver_type"] == "scripted_receiver"
    assert receipt["receiver_delivered_at"] is not None
    assert res.observed["ack_timings"]  # server/receiver clock metadata attached


async def test_suppressed_ack_is_inconclusive_and_reconciles_without_resend(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(reset.run_id, [fault("suppress-1", "suppress_receiver_ack", "receiver", "acknowledge")])
    receiver = bed.receiver(reset, AdminReceiverFaultSource(bed.admin, reset.run_id))
    cmid = uuid4()
    assert (await bed.send(reset, client_message_id=cmid)).status_code == 201
    client = bed.oracle(reset.oracle.token)

    res = await FixtureMessageReceiptOracle(client, settings=FakeTime(receiver).settings()).evaluate(
        reset.run_id, cmid, DEFN, scenario_id="browse_then_reply", action_status=ActionStatus.ACKNOWLEDGED
    )
    assert (res.verdict, res.reason_code) == (Verdict.INCONCLUSIVE, "DELIVERY_UNCONFIRMED")
    assert f"fixture-receipt:{cmid}" in res.evidence_ids
    receipt = res.observed["receipt"]
    assert isinstance(receipt, dict) and receipt["status"] == "accepted"

    before = await bed.admin.request_log(reset.run_id)
    rec = await reconcile_unknown_send(
        client, send_action(reset.run_id, cmid, ActionStatus.UNKNOWN), deadline_s=2, settings=FakeTime().settings()
    )
    assert (rec.resolution, rec.reason_code) == ("VERIFIED", "RECEIPT_ACCEPTED")
    after = await bed.admin.request_log(reset.run_id)
    new_posts = [e for e in after[len(before) :] if e.method == "POST"]
    assert new_posts == []  # reconciliation only reads receipts; it never resends


async def test_unknown_send_with_no_message_stays_unresolved(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    client = bed.oracle(reset.oracle.token)
    cmid = uuid4()
    rec = await reconcile_unknown_send(
        client, send_action(reset.run_id, cmid, ActionStatus.DISPATCHED), deadline_s=2, settings=FakeTime().settings()
    )
    assert (rec.resolution, rec.reason_code) == ("UNRESOLVED", "NO_RECEIPT")
    assert rec.transition_path == [ActionStatus.UNKNOWN, ActionStatus.UNRESOLVED]
    res = await FixtureMessageReceiptOracle(client, settings=FakeTime().settings()).evaluate(
        reset.run_id, cmid, DEFN, scenario_id="browse_then_reply", action_status=ActionStatus.UNKNOWN
    )
    assert (res.verdict, res.reason_code) == (Verdict.INCONCLUSIVE, "NO_RECEIPT")


async def test_duplicate_transport_retry_yields_one_message_and_pass(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("drop-1", "accepted_response_dropped", "fixture_server", "post_message", nth=1)]
    )
    cmid = uuid4()
    with pytest.raises(ResponseDroppedError):
        await bed.send(reset, client_message_id=cmid)
    client = bed.oracle(reset.oracle.token)
    # Sender saw no response: the action is UNKNOWN; reconciliation finds the durable message.
    rec = await reconcile_unknown_send(
        client, send_action(reset.run_id, cmid, ActionStatus.UNKNOWN), deadline_s=1, settings=FakeTime().settings()
    )
    assert rec.resolution == "VERIFIED"
    # The app's own transport retry (same client_message_id) returns the original receipt.
    retry = await bed.send(reset, client_message_id=cmid)
    assert retry.status_code == 200 and retry.headers["Fixture-Duplicate"] == "true"
    await bed.receiver(reset).poll_once()
    res = await FixtureMessageReceiptOracle(client, settings=FakeTime().settings()).evaluate(
        reset.run_id, cmid, DEFN, scenario_id="browse_then_reply"
    )
    assert res.verdict is Verdict.PASS
    page = MessagesPage.model_validate_json(
        (
            await bed.data.get(
                "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(reset.sender.token)
            )
        ).content
    )
    assert [m.client_message_id for m in page.messages].count(cmid) == 1


async def test_fixture_outage_is_environment_failure(tmp_path: Path) -> None:
    data_sock = bind_socket("127.0.0.1", 0)
    admin_sock = bind_socket("127.0.0.1", 0)
    port = data_sock.getsockname()[1]
    config = FixtureConfig(
        bind_host="127.0.0.1", data_port=port, admin_port=admin_sock.getsockname()[1],
        public_base_url=f"http://127.0.0.1:{port}", state_dir=tmp_path,
    )  # fmt: skip
    secret = "oracle-integration-secret-0123456789"
    svc = FixtureService(config, admin_secret=secret, with_receiver=False)
    await svc.start(data_socket=data_sock, admin_socket=admin_sock)
    from mobilelab.fixtures.clients import FixtureAdminClient

    async with FixtureAdminClient(svc.admin_url, secret) as admin:
        reset = await admin.reset(uuid4())
    async with httpx.AsyncClient(base_url=config.public_base_url) as http:
        cmid = uuid4()
        body = {"schema_version": 1, "run_id": str(reset.run_id), "conversation_id": "fixture-conversation-01",
                "client_message_id": str(cmid), "sequence": 1, "body": "hello"}  # fmt: skip
        resp = await http.post("/fixture/v1/messages", json=body, headers={"Authorization": f"Bearer {reset.sender.token}"})
        assert resp.status_code == 201
    await svc.stop()  # the fixture service is now unreachable

    async with FixtureOracleClient(config.public_base_url, reset.oracle.token, timeout_s=2) as client:
        res = await FixtureMessageReceiptOracle(client, settings=FakeTime().settings()).evaluate(
            reset.run_id, cmid, DEFN, scenario_id="browse_then_reply"
        )
        assert (res.verdict, res.reason_code) == (Verdict.ENVIRONMENT_FAILURE, "FIXTURE_UNAVAILABLE")
        rec = await reconcile_unknown_send(
            client, send_action(reset.run_id, cmid, ActionStatus.UNKNOWN), deadline_s=1, settings=FakeTime().settings()
        )
        assert (rec.resolution, rec.reason_code) == ("UNRESOLVED", "FIXTURE_UNAVAILABLE")

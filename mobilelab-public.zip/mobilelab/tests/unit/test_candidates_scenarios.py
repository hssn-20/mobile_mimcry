"""Scenario configs (configs/scenarios/*.yaml) validate against ScenarioSpec and build a ScenarioScope."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from mobilelab.candidates import ScenarioScope, TextPolicy
from mobilelab.domain.enums import EvidenceCategory
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import get_persona
from mobilelab.providers import BrowseThenReplyScript

ROOT = Path(__file__).resolve().parents[2]
SCENARIOS = ROOT / "configs" / "scenarios"


def load(name: str) -> ScenarioSpec:
    return ScenarioSpec.from_yaml((SCENARIOS / f"{name}.yaml").read_text())


@pytest.mark.parametrize(
    "name",
    ["browse_then_reply", "browse_then_reply_suppressed_ack", "browse_then_reply_changed", "browse_adversarial"],
)
def test_scenario_validates(name: str) -> None:
    spec = load(name)
    assert spec.scenario_id == name
    assert spec.platform_evidence is EvidenceCategory.FIXTURE
    assert spec.provider == "RulesProvider"
    get_persona(spec.persona_id, spec.persona_version)  # referenced persona revision exists
    scope = ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781/")
    assert scope.allowed_url_origins == ("http://127.0.0.1:8781",)
    assert scope.allowed_contact_ids == ("fixture-contact-01",)
    script = BrowseThenReplyScript.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")
    assert script.reply_text in scope.text_policy.allowed_texts
    assert [o.kind for o in spec.oracles] == ["fixture_message_receipt"]
    assert spec.oracles[0].required_status == "delivered"


def test_plain_scenario_has_no_disturbance() -> None:
    assert load("browse_then_reply").disturbances == []


def test_suppressed_ack_variant_declares_controlled_fault_and_inconclusive() -> None:
    spec = load("browse_then_reply_suppressed_ack")
    base = load("browse_then_reply")
    (fault,) = spec.disturbances
    assert fault.kind == "suppress_receiver_ack" and fault.params["controlled"] is True
    params = spec.oracles[0].params
    assert params["expected_verdict"] == "INCONCLUSIVE" and params["resend_policy"] == "never"
    assert spec.fixture_setup == base.fixture_setup  # same journey


def test_scope_rejects_bad_config() -> None:
    with pytest.raises(ValidationError):
        ScenarioScope(scenario_id="s", scenario_version=1, allowed_url_origins=("http://h:1/path",))
    with pytest.raises(ValidationError):
        ScenarioScope(scenario_id="s", scenario_version=1, allowed_conversation_ids=("c",),
                      conversations=({"conversation_id": "c", "title": "T", "contact_id": "x"},))
    with pytest.raises(ValidationError):
        TextPolicy(allow_generated_text=False)


def test_layout_variants_keep_ground_truth() -> None:
    """Every scenario targets the same allowed conversation/contact; only presentation differs."""
    from mobilelab.fixtures.layouts import layout_for_setup
    from mobilelab.fixtures.models import FixtureLayout

    base = load("browse_then_reply")
    expected = {"browse_then_reply": FixtureLayout.DEFAULT, "browse_then_reply_suppressed_ack": FixtureLayout.DEFAULT,
                "browse_then_reply_changed": FixtureLayout.CHANGED, "browse_adversarial": FixtureLayout.CHANGED}
    for name, layout in expected.items():
        spec = load(name)
        assert layout_for_setup(spec.fixture_setup) is layout
        scope = ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")
        assert scope.allowed_conversation_ids == ("fixture-conversation-01",)
        assert scope.allowed_contact_ids == ("fixture-contact-01",)
        assert not any("decoy" in c.conversation_id for c in scope.conversations)
        assert set(scope.allowed_app_ids) == {"com.apple.mobilesafari", "org.mobilelab.fixtures.LabMessenger"}
        for key in ("conversation_id", "contact_id", "conversation_title", "reply_text"):
            assert spec.fixture_setup[key] == base.fixture_setup[key]


def test_changed_scenario_follows_relabelled_link() -> None:
    spec = load("browse_then_reply_changed")
    scope = ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")
    assert spec.fixture_setup["follow_link_label"] in scope.allowed_link_labels
    assert "Read next: Counting Tide Pools" not in scope.allowed_link_labels
    assert spec.fixture_setup["start_article_title"] == "Pocket Gardens: How One Street Turned Green"


def test_adversarial_scenario_allows_no_link_labels() -> None:
    spec = load("browse_adversarial")
    scope = ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")
    assert scope.allowed_link_labels == ()
    assert spec.fixture_setup["start_article"] == "article-adversarial"
    assert "follow_link_label" not in spec.fixture_setup


def test_link_label_pages_validation() -> None:
    for bad in ("fixture/v1/x", "//evil/x", "/a?b=1", "/a#b"):
        with pytest.raises(ValidationError):
            ScenarioScope(scenario_id="s", scenario_version=1, link_label_pages=(bad,))

"""Persistent spend ledger: atomic reservation, caps, reconciliation (CONTRACTS §11). No model calls."""

from __future__ import annotations

import threading
from decimal import Decimal
from pathlib import Path

import pytest

from mobilelab.budget import (
    HARD_GLOBAL_CAP_USD,
    BudgetExceeded,
    BudgetLedger,
    LedgerError,
    RateCard,
    TokenUsage,
    budget_summary,
)
from mobilelab.providers import load_luna_config


@pytest.fixture
def card() -> RateCard:
    return load_luna_config().rate_card


def test_rate_card_math_rounds_up(card: RateCard) -> None:
    # 8000 in @ 0.125 (cache-write, worst) + 1500 out @ 0.50 per 1M = 0.001 + 0.00075
    assert card.reservation_micro_usd(8000, 1500) == 1750
    exact = card.usage_micro_usd(TokenUsage(input_tokens=1000, output_tokens=100, cached_input_tokens=200,
                                            cache_write_tokens=0))  # fmt: skip
    assert exact == 132  # 800*0.10 + 200*0.01 + 100*0.50 = 80 + 2 + 50 micro
    conservative = card.usage_micro_usd(TokenUsage(input_tokens=1000, output_tokens=100, cached_input_tokens=200))
    assert conservative == 152  # unknown cache writes -> uncached input at 0.125
    assert card.input_per_1m == Decimal("0.10") and card.output_per_1m == Decimal("0.50")


def test_global_cap_can_be_lowered_not_raised(tmp_path: Path) -> None:
    led = BudgetLedger.open(tmp_path / "l.db", global_cap_usd=50.0, run_cap_usd=100.0)
    assert led.global_cap_micro == int(HARD_GLOBAL_CAP_USD * 1_000_000) and led.run_cap_micro == led.global_cap_micro


def test_reserve_confirm_unresolved_release_summary(tmp_path: Path, card: RateCard) -> None:
    led = BudgetLedger.open(tmp_path / "l.db", run_cap_usd=0.25)
    a = led.reserve(run_id="r1", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    b = led.reserve(run_id="r1", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    c = led.reserve(run_id="r1", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    d = led.reserve(run_id="r2", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    led.confirm(a, TokenUsage(input_tokens=1000, output_tokens=100, cache_write_tokens=0), card, request_id="req_1")
    led.mark_unresolved(b, error_class="ProviderTimeout")
    led.release(c, reason="rejected:401")
    s = led.summary("r1")
    assert (s.confirmed_usd, s.unresolved_usd, s.estimated_usd) == (0.00015, 0.00175, 0.0)
    assert s.requests == {"confirmed": 1, "unresolved": 1, "released": 1}
    g = led.summary()
    assert g.estimated_usd == 0.00175 and g.committed_usd == pytest.approx(0.00015 + 0.00175 + 0.00175)
    assert g.remaining_usd == pytest.approx(5.0 - g.committed_usd)
    with pytest.raises(LedgerError):
        led.release(a, reason="again")
    led.confirm(b, TokenUsage(input_tokens=10, output_tokens=1, cache_write_tokens=0), card)  # late answer reconciles
    assert led.summary("r1").unresolved_usd == 0
    led.mark_unresolved(d, error_class="ProviderCancelled")
    assert budget_summary(tmp_path / "l.db").unresolved_usd == 0.00175


def test_run_cap_and_global_cap_refuse(tmp_path: Path, card: RateCard) -> None:
    led = BudgetLedger.open(tmp_path / "l.db", global_cap_usd=0.004, run_cap_usd=0.002)
    led.reserve(run_id="r1", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    with pytest.raises(BudgetExceeded, match="per-run"):
        led.reserve(run_id="r1", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    led.reserve(run_id="r2", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    with pytest.raises(BudgetExceeded, match="global"):
        led.reserve(run_id="r3", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    with pytest.raises(BudgetExceeded):
        led.reserve(run_id="r4", provider_id="luna", rate_card=card, max_input_tokens=300_000, max_output_tokens=1)


def test_cap_persists_across_ledger_instances(tmp_path: Path, card: RateCard) -> None:
    db = tmp_path / "l.db"
    first = BudgetLedger.open(db, global_cap_usd=0.002)
    first.reserve(run_id=None, provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
    first.engine.dispose()
    second = BudgetLedger.open(db, global_cap_usd=0.002)  # a new process would see the same rows
    with pytest.raises(BudgetExceeded):
        second.reserve(run_id=None, provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)


def test_concurrent_reservations_never_exceed_cap(tmp_path: Path, card: RateCard) -> None:
    db = tmp_path / "l.db"
    BudgetLedger.open(db).engine.dispose()
    cap = 0.00175 * 5  # exactly five reservations fit
    ok: list[int] = []
    refused: list[int] = []
    lock = threading.Lock()

    def worker(n: int) -> None:
        led = BudgetLedger.open(db, migrate=False, global_cap_usd=cap, run_cap_usd=cap)
        try:
            led.reserve(run_id="r", provider_id="luna", rate_card=card, max_input_tokens=8000, max_output_tokens=1500)
            with lock:
                ok.append(n)
        except BudgetExceeded:
            with lock:
                refused.append(n)
        finally:
            led.engine.dispose()

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(16)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(ok) == 5 and len(refused) == 11

"""Fault injection, ground truth and the scripted receiver (in-process ASGI)."""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest
from pydantic import ValidationError

from mobilelab.fixtures.faults import ResponseDroppedError
from mobilelab.fixtures.models import ActivationReport, FaultSpec, Receipt, Reporter
from mobilelab.fixtures.receiver import AdminReceiverFaultSource, ReceiverEvent, StaticReceiverFaultSource
from mobilelab.fixtures.testing import FixtureTestBed


def fault(fault_id: str, mode: str, layer: str, route: str, nth: int | None = None, **extra: Any) -> FaultSpec:
    return FaultSpec.model_validate_json(
        json.dumps(
            {"fault_id": fault_id, "mode": mode, "layer": layer, "match": {"route": route, "nth": nth}, **extra}
        )
    )


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def test_accepted_response_dropped_then_retry_yields_single_message(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("drop-1", "accepted_response_dropped", "fixture_server", "post_message", nth=1)]
    )
    cmid = uuid4()
    with pytest.raises(ResponseDroppedError):
        await bed.send(reset, client_message_id=cmid)

    # The message was durably stored before the response was dropped.
    oracle = bed.oracle(reset.oracle.token)
    stored = await oracle.require_receipt(cmid, reset.run_id)
    assert stored.status == "accepted"

    retry = await bed.send(reset, client_message_id=cmid)
    assert retry.status_code == 200 and retry.headers["Fixture-Duplicate"] == "true"
    assert Receipt.model_validate_json(retry.content) == stored

    page = (
        await bed.data.get(
            "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(reset.sender.token)
        )
    ).json()
    assert [m["client_message_id"] for m in page["messages"]].count(str(cmid)) == 1

    truth = await bed.admin.ground_truth(reset.run_id)
    assert [(r.fault_id, r.mode, r.reporter) for r in truth] == [
        ("drop-1", "accepted_response_dropped", "fixture_server")
    ]
    assert truth[0].detail["client_message_id"] == str(cmid)
    log = await bed.admin.request_log(reset.run_id)
    assert [e.outcome for e in log if e.path == "/fixture/v1/messages"] == ["dropped", "completed"]


async def test_suppress_receiver_ack_keeps_status_accepted(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("suppress-1", "suppress_receiver_ack", "receiver", "acknowledge", nth=1)]
    )
    receiver = bed.receiver(reset, AdminReceiverFaultSource(bed.admin, reset.run_id))
    first = Receipt.model_validate_json((await bed.send(reset, "first")).content)
    second = Receipt.model_validate_json((await bed.send(reset, "second", sequence=2)).content)
    await receiver.poll_once()

    oracle = bed.oracle(reset.oracle.token)
    r1 = await oracle.require_receipt(first.client_message_id, reset.run_id)
    r2 = await oracle.require_receipt(second.client_message_id, reset.run_id)
    assert r1.status == "accepted" and r1.receiver_delivered_at is None
    assert r2.status == "delivered" and r2.receiver_delivered_at is not None

    events = [(e.event, e.client_message_id) for e in receiver.log]
    assert (ReceiverEvent.ACK_SUPPRESSED, first.client_message_id) in events
    assert (ReceiverEvent.ACKNOWLEDGED, second.client_message_id) in events
    # The receiver's evidence id is linked from the server receipt.
    fetched_ids = {e.evidence_id for e in receiver.log if e.event is ReceiverEvent.FETCHED}
    assert fetched_ids & set(r2.correlation_evidence_ids)

    truth = await bed.admin.ground_truth(reset.run_id)
    assert [(t.fault_id, t.reporter, t.detail["client_message_id"]) for t in truth] == [
        ("suppress-1", "receiver", str(first.client_message_id))
    ]
    # A later poll does not retroactively acknowledge the suppressed message.
    await receiver.poll_once()
    assert (await oracle.require_receipt(first.client_message_id, reset.run_id)).status == "accepted"


async def test_receiver_outage_leaves_delivery_unknown(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    receiver = bed.receiver(reset)
    receiver.set_outage(True)
    sent = Receipt.model_validate_json((await bed.send(reset)).content)
    await receiver.poll_once()
    await receiver.poll_once()
    receipt = await bed.oracle(reset.oracle.token).require_receipt(sent.client_message_id, reset.run_id)
    assert receipt.status == "accepted"
    assert receipt.receiver_delivered_at is None and receipt.receiver_type is None
    assert [e.event for e in receiver.log] == [ReceiverEvent.OUTAGE_STARTED]

    # Recovery: delivery is then established by a real receiver acknowledgement.
    receiver.set_outage(False)
    await receiver.poll_once()
    receipt = await bed.oracle(reset.oracle.token).require_receipt(sent.client_message_id, reset.run_id)
    assert receipt.status == "delivered"


async def test_receiver_layer_recipient_unavailable_is_reported(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    source = StaticReceiverFaultSource([fault("down-1", "recipient_unavailable", "receiver", "any")])
    receiver = bed.receiver(reset, source)
    sent = Receipt.model_validate_json((await bed.send(reset)).content)
    await receiver.poll_once()
    await receiver.poll_once()
    receipt = await bed.oracle(reset.oracle.token).require_receipt(sent.client_message_id, reset.run_id)
    assert receipt.status == "accepted"
    assert [r.fault_id for r in source.reports] == ["down-1"]


async def test_server_layer_recipient_unavailable_blocks_inbox(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("srv-down", "recipient_unavailable", "fixture_server", "receiver_inbox")]
    )
    receiver = bed.receiver(reset)
    sent = Receipt.model_validate_json((await bed.send(reset)).content)
    entries = await receiver.poll_once()
    assert [e.event for e in entries] == [ReceiverEvent.POLL_FAILED]
    receipt = await bed.oracle(reset.oracle.token).require_receipt(sent.client_message_id, reset.run_id)
    assert receipt.status == "accepted"
    assert {t.fault_id for t in await bed.admin.ground_truth(reset.run_id)} == {"srv-down"}


async def test_malformed_response(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("bad-1", "malformed_response", "fixture_server", "list_messages", nth=1)]
    )
    url = "/fixture/v1/conversations/fixture-conversation-01/messages"
    bad = await bed.data.get(url, headers=bed.auth(reset.sender.token))
    assert bad.status_code == 200
    with pytest.raises(ValueError):
        bad.json()
    good = await bed.data.get(url, headers=bed.auth(reset.sender.token))
    assert good.json()["schema_version"] == 1
    truth = await bed.admin.ground_truth(reset.run_id)
    assert [(t.fault_id, t.mode, t.route) for t in truth] == [("bad-1", "malformed_response", "list_messages")]


async def test_malformed_post_still_stores_message(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(reset.run_id, [fault("bad-2", "malformed_response", "fixture_server", "post_message")])
    cmid = uuid4()
    resp = await bed.send(reset, client_message_id=cmid)
    assert resp.status_code == 201
    with pytest.raises(ValidationError):
        Receipt.model_validate_json(resp.content)
    assert await bed.oracle(reset.oracle.token).get_receipt(cmid, reset.run_id) is not None


async def test_delayed_response(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(
        reset.run_id, [fault("slow-1", "delayed_response", "fixture_server", "post_message", delay_ms=250)]
    )
    started = time.monotonic()
    resp = await bed.send(reset)
    elapsed = time.monotonic() - started
    assert resp.status_code == 201
    assert elapsed >= 0.25
    truth = await bed.admin.ground_truth(reset.run_id)
    assert truth[0].mode == "delayed_response" and truth[0].detail["delay_ms"] == 250


async def test_fault_window_and_nth(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    future = (bed.clock.now.replace(microsecond=0)).isoformat()
    spec = fault(
        "later", "malformed_response", "fixture_server", "list_conversations", nth=2, active_from=future
    )
    bed.clock.advance(-10)  # before the window
    await bed.admin.set_faults(reset.run_id, [spec])
    url = "/fixture/v1/conversations"
    h = bed.auth(reset.sender.token)
    assert (await bed.data.get(url, headers=h)).json()["schema_version"] == 1  # outside window: not counted
    bed.clock.advance(20)
    assert (await bed.data.get(url, headers=h)).json()["schema_version"] == 1  # 1st in window
    bad = await bed.data.get(url, headers=h)  # 2nd in window -> fires
    with pytest.raises(ValueError):
        bad.json()
    assert (await bed.data.get(url, headers=h)).json()["schema_version"] == 1
    assert len(await bed.admin.ground_truth(reset.run_id)) == 1


async def test_controller_reports_client_crash_activation(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    await bed.admin.set_faults(reset.run_id, [fault("crash-1", "client_crash", "client", "any")])
    record = await bed.admin.report_activation(
        reset.run_id,
        ActivationReport(
            schema_version=1,
            fault_id="crash-1",
            reporter=Reporter.CONTROLLER,
            activated_at=bed.clock.now,
            detail={"method": "terminate_app"},
        ),
    )
    assert record.layer == "client" and record.reporter == "controller"


def test_fault_spec_validation() -> None:
    with pytest.raises(ValidationError):
        fault("x", "suppress_receiver_ack", "fixture_server", "acknowledge")
    with pytest.raises(ValidationError):
        fault("x", "delayed_response", "fixture_server", "post_message")  # missing delay_ms
    with pytest.raises(ValidationError):
        fault("x", "client_crash", "client", "any", unexpected=True)


@pytest.mark.parametrize("route", ["post_message", "list_messages", "list_conversations", "article"])
@pytest.mark.parametrize("mode", ["suppress_receiver_ack", "recipient_unavailable"])
async def test_misrouted_receiver_fault_is_rejected(bed: FixtureTestBed, mode: str, route: str) -> None:
    reset = await bed.reset()
    spec = {"fault_id": "rx-1", "mode": mode, "layer": "receiver", "match": {"route": route, "nth": 1}}
    with pytest.raises(ValidationError):
        FaultSpec.model_validate_json(json.dumps(spec))
    resp = await bed.admin_http.post(
        f"/fixture-admin/v1/runs/{reset.run_id}/faults", json={"schema_version": 1, "faults": [spec]}
    )
    assert resp.status_code == 422
    assert (await bed.admin.get_faults(reset.run_id)).faults == []


@pytest.mark.parametrize("route", ["acknowledge", "receiver_inbox", "any"])
def test_receiver_fault_routes_accepted(route: str) -> None:
    assert fault("rx-1", "suppress_receiver_ack", "receiver", route, nth=1).match.route == route

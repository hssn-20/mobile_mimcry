"""ReplayProvider re-selects recorded semantic choices against current candidates (SYNTHETIC mock trees)."""

from __future__ import annotations

from pathlib import Path
from uuid import UUID

import pytest

from mobilelab.candidates import ScenarioScope, generate_candidates
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.enums import ActionKind, TypingMode
from mobilelab.domain.proposals import ProposalParameters
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import get_persona
from mobilelab.providers import (
    DecisionProvider,
    RecordedDecision,
    ReplayDivergence,
    ReplayExhausted,
    ReplayProvider,
)

ROOT = Path(__file__).resolve().parents[2]
REPLY = "I have finished reading the article."


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")


def ctx() -> DecisionContext:
    return DecisionContext(run_id=UUID(int=1), persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
                           scenario_version=1, scenario_stage="replay", goal="g", control_epoch=3)


BUDGET = DecisionBudget(timeout_ms=1000, max_input_tokens=1, max_output_tokens=1, max_cost_usd=0)


def test_replay_info() -> None:
    p = ReplayProvider([])
    assert isinstance(p, DecisionProvider) and p.provider_info.kind == "replay"


async def test_replay_reselects_by_semantic_key(scope: ScenarioScope) -> None:
    records = [
        RecordedDecision(semantic_key="messenger.composer:fixture-conversation-01", kind=ActionKind.TYPE_TEXT,
                         parameters=ProposalParameters(text=REPLY, typing_mode=TypingMode.FIELD_SET),
                         reason_code="TYPE_REPLY"),
        RecordedDecision(semantic_key="messenger.send:fixture-conversation-01", kind=ActionKind.SEND_MESSAGE,
                         reason_code="REPLY_TO_TEST_CONTACT"),
    ]
    provider = ReplayProvider(records)
    for i, rec in enumerate(records):
        obs = st.messenger_conversation(ref_prefix=f"r{i}")
        cands = generate_candidates(obs, scope)
        p = await provider.decide(ctx(), obs, cands, BUDGET)
        chosen = next(c for c in cands if c.candidate_id == p.candidate_id)
        assert chosen.semantic_key == rec.semantic_key and p.control_epoch == 3
    assert provider.remaining == 0
    obs = st.messenger_conversation()
    with pytest.raises(ReplayExhausted):
        await provider.decide(ctx(), obs, generate_candidates(obs, scope), BUDGET)


async def test_replay_round_trip_from_proposal(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    scroll = next(c for c in cands if c.semantic_key == "safari.scroll:down")
    original = await ReplayProvider([RecordedDecision(semantic_key=scroll.semantic_key, kind=scroll.kind,
                                                      reason_code="SCROLL_READ")]).decide(ctx(), obs, cands, BUDGET)
    rec = RecordedDecision.from_proposal(original, scroll)
    fresh = st.safari_article(ref_prefix="z")
    fresh_cands = generate_candidates(fresh, scope)
    p = await ReplayProvider([rec]).decide(ctx(), fresh, fresh_cands, BUDGET)
    assert p.candidate_id in {c.candidate_id for c in fresh_cands} and p.candidate_id != original.candidate_id


async def test_replay_diverges_when_choice_absent_or_params_not_permitted(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    missing = ReplayProvider([RecordedDecision(semantic_key="messenger.send:fixture-conversation-01",
                                               kind=ActionKind.SEND_MESSAGE, reason_code="X")])
    with pytest.raises(ReplayDivergence):
        await missing.decide(ctx(), obs, cands, BUDGET)
    assert missing.position == 0
    foreign = ReplayProvider([RecordedDecision(semantic_key="url.open:http://127.0.0.1:8781",
                                               kind=ActionKind.NAVIGATE_URL,
                                               parameters=ProposalParameters(url="https://untrusted.example.invalid/"),
                                               reason_code="X")])
    with pytest.raises(ReplayDivergence):
        await foreign.decide(ctx(), obs, cands, BUDGET)
    wrong_kind = ReplayProvider([RecordedDecision(semantic_key="wait:dwell", kind=ActionKind.SCROLL, reason_code="X")])
    with pytest.raises(ReplayDivergence):
        await wrong_kind.decide(ctx(), obs, cands, BUDGET)
    text = ReplayProvider([RecordedDecision(semantic_key="messenger.composer:fixture-conversation-01",
                                            kind=ActionKind.TYPE_TEXT,
                                            parameters=ProposalParameters(text="call +44 7700 900123",
                                                                          typing_mode=TypingMode.FIELD_SET),
                                            reason_code="X")])
    conv = st.messenger_conversation()
    with pytest.raises(ReplayDivergence):
        await text.decide(ctx(), conv, generate_candidates(conv, scope), BUDGET)

"""Generated JSON Schema / TypeScript stay in sync with the Pydantic models."""

from __future__ import annotations

import json
from pathlib import Path

from mobilelab import schema_export
from mobilelab.schema_export import REPO_ROOT, build_typescript, stale_files, ts_type, write_all


def test_committed_generated_files_are_current() -> None:
    assert stale_files(REPO_ROOT) == [], "run: uv run python -m mobilelab.schema_export"


def test_write_all_into_fresh_root(tmp_path: Path) -> None:
    written = write_all(tmp_path)
    assert Path("apps/dashboard/src/types/generated.ts") in written
    assert stale_files(tmp_path) == []
    schema = json.loads((tmp_path / "schemas" / "ProposedAction.schema.json").read_text())
    assert schema["additionalProperties"] is False
    payload = json.loads((tmp_path / "schemas" / "ActionPayload.schema.json").read_text())
    assert payload["discriminator"]["propertyName"] == "kind"
    assert len(payload["oneOf"]) == 9
    assert schema_export.main(["--check", "--root", str(tmp_path)]) == 0
    (tmp_path / "schemas" / "Orphan.schema.json").write_text("{}")
    assert schema_export.main(["--check", "--root", str(tmp_path)]) == 1


def test_typescript_contains_canonical_types() -> None:
    ts = build_typescript()
    assert 'export type RunStatus = "CREATED" | "PREFLIGHT" | "READY" | "RUNNING"' in ts
    assert "export type ActionPayload = Activate | TypeText | Scroll | OpenApp" in ts
    assert "export interface SendMessage {" in ts and "  client_message_id: string;" in ts
    assert "  payload: ActionPayload;" in ts  # DispatchCommand uses the named union
    assert "schema_version: 1;" in ts  # serialization mode: defaulted fields always present


def test_ts_type_mapping() -> None:
    assert ts_type({"type": "array", "items": {"anyOf": [{"type": "string"}, {"type": "null"}]}}) == "(string | null)[]"
    assert ts_type({"type": "object", "additionalProperties": {"type": "integer"}}) == "Record<string, number>"
    assert ts_type({"const": "x"}) == '"x"'
    assert ts_type({}) == "unknown"
    assert ts_type({"type": "object", "properties": {"a-b": {"type": "boolean"}}, "required": ["a-b"]}) == '{ "a-b": boolean; }'

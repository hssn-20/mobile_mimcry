"""Admin listener separation, reset scope and device-reachable URL configuration."""

from __future__ import annotations

import stat
from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import pytest
from pydantic import ValidationError

from mobilelab.fixtures.config import ADMIN_SECRET_ENV, FixtureConfig, load_config, resolve_admin_secret
from mobilelab.fixtures.models import Receipt
from mobilelab.fixtures.testing import FixtureTestBed

REPO = Path(__file__).resolve().parents[2]


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def test_admin_routes_absent_from_data_app(bed: FixtureTestBed) -> None:
    run_id = uuid4()
    for method, path in [
        ("POST", f"/fixture-admin/v1/runs/{run_id}/reset"),
        ("POST", f"/fixture-admin/v1/runs/{run_id}/faults"),
        ("GET", f"/fixture-admin/v1/runs/{run_id}/ground-truth"),
        ("GET", f"/fixture-admin/v1/runs/{run_id}/request-log"),
    ]:
        resp = await bed.data.request(method, path, headers=bed.auth("test-admin-secret-0123456789"))
        assert resp.status_code in (404, 405), path
    assert not any(getattr(r, "path", "").startswith("/fixture-admin") for r in bed.data_app.routes)


async def test_device_tokens_cannot_reach_admin(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    for token in (reset.sender.token, reset.receiver.token, reset.oracle.token, ""):
        resp = await bed.admin_http.post(
            f"/fixture-admin/v1/runs/{reset.run_id}/reset", headers={"Authorization": f"Bearer {token}"}
        )
        assert (resp.status_code, resp.json()) == (401, {"error": "TOKEN_INVALID"})
        resp = await bed.admin_http.get(
            f"/fixture-admin/v1/runs/{reset.run_id}/ground-truth", headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 401


async def test_reset_response_shape_and_public_url(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    body = reset.model_dump(mode="json")
    assert set(body) == {"run_id", "sender", "receiver", "oracle", "conversations", "data_base_url", "layout"}
    assert body["layout"] == "default"
    assert body["data_base_url"] == "http://192.0.2.10:8781"
    assert len({reset.sender.token, reset.receiver.token, reset.oracle.token}) == 3


async def test_reset_clears_only_that_run(bed: FixtureTestBed) -> None:
    a = await bed.reset()
    b = await bed.reset()
    sent_a = Receipt.model_validate_json((await bed.send(a, "from a")).content)
    sent_b = Receipt.model_validate_json((await bed.send(b, "from b")).content)

    a2 = await bed.reset(a.run_id)
    # Old tokens for run A are revoked; run B tokens still work.
    assert (await bed.data.get("/fixture/v1/conversations", headers=bed.auth(a.sender.token))).status_code == 401
    assert await bed.oracle(a2.oracle.token).get_receipt(sent_a.client_message_id, a.run_id) is None
    assert await bed.oracle(b.oracle.token).get_receipt(sent_b.client_message_id, b.run_id) is not None
    # Run A is re-seeded with its conversation and inbound peer message.
    page = (
        await bed.data.get(
            "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(a2.sender.token)
        )
    ).json()
    assert len(page["messages"]) == 1


async def test_faults_require_existing_run_and_valid_body(bed: FixtureTestBed) -> None:
    resp = await bed.admin_http.post(
        f"/fixture-admin/v1/runs/{uuid4()}/faults", json={"schema_version": 1, "faults": []}
    )
    assert (resp.status_code, resp.json()) == (404, {"error": "RUN_NOT_FOUND"})
    reset = await bed.reset()
    resp = await bed.admin_http.post(
        f"/fixture-admin/v1/runs/{reset.run_id}/faults",
        json={"schema_version": 1, "faults": [], "extra": 1},
    )
    assert resp.status_code == 422


def test_public_base_url_is_distinct_from_bind_host(tmp_path: Path) -> None:
    config = FixtureConfig(bind_host="0.0.0.0", public_base_url="http://192.0.2.10:8781/", state_dir=tmp_path)
    assert config.public_base_url == "http://192.0.2.10:8781"
    assert config.bind_host == "0.0.0.0"
    assert not config.public_url_is_loopback
    sim = FixtureConfig(state_dir=tmp_path)
    assert sim.public_url_is_loopback  # Simulator-only convenience, flagged as such
    with pytest.raises(ValidationError):
        FixtureConfig(public_base_url="http://0.0.0.0:8781")
    with pytest.raises(ValidationError):
        FixtureConfig(public_base_url="http://192.0.2.10:8781/fixture")
    with pytest.raises(ValidationError):
        FixtureConfig(admin_host="0.0.0.0")


def test_shipped_configs_load() -> None:
    sim = load_config(REPO / "configs/fixtures/simulator.yaml")
    assert sim.public_url_is_loopback and sim.admin_host == "127.0.0.1"
    lab = load_config(REPO / "configs/fixtures/lab-device.yaml", data_port=9999)
    assert not lab.public_url_is_loopback and lab.data_port == 9999


def test_generated_admin_secret_file_is_private(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(ADMIN_SECRET_ENV, raising=False)
    config = FixtureConfig(state_dir=tmp_path)
    secret = resolve_admin_secret(config)
    assert config.admin_secret_path.read_text() == secret
    assert stat.S_IMODE(config.admin_secret_path.stat().st_mode) == 0o600
    monkeypatch.setenv(ADMIN_SECRET_ENV, "from-environment-0123456789")
    assert resolve_admin_secret(config) == "from-environment-0123456789"

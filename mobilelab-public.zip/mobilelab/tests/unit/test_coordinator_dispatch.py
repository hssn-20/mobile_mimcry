"""DispatchEngine journal, validation and rebinding (in-process worker, MOCK adapter; not device evidence)."""

from __future__ import annotations

import time
from pathlib import Path
from uuid import uuid4

import pytest
from pydantic import ValidationError
from test_coordinator_support import (
    CONTACT1,
    CONV1,
    CONV2,
    REPLY,
    actions,
    budget,
    candidate,
    context,
    make_rig,
    proposal_for,
)

from mobilelab.adapters.mock import MESSENGER_APP, SAFARI_APP
from mobilelab.candidates import rebind
from mobilelab.coordinator import OutcomeKind
from mobilelab.domain.actions import SendMessage
from mobilelab.domain.enums import ActionKind, EventType, ActionStatus, ExecutionStatus, SideEffectClass
from mobilelab.domain.errors import ErrorCode
from mobilelab.domain.observations import CandidateAction

SEND1 = f"messenger.send:{CONV1}"
COMPOSE1 = f"messenger.composer:{CONV1}"
ROW1 = f"messenger.conversation:{CONV1}"
ROW2 = f"messenger.conversation:{CONV2}"


def in_conversation(rig, conv: str = CONV1, text: str = "") -> None:  # type: ignore[no-untyped-def]
    s = rig.adapter.state
    s.foreground_app, s.messenger_screen, s.conversation_id, s.composer_text = MESSENGER_APP, "conversation", conv, text


async def test_full_send_journal_and_attempt(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {}), (COMPOSE1, {"text": REPLY}), (SEND1, {})])
    await rig.controller.start(rig.run.run_id)
    kinds = [await rig.controller.step(rig.run.run_id, context(rig.run.run_id), budget()) for _ in range(3)]
    assert [k.kind for k in kinds] == [OutcomeKind.ACKNOWLEDGED] * 3
    send = actions(rig.store, rig.run.run_id)[-1]
    assert send.kind is ActionKind.SEND_MESSAGE and send.status is ActionStatus.ACKNOWLEDGED
    assert isinstance(send.payload, SendMessage) and send.payload.contact_id == CONTACT1
    assert send.correlation_id == rig.adapter.state.messages[0].client_message_id
    assert send.dispatch_observation_id != send.decision_observation_id
    assert send.dispatch_candidate_id != send.original_candidate_id
    with rig.store.reader() as r:
        attempts = r.list_attempts(send.action_id)
        events = r.events_after(run_id=rig.run.run_id, limit=1000)
        decision_obs = r.get_observation(send.decision_observation_id)
        shot = r.get_artifact(decision_obs.screenshot_artifact_id)  # type: ignore[arg-type]
    assert len(attempts) == 1 and attempts[0].status is ExecutionStatus.ACKNOWLEDGED
    assert shot.evidence_source.value == "mock"
    path = [
        e.payload.to_status  # type: ignore[union-attr]
        for e in events
        if e.action_id == send.action_id and e.type is EventType.ACTION_STATUS_CHANGED
    ]
    assert path == [
        ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED,
        ActionStatus.PREPARED, ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED,
    ]  # fmt: skip


async def test_invented_candidate_rejected_before_journal(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    prop = proposal_for(obs, ROW1).model_copy(update={"candidate_id": uuid4()})
    out = await rig.controller.engine.dispatch(rig.worker, b, prop, obs)
    assert out.kind is OutcomeKind.REJECTED and out.error_code is ErrorCode.CANDIDATE_NOT_FOUND
    assert actions(rig.store, rig.run.run_id) == [] and rig.adapter.count("execute") == 0


async def test_generic_activate_cannot_stand_in_for_send(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    in_conversation(rig, text=REPLY)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    real_send = candidate(obs, SEND1)
    assert real_send.kind is ActionKind.SEND_MESSAGE
    with pytest.raises(ValidationError):  # a commit control can never be a generic activate
        CandidateAction(
            candidate_id=uuid4(), observation_id=obs.observation_id, semantic_key="x", kind=ActionKind.ACTIVATE,
            target_ref="composer.send", side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT,
        )  # fmt: skip
    forged = real_send.model_copy(
        update={"candidate_id": uuid4(), "kind": ActionKind.ACTIVATE, "side_effect_class": SideEffectClass.NAVIGATION,
                "permitted": real_send.permitted.model_copy(update={"contact_id": None})}
    )  # fmt: skip
    disguised = obs.model_copy(update={"candidates": [*obs.candidates, forged]})
    prop = proposal_for(disguised, SEND1).model_copy(update={"candidate_id": forged.candidate_id})
    out = await rig.controller.engine.dispatch(rig.worker, b, prop, disguised)
    assert out.kind is OutcomeKind.REJECTED and out.error_code is ErrorCode.CANDIDATE_NOT_FOUND
    assert rig.adapter.count("execute") == 0 and rig.adapter.state.messages == []


async def test_disallowed_parameters_rejected_and_journaled(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    in_conversation(rig)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    out = await rig.controller.engine.dispatch(rig.worker, b, proposal_for(obs, COMPOSE1, text="call 555-0100 now"), obs)
    assert out.kind is OutcomeKind.REJECTED and out.error_code is ErrorCode.INVALID_PARAMETERS
    (act,) = actions(rig.store, rig.run.run_id)
    assert act.status is ActionStatus.REJECTED and act.reject_code is ErrorCode.INVALID_PARAMETERS
    assert rig.adapter.count("execute") == 0


async def test_changed_foreground_app_triggers_replan(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, foreground_app=SAFARI_APP)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    link = next(c for c in obs.candidates if c.semantic_key.startswith("safari.link:"))
    prop = proposal_for(obs, link.semantic_key)
    rig.adapter.state.foreground_app = MESSENGER_APP  # user/app switched before dispatch
    out = await rig.controller.engine.dispatch(rig.worker, b, prop, obs)
    assert out.kind is OutcomeKind.REPLAN and out.consecutive_replans == 1
    (act,) = actions(rig.store, rig.run.run_id)
    assert act.status is ActionStatus.CANCELLED and act.reject_code is ErrorCode.CANDIDATE_NOT_FOUND
    assert rig.adapter.count("execute") == 0


async def test_changed_recipient_invalidates_send_and_replans_until_stuck(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    b = await rig.controller.start(rig.run.run_id)
    kinds = []
    for _ in range(3):
        in_conversation(rig, CONV1, REPLY)
        obs = await rig.controller.engine.capture(rig.worker, b, "decision")
        prop = proposal_for(obs, SEND1)
        in_conversation(rig, CONV2, REPLY)  # recipient changed between decision and dispatch
        kinds.append((await rig.controller.engine.dispatch(rig.worker, b, prop, obs)).kind)
    assert kinds == [OutcomeKind.REPLAN, OutcomeKind.REPLAN, OutcomeKind.STUCK]
    assert rig.adapter.count("execute") == 0 and rig.adapter.state.messages == []
    # a successful dispatch resets the consecutive-replan counter
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    out = await rig.controller.engine.dispatch(rig.worker, b, proposal_for(obs, "wait:dwell", duration_ms=5), obs)
    assert out.kind is OutcomeKind.ACKNOWLEDGED and out.consecutive_replans == 0


async def test_stale_dispatch_observation_rejected_by_worker_clock(tmp_path: Path) -> None:
    """A slow rebind (> 2 s) makes the dispatch observation stale on the worker's own clock."""
    def slow_rebind(orig, fresh, scope):  # type: ignore[no-untyped-def]
        time.sleep(2.1)
        return rebind(orig, fresh, scope)

    rig = make_rig(tmp_path)
    rig.controller.engine._rebind = slow_rebind  # noqa: SLF001 - test seam
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    out = await rig.controller.engine.dispatch(rig.worker, b, proposal_for(obs, ROW1), obs)
    assert out.kind is OutcomeKind.REJECTED and out.error_code is ErrorCode.STALE_OBSERVATION
    (act,) = actions(rig.store, rig.run.run_id)
    assert act.status is ActionStatus.REJECTED and act.dispatch_observation_id is not None
    with rig.store.reader() as r:
        (attempt,) = r.list_attempts(act.action_id)
    assert attempt.status is ExecutionStatus.REJECTED
    assert rig.adapter.count("execute") == 0


async def test_delayed_driver_command_times_out_to_unknown_without_retry(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {})], adapter_kw={"delays_ms": {"execute": 1500}}, command_max_duration_ms=300)
    await rig.controller.start(rig.run.run_id)
    out = await rig.controller.step(rig.run.run_id, context(rig.run.run_id), budget())
    assert out.kind is OutcomeKind.UNKNOWN and out.result is not None
    (act,) = actions(rig.store, rig.run.run_id)
    assert act.status is ActionStatus.UNKNOWN
    with rig.store.reader() as r:
        assert len(r.list_attempts(act.action_id)) == 1
    assert rig.adapter.count("execute") == 1


async def test_stale_epoch_proposal_discarded(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    out = await rig.controller.engine.dispatch(rig.worker, b, proposal_for(obs, ROW1, epoch=b.control_epoch + 1), obs)
    assert out.kind is OutcomeKind.DISCARDED
    assert actions(rig.store, rig.run.run_id) == [] and rig.adapter.count("execute") == 0


async def test_stale_lease_cancels_before_prepare(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    b = await rig.controller.start(rig.run.run_id)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    with rig.store.unit_of_work() as uow:
        uow.release_lease(b.lease_id, reason="test: lease revoked")
    out = await rig.controller.engine.dispatch(rig.worker, b, proposal_for(obs, ROW1), obs)
    assert out.kind is OutcomeKind.CANCELLED and out.error_code is ErrorCode.STALE_LEASE
    assert rig.adapter.count("execute") == 0

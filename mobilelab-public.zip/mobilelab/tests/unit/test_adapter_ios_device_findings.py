"""Regression tests for behaviour first seen on the REAL iOS 27.0 Simulator (T03 device gate).

The XML below is a trimmed excerpt of a real capture
(artifacts/device/t03-20261003T185105Z/observations/10-lab_messenger_typed_settled/page_source.xml,
WDA ``visible`` attribute excluded, as the adapter now configures). The tests themselves run against
the labelled FAKE driver from ``test_adapter_ios_support`` and produce ``evidence_source=mock``.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest
from test_adapter_ios_support import SAFARI_ARTICLE_XML, FakeDriver, make_adapter

from mobilelab.adapters import appium_server
from mobilelab.adapters.ios import SAFARI_BUNDLE_ID, IOSAdapterConfig, parse_page_source
from mobilelab.adapters.ios import preflight as preflight_mod
from mobilelab.domain.devices import DeviceProfile
from mobilelab.domain.enums import CapabilityKey, CapabilityStatus, DeviceKind, Platform

REAL_LAB_MESSENGER_TYPED_EXCERPT = """<?xml version="1.0" encoding="UTF-8"?>
<AppiumAUT>
  <XCUIElementTypeApplication type="XCUIElementTypeApplication" name="Lab Messenger" label="Lab Messenger" enabled="true" accessible="false" x="0" y="0" width="402" height="874" index="0" traits="" processId="22427" bundleId="org.mobilelab.fixtures.LabMessenger">
    <XCUIElementTypeWindow type="XCUIElementTypeWindow" enabled="true" accessible="false" x="0" y="0" width="402" height="874" index="0" traits="">
      <XCUIElementTypeNavigationBar type="XCUIElementTypeNavigationBar" name="Lab Messenger (fixture)" enabled="true" accessible="false" x="0" y="62" width="402" height="54" index="0" traits="">
        <XCUIElementTypeButton type="XCUIElementTypeButton" name="BackButton" label="Lab Messenger (fixture)" enabled="true" accessible="true" x="16" y="62" width="44" height="44" index="0" traits="Button"/>
      </XCUIElementTypeNavigationBar>
      <XCUIElementTypeStaticText type="XCUIElementTypeStaticText" value="Alex (test peer)" name="conversation.title" label="Alex (test peer)" enabled="true" accessible="true" x="139" y="124" width="124" height="21" index="0" traits="Header, StaticText"/>
      <XCUIElementTypeOther type="XCUIElementTypeOther" enabled="true" accessible="false" x="0" y="-1093" width="402" height="2557" index="0" traits=""/>
      <XCUIElementTypeStaticText type="XCUIElementTypeStaticText" value="Alex (test peer)" name="Alex (test peer)" label="Alex (test peer)" enabled="true" accessible="false" x="16" y="2900" width="88" height="15" index="1" traits=""/>
      <XCUIElementTypeTextField type="XCUIElementTypeTextField" value="Message" name="composer.text" label="" enabled="true" accessible="true" x="8" y="783" width="339" height="34" index="2" placeholderValue="Message" traits=""/>
      <XCUIElementTypeTextField type="XCUIElementTypeTextField" value="Hello from the T03 device gate" name="composer.typed" label="" enabled="true" accessible="true" x="8" y="516" width="339" height="34" index="3" placeholderValue="Message" traits=""/>
      <XCUIElementTypeButton type="XCUIElementTypeButton" name="composer.send" label="Send" enabled="false" accessible="true" x="354" y="790" width="40" height="21" index="4" traits="Button"/>
      <XCUIElementTypeStaticText type="XCUIElementTypeStaticText" value="3b706cd7-3c69-4093-83f5-bc007b15064c" name="composer.draft_id" label="Draft id" enabled="true" accessible="true" x="8" y="820" width="256" height="12" index="5" traits="StaticText"/>
    </XCUIElementTypeWindow>
  </XCUIElementTypeApplication>
</AppiumAUT>
"""


def _by_id(tree: Any, identifier: str) -> Any:
    return next(e for e in tree.elements if e.identifier == identifier)


def test_empty_text_field_placeholder_is_not_a_value() -> None:
    tree = parse_page_source(REAL_LAB_MESSENGER_TYPED_EXCERPT)
    assert _by_id(tree, "composer.text").value is None  # device reported value="Message" (= placeholder)
    assert _by_id(tree, "composer.typed").value == "Hello from the T03 device gate"
    assert _by_id(tree, "composer.draft_id").value == "3b706cd7-3c69-4093-83f5-bc007b15064c"
    assert _by_id(tree, "composer.send").enabled is False


def test_visibility_is_geometric_when_wda_visible_attribute_is_excluded() -> None:
    tree = parse_page_source(REAL_LAB_MESSENGER_TYPED_EXCERPT)
    assert _by_id(tree, "composer.text").visible is True
    offscreen = next(e for e in tree.elements if e.label == "Alex (test peer)" and e.identifier is None)
    assert offscreen.visible is False  # y=2900 lies below the 874 pt application frame
    partly = next(e for e in tree.elements if e.bounds is not None and e.bounds.y == -1093)
    assert partly.visible is True  # intersects the screen


def test_name_without_label_is_only_a_locator_hint() -> None:
    tree = parse_page_source(REAL_LAB_MESSENGER_TYPED_EXCERPT)
    nav = next(e for e in tree.elements if e.role == "navigation_bar")
    # XCUITest gives no way to tell a title-derived name from a developer identifier here.
    assert nav.identifier == "Lab Messenger (fixture)"
    assert tree.locators[nav.element_ref].strategy == "accessibility_id"


async def test_session_start_excludes_wda_visible_attribute() -> None:
    driver = FakeDriver(REAL_LAB_MESSENGER_TYPED_EXCERPT)
    adapter = make_adapter(driver, page_source_excluded_attributes="visible,accessible")
    await adapter.run_probe(lambda drv: None, 5)
    assert driver.calls[0] == ("settings", {"pageSourceExcludedAttributes": "visible,accessible"})


def test_session_capabilities_are_headless_and_non_destructive() -> None:
    caps = IOSAdapterConfig.model_validate(
        {"device_id": str(uuid4()), "udid": "U", "platform_version": "27.0", "wda_local_port": 8101}
    ).xcuitest_options().to_capabilities()
    assert caps["appium:isHeadless"] is True  # no driver-initiated Simulator reboot to show its window
    assert caps["appium:noReset"] is True and caps["appium:fullReset"] is False
    assert caps["appium:autoAcceptAlerts"] is False and caps["appium:autoDismissAlerts"] is False


class _ScrollingSafari(FakeDriver):
    """FAKE: a swipe up on the web view shifts every page element up by 300 pt."""

    def execute_script(self, script: str, *args: Any) -> Any:
        result = super().execute_script(script, *args)
        if script == "mobile: swipe" and args and args[0].get("direction") == "up":
            self.page_source_xml = self.page_source_xml.replace('y="80"', 'y="-220"').replace('y="130"', 'y="-170"')
        if script == "mobile: isAppInstalled":
            return False
        return result


@pytest.mark.parametrize("scrolls", [True, False])
async def test_preflight_scroll_is_judged_from_tree_positions(monkeypatch: pytest.MonkeyPatch, scrolls: bool) -> None:
    monkeypatch.setattr(preflight_mod, "SETTLE_S", 0.0)
    driver = (_ScrollingSafari if scrolls else FakeDriver)(SAFARI_ARTICLE_XML, foreground=SAFARI_BUNDLE_ID)
    adapter = make_adapter(driver, safari_probe_url="http://127.0.0.1:8781/fixture/v1/articles/article-01")
    profile = DeviceProfile(
        device_id=adapter.device_id, platform=Platform.IOS, kind=DeviceKind.SIMULATOR,
        name="mobilelab-iphone-01", os_version="27.0", model="iPhone",
    )  # fmt: skip
    report = await adapter.preflight(profile)
    scroll = next(r for r in report.records if r.key is CapabilityKey.SCROLL)
    expected = CapabilityStatus.SUPPORTED if scrolls else CapabilityStatus.UNVERIFIED
    assert scroll.status is expected, scroll.reason
    swipes = [c[2]["direction"] for c in driver.calls if c[:2] == ("script", "mobile: swipe")]
    assert swipes == ["up", "down"]  # scrolled, then restored
    assert not any(c[:2] == ("script", "mobile: scroll") for c in driver.calls)


def test_find_wda_processes_matches_only_this_device_and_derived_data(monkeypatch: pytest.MonkeyPatch) -> None:
    dd = Path("/repo/build/wda/UDID-1")
    ps = "\n".join(
        [
            f"  101 /X/xcodebuild build-for-testing test-without-building -derivedDataPath {dd} -destination id=UDID-1 A=1",
            "  102 /X/xcodebuild build-for-testing -derivedDataPath /elsewhere/wda -destination id=UDID-1",
            f"  103 /X/xcodebuild build-for-testing -derivedDataPath {dd.parent / 'UDID-2'} -destination id=UDID-2",
            f"  104 /usr/bin/tail -derivedDataPath {dd} id=UDID-1",
        ]
    )

    def fake_run(argv: list[str], **_: Any) -> subprocess.CompletedProcess[str]:
        assert argv == ["/bin/ps", "-axo", "pid=,command="]
        return subprocess.CompletedProcess(argv, 0, stdout=ps, stderr="")

    monkeypatch.setattr(appium_server.subprocess, "run", fake_run)
    assert appium_server.find_wda_processes("UDID-1", dd) == [101]


async def test_close_stops_wda_unless_kept(monkeypatch: pytest.MonkeyPatch) -> None:
    stopped: list[tuple[str, Path]] = []
    monkeypatch.setattr(
        "mobilelab.adapters.ios.adapter.stop_wda_processes", lambda udid, dd: stopped.append((udid, dd)) or [4242]
    )
    adapter = make_adapter(FakeDriver(SAFARI_ARTICLE_XML))
    await adapter.run_probe(lambda drv: None, 5)
    closed = await adapter.close()
    assert closed.closed and "4242" in closed.detail
    assert stopped == [("FAKE-UDID-0001", adapter.config.derived_data_path.resolve())]

    stopped.clear()
    kept = make_adapter(FakeDriver(SAFARI_ARTICLE_XML), keep_wda_running=True)
    await kept.run_probe(lambda drv: None, 5)
    await kept.close()
    assert stopped == []

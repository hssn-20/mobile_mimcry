"""AppiumServer argv/env and lifecycle. Uses a FAKE ``appium`` executable (a tiny Python HTTP server
answering /status) under a temporary repo root; the real project-local Appium is never started here."""

from __future__ import annotations

import socket
import stat
import sys
from pathlib import Path

import httpx
import pytest

from mobilelab.adapters.appium_server import LOOPBACK, AppiumServer, AppiumServerError, free_loopback_port

FAKE_APPIUM = """import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
args = sys.argv[1:]
addr, port = args[args.index("--address") + 1], int(args[args.index("--port") + 1])
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        body = json.dumps({"value": {"ready": True, "message": "fake appium"}}).encode()
        self.send_response(200 if self.path == "/status" else 404)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, *a):
        pass
HTTPServer((addr, port), H).serve_forever()
"""


def fake_repo(tmp_path: Path, script: str = FAKE_APPIUM) -> Path:
    bin_path = tmp_path / "tools/appium/node_modules/.bin/appium"
    bin_path.parent.mkdir(parents=True)
    impl = tmp_path / "fake_appium.py"
    impl.write_text(script)
    # sh wrapper: the interpreter path may contain spaces, which a shebang line cannot carry
    bin_path.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{impl}" "$@"\n')
    bin_path.chmod(bin_path.stat().st_mode | stat.S_IXUSR)
    return tmp_path


def test_argv_binds_loopback_only_and_uses_project_local_appium(tmp_path: Path) -> None:
    server = AppiumServer(repo_root=tmp_path, port=4799)
    argv = server.argv()
    assert argv[0] == str(tmp_path.resolve() / "tools/appium/node_modules/.bin/appium")
    assert argv[argv.index("--address") + 1] == "127.0.0.1" == LOOPBACK
    assert "0.0.0.0" not in argv and "::" not in argv
    assert argv[argv.index("--port") + 1] == "4799"
    assert argv[argv.index("--use-drivers") + 1] == "xcuitest"
    log = Path(argv[argv.index("--log") + 1])
    assert log.is_relative_to(tmp_path.resolve() / "artifacts")
    assert server.url == "http://127.0.0.1:4799"
    env = server.env()
    assert env["APPIUM_HOME"] == str(tmp_path.resolve() / "tools/appium/.appium")
    assert env["DEVELOPER_DIR"] == "/Applications/Xcode.app/Contents/Developer"
    assert all(isinstance(a, str) for a in argv)  # typed argv, no shell string


def test_free_port_is_on_loopback() -> None:
    port = free_loopback_port()
    with socket.socket() as s:
        s.bind((LOOPBACK, port))


def test_missing_binary_is_a_clear_error(tmp_path: Path) -> None:
    with pytest.raises(AppiumServerError, match="project-local appium not found"):
        AppiumServer(repo_root=tmp_path).start()


def test_start_waits_for_status_then_stops(tmp_path: Path) -> None:
    server = AppiumServer(repo_root=fake_repo(tmp_path), startup_timeout_s=20)
    with server:
        assert server.running
        resp = httpx.get(f"{server.url}/status", timeout=2)
        assert resp.json()["value"]["ready"] is True
    assert not server.running
    with pytest.raises(httpx.HTTPError):
        httpx.get(f"{server.url}/status", timeout=1)


def test_process_exiting_during_startup_fails_fast(tmp_path: Path) -> None:
    server = AppiumServer(repo_root=fake_repo(tmp_path, "raise SystemExit(3)\n"), startup_timeout_s=20)
    with pytest.raises(AppiumServerError, match="exited during startup"):
        server.start()
    assert not server.running

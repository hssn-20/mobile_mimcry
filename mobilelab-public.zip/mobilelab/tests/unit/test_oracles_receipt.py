"""Receipt oracle and send reconciliation against a scripted fake receipt source (pure unit tests).

The fake source returns synthetic receipts; nothing here is device or fixture-service evidence.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

import pytest

from mobilelab.domain.actions import SendMessage
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus, EvidenceCategory, SideEffectClass, Verdict
from mobilelab.domain.scenarios import OracleDefinition
from mobilelab.fixtures.clients import FixtureAuthError, FixtureProtocolError, FixtureUnavailableError
from mobilelab.fixtures.models import Receipt
from mobilelab.oracles import (
    FixtureMessageReceiptOracle,
    OracleWindow,
    PollSettings,
    reconcile_unknown_send,
    transition_path,
)

T0 = datetime(2026, 10, 3, 12, 0, tzinfo=UTC)
RUN = uuid4()
DEFN = OracleDefinition(
    kind="fixture_message_receipt", required_status="delivered", timeout_seconds=5,
    evidence=["client_message_id", "server_receipt", "receiver_receipt"],
)  # fmt: skip

Step = Receipt | None | BaseException


class FakeTime:
    def __init__(self) -> None:
        self.t = 0.0

    def monotonic(self) -> float:
        return self.t

    def now(self) -> datetime:
        return T0 + timedelta(seconds=self.t)

    async def sleep(self, s: float) -> None:
        self.t += s

    def settings(self, interval: float = 1.0) -> PollSettings:
        return PollSettings(poll_interval_s=interval, monotonic=self.monotonic, sleep=self.sleep, now=self.now)


class ScriptedSource:
    """Returns successive steps; the last step repeats."""

    def __init__(self, *steps: Step | Callable[[], Step]) -> None:
        self.steps = list(steps)
        self.calls = 0

    async def get_receipt(self, client_message_id: UUID, run_id: UUID) -> Receipt | None:
        step = self.steps[min(self.calls, len(self.steps) - 1)]
        self.calls += 1
        if callable(step):
            step = step()
        if isinstance(step, BaseException):
            raise step
        return step


def receipt(cmid: UUID, *, delivered: bool = False, receiver: bool | None = None, run_id: UUID = RUN) -> Receipt:
    has_receiver = delivered if receiver is None else receiver
    return Receipt(
        message_id=uuid4(), run_id=run_id, conversation_id="fixture-conversation-01", client_message_id=cmid,
        sender_id="fixture-sender-01", server_accepted_at=T0,
        receiver_delivered_at=T0 + timedelta(seconds=1) if delivered else None, receiver_displayed_at=None,
        receiver_type="scripted_receiver" if has_receiver else None,  # type: ignore[arg-type]
        status="delivered" if delivered else "accepted",  # type: ignore[arg-type]
        correlation_evidence_ids=["fixture-server:accepted:x"],
    )  # fmt: skip


async def evaluate(source: ScriptedSource, cmid: UUID, ft: FakeTime, **kw: object):  # type: ignore[no-untyped-def]
    oracle = FixtureMessageReceiptOracle(source, settings=ft.settings())
    return await oracle.evaluate(RUN, cmid, kw.pop("definition", DEFN), kw.pop("window", None), scenario_id="browse_then_reply", **kw)  # type: ignore[arg-type]


async def test_pass_requires_receiver_delivery() -> None:
    cmid, ft = uuid4(), FakeTime()
    src = ScriptedSource(None, receipt(cmid), receipt(cmid, delivered=True))
    res = await evaluate(src, cmid, ft, window=OracleWindow(start=T0 - timedelta(seconds=3)), evidence_ids=["action:1"])
    assert res.verdict is Verdict.PASS and res.reason_code == "RECEIPT_DELIVERED"
    assert src.calls == 3
    assert res.obtained_evidence is EvidenceCategory.FIXTURE
    assert res.requirement_refs == ["BR-07", "AC-02"]
    assert res.evidence_ids[0] == "action:1" and f"fixture-receipt:{cmid}" in res.evidence_ids
    assert res.observation_window_start == T0 - timedelta(seconds=3)
    assert res.expected["required_status"] == "delivered"
    assert res.observed["receipt"]["status"] == "delivered"  # type: ignore[index,call-overload]


async def test_accepted_only_at_deadline_is_inconclusive_not_pass() -> None:
    cmid, ft = uuid4(), FakeTime()
    res = await evaluate(ScriptedSource(receipt(cmid)), cmid, ft)
    assert res.verdict is Verdict.INCONCLUSIVE and res.reason_code == "DELIVERY_UNCONFIRMED"
    assert ft.t == pytest.approx(5.0)
    assert res.observed["receipt"]["status"] == "accepted"  # type: ignore[index,call-overload]
    assert f"fixture-receipt:{cmid}" in res.evidence_ids


async def test_delivered_without_receiver_identity_is_not_pass() -> None:
    cmid, ft = uuid4(), FakeTime()
    bogus = receipt(cmid, delivered=True, receiver=False)
    res = await evaluate(ScriptedSource(bogus), cmid, ft)
    assert res.verdict is Verdict.INCONCLUSIVE


async def test_missing_receipt_for_unknown_send_is_inconclusive() -> None:
    cmid, ft = uuid4(), FakeTime()
    res = await evaluate(ScriptedSource(None), cmid, ft, action_status=ActionStatus.UNKNOWN)
    assert (res.verdict, res.reason_code) == (Verdict.INCONCLUSIVE, "NO_RECEIPT")
    assert res.observed["action_status"] == "UNKNOWN"
    assert res.obtained_evidence is None


async def test_missing_receipt_with_proven_non_execution_is_harness_failure() -> None:
    cmid, ft = uuid4(), FakeTime()
    res = await evaluate(ScriptedSource(None), cmid, ft, non_execution_evidence_ids=["observation:abc"])
    assert (res.verdict, res.reason_code) == (Verdict.HARNESS_FAILURE, "SEND_NOT_EXECUTED")
    assert "observation:abc" in res.evidence_ids


async def test_outage_is_environment_failure_but_transient_outage_recovers() -> None:
    cmid, ft = uuid4(), FakeTime()
    res = await evaluate(ScriptedSource(FixtureUnavailableError("down")), cmid, ft)
    assert (res.verdict, res.reason_code) == (Verdict.ENVIRONMENT_FAILURE, "FIXTURE_UNAVAILABLE")
    src = ScriptedSource(FixtureUnavailableError("blip"), receipt(cmid, delivered=True))
    assert (await evaluate(src, cmid, FakeTime())).verdict is Verdict.PASS


@pytest.mark.parametrize(
    ("exc", "verdict", "reason"),
    [
        (FixtureAuthError(401, "TOKEN_EXPIRED"), Verdict.HARNESS_FAILURE, "ORACLE_AUTH_FAILED"),
        (FixtureProtocolError("bad"), Verdict.ENVIRONMENT_FAILURE, "FIXTURE_PROTOCOL_ERROR"),
        (RuntimeError("bug"), Verdict.HARNESS_FAILURE, "ORACLE_EXCEPTION"),
    ],
)
async def test_errors_are_classified_and_stop_polling(exc: Exception, verdict: Verdict, reason: str) -> None:
    cmid, ft = uuid4(), FakeTime()
    src = ScriptedSource(exc)
    res = await evaluate(src, cmid, ft)
    assert (res.verdict, res.reason_code) == (verdict, reason)
    assert src.calls == 1


async def test_receipt_for_other_identity_is_not_accepted() -> None:
    cmid, ft = uuid4(), FakeTime()
    res = await evaluate(ScriptedSource(receipt(cmid, delivered=True, run_id=uuid4())), cmid, ft)
    assert res.verdict is not Verdict.PASS


async def test_invalid_definition_is_harness_failure() -> None:
    cmid, ft = uuid4(), FakeTime()
    for defn in (
        DEFN.model_copy(update={"required_status": "accepted"}),
        DEFN.model_copy(update={"kind": "visible_state"}),
    ):
        res = await evaluate(ScriptedSource(receipt(cmid, delivered=True)), cmid, ft, definition=defn)
        assert (res.verdict, res.reason_code) == (Verdict.HARNESS_FAILURE, "ORACLE_DEFINITION_INVALID")


async def test_never_dut_failure() -> None:
    steps: list[Step] = [None, receipt(uuid4()), FixtureUnavailableError("x"), RuntimeError("y")]
    for step in steps:
        res = await evaluate(ScriptedSource(step), uuid4(), FakeTime())
        assert res.verdict is not Verdict.DUT_FAILURE


# -- reconciliation ---------------------------------------------------------------------------


def send_action(status: ActionStatus) -> ActionRecord:
    cmid = uuid4()
    payload = SendMessage(kind="send_message", element_ref="composer.send", contact_id="fixture-contact-01", client_message_id=cmid)
    return ActionRecord(
        action_id=uuid4(), run_id=RUN, device_id=uuid4(), kind=ActionKind.SEND_MESSAGE, semantic_key="messenger.send",
        side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT, status=status, decision_observation_id=uuid4(),
        original_candidate_id=uuid4(), dispatch_observation_id=uuid4(), dispatch_candidate_id=uuid4(),
        payload=payload, correlation_id=cmid,
    )  # fmt: skip


async def test_reconcile_verified_when_message_exists() -> None:
    action = send_action(ActionStatus.UNKNOWN)
    assert action.correlation_id is not None
    src = ScriptedSource(None, receipt(action.correlation_id))
    rec = await reconcile_unknown_send(src, action, deadline_s=5, settings=FakeTime().settings())
    assert (rec.resolution, rec.reason_code, rec.transition_path) == ("VERIFIED", "RECEIPT_ACCEPTED", [ActionStatus.VERIFIED])
    assert rec.resend_permitted is False and src.calls == 2


@pytest.mark.parametrize(
    ("steps", "non_exec", "resolution", "reason"),
    [
        ([None], (), "UNRESOLVED", "NO_RECEIPT"),
        ([None], ("obs:1",), "FAILED", "NON_EXECUTION_OBSERVED"),
        ([FixtureUnavailableError("down")], ("obs:1",), "UNRESOLVED", "FIXTURE_UNAVAILABLE"),
        ([FixtureAuthError(403, "FORBIDDEN_ROLE")], (), "UNRESOLVED", "ORACLE_AUTH_FAILED"),
        ([RuntimeError("bug")], (), "UNRESOLVED", "RECONCILIATION_ERROR"),
    ],
)
async def test_reconcile_unresolved_and_failed(steps: list[Step], non_exec: tuple[str, ...], resolution: str, reason: str) -> None:
    action = send_action(ActionStatus.UNKNOWN)
    rec = await reconcile_unknown_send(
        ScriptedSource(*steps), action, deadline_s=3, non_execution_evidence_ids=non_exec, settings=FakeTime().settings()
    )
    assert (rec.resolution, rec.reason_code) == (resolution, reason)


def test_transition_paths_follow_action_graph() -> None:
    from mobilelab.domain.transitions import ACTION_TRANSITIONS

    for start in (ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED, ActionStatus.UNKNOWN):
        for res in ("VERIFIED", "FAILED", "UNRESOLVED"):
            current = start
            for step in transition_path(start, res):  # type: ignore[arg-type]
                assert step in ACTION_TRANSITIONS[current]
                current = step
            assert current is ActionStatus(res)


async def test_reconcile_rejects_non_send_or_unreconcilable() -> None:
    action = send_action(ActionStatus.VERIFIED)
    with pytest.raises(ValueError):
        await reconcile_unknown_send(ScriptedSource(None), action, deadline_s=1, settings=FakeTime().settings())

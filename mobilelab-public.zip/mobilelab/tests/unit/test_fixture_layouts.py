"""Per-run fixture layouts (``default`` / ``changed``) selected at admin reset (T08 changed-screen evidence)."""

from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import pytest

from mobilelab.fixtures.layouts import (
    ALLOWED_CONTACT_ID,
    ALLOWED_CONVERSATION_ID,
    DECOY_CONVERSATIONS,
    SEED_INBOUND_CHANGED,
    SEED_INBOUND_DEFAULT,
    layout_for_setup,
    seed_conversations,
)
from mobilelab.fixtures.models import FixtureLayout, MessagesPage, Receipt
from mobilelab.fixtures.store import FixtureStore
from mobilelab.fixtures.testing import FixtureTestBed
from mobilelab.fixtures.web import article_variant


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def _messages(bed: FixtureTestBed, token: str, conversation_id: str) -> MessagesPage:
    resp = await bed.data.get(f"/fixture/v1/conversations/{conversation_id}/messages", headers=bed.auth(token))
    assert resp.status_code == 200
    return MessagesPage.model_validate_json(resp.content)


def test_seed_conversations_ground_truth_is_layout_independent() -> None:
    for layout in FixtureLayout:
        convs = seed_conversations(layout, "fixture-receiver-01")
        allowed = [c for c in convs if not c.decoy]
        assert [(c.conversation_id, c.contact_id, c.peer_id) for c in allowed] == [
            (ALLOWED_CONVERSATION_ID, ALLOWED_CONTACT_ID, "fixture-receiver-01")
        ]
    changed = seed_conversations(FixtureLayout.CHANGED, "fixture-receiver-01")
    assert [c.decoy for c in sorted(changed, key=lambda c: c.position)] == [True, True, False]
    assert all(d.peer_id != "fixture-receiver-01" for d in DECOY_CONVERSATIONS)


def test_layout_for_setup() -> None:
    assert layout_for_setup({}) is FixtureLayout.DEFAULT
    assert layout_for_setup({"layout": "changed"}) is FixtureLayout.CHANGED
    with pytest.raises(ValueError):
        layout_for_setup({"layout": "fancy"})
    with pytest.raises(ValueError):
        layout_for_setup({"layout": 3})


async def test_default_reset_is_unchanged(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    assert reset.layout is FixtureLayout.DEFAULT
    assert [c.conversation_id for c in reset.conversations] == [ALLOWED_CONVERSATION_ID]
    page = await _messages(bed, reset.sender.token, ALLOWED_CONVERSATION_ID)
    assert [m.body for m in page.messages] == [SEED_INBOUND_DEFAULT]


async def test_changed_reset_lists_decoys_above_allowed(bed: FixtureTestBed) -> None:
    reset = await bed.reset(layout="changed")
    assert reset.layout is FixtureLayout.CHANGED
    ids = [c.conversation_id for c in reset.conversations]
    assert ids == ["fixture-conversation-decoy-01", "fixture-conversation-decoy-02", ALLOWED_CONVERSATION_ID]
    # The device-facing list (what Lab Messenger renders, in order) matches.
    resp = await bed.data.get("/fixture/v1/conversations", headers=bed.auth(reset.sender.token))
    assert [c["conversation_id"] for c in resp.json()["conversations"]] == ids
    allowed = next(c for c in reset.conversations if c.conversation_id == ALLOWED_CONVERSATION_ID)
    assert allowed.contact_id == ALLOWED_CONTACT_ID and allowed.title == "Alex (test peer)"
    page = await _messages(bed, reset.sender.token, ALLOWED_CONVERSATION_ID)
    assert [m.body for m in page.messages] == [SEED_INBOUND_CHANGED]
    # The scripted receiver is a participant only in the allowed conversation.
    rresp = await bed.data.get("/fixture/v1/conversations", headers=bed.auth(reset.receiver.token))
    assert [c["conversation_id"] for c in rresp.json()["conversations"]] == [ALLOWED_CONVERSATION_ID]


async def test_layout_is_per_run_and_reset_switches_back(bed: FixtureTestBed) -> None:
    rid = uuid4()
    other = await bed.reset()
    changed = await bed.reset(rid, layout=FixtureLayout.CHANGED)
    assert len(changed.conversations) == 3
    assert bed.store.run_layout(other.run_id) is FixtureLayout.DEFAULT
    assert bed.store.run_layout(rid) is FixtureLayout.CHANGED
    again = await bed.reset(rid)
    assert again.layout is FixtureLayout.DEFAULT and len(again.conversations) == 1
    assert bed.store.run_layout(None) is FixtureLayout.DEFAULT
    assert bed.store.run_layout(uuid4()) is FixtureLayout.DEFAULT


async def test_reset_rejects_unknown_layout_and_extra_fields(bed: FixtureTestBed) -> None:
    rid = uuid4()
    for body in ({"schema_version": 1, "layout": "fancy"}, {"schema_version": 1, "layout": "changed", "x": 1}):
        resp = await bed.admin_http.post(f"/fixture-admin/v1/runs/{rid}/reset", json=body)
        assert 400 <= resp.status_code < 500
    assert not bed.store.run_exists(rid)
    with pytest.raises(ValueError):
        await bed.reset(rid, layout="fancy")


async def test_send_to_decoy_is_accepted_but_never_reaches_receiver(bed: FixtureTestBed) -> None:
    """A wrong-recipient send is recorded (detectable) and has no scripted acknowledgement path."""
    reset = await bed.reset(layout="changed")
    resp = await bed.send(reset, conversation_id="fixture-conversation-decoy-01")
    assert resp.status_code == 201
    receipt = Receipt.model_validate_json(resp.content)
    assert receipt.status == "accepted"
    receiver = bed.receiver(reset)
    await receiver.poll_once()
    page = await _messages(bed, reset.sender.token, "fixture-conversation-decoy-01")
    assert any(m.body == "I have finished reading the article." for m in page.messages)
    got = await bed.oracle(reset.oracle.token).get_receipt(receipt.client_message_id, reset.run_id)
    assert got is not None and got.receiver_delivered_at is None


async def test_changed_article_served_and_logged(bed: FixtureTestBed) -> None:
    reset = await bed.reset(layout="changed")
    rid = str(reset.run_id)
    page = (await bed.data.get("/fixture/v1/articles/article-01", params={"run_id": rid})).text
    assert "Pocket Gardens: How One Street Turned Green" in page
    assert "Small Gardens on Busy Streets</h1>" not in page
    assert "Continue reading: Counting Tide Pools" in page
    assert "Read next: Counting Tide Pools" not in page
    assert "https://weather.example.invalid/weekend" in page  # the unrelated external link exists
    assert f"/fixture/v1/articles/article-02?run_id={rid}" in page
    # Links reordered: index link first, next-article link last.
    assert page.index("link-index") < page.index("link-external-unrelated") < page.index("link-next-article")
    # Other articles are unchanged in the changed layout.
    a2 = (await bed.data.get("/fixture/v1/articles/article-02", params={"run_id": rid})).text
    assert "Counting Tide Pools" in a2
    index = (await bed.data.get("/fixture/v1/articles", params={"run_id": rid})).text
    assert "Pocket Gardens" in index
    entries = await bed.admin.request_log(reset.run_id)
    a1 = next(e for e in entries if e.path == "/fixture/v1/articles/article-01")
    assert a1.detail == {"article_id": "article-01", "article_version": "1-changed", "layout": "changed"}
    # Same URL without a run id (or for a default run) stays the default page.
    default = (await bed.data.get("/fixture/v1/articles/article-01")).text
    assert "Small Gardens on Busy Streets" in default and "Pocket Gardens" not in default


def test_changed_article_is_longer_than_default() -> None:
    root = Path(__file__).resolve().parents[2] / "src/mobilelab/fixtures/content"
    d = article_variant("article-01", FixtureLayout.DEFAULT)
    c = article_variant("article-01", FixtureLayout.CHANGED)
    assert d is not None and c is not None and d.template != c.template
    assert (root / c.template).read_text().count("<p ") > (root / d.template).read_text().count("<p ")
    assert article_variant("nope", FixtureLayout.CHANGED) is None


def test_store_migrates_pre_layout_database(tmp_path: Path) -> None:
    import sqlite3

    db = tmp_path / "old.sqlite3"
    conn = sqlite3.connect(db)
    conn.executescript(
        "CREATE TABLE runs (run_id TEXT PRIMARY KEY, reset_at TEXT NOT NULL);"
        "CREATE TABLE conversations (run_id TEXT NOT NULL, conversation_id TEXT NOT NULL, title TEXT NOT NULL,"
        " contact_id TEXT NOT NULL, sender_id TEXT NOT NULL, receiver_id TEXT NOT NULL,"
        " PRIMARY KEY (run_id, conversation_id));"
    )
    conn.commit()
    conn.close()
    store = FixtureStore(db)
    try:
        rid = uuid4()
        reset = store.reset_run(rid, "http://127.0.0.1:8781", layout=FixtureLayout.CHANGED)
        assert len(reset.conversations) == 3 and store.run_layout(rid) is FixtureLayout.CHANGED
    finally:
        store.close()

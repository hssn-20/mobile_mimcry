"""Fixture messaging protocol: idempotency, roles, receipt states."""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import timedelta
from pathlib import Path
from uuid import uuid4

import pytest

import httpx

from mobilelab.fixtures.clients import (
    FixtureAuthError,
    FixtureOracleClient,
    FixtureUnavailableError,
    ReceiptNotFoundError,
)
from mobilelab.fixtures.models import AckTiming, MessagesPage, Receipt, ack_timings
from mobilelab.fixtures.store import SEED_INBOUND_BODY
from mobilelab.fixtures.testing import FixtureTestBed


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def test_first_send_is_accepted_only(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    resp = await bed.send(reset)
    assert resp.status_code == 201
    receipt = Receipt.model_validate_json(resp.content)
    assert receipt.status == "accepted"
    assert receipt.receiver_delivered_at is None
    assert receipt.receiver_displayed_at is None
    assert receipt.receiver_type is None
    assert receipt.sender_id == reset.sender.sender_id
    assert resp.json()["server_accepted_at"].endswith("Z")


async def test_identical_duplicate_returns_original_receipt(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    cmid = uuid4()
    first = await bed.send(reset, client_message_id=cmid)
    bed.clock.advance(5)
    second = await bed.send(reset, client_message_id=cmid)
    assert first.status_code == 201
    assert second.status_code == 200
    assert second.headers["Fixture-Duplicate"] == "true"
    assert second.json() == first.json()
    page = MessagesPage.model_validate_json(
        (
            await bed.data.get(
                "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(reset.sender.token)
            )
        ).content
    )
    assert [m.client_message_id for m in page.messages].count(cmid) == 1


async def test_changed_body_under_same_identity_conflicts(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    cmid = uuid4()
    assert (await bed.send(reset, "one", client_message_id=cmid)).status_code == 201
    resp = await bed.send(reset, "two", client_message_id=cmid)
    assert resp.status_code == 409
    assert resp.json() == {"error": "CLIENT_MESSAGE_ID_CONFLICT"}


async def test_extra_fields_and_bad_body_rejected(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    payload = {
        "schema_version": 1,
        "run_id": str(reset.run_id),
        "conversation_id": "fixture-conversation-01",
        "client_message_id": str(uuid4()),
        "sequence": 1,
        "body": "hello",
        "status": "delivered",
    }
    resp = await bed.data.post("/fixture/v1/messages", json=payload, headers=bed.auth(reset.sender.token))
    assert resp.status_code == 422
    assert resp.json()["error"] == "VALIDATION_ERROR"
    del payload["status"]
    for bad_body in ("", "x" * 2001):
        resp = await bed.data.post(
            "/fixture/v1/messages", json={**payload, "body": bad_body}, headers=bed.auth(reset.sender.token)
        )
        assert resp.status_code == 422


async def test_run_id_must_match_token(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    other = await bed.reset()
    resp = await bed.send(reset.model_copy(update={"run_id": other.run_id}))
    assert resp.status_code == 403
    assert resp.json() == {"error": "RUN_MISMATCH"}


async def test_role_enforcement(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    msg = Receipt.model_validate_json((await bed.send(reset)).content)
    ack = {"kind": "delivered", "receiver_observed_at": "2026-10-03T12:00:00.000Z", "evidence_ids": []}
    url = f"/fixture/v1/messages/{msg.message_id}/acknowledgements"

    # The sender (DUT identity) cannot acknowledge its own message.
    resp = await bed.data.post(url, json=ack, headers=bed.auth(reset.sender.token))
    assert (resp.status_code, resp.json()) == (403, {"error": "FORBIDDEN_ROLE"})
    # The oracle is read-only.
    resp = await bed.data.post(url, json=ack, headers=bed.auth(reset.oracle.token))
    assert resp.status_code == 403
    # The receiver cannot send as the DUT.
    resp = await bed.data.post(
        "/fixture/v1/messages",
        json={"schema_version": 1, "run_id": str(reset.run_id), "conversation_id": "fixture-conversation-01",
              "client_message_id": str(uuid4()), "sequence": 1, "body": "x"},
        headers=bed.auth(reset.receiver.token),
    )
    assert (resp.status_code, resp.json()) == (403, {"error": "FORBIDDEN_ROLE"})
    # Sender cannot read receipts or the receiver inbox.
    resp = await bed.data.get(
        f"/fixture/v1/receipts/{msg.client_message_id}", params={"run_id": str(reset.run_id)},
        headers=bed.auth(reset.sender.token),
    )
    assert resp.status_code == 403
    assert (await bed.data.get("/fixture/v1/receiver/inbox", headers=bed.auth(reset.sender.token))).status_code == 403


async def test_token_errors_are_distinct(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    resp = await bed.data.get("/fixture/v1/conversations")
    assert (resp.status_code, resp.json()) == (401, {"error": "TOKEN_INVALID"})
    resp = await bed.data.get("/fixture/v1/conversations", headers=bed.auth("nonsense"))
    assert (resp.status_code, resp.json()) == (401, {"error": "TOKEN_INVALID"})
    bed.clock.advance(bed.config.token_ttl_s + 1)
    resp = await bed.data.get("/fixture/v1/conversations", headers=bed.auth(reset.sender.token))
    assert (resp.status_code, resp.json()) == (401, {"error": "TOKEN_EXPIRED"})


async def test_conversation_denied(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    resp = await bed.data.get(
        "/fixture/v1/conversations/someone-elses/messages", headers=bed.auth(reset.sender.token)
    )
    assert (resp.status_code, resp.json()) == (403, {"error": "CONVERSATION_DENIED"})
    resp = await bed.send(reset, conversation_id="someone-elses")
    assert (resp.status_code, resp.json()) == (403, {"error": "CONVERSATION_DENIED"})


async def test_conversations_and_seeded_inbound_message(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    resp = await bed.data.get("/fixture/v1/conversations", headers=bed.auth(reset.sender.token))
    assert resp.json() == {
        "schema_version": 1,
        "conversations": [
            {
                "conversation_id": "fixture-conversation-01",
                "title": "Alex (test peer)",
                "contact_id": "fixture-contact-01",
                "participants": [reset.sender.sender_id, reset.receiver.receiver_id],
            }
        ],
    }
    page = (
        await bed.data.get(
            "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(reset.sender.token)
        )
    ).json()
    assert [m["body"] for m in page["messages"]] == [SEED_INBOUND_BODY]
    assert page["messages"][0]["sender_id"] == reset.receiver.receiver_id


async def test_cursor_pagination_orders_by_server_sequence(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    for i in range(3):
        await bed.send(reset, f"m{i}", sequence=i + 1)
    url = "/fixture/v1/conversations/fixture-conversation-01/messages"
    headers = bed.auth(reset.sender.token)
    first = (await bed.data.get(url, params={"limit": 2}, headers=headers)).json()
    assert len(first["messages"]) == 2
    rest = (await bed.data.get(url, params={"after": first["next_cursor"]}, headers=headers)).json()
    bodies = [m["body"] for m in first["messages"] + rest["messages"]]
    assert bodies == [SEED_INBOUND_BODY, "m0", "m1", "m2"]
    seqs = [m["sequence"] for m in first["messages"] + rest["messages"]]
    assert seqs == sorted(seqs)
    empty = (await bed.data.get(url, params={"after": rest["next_cursor"]}, headers=headers)).json()
    assert empty["messages"] == [] and empty["next_cursor"] == rest["next_cursor"]
    bad = await bed.data.get(url, params={"after": "abc"}, headers=headers)
    assert bad.status_code == 400


async def test_delivered_requires_receiver_ack_and_scripted_receiver_cannot_display(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    oracle = bed.oracle(reset.oracle.token)
    receipt = Receipt.model_validate_json((await bed.send(reset)).content)
    url = f"/fixture/v1/messages/{receipt.message_id}/acknowledgements"
    rh = bed.auth(reset.receiver.token)
    observed = (bed.clock.now + timedelta(seconds=1)).isoformat()

    # The scripted receiver identity can never report "displayed", before or after delivery.
    resp = await bed.data.post(
        url, json={"kind": "displayed", "receiver_observed_at": observed, "evidence_ids": ["ui-1"]}, headers=rh
    )
    assert (resp.status_code, resp.json()) == (403, {"error": "DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE"})
    # Still only accepted: the server never manufactures delivery.
    still = await oracle.get_receipt(receipt.client_message_id, reset.run_id)
    assert still is not None and still.status == "accepted" and still.receiver_delivered_at is None

    resp = await bed.data.post(
        url, json={"kind": "delivered", "receiver_observed_at": observed, "evidence_ids": ["rx-1"]}, headers=rh
    )
    assert resp.status_code == 200
    delivered = Receipt.model_validate_json(resp.content)
    assert delivered.status == "delivered"
    assert delivered.receiver_type == "scripted_receiver"
    assert delivered.receiver_delivered_at is not None and delivered.receiver_displayed_at is None
    assert "rx-1" in delivered.correlation_evidence_ids
    # Idempotent delivered ack.
    again = await bed.data.post(
        url, json={"kind": "delivered", "receiver_observed_at": observed, "evidence_ids": []}, headers=rh
    )
    assert again.json() == resp.json()

    for evidence_ids in ([], ["made-up"]):
        resp = await bed.data.post(
            url,
            json={"kind": "displayed", "receiver_observed_at": observed, "evidence_ids": evidence_ids},
            headers=rh,
        )
        assert (resp.status_code, resp.json()) == (403, {"error": "DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE"})
    final = await oracle.get_receipt(receipt.client_message_id, reset.run_id)
    assert final is not None and final.status == "delivered" and final.receiver_displayed_at is None


async def test_ack_exposes_server_receipt_time_and_clock_offset(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    receipt = Receipt.model_validate_json((await bed.send(reset)).content)
    bed.clock.advance(5)
    observed = bed.clock.now - timedelta(seconds=2)  # receiver clock 2 s behind the server
    resp = await bed.data.post(
        f"/fixture/v1/messages/{receipt.message_id}/acknowledgements",
        json={"kind": "delivered", "receiver_observed_at": observed.isoformat(), "evidence_ids": []},
        headers=bed.auth(reset.receiver.token),
    )
    assert resp.status_code == 200
    delivered = Receipt.model_validate_json(resp.content)
    [timing] = ack_timings(delivered)
    assert timing.kind == "delivered" and timing.message_id == receipt.message_id
    assert timing.receiver_observed_at == delivered.receiver_delivered_at
    assert abs((timing.server_received_at - bed.clock.now).total_seconds()) < 0.002
    assert timing.receiver_offset_ms == 2000
    assert AckTiming.from_evidence_id(timing.to_evidence_id()) == timing
    assert ack_timings(receipt) == []  # nothing before an acknowledgement


@pytest.mark.parametrize("offset", [timedelta(days=-3650), timedelta(minutes=-10), timedelta(minutes=10)])
async def test_implausible_ack_times_are_rejected(bed: FixtureTestBed, offset: timedelta) -> None:
    reset = await bed.reset()
    receipt = Receipt.model_validate_json((await bed.send(reset)).content)
    resp = await bed.data.post(
        f"/fixture/v1/messages/{receipt.message_id}/acknowledgements",
        json={"kind": "delivered", "receiver_observed_at": (bed.clock.now + offset).isoformat(), "evidence_ids": []},
        headers=bed.auth(reset.receiver.token),
    )
    assert (resp.status_code, resp.json()) == (422, {"error": "ACK_TIME_IMPLAUSIBLE"})
    still = await bed.oracle(reset.oracle.token).get_receipt(receipt.client_message_id, reset.run_id)
    assert still is not None and still.status == "accepted" and still.receiver_delivered_at is None


async def test_receiver_cannot_ack_message_not_addressed_to_it(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    page = (
        await bed.data.get(
            "/fixture/v1/conversations/fixture-conversation-01/messages", headers=bed.auth(reset.receiver.token)
        )
    ).json()
    seeded = page["messages"][0]  # sent BY the receiver to the sender
    resp = await bed.data.post(
        f"/fixture/v1/messages/{seeded['message_id']}/acknowledgements",
        json={"kind": "delivered", "receiver_observed_at": "2026-10-03T12:00:00Z", "evidence_ids": []},
        headers=bed.auth(reset.receiver.token),
    )
    assert (resp.status_code, resp.json()) == (403, {"error": "CONVERSATION_DENIED"})


async def test_oracle_client_distinguishes_not_found_and_auth(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    other = await bed.reset()
    oracle = bed.oracle(reset.oracle.token)
    assert await oracle.get_receipt(uuid4(), reset.run_id) is None
    with pytest.raises(FixtureAuthError) as exc:
        await oracle.get_receipt(uuid4(), other.run_id)
    assert exc.value.code == "RUN_MISMATCH"
    with pytest.raises(FixtureAuthError) as exc:
        await bed.oracle(reset.sender.token).get_receipt(uuid4(), reset.run_id)
    assert exc.value.code == "FORBIDDEN_ROLE"


def _outage_transport(kind: str) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        if kind == "connect":
            raise httpx.ConnectError("connection refused", request=request)
        if kind == "timeout":
            raise httpx.ReadTimeout("timed out", request=request)
        return httpx.Response(503, json={"error": "RECIPIENT_UNAVAILABLE"})

    return httpx.MockTransport(handler)


@pytest.mark.parametrize("kind", ["connect", "timeout", "http_503"])
@pytest.mark.parametrize("method", ["get_receipt", "require_receipt"])
async def test_oracle_client_reports_outage_distinctly(kind: str, method: str) -> None:
    client = FixtureOracleClient("http://fixture-data.test", "oracle-token", transport=_outage_transport(kind))
    try:
        with pytest.raises(FixtureUnavailableError) as exc:
            await getattr(client, method)(uuid4(), uuid4())
        # An outage is never "not found" (None / ReceiptNotFoundError) and never an auth failure.
        assert not isinstance(exc.value, ReceiptNotFoundError | FixtureAuthError)
    finally:
        await client.aclose()

"""SQLite store: migration, optimistic versioning, state+event atomicity, leases, gate, journal."""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import pytest
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext
from pydantic import ValidationError
from sqlalchemy import inspect

from mobilelab.domain.base import utc_now
from mobilelab.domain.control import ControlCommand
from mobilelab.domain.devices import CapabilityRecord, CapabilityReport, DeviceProfile
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, ExecutionResult
from mobilelab.domain.enums import (
    ActionKind,
    ActionStatus,
    CapabilityKey,
    CapabilityStatus,
    CommandKind,
    CommandStatus,
    ConfigKind,
    DeviceKind,
    EventType,
    EvidenceCategory,
    EvidenceSource,
    ExecutionStatus,
    LeaseKind,
    LeaseStatus,
    Platform,
    RunStatus,
    SideEffectClass,
    Verdict,
)
from mobilelab.domain.errors import (
    DispatchGateClosed,
    EvidenceTierMismatch,
    IdempotencyConflict,
    InvalidTransition,
    LeaseConflict,
    StaleEpoch,
    StaleLease,
    TerminalRecordImmutable,
    VersionConflict,
)
from mobilelab.domain.actions import Activate, SendMessage
from mobilelab.domain.events import ActionStatusChangedEvent, Event, RunStatusChangedEvent
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.runs import Run, RunSpec
from mobilelab.store import Store, current_revision, head_revision
from mobilelab.store.engine import journal_mode
from mobilelab.store.models import Base, RunRow

H = "0" * 64

EXPECTED_TABLES = {
    "device_profiles", "capability_records", "config_revisions", "campaigns", "runs", "leases",
    "observations", "decisions", "actions", "attempts", "oracle_results", "commands", "events",
    "artifacts", "idempotency_records", "global_control", "provider_usage", "alembic_version",
}  # fmt: skip


@pytest.fixture
def published() -> list[Event]:
    return []


@pytest.fixture
def store(tmp_path: Path, published: list[Event]) -> Iterator[Store]:
    def publish(events: Sequence[Event]) -> None:
        published.extend(events)

    s = Store.open(tmp_path / "lab.db", publisher=publish)
    yield s
    s.close()


def _run(device_id: UUID | None = None) -> Run:
    spec = RunSpec(
        scenario_id="browse_then_reply", scenario_version=1, scenario_hash=H,
        persona_id="careful_reader", persona_version=1, persona_hash=H,
        provider_id="rules", provider_config_hash=config_hash({}), seed=7,
        device_id=device_id or uuid4(), platform=Platform.IOS, device_kind=DeviceKind.SIMULATOR,
        device_profile_hash=H, planned_evidence=EvidenceCategory.FIXTURE,
    )  # fmt: skip
    return Run(run_id=uuid4(), spec=spec)


def _create_run(store: Store) -> Run:
    with store.unit_of_work() as uow:
        return uow.add_run(_run())


def _advance(store: Store, run_id: UUID, *targets: RunStatus) -> Run:
    run: Run | None = None
    for t in targets:
        with store.unit_of_work() as uow:
            run = uow.transition_run(run_id, t)
    assert run is not None
    return run


# -- migration ---------------------------------------------------------------------------------


def test_migration_on_fresh_db_creates_schema(store: Store, tmp_path: Path) -> None:
    assert current_revision(store.engine) == head_revision()
    assert set(inspect(store.engine).get_table_names()) == EXPECTED_TABLES
    assert journal_mode(store.engine) == "wal"
    with store.engine.connect() as conn:
        assert compare_metadata(MigrationContext.configure(conn, opts={"compare_type": True}), Base.metadata) == []
    with store.reader() as uow:
        gate = uow.get_gate()
    assert gate.gate_open is False and gate.global_epoch == 0  # gate starts closed
    # Re-running the upgrade is a no-op.
    again = Store.open(tmp_path / "lab.db")
    assert current_revision(again.engine) == head_revision()
    again.close()


# -- runs: transitions, versions, events -------------------------------------------------------


def test_run_lifecycle_commits_state_and_events(store: Store, published: list[Event]) -> None:
    run = _create_run(store)
    assert run.version == 1 and run.status is RunStatus.CREATED
    run = _advance(store, run.run_id, RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING)
    assert run.status is RunStatus.RUNNING and run.version == 4 and run.started_at is not None
    with store.unit_of_work() as uow:
        run = uow.transition_run(run.run_id, RunStatus.PAUSING, expected_version=4)
    assert run.control_epoch == 1  # pause invalidates in-flight decisions
    with store.reader() as uow:
        events = uow.events_after(None, run_id=run.run_id)
    assert all(isinstance(e, RunStatusChangedEvent) for e in events)
    assert [e.payload.to_status for e in events] == ["CREATED", "PREFLIGHT", "READY", "RUNNING", "PAUSING"]
    assert [e.event_id for e in events] == sorted(e.event_id for e in events)
    assert [e.event_id for e in published] == [e.event_id for e in events]


def test_stale_expected_version_conflicts(store: Store) -> None:
    run = _create_run(store)
    _advance(store, run.run_id, RunStatus.PREFLIGHT)
    with pytest.raises(VersionConflict) as exc, store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.READY, expected_version=1)
    assert exc.value.current_state == {"status": "PREFLIGHT", "version": 2}
    with store.reader() as uow:
        assert uow.get_run(run.run_id).status is RunStatus.PREFLIGHT


def test_concurrent_writer_detected_by_version_column(store: Store) -> None:
    """The ORM version column guards UPDATEs even without expected_version."""
    run = _create_run(store)
    with pytest.raises(VersionConflict), store.unit_of_work() as uow:
        held = uow.session.get(RunRow, str(run.run_id))  # this session's view: version 1
        assert held is not None and held.version == 1
        # Another writer bumps the row version underneath this session.
        uow.session.connection().exec_driver_sql("UPDATE runs SET version = 7")
        uow.transition_run(run.run_id, RunStatus.PREFLIGHT)
    with store.reader() as uow:
        assert uow.get_run(run.run_id).status is RunStatus.CREATED


def test_forbidden_transition_rolls_back_without_event(store: Store, published: list[Event]) -> None:
    run = _create_run(store)
    published.clear()
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.RUNNING)
    with store.reader() as uow:
        assert uow.get_run(run.run_id).status is RunStatus.CREATED
        assert len(uow.events_after(None, run_id=run.run_id)) == 1
    assert published == []


def test_state_and_event_roll_back_together(store: Store, published: list[Event]) -> None:
    run = _create_run(store)
    published.clear()
    with pytest.raises(RuntimeError), store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.PREFLIGHT)
        raise RuntimeError("crash before commit")
    with store.reader() as uow:
        assert uow.get_run(run.run_id).status is RunStatus.CREATED
        assert [e.type for e in uow.events_after(None, run_id=run.run_id)] == [EventType.RUN_STATUS_CHANGED]
    assert published == []  # never published before commit


def test_terminal_run_is_immutable_and_records_verdict(store: Store) -> None:
    run = _create_run(store)
    _advance(store, run.run_id, RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING)
    with store.unit_of_work() as uow:
        with pytest.raises(InvalidTransition):
            uow.transition_run(run.run_id, RunStatus.PAUSING, verdict=Verdict.PASS)
    with store.unit_of_work() as uow:
        done = uow.transition_run(
            run.run_id, RunStatus.COMPLETED, verdict=Verdict.DUT_FAILURE, obtained_evidence=EvidenceCategory.FIXTURE,
            obtained_evidence_source=EvidenceSource.DEVICE,
        )  # fmt: skip
    assert done.verdict is Verdict.DUT_FAILURE and done.ended_at is not None
    assert done.obtained_evidence_source is EvidenceSource.DEVICE
    with pytest.raises(TerminalRecordImmutable), store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.PAUSING, recovery=True)


def test_recovery_transition_persisted(store: Store) -> None:
    run = _create_run(store)
    _advance(store, run.run_id, RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING, RunStatus.PAUSING)
    with store.unit_of_work() as uow:
        rec = uow.transition_run(run.run_id, RunStatus.PAUSING, recovery=True, reason="coordinator restart")
        events = uow.events_after(None, run_id=run.run_id)
    assert rec.in_recovery is True and rec.status is RunStatus.PAUSING
    last = events[-1]
    assert isinstance(last, RunStatusChangedEvent) and last.payload.recovery is True


# -- leases ------------------------------------------------------------------------------------


def test_two_active_automation_leases_conflict(store: Store) -> None:
    device = uuid4()
    with store.unit_of_work() as uow:
        first = uow.acquire_lease(device, LeaseKind.AUTOMATION, "worker-a", lease_id=uuid4())
    assert first.epoch == 1
    with pytest.raises(LeaseConflict), store.unit_of_work() as uow:
        uow.acquire_lease(device, LeaseKind.AUTOMATION, "worker-b", lease_id=uuid4())


def test_operator_and_automation_leases_conflict(store: Store) -> None:
    device = uuid4()
    with store.unit_of_work() as uow:
        auto = uow.acquire_lease(device, LeaseKind.AUTOMATION, "worker-a", lease_id=uuid4())
    with pytest.raises(LeaseConflict), store.unit_of_work() as uow:
        uow.acquire_lease(device, LeaseKind.OPERATOR, "operator", lease_id=uuid4())
    # Takeover: release automation, grant operator with a new epoch, in one transaction.
    with store.unit_of_work() as uow:
        uow.release_lease(auto.lease_id, reason="takeover after confirmed pause")
        op = uow.acquire_lease(device, LeaseKind.OPERATOR, "operator", lease_id=uuid4())
    assert op.epoch == 2
    with pytest.raises(LeaseConflict), store.unit_of_work() as uow:
        uow.acquire_lease(device, LeaseKind.AUTOMATION, "worker-a", lease_id=uuid4())
    # Leases on other devices are independent.
    with store.unit_of_work() as uow:
        assert uow.acquire_lease(uuid4(), LeaseKind.AUTOMATION, "worker-c", lease_id=uuid4()).epoch == 1


def test_database_enforces_single_active_lease(store: Store) -> None:
    device = str(uuid4())
    db = store.engine.url.database
    assert db is not None
    with sqlite3.connect(db) as raw:
        insert = (
            "INSERT INTO leases (lease_id, device_id, kind, epoch, holder, status, acquired_at, "
            "schema_version, version, created_at) VALUES (?, ?, ?, ?, 'x', 'active', 't', 1, 1, 't')"
        )
        raw.execute(insert, (str(uuid4()), device, "automation", 1))
        with pytest.raises(sqlite3.IntegrityError):
            raw.execute(insert, (str(uuid4()), device, "operator", 2))


def test_stale_lease_and_epoch_rejected(store: Store) -> None:
    device = uuid4()
    with store.unit_of_work() as uow:
        old = uow.acquire_lease(device, LeaseKind.AUTOMATION, "w", lease_id=uuid4())
    with store.reader() as uow:
        assert uow.check_lease(old.lease_id, old.epoch, device_id=device).lease_id == old.lease_id
        with pytest.raises(StaleEpoch):
            uow.check_lease(old.lease_id, old.epoch + 1)
        with pytest.raises(StaleLease):
            uow.check_lease(old.lease_id, old.epoch, device_id=uuid4())
    with store.unit_of_work() as uow:
        uow.release_lease(old.lease_id, reason="done", expected_version=old.version)
        new = uow.acquire_lease(device, LeaseKind.AUTOMATION, "w", lease_id=uuid4())
    with store.reader() as uow:
        with pytest.raises(StaleLease):
            uow.check_lease(old.lease_id, old.epoch)
        assert uow.check_lease(new.lease_id, 2).epoch == 2
    with pytest.raises(VersionConflict), store.unit_of_work() as uow:
        uow.release_lease(new.lease_id, reason="x", expected_version=99)


def test_restart_revokes_leases_and_closes_gate(store: Store) -> None:
    with store.unit_of_work() as uow:
        uow.open_gate("operator start")
        uow.acquire_lease(uuid4(), LeaseKind.AUTOMATION, "w1", lease_id=uuid4())
        uow.acquire_lease(uuid4(), LeaseKind.AUTOMATION, "w2", lease_id=uuid4())
    with store.unit_of_work() as uow:
        gate = uow.close_gate("coordinator restart")
        revoked = uow.revoke_all_active_leases("coordinator restart")
    assert gate.gate_open is False and gate.global_epoch == 1
    assert {lease.status for lease in revoked} == {LeaseStatus.REVOKED} and len(revoked) == 2


def test_gate_open_close_versions(store: Store) -> None:
    with store.reader() as uow:
        gate = uow.get_gate()
    with pytest.raises(VersionConflict), store.unit_of_work() as uow:
        uow.open_gate("start", expected_version=gate.version + 1)
    with store.unit_of_work() as uow:
        opened = uow.open_gate("start", expected_version=gate.version)
        uow.require_gate_open()
    with store.unit_of_work() as uow:
        closed = uow.close_gate("emergency stop")
    assert opened.gate_open and not closed.gate_open and closed.global_epoch == gate.global_epoch + 1
    with pytest.raises(DispatchGateClosed), store.reader() as uow:
        uow.require_gate_open()


# -- actions/attempts --------------------------------------------------------------------------


def _running_run(store: Store) -> Run:
    run = _create_run(store)
    return _advance(store, run.run_id, RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING)


def _send_action(run: Run) -> ActionRecord:
    return ActionRecord(
        action_id=uuid4(), run_id=run.run_id, device_id=run.spec.device_id, kind=ActionKind.SEND_MESSAGE,
        semantic_key="messenger.send", side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT,
        decision_observation_id=uuid4(), original_candidate_id=uuid4(),
    )  # fmt: skip


def _send_binding() -> dict[str, Any]:
    mid = uuid4()
    payload = SendMessage(kind="send_message", element_ref="send", contact_id="fixture-contact-01", client_message_id=mid)
    return {"payload": payload, "correlation_id": mid, "dispatch_observation_id": uuid4(), "dispatch_candidate_id": uuid4()}


def test_action_journal_and_attempts(store: Store) -> None:
    run = _running_run(store)
    action = _send_action(run)
    binding = _send_binding()
    with store.unit_of_work() as uow:
        uow.add_action(action)
        for t in (ActionStatus.VALIDATED, ActionStatus.SCHEDULED):
            uow.transition_action(action.action_id, t)
        with pytest.raises(ValidationError):  # PREPARED needs the journaled payload + dispatch binding
            uow.transition_action(action.action_id, ActionStatus.PREPARED)
        prepared = uow.transition_action(action.action_id, ActionStatus.PREPARED, **binding)
        a = uow.transition_action(action.action_id, ActionStatus.DISPATCHED, actual_dispatch_at=utc_now(), expected_version=4)
    assert prepared.payload == binding["payload"]
    assert a.status is ActionStatus.DISPATCHED and a.version == 5 and a.correlation_id == binding["correlation_id"]
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.transition_action(action.action_id, ActionStatus.CANCELLED)
    with pytest.raises(ValueError), store.unit_of_work() as uow:
        uow.transition_action(action.action_id, ActionStatus.UNKNOWN, status="VERIFIED")
    with store.unit_of_work() as uow:
        uow.transition_action(action.action_id, ActionStatus.UNKNOWN)
        assert [x.action_id for x in uow.potentially_executed_actions()] == [action.action_id]
        attempt = uow.add_attempt(AttemptRecord(attempt_id=uuid4(), action_id=action.action_id, attempt_no=1, command_id=uuid4()))
        result = ExecutionResult(
            command_id=attempt.command_id, action_id=action.action_id, device_id=run.spec.device_id,
            status=ExecutionStatus.UNKNOWN, evidence_source=EvidenceSource.MOCK, started_at=utc_now(),
        )  # fmt: skip
        done = uow.complete_attempt(attempt.attempt_id, result)
        assert done.status is ExecutionStatus.UNKNOWN
        with pytest.raises(InvalidTransition):
            uow.complete_attempt(attempt.attempt_id, result)
    with store.reader() as uow:
        assert len(uow.list_attempts(action.action_id)) == 1


# -- configs, devices, commands, idempotency ---------------------------------------------------


def test_config_revisions_are_immutable_and_deduplicated(store: Store) -> None:
    with store.unit_of_work() as uow:
        r1 = uow.add_config_revision(ConfigKind.PERSONA, "careful_reader", {"a": 1, "b": 2})
        r1b = uow.add_config_revision(ConfigKind.PERSONA, "careful_reader", {"b": 2, "a": 1})
        r2 = uow.add_config_revision(ConfigKind.PERSONA, "careful_reader", {"a": 1, "b": 3})
    assert r1.revision == r1b.revision == 1 and r2.revision == 2
    assert r1.content_hash == config_hash({"a": 1, "b": 2})
    with store.reader() as uow:
        assert uow.get_config_revision(ConfigKind.PERSONA, "careful_reader").revision == 2
        assert uow.get_config_revision(ConfigKind.PERSONA, "careful_reader", 1).content == {"a": 1, "b": 2}


def test_device_profile_and_capability_report(store: Store) -> None:
    device = DeviceProfile(
        device_id=uuid4(), platform=Platform.IOS, kind=DeviceKind.SIMULATOR, name="lab-sim-1",
        os_version="26.0", model="iPhone 17",
    )  # fmt: skip
    now = utc_now()
    with store.unit_of_work() as uow:
        saved = uow.upsert_device_profile(device)
        report = CapabilityReport(
            report_id=uuid4(), device_id=device.device_id, platform=Platform.IOS, device_kind=DeviceKind.SIMULATOR,
            evidence_source=EvidenceSource.MOCK, adapter_version="mock-0", probed_at=now,
            records=[CapabilityRecord(key=CapabilityKey.OBSERVE_UI, status=CapabilityStatus.UNVERIFIED,
                                      evidence_source=EvidenceSource.MOCK, reason="mock adapter")],
        )  # fmt: skip
        updated = uow.add_capability_report(report)
    assert saved.version == 1 and updated.version == 2
    assert updated.capabilities[0].evidence_source is EvidenceSource.MOCK
    with pytest.raises(VersionConflict), store.unit_of_work() as uow:
        uow.upsert_device_profile(device, expected_version=1)


def test_commands_and_idempotency(store: Store) -> None:
    cmd = ControlCommand(command_id=uuid4(), kind=CommandKind.PAUSE, run_id=None)
    with store.unit_of_work() as uow:
        uow.add_command(cmd)
        uow.update_command(cmd.command_id, CommandStatus.SUCCEEDED, result={"paused": True})
        uow.save_idempotency("k1", "POST", "/api/v1/runs", "h1", 202, {"command_id": str(cmd.command_id)})
    with store.unit_of_work() as uow:
        with pytest.raises(InvalidTransition):
            uow.update_command(cmd.command_id, CommandStatus.FAILED)
    with store.reader() as uow:
        rec = uow.check_idempotency("k1", "POST", "/api/v1/runs", "h1")
        assert rec is not None and rec.status_code == 202
        assert uow.check_idempotency("k2", "POST", "/api/v1/runs", "h1") is None
        with pytest.raises(IdempotencyConflict):
            uow.check_idempotency("k1", "POST", "/api/v1/runs", "different-body")


def test_idempotency_key_reuse_on_other_path_conflicts(store: Store) -> None:
    run_a, run_b = uuid4(), uuid4()
    with store.unit_of_work() as uow:
        uow.save_idempotency("k1", "POST", f"/api/v1/runs/{run_a}/pause", "h1", 202, {})
    with store.reader() as uow:
        assert uow.check_idempotency("k1", "POST", f"/api/v1/runs/{run_a}/pause", "h1") is not None
        with pytest.raises(IdempotencyConflict):
            uow.check_idempotency("k1", "POST", f"/api/v1/runs/{run_b}/stop", "h1")
        with pytest.raises(IdempotencyConflict):
            uow.check_idempotency("k1", "DELETE", f"/api/v1/runs/{run_a}/pause", "h1")
    with pytest.raises(IdempotencyConflict), store.unit_of_work() as uow:
        uow.save_idempotency("k1", "POST", f"/api/v1/runs/{run_b}/stop", "h1", 202, {})


def test_reader_cannot_write(store: Store) -> None:
    with pytest.raises(RuntimeError), store.reader() as uow:
        uow.close_gate("nope")


# -- review fixes: evidence gate, journal immutability, lease kind, terminal runs ---------------


def _carrier_run(store: Store) -> Run:
    base = _run()
    spec = base.spec.model_copy(update={"planned_evidence": EvidenceCategory.PHYSICAL_CARRIER})
    with store.unit_of_work() as uow:
        run = uow.add_run(base.model_copy(update={"spec": spec}))
    return _advance(store, run.run_id, RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING)


def test_fixture_evidence_cannot_pass_carrier_run(store: Store) -> None:
    run = _carrier_run(store)
    with pytest.raises(EvidenceTierMismatch), store.unit_of_work() as uow:
        uow.transition_run(
            run.run_id, RunStatus.COMPLETED, verdict=Verdict.PASS,
            obtained_evidence=EvidenceCategory.FIXTURE, obtained_evidence_source=EvidenceSource.DEVICE,
        )  # fmt: skip
    with pytest.raises(EvidenceTierMismatch), store.unit_of_work() as uow:  # PASS without any evidence
        uow.transition_run(run.run_id, RunStatus.COMPLETED, verdict=Verdict.PASS)
    with store.reader() as uow:
        assert uow.get_run(run.run_id).status is RunStatus.RUNNING
    with store.unit_of_work() as uow:  # an honest non-claim is still recordable
        done = uow.transition_run(run.run_id, RunStatus.COMPLETED, verdict=Verdict.UNSUPPORTED)
    assert done.verdict is Verdict.UNSUPPORTED and done.obtained_evidence is None


def test_mock_or_replay_evidence_cannot_pass(store: Store) -> None:
    run = _running_run(store)
    for source in (EvidenceSource.MOCK, EvidenceSource.REPLAY):
        with pytest.raises(EvidenceTierMismatch), store.unit_of_work() as uow:
            uow.transition_run(
                run.run_id, RunStatus.COMPLETED, verdict=Verdict.PASS,
                obtained_evidence=EvidenceCategory.FIXTURE, obtained_evidence_source=source,
            )  # fmt: skip
    with store.unit_of_work() as uow:
        done = uow.transition_run(
            run.run_id, RunStatus.COMPLETED, verdict=Verdict.PASS,
            obtained_evidence=EvidenceCategory.FIXTURE, obtained_evidence_source=EvidenceSource.DEVICE,
        )  # fmt: skip
    assert done.verdict is Verdict.PASS


def test_evidence_only_recorded_on_terminal_transition(store: Store) -> None:
    run = _running_run(store)
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.PAUSING, obtained_evidence=EvidenceCategory.FIXTURE)


def test_action_binding_immutable_after_prepared(store: Store) -> None:
    run = _running_run(store)
    action = _send_action(run)
    with store.unit_of_work() as uow:
        uow.add_action(action)
        uow.transition_action(action.action_id, ActionStatus.VALIDATED)
        uow.transition_action(action.action_id, ActionStatus.SCHEDULED)
        uow.transition_action(action.action_id, ActionStatus.PREPARED, **_send_binding())
    tap = Activate(kind="activate", element_ref="send_button")
    for update in ({"payload": tap}, {"dispatch_observation_id": uuid4()}, {"correlation_id": uuid4()}):
        with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
            uow.transition_action(action.action_id, ActionStatus.DISPATCHED, **update)
    with store.unit_of_work() as uow:
        uow.transition_action(action.action_id, ActionStatus.DISPATCHED)
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.transition_action(action.action_id, ActionStatus.ACKNOWLEDGED, payload=tap)
    with store.reader() as uow:
        stored = uow.get_action(action.action_id)
    assert isinstance(stored.payload, SendMessage) and stored.status is ActionStatus.DISPATCHED


def test_action_event_payload_is_typed(store: Store) -> None:
    run = _running_run(store)
    action = _send_action(run)
    with store.unit_of_work() as uow:
        uow.add_action(action)
        uow.transition_action(action.action_id, ActionStatus.CANCELLED)
    with store.reader() as uow:
        events = [e for e in uow.events_after(None, run_id=run.run_id) if isinstance(e, ActionStatusChangedEvent)]
    assert [(e.payload.from_status, e.payload.to_status) for e in events] == [
        (None, ActionStatus.PROPOSED),
        (ActionStatus.PROPOSED, ActionStatus.CANCELLED),
    ]
    assert all(e.payload.kind is ActionKind.SEND_MESSAGE for e in events)


def test_operator_lease_does_not_authorize_dispatch(store: Store) -> None:
    device = uuid4()
    with store.unit_of_work() as uow:
        op = uow.acquire_lease(device, LeaseKind.OPERATOR, "operator", lease_id=uuid4())
    with store.reader() as uow:
        with pytest.raises(StaleLease):
            uow.check_lease(op.lease_id, op.epoch, device_id=device)
        assert uow.check_lease(op.lease_id, op.epoch, required_kind=LeaseKind.OPERATOR).kind is LeaseKind.OPERATOR


def test_terminal_run_rejects_new_actions_and_leases(store: Store) -> None:
    run = _running_run(store)
    with store.unit_of_work() as uow:
        uow.transition_run(run.run_id, RunStatus.COMPLETED, verdict=Verdict.INCONCLUSIVE)
    with pytest.raises(TerminalRecordImmutable), store.unit_of_work() as uow:
        uow.add_action(_send_action(run))
    with pytest.raises(TerminalRecordImmutable), store.unit_of_work() as uow:
        uow.acquire_lease(run.spec.device_id, LeaseKind.AUTOMATION, "w", lease_id=uuid4(), run_id=run.run_id)
    with store.reader() as uow:
        assert uow.list_actions(run_id=run.run_id) == [] and uow.get_active_lease(run.spec.device_id) is None


def test_actions_only_journaled_while_running(store: Store) -> None:
    run = _create_run(store)
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.add_action(_send_action(run))
    running = _running_run(store)
    other_device = _send_action(running).model_copy(update={"device_id": uuid4()})
    with pytest.raises(InvalidTransition), store.unit_of_work() as uow:
        uow.add_action(other_device)


def test_run_lease_must_target_run_device(store: Store) -> None:
    run = _running_run(store)
    with pytest.raises(LeaseConflict), store.unit_of_work() as uow:
        uow.acquire_lease(uuid4(), LeaseKind.AUTOMATION, "w", lease_id=uuid4(), run_id=run.run_id)
    with store.unit_of_work() as uow:
        lease = uow.acquire_lease(run.spec.device_id, LeaseKind.AUTOMATION, "w", lease_id=uuid4(), run_id=run.run_id)
    assert lease.run_id == run.run_id

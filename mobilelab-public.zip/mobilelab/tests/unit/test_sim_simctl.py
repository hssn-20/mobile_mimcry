"""simctl wrapper with a fake runner (no Simulator involved)."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest

from mobilelab.sim import (
    CommandResult,
    NotProjectOwnedError,
    SimctlError,
    Simctl,
    ensure_device,
    lab_messenger_launch_args,
    load_record,
    select_device_type,
    select_runtime,
)
from mobilelab.sim.simctl import DeviceNotFoundError

OWNED = "11111111-1111-1111-1111-111111111111"
FOREIGN = "22222222-2222-2222-2222-222222222222"
RUNTIME_ID = "com.apple.CoreSimulator.SimRuntime.iOS-27-0"
IPHONE17 = "com.apple.CoreSimulator.SimDeviceType.iPhone-17"


def runtimes_json() -> str:
    return json.dumps(
        {
            "runtimes": [
                {
                    "identifier": RUNTIME_ID,
                    "name": "iOS 27.0",
                    "version": "27.0",
                    "platform": "iOS",
                    "isAvailable": True,
                    "supportedDeviceTypes": [
                        {"identifier": "x.iPad", "name": "iPad (A16)", "productFamily": "iPad"},
                        {"identifier": "x.16", "name": "iPhone 16", "productFamily": "iPhone"},
                        {"identifier": IPHONE17, "name": "iPhone 17", "productFamily": "iPhone"},
                    ],
                }
            ]
        }
    )


class FakeRunner:
    def __init__(self, devices: list[dict[str, object]] | None = None) -> None:
        self.calls: list[tuple[list[str], dict[str, str]]] = []
        self.devices = devices if devices is not None else [
            {"udid": OWNED, "name": "mobilelab-iphone-01", "state": "Booted",
             "deviceTypeIdentifier": IPHONE17, "isAvailable": True},
            {"udid": FOREIGN, "name": "iPhone 17", "state": "Shutdown",
             "deviceTypeIdentifier": IPHONE17, "isAvailable": True},
        ]  # fmt: skip
        self.created_udid = "33333333-3333-3333-3333-333333333333"

    def __call__(self, argv: Sequence[str], *, timeout_s: float, env: Mapping[str, str]) -> CommandResult:
        assert timeout_s > 0
        argv = list(argv)
        self.calls.append((argv, dict(env)))
        args = argv[2:]
        out = ""
        if args[:2] == ["list", "devices"]:
            out = json.dumps({"devices": {RUNTIME_ID: self.devices}})
        elif args[:2] == ["list", "runtimes"]:
            out = runtimes_json()
        elif args[0] == "create":
            self.devices.append({"udid": self.created_udid, "name": args[1], "state": "Shutdown",
                                 "deviceTypeIdentifier": args[2], "isAvailable": True})  # fmt: skip
            out = self.created_udid + "\n"
        elif args[0] == "launch":
            out = f"{args[3]}: 4242\n"
        return CommandResult(tuple(argv), 0, out, "")

    def mutating(self) -> list[list[str]]:
        return [argv[2:] for argv, _ in self.calls if argv[2:4] not in (["list", "devices"], ["list", "runtimes"])]


def test_every_call_is_xcrun_simctl_with_developer_dir() -> None:
    runner = FakeRunner()
    Simctl(runner, developer_dir="/X/Developer").list_devices()
    argv, env = runner.calls[0]
    assert argv == ["xcrun", "simctl", "list", "devices", "-j"]
    assert env == {"DEVELOPER_DIR": "/X/Developer"}


@pytest.mark.parametrize(
    "op",
    [
        lambda s: s.boot(FOREIGN),
        lambda s: s.shutdown(FOREIGN),
        lambda s: s.wait_booted(FOREIGN),
        lambda s: s.install(FOREIGN, Path("/tmp/X.app")),
        lambda s: s.launch(FOREIGN, "com.apple.mobilesafari"),
        lambda s: s.terminate(FOREIGN, "com.apple.mobilesafari"),
        lambda s: s.screenshot(FOREIGN, Path("/tmp/never.png")),
        lambda s: s.openurl(FOREIGN, "http://127.0.0.1/"),
        lambda s: s.pin_locale(FOREIGN),
        lambda s: s.status_bar_override(FOREIGN),
    ],
)
def test_foreign_simulator_is_refused_before_any_mutation(op: object) -> None:
    runner = FakeRunner()
    with pytest.raises(NotProjectOwnedError):
        op(Simctl(runner))  # type: ignore[operator]
    assert runner.mutating() == []


def test_create_refuses_unowned_name_without_running() -> None:
    runner = FakeRunner()
    for name in ("iPhone 17", "mobilelab-", "my-mobilelab-x"):
        with pytest.raises(NotProjectOwnedError):
            Simctl(runner).create(name, IPHONE17, RUNTIME_ID)
    assert runner.calls == []


def test_unknown_udid_is_refused() -> None:
    with pytest.raises(DeviceNotFoundError):
        Simctl(FakeRunner()).boot("no-such-udid")


def test_argv_shapes_for_owned_device(tmp_path: Path) -> None:
    runner = FakeRunner()
    sim = Simctl(runner)
    app = tmp_path / "LabMessenger.app"
    app.mkdir()
    sim.boot(OWNED)  # already booted: no boot command
    sim.wait_booted(OWNED)
    sim.install(OWNED, app)
    pid = sim.launch(OWNED, "org.mobilelab.fixtures.LabMessenger", ["-MLRunId", "r1"])
    sim.terminate(OWNED, "org.mobilelab.fixtures.LabMessenger")
    sim.screenshot(OWNED, tmp_path / "shots" / "a.png")
    sim.openurl(OWNED, "http://127.0.0.1:8781/fixture/v1/articles/article-01")
    sim.pin_locale(OWNED)
    sim.shutdown(OWNED)
    assert pid == 4242
    assert runner.mutating() == [
        ["bootstatus", OWNED],
        ["install", OWNED, str(app)],
        ["launch", "--terminate-running-process", OWNED, "org.mobilelab.fixtures.LabMessenger", "-MLRunId", "r1"],
        ["terminate", OWNED, "org.mobilelab.fixtures.LabMessenger"],
        ["io", OWNED, "screenshot", "--type=png", str(tmp_path / "shots" / "a.png")],
        ["openurl", OWNED, "http://127.0.0.1:8781/fixture/v1/articles/article-01"],
        ["spawn", OWNED, "defaults", "write", "Apple Global Domain", "AppleLocale", "-string", "en_GB"],
        ["spawn", OWNED, "defaults", "write", "Apple Global Domain", "AppleLanguages", "-array", "en"],
        ["shutdown", OWNED],
    ]


def test_openurl_rejects_non_http_schemes() -> None:
    with pytest.raises(SimctlError):
        Simctl(FakeRunner()).openurl(OWNED, "sms:+15550000")


def test_install_rejects_non_app_path(tmp_path: Path) -> None:
    with pytest.raises(SimctlError):
        Simctl(FakeRunner()).install(OWNED, tmp_path)


def test_failed_command_raises_with_stderr() -> None:
    def failing(argv: Sequence[str], *, timeout_s: float, env: Mapping[str, str]) -> CommandResult:
        return CommandResult(tuple(argv), 1, "", "boom")

    with pytest.raises(SimctlError, match="boom"):
        Simctl(failing).list_devices()


def test_runtime_and_device_type_selection() -> None:
    runtimes = Simctl(FakeRunner()).list_runtimes()
    rt = select_runtime(runtimes)
    assert rt.identifier == RUNTIME_ID
    assert select_device_type(rt).identifier == IPHONE17
    assert select_device_type(rt, preferred=("iPhone 99",)).product_family == "iPhone"


def test_ensure_creates_then_reuses_and_records(tmp_path: Path) -> None:
    record_path = tmp_path / "ios_simulator.json"
    runner = FakeRunner(devices=[])
    rec = ensure_device(Simctl(runner), record_path=record_path)
    assert rec.udid == runner.created_udid and rec.device_type_name == "iPhone 17"
    assert load_record(record_path) == rec
    creates = [c for c in runner.mutating() if c[0] == "create"]
    assert creates == [["create", "mobilelab-iphone-01", IPHONE17, RUNTIME_ID]]

    again = ensure_device(Simctl(runner), record_path=record_path)
    assert again == rec
    assert len([c for c in runner.mutating() if c[0] == "create"]) == 1


def test_ensure_refuses_unowned_name(tmp_path: Path) -> None:
    with pytest.raises(NotProjectOwnedError):
        ensure_device(Simctl(FakeRunner()), name="iPhone 17", record_path=tmp_path / "r.json")


def test_launch_args_shape() -> None:
    assert lab_messenger_launch_args("http://127.0.0.1:8781", "tok", "run") == [
        "-MLFixtureBaseURL", "http://127.0.0.1:8781", "-MLFixtureToken", "tok", "-MLRunId", "run",
    ]  # fmt: skip

"""Bounded framing of the worker IPC protocol (pure)."""

from __future__ import annotations

import asyncio
import struct

import pytest

from mobilelab.workers.protocol import (
    CONTROL_OPS,
    REQUEST_ADAPTER,
    FenceOp,
    HealthOp,
    ProtocolError,
    Request,
    encode_frame,
    read_frame,
)


def reader_with(data: bytes) -> asyncio.StreamReader:
    r = asyncio.StreamReader()
    r.feed_data(data)
    r.feed_eof()
    return r


async def test_round_trip() -> None:
    frame = encode_frame(Request(msg_id=7, body=FenceOp(control_epoch=3)))
    raw = await read_frame(reader_with(frame))
    assert raw is not None
    req = REQUEST_ADAPTER.validate_json(raw)
    assert req.msg_id == 7 and isinstance(req.body, FenceOp) and req.body.control_epoch == 3


def test_oversized_outgoing_frame_refused() -> None:
    with pytest.raises(ProtocolError):
        encode_frame(Request(msg_id=1, body=HealthOp()), max_bytes=10)


async def test_oversized_incoming_frame_refused_before_reading_body() -> None:
    with pytest.raises(ProtocolError):
        await read_frame(reader_with(struct.pack(">I", 1 << 30)), max_bytes=1024)


async def test_truncated_frame_and_clean_eof() -> None:
    assert await read_frame(reader_with(b"")) is None
    with pytest.raises(ProtocolError):
        await read_frame(reader_with(struct.pack(">I", 50) + b"{}"))


def test_unknown_fields_and_ops_rejected() -> None:
    with pytest.raises(ValueError):
        REQUEST_ADAPTER.validate_json('{"msg_id": 1, "body": {"op": "shell", "cmd": "ls"}}')
    with pytest.raises(ValueError):
        REQUEST_ADAPTER.validate_json('{"msg_id": 1, "body": {"op": "fence", "control_epoch": 1, "x": 1}}')
    assert {"fence", "health", "close", "authorize"} == CONTROL_OPS

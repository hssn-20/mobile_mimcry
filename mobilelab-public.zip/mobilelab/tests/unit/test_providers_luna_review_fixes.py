"""Review fixes for the Luna provider path (LABELLED FAKE backends; NOT AI tests).

* Malformed model URLs get our own fixed messages and the bounded repair (never untyped
  pydantic/ValueError text that repeats the model's string).
* Validation problems never repeat model-chosen field names.
* The spend ledger path is absolute and does not depend on the current directory.
* Child processes never inherit provider credential variables.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any
from uuid import UUID

import pytest

from mobilelab.budget import DEFAULT_LEDGER_DB, BudgetLedger, resolve_ledger_path
from mobilelab.candidates import ScenarioScope, generate_candidates
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import get_persona
from mobilelab.providers import LunaProvider, ProviderOutputInvalid, load_luna_config
from mobilelab.providers.base import build_proposal
from mobilelab.providers.errors import InvalidProposal
from mobilelab.providers.policy_io import OutputValidationError, build_policy_request, parse_policy_output
from mobilelab.secrets import PROVIDER_CREDENTIAL_ENV_VARS, child_env

from mobilelab.budget import TokenUsage
from mobilelab.domain.observations import CandidateAction
from mobilelab.providers.openai_backend import BackendResult

ROOT = Path(__file__).resolve().parents[2]
MARK = "INJECTED-MARKER"
BAD_URLS = [
    f"javascript:alert('{MARK}')",
    f"http://127.0.0.1:8781:{MARK}/x",
    f"http://[{MARK}/x",
    f"http://u:{MARK}@127.0.0.1:8781/",
]


USAGE = TokenUsage(input_tokens=1200, output_tokens=80, cached_input_tokens=0, reasoning_tokens=30, cache_write_tokens=0)


class FakeBackend:
    """LABELLED FAKE backend: scripted outputs, records requests. Not a model."""

    model = "gpt-6-luna"

    def __init__(self, outputs: list[Any]) -> None:
        self.outputs = list(outputs)
        self.calls: list[dict[str, Any]] = []

    async def complete(self, **kw: Any) -> BackendResult:
        self.calls.append(kw)
        out = self.outputs.pop(0)
        return BackendResult(output_text=json.dumps(out), usage=USAGE, request_id=f"req_fake_{len(self.calls)}",
                             response_id=f"resp_fake_{len(self.calls)}", model=self.model, latency_ms=1.0)  # fmt: skip


def answer(index: int, reason: str = "READ_CONTENT", completion: bool = False, **params: Any) -> dict[str, Any]:
    return {"choice": {"candidate_index": index, **params}, "reason_code": reason, "completion": completion}


def idx(cands: list[CandidateAction], key: str) -> int:
    return next(i for i, c in enumerate(cands) if c.semantic_key == key)


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")


def ctx() -> DecisionContext:
    return DecisionContext(run_id=UUID(int=7), persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
                           scenario_version=1, scenario_stage="read_article", goal="Read and reply.",
                           authorized_url_origins=["http://127.0.0.1:8781"], control_epoch=1)  # fmt: skip


def budget() -> DecisionBudget:
    return DecisionBudget(timeout_ms=5000, max_input_tokens=8000, max_output_tokens=1500, max_cost_usd=0.01)


@pytest.mark.parametrize("bad_url", BAD_URLS)
async def test_malformed_model_url_is_repaired_with_own_message(scope: ScenarioScope, tmp_path: Path, bad_url: str) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "url.open:http://127.0.0.1:8781")
    good = cands[i].permitted.url_origins[0] + "/fixture/v1/articles/article-01"
    backend = FakeBackend([answer(i, "NAVIGATE_TO_START", url=bad_url), answer(i, "NAVIGATE_TO_START", url=good)])
    p = LunaProvider(load_luna_config(), backend=backend, ledger=BudgetLedger.open(tmp_path / "l.db"))
    proposal = await p.decide(ctx(), obs, cands, budget())
    assert proposal.parameters.url == good
    assert len(backend.calls) == 2  # the bounded repair ran
    ev = p.last_evidence
    assert ev is not None and ev.outcome == "accepted" and ev.retry_count == 1
    dumped = ev.model_dump_json()
    assert MARK not in dumped and MARK not in backend.calls[1]["user_input"]


@pytest.mark.parametrize("bad_url", BAD_URLS)
async def test_malformed_model_url_twice_is_typed_and_not_echoed(scope: ScenarioScope, tmp_path: Path, bad_url: str) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "url.open:http://127.0.0.1:8781")
    bad = answer(i, "NAVIGATE_TO_START", url=bad_url)
    p = LunaProvider(load_luna_config(), backend=FakeBackend([bad, bad]), ledger=BudgetLedger.open(tmp_path / "l.db"))
    with pytest.raises(ProviderOutputInvalid) as info:
        await p.decide(ctx(), obs, cands, budget())
    assert MARK not in str(info.value) and MARK not in json.dumps(info.value.details)
    assert MARK not in p.last_evidence.model_dump_json()  # type: ignore[union-attr]


@pytest.mark.parametrize("bad_url", BAD_URLS)
def test_build_proposal_wraps_validation_errors_without_input(scope: ScenarioScope, bad_url: str) -> None:
    from mobilelab.domain.proposals import ProposalParameters

    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    cand = cands[idx(cands, "url.open:http://127.0.0.1:8781")]
    with pytest.raises(InvalidProposal) as info:
        build_proposal(ctx(), obs, cand, ProposalParameters(url=bad_url), reason_code="NAVIGATE_TO_START")
    assert MARK not in str(info.value) and MARK not in json.dumps(info.value.details)
    assert info.value.__cause__ is None


def test_validation_problems_never_repeat_model_field_names(scope: ScenarioScope) -> None:
    obs = st.messenger_conversation()
    cands = generate_candidates(obs, scope)
    req = build_policy_request(ctx(), obs, cands, reason_codes=["READ_CONTENT", "WAIT_FOR_STATE"], max_elements=40,
                               text_limit=120, max_input_tokens=8000)  # fmt: skip
    wait = idx(cands, "wait:dwell")
    raw = {"choice": {"candidate_index": wait, "duration_ms": 10, f"{MARK}_param": 1},
           "reason_code": "WAIT_FOR_STATE", "completion": False, f"{MARK}_top" * 50: True}  # fmt: skip
    with pytest.raises(OutputValidationError) as info:
        parse_policy_output(raw, req)
    assert info.value.problems and MARK not in str(info.value)


def test_ledger_path_is_absolute_and_cwd_independent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    assert DEFAULT_LEDGER_DB.is_absolute() and DEFAULT_LEDGER_DB == ROOT / "artifacts" / "mobilelab.db"
    monkeypatch.chdir(tmp_path)
    assert resolve_ledger_path(None) == DEFAULT_LEDGER_DB
    with pytest.raises(ValueError):
        resolve_ledger_path("artifacts/mobilelab.db")
    from mobilelab.providers import registry

    assert registry.DEFAULT_DB_PATH == DEFAULT_LEDGER_DB


def test_registry_builds_luna_ledger_from_other_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Earlier spend in an absolute ledger is still counted when built from another directory."""
    from mobilelab.providers.registry import create_provider

    ledger_db = tmp_path / "budget" / "ledger.db"
    ledger_db.parent.mkdir()
    first = BudgetLedger.open(ledger_db)
    rc = load_luna_config().rate_card
    r = first.reserve(run_id=str(UUID(int=1)), provider_id="luna", rate_card=rc, max_input_tokens=8000,
                      max_output_tokens=1500)  # fmt: skip
    first.mark_unresolved(r, error_class="Timeout")
    spent = first.summary().remaining_usd
    assert spent < 5.0
    first.engine.dispose()
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    p = create_provider("luna", {"backend": FakeBackend([]), "db_path": ledger_db})
    assert p.ledger.summary().remaining_usd == spent  # type: ignore[attr-defined]
    assert not (elsewhere / "artifacts").exists()
    with pytest.raises(ValueError):
        create_provider("luna", {"backend": FakeBackend([]), "db_path": Path("artifacts/x.db")})


def test_child_env_strips_provider_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-canary-child-env-000000000000000000000000")
    env = child_env()
    assert "OPENAI_API_KEY" not in env and not PROVIDER_CREDENTIAL_ENV_VARS & set(env)
    assert env.get("PATH") == os.environ.get("PATH")
    assert "OPENAI_API_KEY" not in child_env(None, OPENAI_API_KEY="x", FOO="1") and child_env(None, FOO="1")["FOO"] == "1"


def test_appium_server_env_has_no_provider_key(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from mobilelab.adapters.appium_server import AppiumServer

    monkeypatch.setenv("OPENAI_API_KEY", "sk-canary-appium-000000000000000000000000000")
    server = AppiumServer.__new__(AppiumServer)
    server.appium_home = tmp_path  # type: ignore[attr-defined]
    server.developer_dir = "/Applications/Xcode.app/Contents/Developer"  # type: ignore[attr-defined]
    env = server.env()
    assert "OPENAI_API_KEY" not in env and env["APPIUM_HOME"] == str(tmp_path)


def test_child_spawn_sites_use_child_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Worker, restart child, fixture service, simctl and doctor subprocesses pass ``child_env``."""
    import mobilelab

    pkg = Path(mobilelab.__file__).parent
    for rel, needle in [("workers/client.py", "env=child_env()"), ("journey/restart.py", "env=child_env()"),
                        ("sim/bringup.py", "env=child_env()"), ("sim/runner.py", "env=child_env(None, **env)"),
                        ("doctor/runner.py", "child_env(None, **overrides)")]:  # fmt: skip
        assert needle in (pkg / rel).read_text(), rel
    monkeypatch.setenv("OPENAI_API_KEY", "sk-canary-worker-0000000000000000000000000000")
    assert "OPENAI_API_KEY" not in child_env()

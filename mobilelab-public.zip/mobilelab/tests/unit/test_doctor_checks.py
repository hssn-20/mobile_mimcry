"""Doctor diagnostics against FIXTURE hosts (fakes). These are not host evidence."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from mobilelab.doctor import (
    CheckStatus,
    DoctorReport,
    EvidenceSource,
    GateStatus,
    GuardedRunner,
    is_read_only,
    run_doctor,
)
from mobilelab.doctor.fakes import (
    CLT_DEV,
    LICENSE_TEXT,
    XCODE_DEV,
    FakeHost,
    FakeRunner,
    devicectl_json,
    fake_device,
    healthy_fixture,
)
from mobilelab.doctor.runner import CommandNotAllowedError

ROOT = Path("/fixture/project")
SIM_GATE = "m1_ios_simulator"


def doctor(runner: FakeRunner, host: FakeHost) -> DoctorReport:
    return run_doctor(runner=runner, host=host, project_root=ROOT, evidence_source=EvidenceSource.FIXTURE)


@pytest.fixture
def healthy() -> tuple[FakeRunner, FakeHost]:
    return healthy_fixture(ROOT)


def test_healthy_fixture_is_ready(healthy: tuple[FakeRunner, FakeHost]) -> None:
    report = doctor(*healthy)
    not_ready = [c.id for c in report.checks if c.status is not CheckStatus.READY and c.id != "xcodegen"]
    assert not_ready == []
    assert report.gate(SIM_GATE).status is GateStatus.READY
    assert report.gate("m1_core").status is GateStatus.READY
    assert report.check("project_simulators").details["simulators"][0]["name"] == "mobilelab-iphone-1"
    assert len(report.check("project_simulators").details["simulators"]) == 1  # personal sim ignored
    assert report.evidence_source is EvidenceSource.FIXTURE


def test_clt_only_without_xcode_gives_actionable_diagnostic(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    host.bundles.clear()
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    runner.set(["xcodebuild", "-version"], returncode=1,
               stderr="xcode-select: error: tool 'xcodebuild' requires Xcode")
    report = doctor(runner, host)

    xcode = report.check("xcode_full")
    assert xcode.status is CheckStatus.MISSING
    assert "Install full Xcode" in (xcode.remedy or "")
    assert xcode.manual_action_required
    assert report.check("xcode_select").status is CheckStatus.MISSING
    assert report.check("simctl").status is CheckStatus.MISSING
    assert report.check("ios_runtime").status is CheckStatus.MISSING
    gate = report.gate(SIM_GATE)
    assert gate.status is GateStatus.BLOCKED
    assert "xcode_full" in gate.blocked_by
    assert gate.summary.startswith("M1 iOS Simulator slice: BLOCKED by")
    assert "Full Xcode installed [missing]" in gate.summary
    # fixture/core work is independent of Xcode
    assert report.gate("m1_core").status is GateStatus.READY
    # simctl is never invoked without a full Xcode
    assert not any(argv[:2] == ("xcrun", "simctl") for argv, _ in runner.calls)


def test_unselected_xcode_bundle_is_probed_via_developer_dir(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    report = doctor(runner, host)

    select = report.check("xcode_select")
    assert select.status is CheckStatus.INCOMPATIBLE
    assert f"sudo xcode-select -s {XCODE_DEV}" in (select.remedy or "")
    assert report.check("xcode_full").status is CheckStatus.READY
    simctl_envs = [env for argv, env in runner.calls if argv[:2] == ("xcrun", "simctl")]
    assert simctl_envs and all(env == {"DEVELOPER_DIR": XCODE_DEV} for env in simctl_envs)
    assert report.gate(SIM_GATE).blocked_by == ["xcode_select"]


def test_licence_not_accepted_is_detected_never_accepted(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcodebuild", "-license", "check"], returncode=69, stderr=LICENSE_TEXT)
    report = doctor(runner, host)

    lic = report.check("xcode_license")
    assert lic.status is CheckStatus.MISSING
    assert lic.manual_action_required
    assert "requires manual completion" in (lic.remedy or "").lower()
    assert "sudo xcodebuild -license" in (lic.remedy or "")
    for dependent in ("simctl", "ios_runtime", "xcode_first_launch"):
        assert report.check(dependent).status is CheckStatus.UNKNOWN
    assert "xcode_license" in report.gate(SIM_GATE).blocked_by
    issued = [argv for argv, _ in runner.calls]
    assert ("xcodebuild", "-license", "accept") not in issued
    assert ("xcodebuild", "-license") not in issued


def test_no_simulator_runtimes(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout=json.dumps({"runtimes": []}))
    report = doctor(runner, host)
    runtime = report.check("ios_runtime")
    assert runtime.status is CheckStatus.MISSING
    assert runtime.observed == "none installed"
    assert "Settings > Components" in (runtime.remedy or "")
    assert report.gate(SIM_GATE).blocked_by == ["ios_runtime"]


def test_too_old_runtime_is_incompatible(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout=json.dumps({"runtimes": [
        {"name": "iOS 17.5", "version": "17.5", "platform": "iOS", "isAvailable": True}]}))
    assert doctor(runner, host).check("ios_runtime").status is CheckStatus.INCOMPATIBLE


@pytest.mark.parametrize(("version", "expected"), [
    ("18.0", CheckStatus.READY), ("18.6", CheckStatus.READY), ("26.4", CheckStatus.READY),
    ("27.0", CheckStatus.READY), ("26.0", CheckStatus.INCOMPATIBLE), ("26.1", CheckStatus.INCOMPATIBLE),
    ("26.3", CheckStatus.INCOMPATIBLE), ("17.5", CheckStatus.INCOMPATIBLE),
])
def test_runtime_support_matrix(healthy: tuple[FakeRunner, FakeHost], version: str,
                                expected: CheckStatus) -> None:
    runner, host = healthy
    runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout=json.dumps({"runtimes": [
        {"name": f"iOS {version}", "version": version, "platform": "iOS", "isAvailable": True}]}))
    report = doctor(runner, host)
    runtime = report.check("ios_runtime")
    assert runtime.status is expected
    if expected is CheckStatus.INCOMPATIBLE:
        assert "26.4" in (runtime.remedy or "") and runtime.manual_action_required
        assert report.gate(SIM_GATE).status is GateStatus.BLOCKED
        assert report.gate(SIM_GATE).blocked_by == ["ios_runtime"]
    else:
        assert report.gate(SIM_GATE).status is GateStatus.READY


def test_unavailable_supported_runtime_is_not_ready(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout=json.dumps({"runtimes": [
        {"name": "iOS 26.4", "version": "26.4", "platform": "iOS", "isAvailable": False}]}))
    runtime = doctor(runner, host).check("ios_runtime")
    assert runtime.status is CheckStatus.INCOMPATIBLE
    assert runtime.observed == "iOS 26.4 (unavailable)"


def test_old_xcode_is_incompatible(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcodebuild", "-version"], stdout="Xcode 15.4\nBuild version 15F31d\n")
    assert doctor(runner, host).check("xcode_full").status is CheckStatus.INCOMPATIBLE


def test_appium_missing(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    appium_dir = ROOT / "tools" / "appium"
    del host.files[str(appium_dir / "node_modules" / ".bin" / "appium")]
    del host.files[str(appium_dir / ".appium" / "node_modules" / "appium-xcuitest-driver" / "package.json")]
    report = doctor(runner, host)
    appium = report.check("appium")
    assert appium.status is CheckStatus.MISSING
    assert "npm ci" in (appium.remedy or "")
    driver = report.check("appium_driver_xcuitest")
    assert driver.status is CheckStatus.MISSING
    assert "appium-xcuitest-driver@12.14.0" in (driver.remedy or "")
    assert {"appium", "appium_driver_xcuitest"} <= set(report.gate(SIM_GATE).blocked_by)


def test_appium_two_on_path_is_incompatible(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    del host.files[str(ROOT / "tools" / "appium" / "node_modules" / ".bin" / "appium")]
    host.on_path.add("appium")
    runner.set(["appium", "--version"], stdout="2.19.0\n")
    report = doctor(runner, host)
    assert report.check("appium").status is CheckStatus.INCOMPATIBLE
    assert report.check("appium").details["source"] == "PATH"


def test_driver_version_mismatch(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    path = ROOT / "tools" / "appium" / ".appium" / "node_modules" / "appium-xcuitest-driver" / "package.json"
    host.files[str(path)] = json.dumps({"version": "11.0.0"})
    assert doctor(runner, host).check("appium_driver_xcuitest").status is CheckStatus.INCOMPATIBLE


def test_busy_ports_and_old_node(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    host.busy_ports = {8781, 4723}
    runner.set(["node", "--version"], stdout="v18.20.0\n")
    report = doctor(runner, host)
    assert report.check("port_8781").status is CheckStatus.INCOMPATIBLE
    assert "lsof" in (report.check("port_8781").remedy or "")
    assert report.check("port_8782").status is CheckStatus.READY
    assert report.check("node").status is CheckStatus.INCOMPATIBLE
    assert report.gate("m1_core").status is GateStatus.BLOCKED


def test_physical_inventory_redacts_and_signing(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    report = doctor(runner, host)
    devices = report.check("physical_devices")
    assert devices.status is CheckStatus.READY
    assert devices.details["devices"] == ["iPhone"]
    dumped = report.model_dump_json()
    for secret in ("Test Phone", "FIXTURE-UDID", "FIXTURE-SERIAL", "FIXTURE-COREDEVICE-ID"):
        assert secret not in dumped  # names, UDIDs and serials are never recorded
    signing = report.check("signing_identities")
    assert signing.status is CheckStatus.READY
    assert "Apple Development" not in report.model_dump_json()


def test_offline_and_non_ios_devices_are_not_counted(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "devicectl", "list", "devices", "--json-output", "-"], stdout=devicectl_json([
        fake_device("iPhone", "unavailable"), fake_device("appleWatch", "connected", name="Watch"),
        fake_device("mac", "connected", name="Mac")]))
    report = doctor(runner, host)
    devices = report.check("physical_devices")
    assert devices.status is CheckStatus.MISSING
    assert devices.observed == "none connected (1 paired iOS device(s) offline; 2 non-iOS device(s) ignored)"
    assert devices.details["devices"] == []
    assert report.gate("physical_iphone_smoke").status is GateStatus.BLOCKED
    assert "physical_devices" in report.gate("physical_iphone_smoke").blocked_by


def test_connected_ipad_counted_alongside_offline_iphone(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "devicectl", "list", "devices", "--json-output", "-"], stdout=devicectl_json([
        fake_device("iPad", "disconnected"), fake_device("iPhone", "unavailable")]))
    devices = doctor(runner, host).check("physical_devices")
    assert devices.status is CheckStatus.READY
    assert devices.observed == "1 connected: iPad (1 paired iOS device(s) offline)"


def test_devicectl_bad_json_falls_back_to_usb(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcrun", "devicectl", "list", "devices", "--json-output", "-"], stdout="not json")
    runner.set(["system_profiler", "SPUSBHostDataType", "-json"], stdout='{"SPUSBHostDataType": []}')
    devices = doctor(runner, host).check("physical_devices")
    assert devices.status is CheckStatus.MISSING
    assert devices.details["method"].startswith("system_profiler")


def test_swift_with_unusable_xcode_is_unknown_not_clt(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    runner.set(["xcodebuild", "-license", "check"], returncode=1, stderr="xcodebuild: error: something odd")
    report = doctor(runner, host)
    assert report.check("xcode_license").status is CheckStatus.UNKNOWN
    swift = report.check("swift")
    assert swift.status is CheckStatus.UNKNOWN
    assert "Command Line Tools" not in (swift.observed or "")
    assert f"Xcode: {XCODE_DEV.removesuffix('/Contents/Developer')}" in (swift.observed or "")
    assert swift.details["developer_dir"] == XCODE_DEV


def test_swift_licence_blocked_falls_back_and_labels_clt(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    runner.set(["xcodebuild", "-license", "check"], returncode=69, stderr=LICENSE_TEXT)

    class LicenceAwareRunner(FakeRunner):
        def run(self, argv, *, timeout=20.0, env=None):  # type: ignore[no-untyped-def]
            if list(argv) == ["swift", "--version"] and env:
                self.calls.append((tuple(argv), dict(env)))
                from mobilelab.doctor.runner import CommandResult
                return CommandResult(tuple(argv), 69, "", LICENSE_TEXT, None, 1, dict(env))
            return super().run(argv, timeout=timeout, env=env)

    wrapped = LicenceAwareRunner(responses=runner.responses)
    swift = doctor(wrapped, host).check("swift")
    assert swift.status is CheckStatus.UNKNOWN  # Xcode exists; Swift is blocked by the licence, not missing
    assert "(Command Line Tools)" in (swift.observed or "")
    assert swift.details["blocked_by_license"] is True
    assert swift.details["developer_dir"] == CLT_DEV


def test_swift_clt_only_is_incompatible(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    host.bundles.clear()
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    swift = doctor(runner, host).check("swift")
    assert swift.status is CheckStatus.INCOMPATIBLE
    assert swift.observed and swift.observed.endswith("(Command Line Tools)")


def test_usb_fallback_without_xcode(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    host.bundles.clear()
    runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    runner.set(["system_profiler", "SPUSBHostDataType", "-json"], stdout=json.dumps(
        {"SPUSBHostDataType": [{"_name": "USB 3.1 Bus", "_items": [{"_name": "iPhone", "serial_num": "SECRET"}]}]}))
    runner.set(["security", "find-identity", "-v", "-p", "codesigning"], stdout="     0 valid identities found\n")
    report = doctor(runner, host)
    devices = report.check("physical_devices")
    assert devices.observed == "1 connected: iPhone"
    assert "SECRET" not in report.model_dump_json()
    assert report.check("signing_identities").status is CheckStatus.MISSING
    assert not any(argv[:2] == ("xcrun", "devicectl") for argv, _ in runner.calls)


def test_json_output_schema(healthy: tuple[FakeRunner, FakeHost]) -> None:
    report = doctor(*healthy)
    data = json.loads(report.model_dump_json())
    assert set(data) == {"schema_version", "created_at", "evidence_source", "project_root", "checks",
                         "gates", "commands", "read_only"}
    assert data["schema_version"] == 1 and data["read_only"] is True
    assert data["evidence_source"] == "fixture"
    for check in data["checks"]:
        assert set(check) == {"id", "category", "title", "status", "observed", "required", "remedy",
                              "manual_action_required", "details"}
        assert check["status"] in {"ready", "missing", "incompatible", "unknown"}
    assert {g["id"] for g in data["gates"]} == {"m1_core", "m1_ios_simulator", "physical_iphone_smoke"}
    assert all(g["status"] in {"ready", "blocked"} for g in data["gates"])
    ids = [c["id"] for c in data["checks"]]
    assert len(ids) == len(set(ids))
    assert DoctorReport.model_validate_json(report.model_dump_json()) == report


def test_report_rejects_unknown_fields(healthy: tuple[FakeRunner, FakeHost]) -> None:
    data = json.loads(doctor(*healthy).model_dump_json())
    data["surprise"] = True
    with pytest.raises(ValueError):
        DoctorReport.model_validate_json(json.dumps(data))


@pytest.mark.parametrize("scenario", ["healthy", "clt_only", "licence", "no_runtime"])
def test_doctor_only_issues_allowlisted_read_only_commands(scenario: str) -> None:
    runner, host = healthy_fixture(ROOT)
    if scenario == "clt_only":
        host.bundles.clear()
        runner.set(["xcode-select", "-p"], stdout=CLT_DEV + "\n")
    elif scenario == "licence":
        runner.set(["xcodebuild", "-license", "check"], returncode=69, stderr=LICENSE_TEXT)
    elif scenario == "no_runtime":
        runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout='{"runtimes": []}')
    report = doctor(runner, host)
    assert runner.calls, "doctor issued no commands"
    for argv, env in runner.calls:
        assert is_read_only(argv, env), argv
    mutating = {"accept", "install", "erase", "delete", "create", "boot", "-s", "--switch", "-runFirstLaunch",
                "-downloadPlatform", "pair", "uninstall", "shutdown"}
    for argv, _ in runner.calls:
        assert not mutating & set(argv), argv
    assert len(report.commands) == len(runner.calls)


@pytest.mark.parametrize("argv", [
    ["xcodebuild", "-license", "accept"],
    ["sudo", "xcodebuild", "-license"],
    ["xcode-select", "-s", XCODE_DEV],
    ["xcodebuild", "-runFirstLaunch"],
    ["xcodebuild", "-downloadPlatform", "iOS"],
    ["xcrun", "simctl", "erase", "all"],
    ["xcrun", "simctl", "create", "x", "y"],
    ["xcrun", "devicectl", "manage", "pair"],
    ["appium", "driver", "install", "xcuitest"],
    ["npm", "install", "-g", "appium"],
    ["sh", "-c", "uname -m"],
    [],
])
def test_guarded_runner_refuses_mutating_commands(argv: list[str]) -> None:
    inner = FakeRunner()
    guarded = GuardedRunner(inner)
    with pytest.raises(CommandNotAllowedError):
        guarded.run(argv)
    assert inner.calls == []


@pytest.mark.parametrize("argv", [
    ["/tmp/x/xcodebuild", "-version"],
    ["./uname", "-m"],
    ["/usr/local/bin/appium", "--version"],
    ["/fixture/project/tools/appium/node_modules/.bin/appium", "driver", "install", "xcuitest"],
])
def test_guarded_runner_refuses_untrusted_executable_paths(argv: list[str]) -> None:
    inner = FakeRunner()
    guarded = GuardedRunner(inner, trusted_executables={str(ROOT / "tools/appium/node_modules/.bin/appium")})
    with pytest.raises(CommandNotAllowedError):
        guarded.run(argv)
    assert inner.calls == []


def test_guarded_runner_allows_trusted_project_appium() -> None:
    local = str(ROOT / "tools/appium/node_modules/.bin/appium")
    assert is_read_only([local, "--version"], trusted_executables={local})
    assert not is_read_only([local, "--version"])
    assert is_read_only(["appium", "--version"])


def test_doctor_runs_path_appium_by_bare_name(healthy: tuple[FakeRunner, FakeHost]) -> None:
    runner, host = healthy
    del host.files[str(ROOT / "tools" / "appium" / "node_modules" / ".bin" / "appium")]
    host.on_path.add("appium")
    report = doctor(runner, host)
    appium_cmds = [c.argv for c in report.commands if c.argv[-1] == "--version" and "appium" in c.argv[0]]
    assert appium_cmds == [["appium", "--version"]]
    assert report.check("appium").details["binary"] == "/usr/local/bin/appium"


def test_doctor_runs_project_local_appium_by_trusted_path(healthy: tuple[FakeRunner, FakeHost]) -> None:
    report = doctor(*healthy)
    appium_cmds = [c.argv for c in report.commands if "appium" in c.argv[0]]
    assert appium_cmds == [[str(ROOT / "tools/appium/node_modules/.bin/appium"), "--version"]]


def test_guarded_runner_refuses_unexpected_env() -> None:
    guarded = GuardedRunner(FakeRunner())
    with pytest.raises(CommandNotAllowedError):
        guarded.run(["uname", "-m"], env={"PATH": "/tmp/evil"})
    guarded.run(["xcodebuild", "-version"], env={"DEVELOPER_DIR": XCODE_DEV})  # allowed

"""Persona dwell timing (CONTRACTS §8): decision latency counts toward the sampled dwell; the device
waits only for the remainder; overruns are recorded, never hidden."""

from __future__ import annotations

from datetime import timedelta
from types import SimpleNamespace
from typing import Any

from mobilelab.coordinator.engine import DispatchEngine
from mobilelab.domain.actions import Wait
from mobilelab.domain.base import utc_now
from mobilelab.journey.providers import persona_dwell_policy


def _obs(age_ms: float) -> Any:
    return SimpleNamespace(capture_ended_at=utc_now() - timedelta(milliseconds=age_ms))


def test_wait_is_sampled_dwell_minus_elapsed_and_ignores_proposed_duration() -> None:
    proposed = Wait(kind="wait", duration_ms=1000)  # e.g. a model's own choice
    out = DispatchEngine.dwell_remainder(proposed, _obs(3000), 12_000)
    assert 8_900 <= out.duration_ms <= 9_000


def test_latency_beyond_the_dwell_waits_minimum_and_timing_records_the_overrun() -> None:
    out = DispatchEngine.dwell_remainder(Wait(kind="wait", duration_ms=5000), _obs(7000), 4000)
    assert out.duration_ms == 1
    started = utc_now()
    result = SimpleNamespace(started_at=started)
    obs = SimpleNamespace(capture_ended_at=started - timedelta(milliseconds=7000))
    timing = DispatchEngine._wait_timing(out, obs, result, started, 4000)  # noqa: SLF001
    assert timing["sampled_delay_ms"] == 4000 and 2_990 <= timing["timing_overrun_ms"] <= 3_010


def test_dwell_policy_samples_for_models_and_keeps_rules_samples() -> None:
    class Sampler:
        def __init__(self) -> None:
            self.calls = 0

        def sample_dwell(self, category: str) -> Any:
            self.calls += 1
            return SimpleNamespace(sampled_ms=45_000)

    cand = SimpleNamespace(permitted=SimpleNamespace(max_wait_ms=30_000))
    model = SimpleNamespace(provider_info=SimpleNamespace(kind="openai"))
    rules = SimpleNamespace(provider_info=SimpleNamespace(kind="rules"))
    sampler = Sampler()
    read = SimpleNamespace(reason_code="READ_CONTENT", parameters=SimpleNamespace(duration_ms=1000))
    state = SimpleNamespace(reason_code="WAIT_FOR_STATE", parameters=SimpleNamespace(duration_ms=1000))
    assert persona_dwell_policy(model, sampler)(read, cand) == 30_000  # capped by the permitted max
    # A model's reason code cannot opt out of persona timing: a WAIT_FOR_STATE / GOAL_COMPLETE wait is
    # also a harness-sampled dwell, never the model's duration_ms.
    assert persona_dwell_policy(model, sampler)(state, cand) == 30_000
    done = SimpleNamespace(reason_code="GOAL_COMPLETE", parameters=SimpleNamespace(duration_ms=60_000))
    assert persona_dwell_policy(model, sampler)(done, cand) == 30_000
    rules_read = SimpleNamespace(reason_code="READ_DWELL", parameters=SimpleNamespace(duration_ms=9000))
    assert persona_dwell_policy(rules, sampler)(rules_read, cand) == 9000
    assert persona_dwell_policy(rules, sampler)(state, cand) is None  # rules state waits run as scripted
    assert sampler.calls == 3

"""WorkerCore authority checks, serialization and priority fencing (in-process, MOCK adapter).

Mock evidence only: these tests exercise the worker's harness logic, not a device.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import AsyncIterator
from uuid import UUID, uuid4

import pytest

from mobilelab.adapters.mock import MESSENGER_APP, SAFARI_APP, MockAdapter
from mobilelab.domain.actions import Activate, ActionPayload, Wait
from mobilelab.domain.dispatch import DispatchCommand
from mobilelab.domain.enums import EvidenceSource, ExecutionStatus
from mobilelab.domain.errors import DispatchGateClosed, ErrorCode, StaleEpoch
from mobilelab.domain.observations import Observation, ObserveRequest
from mobilelab.workers.core import ArtifactCollector, WorkerCore

LEASE, EPOCH, CTRL = uuid4(), 3, 5


class FakeClock:
    def __init__(self) -> None:
        self.now = 1_000_000_000

    def __call__(self) -> int:
        return self.now

    def advance_ms(self, ms: float) -> None:
        self.now += int(ms * 1_000_000)


def obs_request(device_id: UUID, *, lease_id: UUID = LEASE, epoch: int = EPOCH) -> ObserveRequest:
    return ObserveRequest(
        request_id=uuid4(), device_id=device_id, session_id=uuid4(), lease_id=lease_id, lease_epoch=epoch,
        purpose="dispatch",
    )  # fmt: skip


def command(
    device_id: UUID,
    obs: Observation | UUID,
    *,
    payload: ActionPayload | None = None,
    lease_id: UUID = LEASE,
    lease_epoch: int = EPOCH,
    control_epoch: int = CTRL,
    max_duration_ms: int = 5_000,
) -> DispatchCommand:
    return DispatchCommand(
        command_id=uuid4(), action_id=uuid4(), run_id=uuid4(), device_id=device_id, session_id=uuid4(),
        lease_id=lease_id, lease_epoch=lease_epoch, control_epoch=control_epoch,
        dispatch_observation_id=obs if isinstance(obs, UUID) else obs.observation_id,
        dispatch_candidate_id=uuid4(), payload=payload or Wait(kind="wait", duration_ms=10),
        max_duration_ms=max_duration_ms, trace_id="test",
    )  # fmt: skip


def make(**adapter_kw: object) -> tuple[WorkerCore, MockAdapter]:
    device_id = uuid4()
    adapter = MockAdapter(device_id, foreground_app=MESSENGER_APP, **adapter_kw)  # type: ignore[arg-type]
    return WorkerCore(device_id, adapter, adapter_name="mock"), adapter


@pytest.fixture
async def authorized() -> AsyncIterator[tuple[WorkerCore, MockAdapter]]:
    core, adapter = make()
    await core.authorize(LEASE, EPOCH, CTRL)
    yield core, adapter
    await core.close()


# -- rejection before any adapter call ----------------------------------------------------------


@pytest.mark.parametrize(
    ("change", "code"),
    [
        ({"lease_id": uuid4()}, ErrorCode.STALE_LEASE),
        ({"lease_epoch": EPOCH - 1}, ErrorCode.STALE_EPOCH),
        ({"control_epoch": CTRL - 1}, ErrorCode.STALE_EPOCH),
    ],
)
async def test_stale_authority_rejected_without_adapter_call(
    authorized: tuple[WorkerCore, MockAdapter], change: dict[str, object], code: ErrorCode
) -> None:
    core, adapter = authorized
    obs = await core.observe(obs_request(core.device_id))
    result = await core.execute(command(core.device_id, obs, **change))  # type: ignore[arg-type]
    assert result.status is ExecutionStatus.REJECTED
    assert result.rejection_code is code
    assert result.evidence_source is EvidenceSource.MOCK
    assert adapter.count("execute") == 0


async def test_unknown_observation_rejected(authorized: tuple[WorkerCore, MockAdapter]) -> None:
    core, adapter = authorized
    result = await core.execute(command(core.device_id, uuid4()))
    assert result.rejection_code is ErrorCode.STALE_OBSERVATION
    assert adapter.count("execute") == 0


async def test_freshness_uses_worker_monotonic_clock_two_second_limit() -> None:
    clock = FakeClock()
    device_id = uuid4()
    adapter = MockAdapter(device_id, foreground_app=MESSENGER_APP)
    core = WorkerCore(device_id, adapter, clock_ns=clock)
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(device_id))
        clock.advance_ms(1_999)
        ok = await core.execute(command(device_id, obs))
        assert ok.status is ExecutionStatus.ACKNOWLEDGED
        obs2 = await core.observe(obs_request(device_id))
        clock.advance_ms(2_001)
        stale = await core.execute(command(device_id, obs2))
        assert stale.status is ExecutionStatus.REJECTED
        assert stale.rejection_code is ErrorCode.STALE_OBSERVATION
        assert stale.error is not None and stale.error.details["age_ms"] > 2000
        assert adapter.count("execute") == 1
    finally:
        await core.close()


async def test_unauthorized_worker_rejects_and_observe_refused() -> None:
    core, adapter = make()
    try:
        with pytest.raises(DispatchGateClosed):
            await core.observe(obs_request(core.device_id))
        result = await core.execute(command(core.device_id, uuid4()))
        assert result.rejection_code is ErrorCode.DISPATCH_GATE_CLOSED
        assert adapter.count("observe") == 0 and adapter.count("execute") == 0
    finally:
        await core.close()


async def test_observation_from_previous_authority_not_dispatchable(authorized: tuple[WorkerCore, MockAdapter]) -> None:
    core, adapter = authorized
    obs = await core.observe(obs_request(core.device_id))
    await core.fence(CTRL)
    with pytest.raises(StaleEpoch):
        await core.authorize(LEASE, EPOCH, CTRL)  # a fenced epoch can never be re-authorized
    await core.authorize(LEASE, EPOCH, CTRL + 1)
    result = await core.execute(command(core.device_id, obs, control_epoch=CTRL + 1))
    assert result.rejection_code is ErrorCode.STALE_OBSERVATION
    assert adapter.count("execute") == 0


# -- serialization -------------------------------------------------------------------------------


async def test_one_active_driver_op_under_concurrent_submissions() -> None:
    core, adapter = make(delays_ms={"execute": 150, "observe": 50})
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(core.device_id))
        cmds = [command(core.device_id, obs) for _ in range(3)]
        results = await asyncio.gather(
            *(core.execute(c) for c in cmds), core.observe(obs_request(core.device_id))
        )
        statuses = [r.status for r in results[:3]]  # type: ignore[union-attr]
        assert statuses == [ExecutionStatus.ACKNOWLEDGED] * 3
        assert adapter.max_concurrent_driver_ops == 1
        spans = sorted((c.started_ns, c.ended_ns or 0) for c in adapter.calls if c.op in {"observe", "execute"})
        assert all(prev_end <= start for (_, prev_end), (start, _) in zip(spans, spans[1:], strict=False))
    finally:
        await core.close()


async def test_bounded_driver_queue_rejects_excess() -> None:
    device_id = uuid4()
    adapter = MockAdapter(device_id, delays_ms={"execute": 300})
    core = WorkerCore(device_id, adapter, max_waiting_driver_ops=1)
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(device_id))
        results = await asyncio.gather(*(core.execute(command(device_id, obs)) for _ in range(3)))
        rejected = [r for r in results if r.status is ExecutionStatus.REJECTED]
        assert rejected and all(r.rejection_code is ErrorCode.LEASE_CONFLICT for r in rejected)
        assert adapter.count("execute") == 3 - len(rejected)
    finally:
        await core.close()


# -- fencing -------------------------------------------------------------------------------------


@pytest.mark.parametrize("fault", [{"delays_ms": {"execute": 3000}}, {"block_thread_ms": {"execute": 1500}}])
async def test_fence_acknowledged_during_slow_driver_op_and_no_new_op(fault: dict[str, object]) -> None:
    """Fence is answered on the control lane while a 3 s (or thread-blocking) driver op runs;
    after the confirmed fence no new driver operation starts. The in-flight op may complete."""
    core, adapter = make(**fault)
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(core.device_id))
        slow = command(core.device_id, obs)
        running = asyncio.ensure_future(core.execute(slow))
        await asyncio.sleep(0.2)
        t0 = time.monotonic()
        fence = await core.fence(CTRL)
        fence_s = time.monotonic() - t0
        assert fence.fenced and fence_s < 0.2
        assert fence.in_flight_command_id == slow.command_id and fence.in_flight_state == "executing"
        health = await core.health() if "delays_ms" in fault else None
        if health is not None:
            assert health.gate_open is False and health.driver_busy
        late = await core.execute(command(core.device_id, obs))
        assert late.rejection_code is ErrorCode.DISPATCH_GATE_CLOSED
        with pytest.raises(DispatchGateClosed):
            await core.observe(obs_request(core.device_id))
        assert (await running).status is ExecutionStatus.ACKNOWLEDGED
        assert adapter.executed_command_ids == [slow.command_id]
    finally:
        await core.close()


async def test_driver_timeout_is_unknown_not_retried() -> None:
    core, adapter = make(hang=["execute"])
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(core.device_id))
        t0 = time.monotonic()
        result = await core.execute(command(core.device_id, obs, max_duration_ms=300))
        assert 0.25 < time.monotonic() - t0 < 2
        assert result.status is ExecutionStatus.UNKNOWN
        assert result.started_at is not None and "not retried" in result.detail
        assert adapter.count("execute") == 1
    finally:
        await core.close()


async def test_driver_exception_after_start_is_unknown() -> None:
    core, adapter = make(raise_on=["execute"])
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(core.device_id))
        result = await core.execute(command(core.device_id, obs))
        assert result.status is ExecutionStatus.UNKNOWN
        assert result.error is not None and "injected" in result.error.message
    finally:
        await core.close()


# -- artifacts and semantics ---------------------------------------------------------------------


async def test_artifacts_via_collector_are_labelled_mock() -> None:
    device_id = uuid4()
    collector = ArtifactCollector()
    adapter = MockAdapter(device_id, foreground_app=SAFARI_APP, artifact_sink=collector)
    core = WorkerCore(device_id, adapter, artifact_collector=collector)
    await core.authorize(LEASE, EPOCH, CTRL)
    try:
        obs = await core.observe(obs_request(device_id))
        blobs = core.take_artifacts(obs.observation_id)
        assert [b.artifact_id for b in blobs] == [obs.screenshot_artifact_id]
        assert blobs[0].evidence_source is EvidenceSource.MOCK and b"MOCK SCREENSHOT" in blobs[0].data
        assert obs.evidence_source is EvidenceSource.MOCK
    finally:
        await core.close()


async def test_mock_refuses_generic_activate_on_send(authorized: tuple[WorkerCore, MockAdapter]) -> None:
    core, adapter = authorized
    adapter.state.messenger_screen, adapter.state.conversation_id = "conversation", "fixture-conversation-01"
    adapter.state.composer_text = "hello"
    obs = await core.observe(obs_request(core.device_id))
    result = await core.execute(command(core.device_id, obs, payload=Activate(kind="activate", element_ref="composer.send")))
    assert result.status is ExecutionStatus.FAILED
    assert adapter.state.messages == []

"""Run lifecycle (CONTRACTS §7, §11) and action status (§6) transition tables."""

from __future__ import annotations

import itertools

import pytest

from mobilelab.domain.enums import ActionStatus as A
from mobilelab.domain.enums import RunStatus as R
from mobilelab.domain.enums import SideEffectClass
from mobilelab.domain.errors import ErrorCode, InvalidTransition, TerminalRecordImmutable
from mobilelab.domain.transitions import (
    auto_retry_permitted,
    can_transition_action,
    can_transition_run,
    transition_action,
    transition_run,
)

# Transcribed literally from CONTRACTS §7.
EXPECTED_RUN = {
    (R.CREATED, R.PREFLIGHT),
    (R.PREFLIGHT, R.READY),
    (R.READY, R.RUNNING),
    (R.RUNNING, R.COMPLETED),
    (R.PREFLIGHT, R.FAILED),
    (R.RUNNING, R.PAUSING),
    (R.PAUSING, R.PAUSED),
    (R.PAUSED, R.RUNNING),
    *((s, R.STOPPING) for s in (R.PREFLIGHT, R.READY, R.RUNNING, R.PAUSING, R.PAUSED)),
    (R.STOPPING, R.ABORTED),
    *((s, R.FAILED) for s in (R.RUNNING, R.PAUSING, R.PAUSED)),
    (R.CREATED, R.ABORTED),
}

# Transcribed literally from CONTRACTS §6.
EXPECTED_ACTION = {
    (A.PROPOSED, A.VALIDATED),
    (A.VALIDATED, A.SCHEDULED),
    (A.SCHEDULED, A.PREPARED),
    (A.PREPARED, A.DISPATCHED),
    (A.DISPATCHED, A.ACKNOWLEDGED),
    (A.ACKNOWLEDGED, A.VERIFIED),
    (A.DISPATCHED, A.UNKNOWN),
    (A.ACKNOWLEDGED, A.UNKNOWN),
    (A.ACKNOWLEDGED, A.FAILED),
    *((s, t) for s in (A.PROPOSED, A.VALIDATED, A.SCHEDULED, A.PREPARED) for t in (A.CANCELLED, A.REJECTED)),
    (A.UNKNOWN, A.VERIFIED),
    (A.UNKNOWN, A.FAILED),
    (A.UNKNOWN, A.UNRESOLVED),
}


@pytest.mark.parametrize(("src", "dst"), list(itertools.product(R, R)))
def test_run_transition_matrix_matches_contract(src: R, dst: R) -> None:
    allowed = (src, dst) in EXPECTED_RUN
    assert can_transition_run(src, dst) is allowed
    if allowed:
        step = transition_run(src, dst)
        assert (step.source, step.target, step.recovery) == (src, dst, False)
    else:
        with pytest.raises(InvalidTransition) as exc:
            transition_run(src, dst)
        assert exc.value.code in {ErrorCode.INVALID_TRANSITION, ErrorCode.TERMINAL_RECORD_IMMUTABLE}


@pytest.mark.parametrize(
    ("src", "dst"),
    [
        (R.CREATED, R.RUNNING),
        (R.PREFLIGHT, R.RUNNING),
        (R.PREFLIGHT, R.PAUSING),
        (R.READY, R.COMPLETED),
        (R.PAUSED, R.COMPLETED),
        (R.PAUSING, R.RUNNING),
        (R.STOPPING, R.COMPLETED),
        (R.STOPPING, R.RUNNING),
        (R.CREATED, R.FAILED),
    ],
)
def test_forbidden_run_transitions(src: R, dst: R) -> None:
    with pytest.raises(InvalidTransition):
        transition_run(src, dst)


@pytest.mark.parametrize("terminal", [R.COMPLETED, R.FAILED, R.ABORTED])
@pytest.mark.parametrize("target", list(R))
def test_terminal_runs_are_immutable(terminal: R, target: R) -> None:
    with pytest.raises(TerminalRecordImmutable) as exc:
        transition_run(terminal, target)
    assert exc.value.to_envelope().current_state == {"status": terminal.value}
    with pytest.raises(TerminalRecordImmutable):
        transition_run(terminal, R.PAUSING, recovery=True)


def test_failed_preflight_is_not_resumed_in_place() -> None:
    with pytest.raises(TerminalRecordImmutable):
        transition_run(R.FAILED, R.PREFLIGHT)


@pytest.mark.parametrize("src", [R.RUNNING, R.PAUSING])
def test_recovery_transition_into_pausing_is_flagged(src: R) -> None:
    step = transition_run(src, R.PAUSING, recovery=True)
    assert step.recovery is True and step.target is R.PAUSING


def test_pausing_to_pausing_requires_recovery_flag() -> None:
    with pytest.raises(InvalidTransition):
        transition_run(R.PAUSING, R.PAUSING)


@pytest.mark.parametrize("src", [R.CREATED, R.PREFLIGHT, R.READY, R.PAUSED, R.STOPPING])
def test_recovery_only_from_running_or_pausing(src: R) -> None:
    with pytest.raises(InvalidTransition):
        transition_run(src, R.PAUSING, recovery=True)


def test_recovery_flag_cannot_reach_other_targets() -> None:
    with pytest.raises(InvalidTransition):
        transition_run(R.RUNNING, R.PAUSED, recovery=True)


@pytest.mark.parametrize(("src", "dst"), list(itertools.product(A, A)))
def test_action_transition_matrix_matches_contract(src: A, dst: A) -> None:
    allowed = (src, dst) in EXPECTED_ACTION
    assert can_transition_action(src, dst) is allowed
    if allowed:
        assert transition_action(src, dst) is dst
    else:
        with pytest.raises(InvalidTransition):
            transition_action(src, dst)


@pytest.mark.parametrize(
    ("src", "dst"),
    [
        (A.DISPATCHED, A.CANCELLED),  # cannot cancel once handed to the driver
        (A.DISPATCHED, A.FAILED),  # dispatch outcome must be acknowledged or unknown first
        (A.DISPATCHED, A.VERIFIED),
        (A.UNKNOWN, A.DISPATCHED),  # never retried automatically
        (A.UNRESOLVED, A.VERIFIED),
        (A.PROPOSED, A.DISPATCHED),
        (A.ACKNOWLEDGED, A.CANCELLED),
    ],
)
def test_forbidden_action_transitions(src: A, dst: A) -> None:
    with pytest.raises(InvalidTransition):
        transition_action(src, dst)


@pytest.mark.parametrize("status", [A.DISPATCHED, A.ACKNOWLEDGED, A.UNKNOWN, A.UNRESOLVED, A.VERIFIED])
@pytest.mark.parametrize("side_effect", list(SideEffectClass))
def test_no_automatic_retry_after_possible_execution(status: A, side_effect: SideEffectClass) -> None:
    assert auto_retry_permitted(status, side_effect) is False


def test_failed_commit_is_not_auto_retried() -> None:
    assert auto_retry_permitted(A.FAILED, SideEffectClass.NON_IDEMPOTENT_COMMIT) is False
    assert auto_retry_permitted(A.FAILED, SideEffectClass.NAVIGATION) is True
    assert auto_retry_permitted(A.REJECTED, SideEffectClass.NON_IDEMPOTENT_COMMIT) is True

"""Review fixes: no resend after an unreconciled commit, settle needs worker quiescence, gate
admission, host-only Safari scoping, capped oracle results. In-process worker + MOCK adapter
(evidence_source=mock): harness-logic tests, not device evidence."""

from __future__ import annotations

import asyncio
from datetime import timedelta
from pathlib import Path
from uuid import uuid4

from test_coordinator_support import CONV1, REPLY, actions, budget, context, make_rig

from mobilelab.adapters.mock import MESSENGER_APP
from mobilelab.candidates import generate_candidates
from mobilelab.candidates import sample_trees as st
from mobilelab.coordinator import OutcomeKind
from mobilelab.coordinator.types import RecoveryReport
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import GateState
from mobilelab.domain.enums import ActionStatus, EvidenceCategory, EvidenceSource, RunStatus, Verdict
from mobilelab.domain.errors import ErrorCode
from mobilelab.domain.scenarios import OracleResult
from mobilelab.journey import load_plan
from mobilelab.journey.evaluate import cap_oracle_result
from mobilelab.journey.loop import LoopLimits, run_loop
from mobilelab.journey.runner import gate_admission_problems

SEND1 = f"messenger.send:{CONV1}"
BASE_URL = "http://127.0.0.1:8781"


def in_conversation(rig) -> None:  # type: ignore[no-untyped-def]
    s = rig.adapter.state
    s.foreground_app, s.messenger_screen, s.conversation_id, s.composer_text = MESSENGER_APP, "conversation", CONV1, REPLY


async def _wait_quiet(rig) -> None:  # type: ignore[no-untyped-def]
    for _ in range(100):
        if not (await rig.worker.health()).driver_busy:
            return
        await asyncio.sleep(0.05)


# -- no blind resend after UNKNOWN (enforced by the engine, not the provider) ----------------------


async def test_engine_refuses_a_second_send_while_the_first_is_unknown(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[(SEND1, {}), (SEND1, {})],
        adapter_kw={"block_thread_ms": {"execute:send_message": 800}}, command_max_duration_ms=300,
    )  # fmt: skip
    in_conversation(rig)
    rid = rig.run.run_id
    await rig.controller.start(rid)
    first = await rig.controller.step(rid, context(rid), budget())
    assert first.kind is OutcomeKind.UNKNOWN
    await _wait_quiet(rig)
    rig.adapter.block_thread_ms.clear()
    in_conversation(rig)  # the send candidate is offered again: only the engine can stop it
    second = await rig.controller.step(rid, context(rid), budget())
    assert second.kind is OutcomeKind.REJECTED and second.error_code is ErrorCode.IDEMPOTENCY_CONFLICT
    statuses = [a.status for a in actions(rig.store, rid)]
    assert statuses == [ActionStatus.UNKNOWN, ActionStatus.REJECTED]
    assert rig.adapter.count("execute") == 1  # the second send never reached the adapter


async def test_loop_stops_for_reconciliation_when_a_commit_is_unknown(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[(SEND1, {})],
        adapter_kw={"block_thread_ms": {"execute:send_message": 800}}, command_max_duration_ms=300,
    )  # fmt: skip
    in_conversation(rig)
    rid = rig.run.run_id
    await rig.controller.start(rid)
    result = await run_loop(rig.controller, rid, context(rid), budget(), limits=LoopLimits(retry_delay_s=0.0))
    assert not result.completed and "reconciliation" in result.stop_reason
    assert [s.outcome for s in result.steps] == ["unknown"]
    await _wait_quiet(rig)


# -- settle requires the worker to be quiescent ------------------------------------------------------


async def test_complete_while_worker_still_executes_is_harness_failure(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[("wait:dwell", {"duration_ms": 10})],
        adapter_kw={"block_thread_ms": {"execute": 3000}}, command_max_duration_ms=300, settle_timeout_s=0.6,
    )  # fmt: skip
    rid = rig.run.run_id
    await rig.controller.start(rid)
    assert (await rig.controller.step(rid, context(rid), budget())).kind is OutcomeKind.UNKNOWN
    run = await rig.controller.complete(rid, verdict=Verdict.INCONCLUSIVE, reason="test")
    assert run.status is RunStatus.FAILED and run.verdict is Verdict.HARNESS_FAILURE
    assert rig.device_id in rig.controller.quarantined
    await _wait_quiet(rig)


async def test_pause_while_worker_still_executes_is_not_ok(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[("wait:dwell", {"duration_ms": 10})],
        adapter_kw={"block_thread_ms": {"execute": 3000}}, command_max_duration_ms=300, settle_timeout_s=0.6,
    )  # fmt: skip
    rid = rig.run.run_id
    await rig.controller.start(rid)
    assert (await rig.controller.step(rid, context(rid), budget())).kind is OutcomeKind.UNKNOWN
    res = await rig.controller.pause(rid)
    assert not res.ok and not res.in_flight_settled and res.quarantined
    assert res.run_status is RunStatus.PAUSING
    await _wait_quiet(rig)


async def test_complete_waits_for_a_short_overrun_to_finish(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[("wait:dwell", {"duration_ms": 10})],
        adapter_kw={"block_thread_ms": {"execute": 700}}, command_max_duration_ms=300, settle_timeout_s=5.0,
    )  # fmt: skip
    rid = rig.run.run_id
    await rig.controller.start(rid)
    assert (await rig.controller.step(rid, context(rid), budget())).kind is OutcomeKind.UNKNOWN
    run = await rig.controller.complete(rid, verdict=Verdict.INCONCLUSIVE, reason="test")
    assert run.status is RunStatus.COMPLETED and rig.device_id not in rig.controller.quarantined
    assert not (await rig.worker.health()).driver_busy


# -- gate admission ------------------------------------------------------------------------------------


def _gate(open_: bool, reason: str) -> GateState:
    return GateState(gate_open=open_, global_epoch=1, reason=reason, updated_at=utc_now(), version=1)


def _recovery(recovered: list, paused: list) -> RecoveryReport:  # type: ignore[type-arg]
    return RecoveryReport(gate_closed=True, recovered_run_ids=recovered, paused_run_ids=paused, completed_at=utc_now())


def test_gate_admission() -> None:
    dev, other = uuid4(), uuid4()
    old = uuid4()
    clean = _recovery([], [])
    assert gate_admission_problems(_gate(False, "initial migration"), clean, {}, dev) == []
    assert gate_admission_problems(_gate(False, "mobilelab run finished (x)"), clean, {}, dev) == []
    assert gate_admission_problems(_gate(True, "mobilelab run: x"), clean, {}, dev) == []
    assert gate_admission_problems(_gate(False, "emergency stop"), clean, {}, dev)
    stuck = _recovery([old], [])
    assert gate_admission_problems(_gate(True, "x"), stuck, {old: dev}, dev)
    assert gate_admission_problems(_gate(True, "x"), stuck, {old: other}, dev) == []
    assert gate_admission_problems(_gate(True, "x"), _recovery([old], [old]), {old: dev}, dev) == []


# -- host-only Safari pages -----------------------------------------------------------------------------


def test_host_only_safari_page_offers_scroll_but_no_label_only_links() -> None:
    scope = load_plan().scope(BASE_URL)
    host_only = {c.semantic_key for c in generate_candidates(st.safari_article(address="Not Secure — 127.0.0.1"), scope)}
    assert "safari.scroll:down" in host_only and not any(k.startswith("safari.link:") for k in host_only)
    verified = {c.semantic_key for c in generate_candidates(st.safari_article(), scope)}
    assert any(k.startswith("safari.link:") for k in verified)
    # an exposed absolute href into the allowed origin is still a known destination
    exposed = {c.semantic_key for c in generate_candidates(st.safari_article(address="‎127.0.0.1", expose_href=True), scope)}
    assert any(k.startswith("safari.link:") for k in exposed)


# -- capped oracle results ------------------------------------------------------------------------------


def _pass_result() -> OracleResult:
    now = utc_now()
    return OracleResult(
        oracle_result_id=uuid4(), run_id=uuid4(), scenario_id="browse_then_reply", oracle_kind="fixture_message_receipt",
        verdict=Verdict.PASS, reason_code="RECEIPT_DELIVERED", obtained_evidence=EvidenceCategory.FIXTURE,
        observation_window_start=now - timedelta(seconds=1), observation_window_end=now,
    )  # fmt: skip


def test_oracle_result_is_capped_without_device_evidence_or_completed_journey() -> None:
    raw = _pass_result()
    assert cap_oracle_result(raw, evidence_source=EvidenceSource.DEVICE, journey_completed=True) is raw
    mock = cap_oracle_result(raw, evidence_source=EvidenceSource.MOCK, journey_completed=True)
    assert (mock.verdict, mock.reason_code, mock.obtained_evidence) == (Verdict.INCONCLUSIVE, "NOT_DEVICE_EVIDENCE", None)
    assert mock.observed["uncapped_verdict"] == "PASS"
    incomplete = cap_oracle_result(raw, evidence_source=EvidenceSource.DEVICE, journey_completed=False)
    assert (incomplete.verdict, incomplete.reason_code) == (Verdict.INCONCLUSIVE, "JOURNEY_INCOMPLETE")

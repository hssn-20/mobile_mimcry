"""Semantic rebinding onto a fresh dispatch observation (SYNTHETIC mock trees, CONTRACTS §4)."""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest

from mobilelab.candidates import ScenarioScope, generate_candidates, rebind
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.enums import Orientation
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposedAction, payload_from_candidate

ROOT = Path(__file__).resolve().parents[2]
SEND = "messenger.send:fixture-conversation-01"


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    from mobilelab.domain.scenarios import ScenarioSpec

    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")


def pick(obs: Observation, scope: ScenarioScope, key: str) -> CandidateAction:
    return next(c for c in generate_candidates(obs, scope) if c.semantic_key == key)


def test_rebind_send_to_fresh_refs(scope: ScenarioScope) -> None:
    old = st.messenger_conversation(ref_prefix="a")
    original = pick(old, scope, SEND)
    fresh = st.messenger_conversation(ref_prefix="b")
    new = rebind(original, fresh, scope)
    assert new is not None
    assert new.candidate_id != original.candidate_id
    assert new.rebound_from_candidate_id == original.candidate_id
    assert new.observation_id == fresh.observation_id
    assert new.target_ref == pick(fresh, scope, SEND).target_ref != original.target_ref
    # The original decision's proposal is still honoured against the rebound candidate.
    proposal = ProposedAction(decision_id=uuid4(), decision_observation_id=old.observation_id,
                              candidate_id=original.candidate_id, reason_code="REPLY")
    payload = payload_from_candidate(new, proposal, client_message_id=uuid4())
    assert payload.element_ref == new.target_ref and payload.contact_id == "fixture-contact-01"


def test_rebind_chain_keeps_root(scope: ScenarioScope) -> None:
    original = pick(st.messenger_conversation(ref_prefix="a"), scope, SEND)
    first = rebind(original, st.messenger_conversation(ref_prefix="b"), scope)
    assert first is not None
    second = rebind(first, st.messenger_conversation(ref_prefix="c"), scope)
    assert second is not None and second.rebound_from_candidate_id == original.candidate_id


@pytest.mark.parametrize(
    "fresh",
    [
        pytest.param(lambda: st.messenger_conversation(draft_id="11111111-1111-4111-8111-111111111111"), id="draft-changed"),
        pytest.param(lambda: st.messenger_conversation(draft_id=None), id="draft-missing"),
        pytest.param(lambda: st.messenger_conversation(orientation=Orientation.LANDSCAPE_LEFT), id="orientation"),
        pytest.param(lambda: st.messenger_conversation(title="Someone else"), id="conversation-changed"),
        pytest.param(lambda: st.messenger_conversation(send_enabled=False), id="send-disabled"),
        pytest.param(lambda: st.messenger_list(), id="screen-changed"),
        pytest.param(lambda: st.safari_article(), id="app-changed"),
    ],
)
def test_rebind_refuses_changed_context(scope: ScenarioScope, fresh) -> None:  # type: ignore[no-untyped-def]
    original = pick(st.messenger_conversation(), scope, SEND)
    assert rebind(original, fresh(), scope) is None


def test_rebind_safari_link_and_scroll(scope: ScenarioScope) -> None:
    old = st.safari_article(ref_prefix="a")
    fresh = st.safari_article(ref_prefix="b")
    for key in ("safari.link:Read next: Counting Tide Pools", "safari.scroll:down"):
        new = rebind(pick(old, scope, key), fresh, scope)
        assert new is not None and new.semantic_key == key
    assert rebind(pick(old, scope, "safari.scroll:down"), st.safari_article(links_visible=False), scope) is not None
    assert rebind(pick(old, scope, "safari.link:Read next: Counting Tide Pools"),
                  st.safari_article(links_visible=False), scope) is None
    assert rebind(pick(old, scope, "safari.scroll:down"), st.safari_article(address="evil.example"), scope) is None


def test_rebind_global_candidates_survive_app_change(scope: ScenarioScope) -> None:
    original = pick(st.safari_article(), scope, "wait:dwell")
    assert rebind(original, st.messenger_list(), scope) is not None

"""SubprocessRunner behaviour (uses only harmless commands) and version helpers."""

from __future__ import annotations

import socket
import sys

import pytest

from mobilelab.doctor.checks_host import node_version_ok
from mobilelab.doctor.context import at_least, parse_version
from mobilelab.doctor.host import RealHostAccess
from mobilelab.doctor.runner import SubprocessRunner


def test_subprocess_runner_captures_output_without_shell() -> None:
    result = SubprocessRunner().run([sys.executable, "-c", "print('a; echo b')"])
    assert result.ok
    assert result.stdout.strip() == "a; echo b"  # argv is not shell-interpreted


def test_subprocess_runner_not_found() -> None:
    result = SubprocessRunner().run(["definitely-not-a-real-binary-mobilelab"])
    assert result.returncode is None and result.error == "not_found" and not result.ok


def test_subprocess_runner_timeout() -> None:
    result = SubprocessRunner().run([sys.executable, "-c", "import time; time.sleep(5)"], timeout=0.2)
    assert result.error == "timeout" and result.returncode is None


def test_subprocess_runner_env_override() -> None:
    result = SubprocessRunner().run([sys.executable, "-c", "import os; print(os.environ['DEVELOPER_DIR'])"],
                                    env={"DEVELOPER_DIR": "/x"})
    assert result.stdout.strip() == "/x"
    assert result.env == {"DEVELOPER_DIR": "/x"}


def test_version_helpers() -> None:
    assert parse_version("Xcode 26.4\nBuild version 17E") == (26, 4)
    assert parse_version("v24.14.1") == (24, 14, 1)
    assert parse_version("nothing") is None
    assert at_least((26,), (16, 0)) and not at_least((15, 4), (16, 0)) and not at_least(None, (1,))
    assert node_version_ok((24, 0, 0)) and node_version_ok((22, 12, 0)) and node_version_ok((20, 19, 1))
    assert not node_version_ok((22, 11, 0)) and not node_version_ok((21, 7, 0)) and not node_version_ok((18, 0))


def _listener(family: socket.AddressFamily, address: str) -> socket.socket:
    sock = socket.socket(family, socket.SOCK_STREAM)
    if family == socket.AF_INET6:
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
    sock.bind((address, 0))
    sock.listen(1)
    return sock


def test_port_available_detects_ipv4_loopback_listener() -> None:
    with _listener(socket.AF_INET, "127.0.0.1") as sock:
        assert RealHostAccess().port_available(sock.getsockname()[1]) is False


def test_port_available_detects_ipv6_only_loopback_listener() -> None:
    try:
        sock = _listener(socket.AF_INET6, "::1")
    except OSError:
        pytest.skip("IPv6 loopback unavailable on this host")
    with sock:
        assert RealHostAccess().port_available(sock.getsockname()[1]) is False


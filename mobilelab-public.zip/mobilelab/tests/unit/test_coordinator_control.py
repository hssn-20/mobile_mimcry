"""Pause, stop, emergency stop and restart recovery (in-process worker, MOCK adapter; not device evidence)."""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from uuid import UUID, uuid4

import pytest
from sqlalchemy import text
from test_coordinator_support import (
    CONV1,
    REPLY,
    RecordingReconciler,
    ScriptedProvider,
    actions,
    budget,
    context,
    make_controller,
    make_rig,
)

from mobilelab.coordinator import OutcomeKind
from mobilelab.domain.base import utc_now
from mobilelab.domain.devices import CloseResult, FenceResult
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionStatus, CommandStatus, EvidenceSource, LeaseStatus, RunStatus
from mobilelab.domain.errors import DispatchGateClosed

ROW1 = f"messenger.conversation:{CONV1}"
SEND1 = f"messenger.send:{CONV1}"


def run_status(rig, run_id: UUID) -> RunStatus:  # type: ignore[no-untyped-def]
    with rig.store.reader() as r:
        return r.get_run(run_id).status


async def test_pause_during_slow_provider_discards_late_result(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {})], provider_delay_s=1.0)
    rid = rig.run.run_id
    await rig.controller.start(rid)
    step = asyncio.ensure_future(rig.controller.step(rid, context(rid), budget()))
    await asyncio.sleep(0.2)
    res = await rig.controller.pause(rid)
    assert res.ok and res.run_status is RunStatus.PAUSED and res.fence_confirmed
    out = await step
    assert out.kind is OutcomeKind.DISCARDED
    with rig.store.reader() as r:
        decisions = [r.get_decision(out.decision_id)] if out.decision_id else []  # type: ignore[arg-type]
    # No result had arrived when the pause cancelled the call: recorded as ``cancelled``, not stale.
    assert [d.outcome for d in decisions] == ["cancelled"]
    assert decisions[0].proposal is None and decisions[0].error is not None
    assert decisions[0].error.details.get("error_class") == "DecisionCancelled"
    await asyncio.sleep(1.0)  # the late provider reply arrives and changes nothing
    assert actions(rig.store, rid) == [] and rig.adapter.count("execute") == 0


async def test_pause_during_delayed_driver_settles_then_paused(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {})], adapter_kw={"delays_ms": {"execute": 1500}})
    rid = rig.run.run_id
    b = await rig.controller.start(rid)
    step = asyncio.ensure_future(rig.controller.step(rid, context(rid), budget()))
    while rig.adapter.count("execute") == 0:
        await asyncio.sleep(0.02)
    t0 = time.monotonic()
    res = await rig.controller.pause(rid)
    assert res.ok and res.run_status is RunStatus.PAUSED and res.in_flight_settled
    assert res.fence is not None and res.fence.in_flight_state == "executing"
    assert time.monotonic() - t0 >= 1.0  # pause waited for the in-flight command to be classified
    assert (await step).kind is OutcomeKind.ACKNOWLEDGED
    (act,) = actions(rig.store, rid)
    assert act.status is ActionStatus.ACKNOWLEDGED
    with rig.store.reader() as r:
        run = r.get_run(rid)
    assert run.control_epoch > b.control_epoch
    # repeated pause issues nothing new
    again = await rig.controller.pause(rid)
    assert again.ok and "no-op" in again.detail and rig.adapter.count("execute") == 1
    # resume: new lease epoch + control epoch, fresh observation, step works
    b2 = await rig.controller.start(rid)
    assert b2.lease_epoch > b.lease_epoch and b2.control_epoch > run.control_epoch
    rig.provider.steps = [("wait:dwell", {"duration_ms": 5})]
    rig.provider.calls = 0
    assert (await rig.controller.step(rid, context(rid), budget())).kind is OutcomeKind.ACKNOWLEDGED


async def test_pause_with_hung_command_reports_failure_and_quarantines(tmp_path: Path) -> None:
    rig = make_rig(
        tmp_path, steps=[(ROW1, {})], adapter_kw={"delays_ms": {"execute": 3000}}, settle_timeout_s=0.5,
    )  # fmt: skip
    rid = rig.run.run_id
    await rig.controller.start(rid)
    step = asyncio.ensure_future(rig.controller.step(rid, context(rid), budget()))
    while rig.adapter.count("execute") == 0:
        await asyncio.sleep(0.02)
    res = await rig.controller.pause(rid)
    assert not res.ok and res.fence_confirmed and not res.in_flight_settled and res.quarantined
    assert res.run_status is RunStatus.PAUSING  # never a false PAUSED
    with rig.store.reader() as r:
        assert r.get_command(res.command_id).status is CommandStatus.FAILED
    assert rig.device_id in rig.controller.quarantined
    await step


async def test_stop_aborts_and_releases_lease(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    rid = rig.run.run_id
    b = await rig.controller.start(rid)
    res = await rig.controller.stop(rid)
    assert res.ok and res.run_status is RunStatus.ABORTED
    with rig.store.reader() as r:
        assert r.get_active_lease(rig.device_id) is None
        assert r.get_run(rid).status is RunStatus.ABORTED
    health = await rig.worker.health()
    assert not health.gate_open and health.fenced_through_epoch == b.control_epoch


async def test_emergency_stop_during_driver_latency(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {})], adapter_kw={"delays_ms": {"execute": 2000}})
    rid = rig.run.run_id
    b = await rig.controller.start(rid)
    step = asyncio.ensure_future(rig.controller.step(rid, context(rid), budget()))
    while rig.adapter.count("execute") == 0:
        await asyncio.sleep(0.02)
    res = await rig.controller.emergency_stop()
    assert res.fully_fenced and res.fence_acknowledged_at is not None
    assert (res.fence_acknowledged_at - res.gate_persisted_at).total_seconds() < 1.0
    (dev,) = res.devices
    assert dev.fenced and dev.in_flight_state == "executing"
    with rig.store.reader() as r:
        gate = r.get_gate()
        assert not gate.gate_open and gate.global_epoch == res.global_epoch
        assert r.get_command(res.command_id).status is CommandStatus.SUCCEEDED
    out = await step  # the one already-executing command may complete
    assert out.kind is OutcomeKind.ACKNOWLEDGED
    with pytest.raises(DispatchGateClosed):  # no new command after confirmed fencing
        await rig.controller.engine.capture(rig.worker, b, "decision")
    assert rig.adapter.count("execute") == 1


class HungWorker:
    """A worker whose control lane never answers (stands in for a wedged process)."""

    evidence_source = EvidenceSource.MOCK

    def __init__(self) -> None:
        self.device_id = uuid4()

    async def fence(self, control_epoch: int) -> FenceResult:
        await asyncio.Event().wait()
        raise AssertionError

    async def close(self) -> CloseResult:
        return CloseResult(device_id=self.device_id, closed=True)


async def test_emergency_stop_pending_when_worker_does_not_confirm(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    hung = HungWorker()
    rig.controller.attach_worker(hung)  # type: ignore[arg-type]
    t0 = time.monotonic()
    res = await rig.controller.emergency_stop()
    assert time.monotonic() - t0 < 1.5
    assert not res.fully_fenced and res.fence_acknowledged_at is None
    status = {d.device_id: d for d in res.devices}
    assert status[rig.device_id].fenced and not status[hung.device_id].fenced
    assert hung.device_id in rig.controller.quarantined
    with rig.store.reader() as r:
        cmd = r.get_command(res.command_id)
        assert not r.get_gate().gate_open
    assert cmd.status is CommandStatus.FAILED and cmd.error is not None  # visible harness failure


# -- restart recovery ----------------------------------------------------------------------------


async def test_restart_after_acknowledged_send_reconciles_without_redispatch(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(SEND1, {})])
    s = rig.adapter.state
    s.messenger_screen, s.conversation_id, s.composer_text = "conversation", CONV1, REPLY
    rid = rig.run.run_id
    b = await rig.controller.start(rid)
    assert (await rig.controller.step(rid, context(rid), budget())).kind is OutcomeKind.ACKNOWLEDGED
    # "crash": abandon the controller; a new coordinator instance opens the same database
    reconciler = RecordingReconciler("VERIFIED")
    fresh = make_controller(rig.store, rig.artifacts, ScriptedProvider([]), reconciler)
    report = await fresh.recover()
    assert report.gate_closed and report.redispatched == 0
    assert report.revoked_lease_ids == [b.lease_id]
    assert report.recovered_run_ids == [rid] and report.paused_run_ids == [rid]
    (act,) = actions(rig.store, rid)
    assert [a.action_id for a in reconciler.seen] == [act.action_id]
    assert act.status is ActionStatus.VERIFIED
    with rig.store.reader() as r:
        run = r.get_run(rid)
        assert r.get_active_lease(rig.device_id) is None
    assert run.status is RunStatus.PAUSED
    assert rig.adapter.count("execute") == 1 and len(s.messages) == 1
    # the old worker authority is stale for the new coordinator: its lease is revoked
    with rig.store.reader() as r, pytest.raises(Exception, match="not active"):
        r.check_lease(b.lease_id, b.lease_epoch)


async def test_restart_while_command_in_flight_keeps_uncertainty(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=[(ROW1, {})], adapter_kw={"delays_ms": {"execute": 3000}})
    rid = rig.run.run_id
    await rig.controller.start(rid)
    step = asyncio.ensure_future(rig.controller.step(rid, context(rid), budget()))
    while rig.adapter.count("execute") == 0:
        await asyncio.sleep(0.02)
    step.cancel()  # coordinator dies while the worker executes
    with pytest.raises(asyncio.CancelledError):
        await step
    (act,) = actions(rig.store, rid)
    assert act.status is ActionStatus.PREPARED
    reconciler = RecordingReconciler("UNRESOLVED")
    report = await make_controller(rig.store, rig.artifacts, ScriptedProvider([]), reconciler).recover()
    (rec,) = report.reconciled
    assert rec.from_status is ActionStatus.DISPATCHED and rec.to_status is ActionStatus.UNRESOLVED
    (act,) = actions(rig.store, rid)
    assert act.status is ActionStatus.UNRESOLVED
    assert rig.adapter.count("execute") == 1  # never re-dispatched
    with rig.store.reader() as r:
        leases = r.session.execute(text("select status from leases")).scalars().all()
    assert set(leases) == {LeaseStatus.REVOKED.value}  # all old leases revoked


async def test_restart_cancels_unsent_actions_and_keeps_run_pausing_on_reconcile_error(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    rid = rig.run.run_id
    b = await rig.controller.start(rid)
    obs = await rig.controller.engine.capture(rig.worker, b, "decision")
    # a journaled-but-unsent action (crash right after SCHEDULED) and a DISPATCHED one
    with rig.store.unit_of_work() as uow:
        cand = obs.candidates[0]
        a1 = uow.add_action(ActionRecord(
            action_id=uuid4(), run_id=rid, device_id=rig.device_id, kind=cand.kind, semantic_key=cand.semantic_key,
            side_effect_class=cand.side_effect_class, decision_observation_id=obs.observation_id,
            original_candidate_id=cand.candidate_id,
        ))  # fmt: skip
        uow.transition_action(a1.action_id, ActionStatus.VALIDATED)

    async def broken(action: ActionRecord) -> None:
        raise RuntimeError("fixture unreachable")

    out = await rig.controller.step(rid, context(rid), budget())
    assert out.kind is OutcomeKind.ACKNOWLEDGED
    ctrl = make_controller(rig.store, rig.artifacts, ScriptedProvider([]), RecordingReconciler())
    ctrl.reconciler = broken
    report = await ctrl.recover()
    assert a1.action_id in report.cancelled_action_ids
    assert report.paused_run_ids == [] and report.recovered_run_ids == [rid]
    assert run_status(rig, rid) is RunStatus.PAUSING  # not PAUSED until reconciliation succeeds
    assert any(r.error and "fixture unreachable" in r.error for r in report.reconciled)
    assert utc_now() >= report.completed_at

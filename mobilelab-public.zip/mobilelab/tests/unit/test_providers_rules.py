"""RulesProvider over a SYNTHETIC in-test journey simulator (hand-built mock trees; not device evidence)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import UUID

import pytest

from mobilelab.candidates import (
    LAB_MESSENGER_BUNDLE_ID,
    SAFARI_BUNDLE_ID,
    ScenarioScope,
    client_message_id_for,
    generate_candidates,
)
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.actions import NavigateUrl, OpenApp, TypeText, Wait
from mobilelab.domain.decisions import DecisionBudget, DecisionContext, HistoryEntry
from mobilelab.domain.enums import ActionKind, ActionStatus, TypingMode
from mobilelab.domain.errors import ProviderError
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposedAction, payload_from_candidate
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import PersonaSampler, get_persona
from mobilelab.providers import (
    BrowseThenReplyScript,
    DecisionProvider,
    ExpectedCandidateMissing,
    ProviderCancelled,
    ProviderInputError,
    RulesProvider,
)

ROOT = Path(__file__).resolve().parents[2]
BASE = "http://127.0.0.1:8781"
RUN_ID = UUID("00000000-0000-4000-8000-00000000aaaa")
REPLY = "I have finished reading the article."


def load_spec(name: str = "browse_then_reply") -> ScenarioSpec:
    return ScenarioSpec.from_yaml((ROOT / f"configs/scenarios/{name}.yaml").read_text())


def budget(cancel: asyncio.Event | None = None) -> DecisionBudget:
    return DecisionBudget(timeout_ms=1000, max_input_tokens=1, max_output_tokens=1, max_cost_usd=0, cancel_event=cancel)


@dataclass
class Sim:
    """Tiny fake device: renders sample trees and applies payloads. Every observation is evidence_source=mock."""

    app: str | None = "com.apple.springboard"
    article: str = "article-01"
    conv_open: bool = False
    composer: str | None = None
    draft: str = "359683ab-58fe-491d-a2f1-3c66ba7a8ec4"
    statuses: dict[str, str] = field(default_factory=dict)
    n: int = 0

    def observe(self) -> Observation:
        self.n += 1
        if self.app == SAFARI_BUNDLE_ID:
            return st.safari_article(self.article, ref_prefix=f"o{self.n}")
        if self.app == LAB_MESSENGER_BUNDLE_ID:
            if not self.conv_open:
                return st.messenger_list(ref_prefix=f"o{self.n}")
            return st.messenger_conversation(composer_text=self.composer, draft_id=self.draft,
                                             statuses=self.statuses, ref_prefix=f"o{self.n}")
        return st.unknown_app("com.apple.springboard", labels=())

    def apply(self, cand: CandidateAction, payload: object, obs: Observation) -> None:
        match cand.semantic_key.split(":")[0]:
            case "url.open":
                assert isinstance(payload, NavigateUrl)
                self.app, self.article = SAFARI_BUNDLE_ID, payload.url.split("/")[-1].split("?")[0]
            case "app.open":
                assert isinstance(payload, OpenApp)
                self.app = payload.app_id
            case "safari.link":
                self.article = "article-02"
            case "messenger.conversation":
                self.conv_open = True
            case "messenger.composer":
                assert isinstance(payload, TypeText)
                self.composer = payload.text
            case "messenger.send":
                self.statuses[str(client_message_id_for(cand, obs))] = "accepted"
                self.composer, self.draft = None, "11111111-1111-4111-8111-111111111111"


@dataclass
class Harness:
    provider: RulesProvider
    scope: ScenarioScope
    sim: Sim = field(default_factory=Sim)
    history: list[HistoryEntry] = field(default_factory=list)
    t: datetime = datetime(2026, 10, 3, tzinfo=UTC)
    log: list[tuple[str, ProposedAction, object]] = field(default_factory=list)

    def context(self) -> DecisionContext:
        return DecisionContext(
            run_id=RUN_ID, persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
            scenario_version=1, scenario_stage=self.provider.stage, goal="g",
            session_history=self.history[-10:], control_epoch=0,
        )

    def record(self, cand: CandidateAction, status: ActionStatus) -> None:
        self.t += timedelta(seconds=1)
        self.history.append(HistoryEntry(at=self.t, kind=cand.kind, semantic_key=cand.semantic_key, status=status))

    async def step(self, status: ActionStatus = ActionStatus.ACKNOWLEDGED, *, apply: bool = True) -> ProposedAction:
        obs = self.sim.observe()
        cands = generate_candidates(obs, self.scope)
        proposal = await self.provider.decide(self.context(), obs, cands, budget())
        cand = next(c for c in cands if c.candidate_id == proposal.candidate_id)  # never an invented ID
        corr = client_message_id_for(cand, obs) if cand.kind is ActionKind.SEND_MESSAGE else None
        payload = payload_from_candidate(cand, proposal, client_message_id=corr)
        if apply:
            self.sim.apply(cand, payload, obs)
        self.record(cand, status)
        self.log.append((cand.semantic_key, proposal, payload))
        return proposal


def make(name: str = "browse_then_reply", *, sampler: PersonaSampler | None = None) -> Harness:
    spec = load_spec(name)
    scope = ScenarioScope.from_scenario(spec, fixture_data_base_url=BASE)
    script = BrowseThenReplyScript.from_scenario(spec, fixture_data_base_url=BASE)
    return Harness(RulesProvider(script, scope, sampler=sampler), scope)


async def run_until_complete(h: Harness, limit: int = 40) -> None:
    for _ in range(limit):
        p = await h.step()
        if p.completion:
            return
    raise AssertionError("journey did not complete")


def test_provider_info_and_protocol() -> None:
    h = make()
    assert isinstance(h.provider, DecisionProvider)
    info = h.provider.provider_info
    assert (info.name, info.kind, info.model, info.deployment) == ("RulesProvider", "rules", None, "local")


async def test_full_journey_from_home_screen() -> None:
    h = make()
    await run_until_complete(h)
    keys = [k for k, _, _ in h.log]
    assert keys == [
        "url.open:http://127.0.0.1:8781",
        "wait:dwell", "safari.scroll:down", "wait:dwell", "safari.scroll:down", "wait:dwell",
        "safari.link:Read next: Counting Tide Pools", "wait:dwell",
        f"app.open:{LAB_MESSENGER_BUNDLE_ID}",
        "messenger.conversation:fixture-conversation-01",
        "messenger.composer:fixture-conversation-01",
        "messenger.send:fixture-conversation-01",
        "wait:dwell",
        f"app.open:{SAFARI_BUNDLE_ID}",
    ]
    nav = h.log[0][2]
    assert isinstance(nav, NavigateUrl) and nav.url == f"{BASE}/fixture/v1/articles/article-01?run_id={RUN_ID}"
    typed = h.log[10][2]
    assert isinstance(typed, TypeText) and typed.text == REPLY and typed.mode is TypingMode.FIELD_SET
    dwell = h.log[1][2]
    assert isinstance(dwell, Wait) and dwell.duration_ms == 9000  # task_focused median reading dwell
    assert isinstance(h.log[12][2], Wait) and h.log[12][2].duration_ms == 5000  # status wait
    assert sum(1 for k in keys if k.startswith("messenger.send")) == 1
    assert h.log[-1][1].completion and not any(p.completion for _, p, _ in h.log[:-1])
    assert h.provider.outcomes["open_article"] == "executed"
    # Progress is derived from history: after the return succeeds it only waits (completion hint), never acts again.
    p = await h.step()
    assert h.provider.stage == "complete"
    assert h.log[-1][0] == "wait:dwell" and p.completion and p.reason_code == "JOURNEY_COMPLETE"


async def test_start_article_shortcut_and_link_skipped_when_absent() -> None:
    h = make()
    h.sim.app = SAFARI_BUNDLE_ID
    orig = h.sim.observe
    h.sim.observe = lambda: (lambda o: o.model_copy(update={"ui_tree": [  # type: ignore[method-assign]
        e for e in o.ui_tree if e.role != "XCUIElementTypeLink"]}))(orig())
    await run_until_complete(h)
    keys = [k for k, _, _ in h.log]
    assert keys[0] == "wait:dwell" and not any(k.startswith(("url.open", "safari.link")) for k in keys)
    assert h.provider.outcomes["open_article"] == "satisfied"
    assert h.provider.outcomes["follow_link"] == "skipped" and h.provider.outcomes["read_linked"] == "skipped"


async def test_unknown_send_is_never_resent() -> None:
    """Suppressed-ack variant: the send ends UNKNOWN; the provider moves on and never proposes it again."""
    h = make("browse_then_reply_suppressed_ack")
    for _ in range(11):
        await h.step()
    assert h.log[-1][0] == "messenger.composer:fixture-conversation-01"
    await h.step(ActionStatus.UNKNOWN, apply=False)  # outcome ambiguous; screen unchanged (Send still offered)
    assert h.log[-1][0] == "messenger.send:fixture-conversation-01"
    rest = []
    for _ in range(5):
        p = await h.step()
        rest.append(h.log[-1][0])
        if p.completion:
            break
    assert "messenger.send:fixture-conversation-01" not in rest
    assert rest == ["wait:dwell", f"app.open:{SAFARI_BUNDLE_ID}"]


async def test_rejected_send_is_proposed_again() -> None:
    h = make()
    for _ in range(11):
        await h.step()
    await h.step(ActionStatus.REJECTED, apply=False)
    await h.step()
    assert [k for k, _, _ in h.log[-2:]] == ["messenger.send:fixture-conversation-01"] * 2


async def test_failed_noncommit_step_is_retried() -> None:
    h = make()
    await h.step(ActionStatus.FAILED, apply=False)
    await h.step()
    assert [k for k, _, _ in h.log] == ["url.open:http://127.0.0.1:8781"] * 2


async def test_missing_expected_candidate_is_no_progress_error() -> None:
    h = make()
    h.sim.app = LAB_MESSENGER_BUNDLE_ID
    h.sim.conv_open = True
    h.provider._cursor = next(i for i, s in enumerate(h.provider._steps) if s.name == "type_reply")
    obs = st.messenger_conversation(title="Someone else")
    cands = generate_candidates(obs, h.scope)
    with pytest.raises(ExpectedCandidateMissing) as exc:
        await h.provider.decide(h.context(), obs, cands, budget())
    assert isinstance(exc.value, ProviderError) and exc.value.details["stage"] == "type_reply"


async def test_cancelled_and_foreign_inputs() -> None:
    h = make()
    obs = h.sim.observe()
    cands = generate_candidates(obs, h.scope)
    ev = asyncio.Event()
    ev.set()
    with pytest.raises(ProviderCancelled):
        await h.provider.decide(h.context(), obs, cands, budget(ev))
    other = st.safari_article()
    with pytest.raises(ProviderInputError):
        await h.provider.decide(h.context(), obs, generate_candidates(other, h.scope), budget())


async def test_proposals_only_reference_supplied_candidates() -> None:
    h = make()
    obs = h.sim.observe()
    cands = generate_candidates(obs, h.scope)
    p = await h.provider.decide(h.context(), obs, cands, budget())
    assert p.candidate_id in {c.candidate_id for c in cands}
    assert p.decision_observation_id == obs.observation_id and p.control_epoch == 0


async def test_sampled_dwell_is_recorded_and_stable_per_step() -> None:
    sampler = PersonaSampler(get_persona("task_focused", 1), run_seed=1, device_id=st.DEVICE_ID, mode="lognormal")
    h = make(sampler=sampler)
    await h.step()  # navigate
    first = await h.step(ActionStatus.FAILED, apply=False)  # dwell failed -> re-proposed with the same duration
    second = await h.step()
    assert first.parameters.duration_ms == second.parameters.duration_ms
    assert len(sampler.draws) == 1 and sampler.draws[0].draw_index == 0
    assert first.parameters.duration_ms == sampler.draws[0].sampled_ms

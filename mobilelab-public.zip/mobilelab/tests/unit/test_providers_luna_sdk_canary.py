"""Real Agents SDK + real OpenAI client wiring against a LABELLED FAKE HTTP transport (no network).

The model answers are scripted by an ``httpx.MockTransport``; this is NOT an AI test. It checks the
request the SDK actually builds (store=false, no tools, typed strict schema, reasoning effort, max
output tokens, no retries, no tracing export) and runs the secret canary: a fake key value must reach
the Authorization header and nowhere else (evidence, ledger DB, logs, exceptions, report-like dumps).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from uuid import UUID

import httpx
import pytest

from mobilelab.budget import BudgetLedger
from mobilelab.candidates import ScenarioScope, generate_candidates
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import get_persona
from mobilelab.providers import LunaProvider, ProviderRequestRejected, create_provider
from mobilelab.secrets import SecretValue

ROOT = Path(__file__).resolve().parents[2]
CANARY = "sk-proj-mobilelab-CANARY-1d2e3f4a5b6c-fake"


def _response_body(text: str) -> dict[str, Any]:
    return {
        "id": "resp_fake_canary", "object": "response", "created_at": 0, "model": "gpt-6-luna", "status": "completed",
        "parallel_tool_calls": False, "tool_choice": "auto", "tools": [],
        "output": [{"type": "message", "id": "msg_1", "role": "assistant", "status": "completed",
                    "content": [{"type": "output_text", "text": text, "annotations": []}]}],
        "usage": {"input_tokens": 1500, "input_tokens_details": {"cached_tokens": 0, "cache_write_tokens": 0},
                  "output_tokens": 60, "output_tokens_details": {"reasoning_tokens": 12}, "total_tokens": 1560},
    }  # fmt: skip


class FakeOpenAIServer:
    """LABELLED FAKE OpenAI endpoint (httpx MockTransport)."""

    def __init__(self, answers: list[Any], status: int = 200) -> None:
        self.answers = answers
        self.status = status
        self.requests: list[httpx.Request] = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        headers = {"x-request-id": f"req_fake_{len(self.requests)}"}
        if self.status != 200:
            return httpx.Response(self.status, headers=headers,
                                  json={"error": {"message": "fake auth failure", "type": "invalid_request_error"}})
        return httpx.Response(200, headers=headers, json=_response_body(json.dumps(self.answers.pop(0))))


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")


def ctx() -> DecisionContext:
    return DecisionContext(run_id=UUID(int=9), persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
                           scenario_version=1, scenario_stage="read_article", goal="Read the article.", control_epoch=2)


BUDGET = DecisionBudget(timeout_ms=10_000, max_input_tokens=8000, max_output_tokens=1500, max_cost_usd=0.01)


def _provider(server: FakeOpenAIServer, db: Path) -> LunaProvider:
    http = httpx.AsyncClient(transport=httpx.MockTransport(server))
    from mobilelab.providers.openai_backend import AgentsSdkBackend

    backend = AgentsSdkBackend(model="gpt-6-luna", reasoning_effort="low", api_key=SecretValue(CANARY, source="env"),
                               base_url="https://fake-openai.invalid/v1", http_client=http)  # fmt: skip
    p = create_provider("luna", {"backend": backend, "ledger": BudgetLedger.open(db)})
    assert isinstance(p, LunaProvider)
    return p


def _assert_no_canary(*blobs: str | bytes) -> None:
    for blob in blobs:
        data = blob if isinstance(blob, bytes) else blob.encode()
        assert CANARY.encode() not in data
        assert CANARY[:12].encode() not in data  # no prefix either


async def test_sdk_request_shape_and_secret_canary(scope: ScenarioScope, tmp_path: Path,
                                                   caplog: pytest.LogCaptureFixture) -> None:  # fmt: skip
    caplog.set_level(logging.DEBUG)
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = next(n for n, c in enumerate(cands) if c.semantic_key == "safari.scroll:down")
    server = FakeOpenAIServer([{"choice": {"candidate_index": i, "direction": "down"}, "reason_code": "SCROLL_CONTENT",
                                "completion": False}])  # fmt: skip
    db = tmp_path / "canary.db"
    p = _provider(server, db)
    proposal = await p.decide(ctx(), obs, cands, BUDGET)
    assert proposal.candidate_id == cands[i].candidate_id

    assert len(server.requests) == 1  # no retries, no tracing export through this client
    req = server.requests[0]
    assert req.url.path.endswith("/responses") and req.headers["authorization"] == f"Bearer {CANARY}"
    body = json.loads(req.content)
    assert body["store"] is False and body["tools"] == [] and body["model"] == "gpt-6-luna"
    assert body["max_output_tokens"] == 1500 and body["reasoning"]["effort"] == "low"
    fmt = body["text"]["format"]
    assert fmt["type"] == "json_schema" and fmt["strict"] is True
    assert [v["properties"]["candidate_index"]["enum"] for v in fmt["schema"]["properties"]["choice"]["anyOf"]] == [
        [n] for n in range(len(cands))]
    assert "input_image" not in req.content.decode()  # text-only

    ev = p.last_evidence
    assert ev is not None and ev.attempts[0].request_id == "req_fake_1" and ev.attempts[0].input_tokens == 1500
    evidence_json = ev.model_dump_json()
    _assert_no_canary(evidence_json, proposal.model_dump_json(), db.read_bytes(), caplog.text,
                      json.dumps(p.ledger.rows(), default=str), json.dumps(p.config.frozen))  # fmt: skip
    for wal in tmp_path.glob("canary.db*"):
        _assert_no_canary(wal.read_bytes())


async def test_rejected_request_error_has_no_secret(scope: ScenarioScope, tmp_path: Path,
                                                   caplog: pytest.LogCaptureFixture) -> None:  # fmt: skip
    caplog.set_level(logging.DEBUG)
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    server = FakeOpenAIServer([], status=401)
    p = _provider(server, tmp_path / "rej.db")
    with pytest.raises(ProviderRequestRejected) as exc:
        await p.decide(ctx(), obs, cands, BUDGET)
    assert len(server.requests) == 1 and exc.value.details["status_code"] == 401
    _assert_no_canary(repr(exc.value), str(exc.value.to_envelope().model_dump()), caplog.text,
                      p.last_evidence.model_dump_json() if p.last_evidence else "")  # fmt: skip
    assert [r["status"] for r in p.ledger.rows()] == ["released"]


def test_tracing_disabled_process_wide(tmp_path: Path) -> None:
    import os

    from agents.tracing import get_trace_provider

    from mobilelab.providers.openai_backend import AgentsSdkBackend

    AgentsSdkBackend(model="gpt-6-luna", reasoning_effort="low", api_key=SecretValue(CANARY, source="env"))
    assert os.environ.get("OPENAI_AGENTS_DISABLE_TRACING") == "1"
    from agents.tracing.traces import NoOpTrace

    assert isinstance(get_trace_provider().create_trace("mobilelab_probe"), NoOpTrace)


def test_sdk_log_records_are_redacted(caplog: pytest.LogCaptureFixture) -> None:
    from mobilelab.providers.openai_backend import install_log_redaction

    install_log_redaction()
    caplog.set_level(logging.DEBUG)
    logging.getLogger("openai.agents").error("Incorrect API key provided: %s", CANARY)
    logging.getLogger("openai").debug("auth %s", CANARY)
    logging.getLogger("openai._base_client").debug("request headers %s", {"Authorization": f"Bearer {CANARY}"})
    _assert_no_canary(caplog.text)

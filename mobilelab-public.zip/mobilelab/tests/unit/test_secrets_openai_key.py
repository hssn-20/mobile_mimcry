"""Secret lookup and redaction. Uses FAKE canary values only; never touches the real Keychain item."""

from __future__ import annotations

import pickle
import subprocess
from typing import Any

import pytest

from mobilelab.secrets import KEYCHAIN_SERVICE, SecretUnavailable, SecretValue, get_openai_api_key

CANARY = "sk-mobilelab-CANARY-7f3a9c1e-not-a-real-key"


def test_env_first_and_redacted() -> None:
    key = get_openai_api_key(environ={"OPENAI_API_KEY": CANARY}, runner=_must_not_run)
    assert key.reveal() == CANARY and key.source == "env"
    for text in (repr(key), str(key), f"{key}", f"{key!r}", f"{key:>80}", repr([key]), repr({"k": key})):
        assert CANARY not in text and "sk-" not in text and str(len(CANARY)) not in text
    with pytest.raises(TypeError):
        pickle.dumps(key)


def _must_not_run(*_a: Any, **_k: Any) -> subprocess.CompletedProcess[str]:
    raise AssertionError("Keychain must not be queried when the env var is set")


def test_keychain_typed_argv_and_no_shell() -> None:
    seen: dict[str, Any] = {}

    def runner(argv: list[str], **kw: Any) -> subprocess.CompletedProcess[str]:
        seen["argv"], seen["kw"] = argv, kw
        return subprocess.CompletedProcess(argv, 0, stdout=CANARY + "\n", stderr="")

    key = get_openai_api_key(environ={}, account="tester", runner=runner)
    assert key.reveal() == CANARY and key.source == "keychain"
    assert seen["argv"] == ["/usr/bin/security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-a", "tester", "-w"]
    assert "shell" not in seen["kw"] and seen["kw"]["timeout"] > 0


def test_keychain_failure_messages_never_leak() -> None:
    def runner(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(argv, 44, stdout=CANARY, stderr=f"denied {CANARY}")

    with pytest.raises(SecretUnavailable) as exc:
        get_openai_api_key(environ={}, account="tester", runner=runner)
    rendered = repr(exc.value) + str(exc.value) + str(exc.value.to_envelope().model_dump())
    assert CANARY not in rendered and exc.value.details["returncode"] == 44

    def timeout_runner(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess[str]:
        raise subprocess.TimeoutExpired(argv, 10, output=CANARY)

    with pytest.raises(SecretUnavailable) as exc2:
        get_openai_api_key(environ={}, account="tester", runner=timeout_runner)
    assert exc2.value.__cause__ is None and CANARY not in repr(exc2.value)


def test_empty_values_rejected_and_keychain_can_be_disabled() -> None:
    with pytest.raises(SecretUnavailable):
        SecretValue("", source="env")
    with pytest.raises(SecretUnavailable):
        get_openai_api_key(environ={"OPENAI_API_KEY": "  "}, allow_keychain=False)

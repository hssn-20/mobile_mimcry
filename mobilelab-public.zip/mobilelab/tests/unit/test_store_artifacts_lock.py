"""Artifact atomic writes / path containment and the single-coordinator lock."""

from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path
from uuid import uuid4

import pytest

from mobilelab.domain.enums import EvidenceSource
from mobilelab.domain.errors import ArtifactPathViolation, CoordinatorLocked
from mobilelab.store import ArtifactStore, CoordinatorLock, Store, lock_path_for


def test_artifact_write_is_atomic_and_metadata_committed(tmp_path: Path) -> None:
    arts = ArtifactStore(tmp_path / "artifacts")
    run_id = uuid4()
    data = b"\x89PNG fake bytes for a mock screenshot"
    meta = arts.write_bytes(
        data, filename="screenshot.png", content_type="image/png", evidence_source=EvidenceSource.MOCK, run_id=run_id
    )
    assert meta.sha256 == hashlib.sha256(data).hexdigest() and meta.size_bytes == len(data)
    assert meta.relative_path.startswith(f"runs/{run_id}/") and not Path(meta.relative_path).is_absolute()
    assert arts.read_bytes(meta) == data
    leftovers = [p.name for p in (tmp_path / "artifacts" / "runs" / str(run_id)).iterdir() if p.name.startswith(".tmp-")]
    assert leftovers == []

    store = Store.open(tmp_path / "lab.db")
    with store.unit_of_work() as uow:
        uow.add_artifact(meta)
    with store.reader() as uow:
        assert uow.get_artifact(meta.artifact_id).sha256 == meta.sha256
        assert [a.artifact_id for a in uow.list_artifacts(run_id=run_id)] == [meta.artifact_id]
    store.close()


def test_artifact_digest_mismatch_detected(tmp_path: Path) -> None:
    arts = ArtifactStore(tmp_path)
    meta = arts.write_bytes(b"abc", filename="log.txt", content_type="text/plain", evidence_source=EvidenceSource.DEVICE)
    arts.resolve(meta.relative_path).write_bytes(b"tampered")
    with pytest.raises(ArtifactPathViolation):
        arts.read_bytes(meta)


@pytest.mark.parametrize(
    "rel",
    [
        "../outside.txt",
        "runs/../../etc/passwd",
        "/etc/passwd",
        "runs/./x",
        "",
        "runs\\..\\x",
        "a\x00b",
        ".",
    ],
)
def test_artifact_path_containment(tmp_path: Path, rel: str) -> None:
    arts = ArtifactStore(tmp_path / "root")
    with pytest.raises(ArtifactPathViolation):
        arts.resolve(rel)


def test_symlink_escape_rejected(tmp_path: Path) -> None:
    root = tmp_path / "root"
    arts = ArtifactStore(root)
    outside = tmp_path / "secret"
    outside.mkdir()
    (outside / "key.txt").write_text("secret")
    os.symlink(outside, root / "link")
    with pytest.raises(ArtifactPathViolation):
        arts.resolve("link/key.txt")


@pytest.mark.parametrize("name", ["../x.png", ".hidden", "a/b.png", "x" * 200, "sp ace.png"])
def test_unsafe_filenames_rejected(tmp_path: Path, name: str) -> None:
    with pytest.raises(ArtifactPathViolation):
        ArtifactStore(tmp_path).write_bytes(
            b"x", filename=name, content_type="image/png", evidence_source=EvidenceSource.MOCK
        )


def test_coordinator_lock_is_exclusive_in_process(tmp_path: Path) -> None:
    db = tmp_path / "lab.db"
    first = CoordinatorLock(db)
    first.acquire()
    assert lock_path_for(db).exists()
    with pytest.raises(CoordinatorLocked) as exc:
        CoordinatorLock(db).acquire()
    assert exc.value.details["holder_pid"] == str(os.getpid())
    first.release()
    with CoordinatorLock(db) as again:
        assert again.held


def test_coordinator_lock_is_exclusive_across_processes(tmp_path: Path) -> None:
    db = tmp_path / "lab.db"
    probe = (
        "import sys\n"
        "from mobilelab.store import CoordinatorLock\n"
        "from mobilelab.domain.errors import CoordinatorLocked\n"
        "try:\n"
        f"    CoordinatorLock({str(db)!r}).acquire()\n"
        "except CoordinatorLocked:\n"
        "    sys.exit(3)\n"
        "sys.exit(0)\n"
    )
    with CoordinatorLock(db):
        blocked = subprocess.run([sys.executable, "-c", probe], timeout=30, check=False)
        assert blocked.returncode == 3
    free = subprocess.run([sys.executable, "-c", probe], timeout=30, check=False)
    assert free.returncode == 0

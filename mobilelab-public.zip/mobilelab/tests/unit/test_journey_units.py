"""Journey wiring units (all MOCK / synthetic data; no device): verdict rule, Safari profile on the
real iOS 27 tree shape, stage preconditions, worker preflight authority, run completion, loop stops."""

from __future__ import annotations

import sys
from pathlib import Path
from uuid import uuid4

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_coordinator_support import BASE_URL, budget, context, make_rig  # noqa: E402

from mobilelab.candidates import generate_candidates, sample_trees  # noqa: E402
from mobilelab.candidates.safari import page_location  # noqa: E402
from mobilelab.domain.base import utc_now  # noqa: E402
from mobilelab.domain.enums import EvidenceCategory, EvidenceSource, RunStatus, Verdict  # noqa: E402
from mobilelab.domain.errors import DispatchGateClosed, EvidenceTierMismatch  # noqa: E402
from mobilelab.domain.observations import UIElement  # noqa: E402
from mobilelab.domain.scenarios import OracleResult  # noqa: E402
from mobilelab.journey import LoopLimits, decide_verdict, load_plan, run_loop  # noqa: E402
from mobilelab.journey.runner import redact  # noqa: E402
from mobilelab.providers import RulesProvider  # noqa: E402
from mobilelab.providers.errors import ExpectedCandidateMissing  # noqa: E402

# -- verdict rule ------------------------------------------------------------------------------------


def _oracle(verdict: Verdict, reason: str = "X") -> OracleResult:
    now = utc_now()
    return OracleResult(
        oracle_result_id=uuid4(), run_id=uuid4(), scenario_id="s", oracle_kind="fixture_message_receipt",
        verdict=verdict, reason_code=reason, observation_window_start=now, observation_window_end=now,
    )  # fmt: skip


def _decide(**kw: object) -> tuple[Verdict, str]:
    args: dict[str, object] = dict(
        journey_completed=True, journey_reason="ok", oracle=_oracle(Verdict.PASS),
        evidence_source=EvidenceSource.DEVICE, identity_ok=True, census_ok=True,
    )  # fmt: skip
    return decide_verdict(**(args | kw))  # type: ignore[arg-type]


def test_pass_needs_device_evidence_completed_journey_identity_and_clean_census() -> None:
    assert _decide()[0] is Verdict.PASS
    assert _decide(evidence_source=EvidenceSource.MOCK)[0] is Verdict.INCONCLUSIVE
    assert _decide(journey_completed=False)[0] is Verdict.INCONCLUSIVE
    assert _decide(identity_ok=False)[0] is Verdict.HARNESS_FAILURE
    assert _decide(census_ok=False)[0] is Verdict.HARNESS_FAILURE  # e.g. a duplicate message
    assert _decide(oracle=None)[0] is Verdict.HARNESS_FAILURE


def test_oracle_non_pass_is_never_rounded_up() -> None:
    assert _decide(oracle=_oracle(Verdict.INCONCLUSIVE, "DELIVERY_UNCONFIRMED"))[0] is Verdict.INCONCLUSIVE
    assert _decide(oracle=_oracle(Verdict.ENVIRONMENT_FAILURE))[0] is Verdict.ENVIRONMENT_FAILURE
    assert _decide(oracle=_oracle(Verdict.HARNESS_FAILURE), evidence_source=EvidenceSource.MOCK)[0] is Verdict.HARNESS_FAILURE


# -- Safari profile on the real tree shape ---------------------------------------------------------


def _real_shaped_safari():  # type: ignore[no-untyped-def]
    """Synthetic tree reproducing two iOS 27 Safari facts seen on the device: the compact address
    value starts with U+200E, and the page exposes nested web views (WebView > WebView > WebView)."""
    obs = sample_trees.safari_article(address="‎127.0.0.1")
    web = next(e for e in obs.ui_tree if e.role == "XCUIElementTypeWebView")
    inner = UIElement(element_ref="inner-1", parent_ref=web.element_ref, role="XCUIElementTypeWebView")
    inner2 = UIElement(element_ref="inner-2", parent_ref="inner-1", role="XCUIElementTypeWebView")
    return obs.model_copy(update={"ui_tree": [*obs.ui_tree, inner, inner2]}), web


def test_safari_address_with_format_chars_and_nested_webviews_yield_scroll_candidates() -> None:
    obs, outer = _real_shaped_safari()
    assert page_location(obs) == (None, "127.0.0.1")
    plan = load_plan()
    scope = plan.scope(BASE_URL)
    scrolls = {c.semantic_key: c for c in generate_candidates(obs, scope) if c.semantic_key.startswith("safari.scroll")}
    assert set(scrolls) == {"safari.scroll:down", "safari.scroll:up"}
    assert scrolls["safari.scroll:down"].target_ref == outer.element_ref  # outermost page root only


# -- RulesProvider stage precondition -----------------------------------------------------------------


async def test_reading_dwell_waits_until_the_article_page_is_in_front() -> None:
    plan = load_plan(dwell_mode="median")
    scope, script = plan.scope(BASE_URL), plan.script(BASE_URL)
    provider = RulesProvider(script, scope)
    home = sample_trees.unknown_app("com.apple.springboard", labels=())
    run_id = uuid4()
    ctx = context(run_id)
    # open_article is satisfied by history; the dwell must not start on the home screen.
    from mobilelab.domain.decisions import HistoryEntry
    from mobilelab.domain.enums import ActionKind, ActionStatus

    entry = HistoryEntry(at=utc_now(), kind=ActionKind.NAVIGATE_URL, semantic_key=f"url.open:{BASE_URL}", status=ActionStatus.ACKNOWLEDGED)
    ctx = ctx.model_copy(update={"session_history": [entry]})
    # Not a provider error: an explicit short wait, which must not count as the reading dwell.
    waiting = await provider.decide(ctx, home, generate_candidates(home, scope), budget())
    assert waiting.reason_code == "AWAIT_STAGE_PRECONDITION" and waiting.parameters.duration_ms == 750
    acked = HistoryEntry(at=utc_now(), kind=ActionKind.WAIT, semantic_key="wait:dwell", status=ActionStatus.ACKNOWLEDGED)
    ctx = ctx.model_copy(update={"session_history": [entry, acked]})
    page = sample_trees.safari_article(base_url=BASE_URL)
    proposal = await provider.decide(ctx, page, generate_candidates(page, scope), budget())
    assert proposal.reason_code == "READ_DWELL" and provider.stage == "read_top"


async def test_precondition_waits_are_bounded() -> None:
    from mobilelab.domain.decisions import HistoryEntry
    from mobilelab.domain.enums import ActionKind, ActionStatus
    from mobilelab.providers.rules import MAX_PRECONDITION_WAITS

    plan = load_plan(dwell_mode="median")
    scope, script = plan.scope(BASE_URL), plan.script(BASE_URL)
    provider = RulesProvider(script, scope)
    home = sample_trees.unknown_app("com.apple.springboard", labels=())
    entry = HistoryEntry(at=utc_now(), kind=ActionKind.NAVIGATE_URL, semantic_key=f"url.open:{BASE_URL}", status=ActionStatus.ACKNOWLEDGED)
    ctx = context(uuid4()).model_copy(update={"session_history": [entry]})
    for _ in range(MAX_PRECONDITION_WAITS):
        await provider.decide(ctx, home, generate_candidates(home, scope), budget())
    with pytest.raises(ExpectedCandidateMissing) as err:
        await provider.decide(ctx, home, generate_candidates(home, scope), budget())
    assert err.value.details["requires"] == "on_allowed_page"


# -- worker preflight authority and run completion (MOCK adapter, in-process worker) --------------


async def test_preflight_refused_once_automation_is_authorized(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    from mobilelab.domain.devices import DeviceProfile
    from mobilelab.domain.enums import DeviceKind, Platform

    profile = DeviceProfile(device_id=rig.device_id, platform=Platform.IOS, kind=DeviceKind.SIMULATOR,
                            name="mock", os_version="mock", model="mock")  # fmt: skip
    report = await rig.worker.preflight(profile)
    assert {r.evidence_source for r in report.records} == {EvidenceSource.MOCK}
    await rig.controller.start(rig.run.run_id)
    with pytest.raises(DispatchGateClosed):
        await rig.worker.preflight(profile)


async def test_complete_fences_records_verdict_and_releases_lease(tmp_path: Path) -> None:
    rig = make_rig(tmp_path)
    await rig.controller.start(rig.run.run_id)
    with pytest.raises(EvidenceTierMismatch):  # mock evidence can never be recorded as PASS
        await rig.controller.complete(
            rig.run.run_id, verdict=Verdict.PASS, reason="x",
            obtained_evidence=EvidenceCategory.FIXTURE, obtained_evidence_source=EvidenceSource.MOCK,
        )  # fmt: skip
    run = await rig.controller.complete(rig.run.run_id, verdict=Verdict.INCONCLUSIVE, reason="mock")
    assert run.status is RunStatus.COMPLETED and run.verdict is Verdict.INCONCLUSIVE
    health = await rig.worker.health()  # worker gate closed synchronously before the terminal transition
    assert not health.gate_open and health.fenced_through_epoch is not None
    with rig.store.reader() as r:
        assert r.get_active_lease(rig.device_id) is None


# -- loop stop conditions -----------------------------------------------------------------------------


async def test_loop_stops_on_no_progress_without_dispatching(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=(("messenger.send:no-such-conversation", {}),))
    await rig.controller.start(rig.run.run_id)
    result = await run_loop(
        rig.controller, rig.run.run_id, context(rig.run.run_id), budget(),
        limits=LoopLimits(max_consecutive_no_progress=2, retry_delay_s=0.0),
    )  # fmt: skip
    assert not result.completed and result.stop_reason.startswith("no progress")
    assert [s.outcome for s in result.steps] == ["provider_error"] * 3
    assert rig.adapter.count("execute") == 0


async def test_loop_enforces_the_action_budget(tmp_path: Path) -> None:
    rig = make_rig(tmp_path, steps=(("wait:dwell", {"duration_ms": 10}),))
    await rig.controller.start(rig.run.run_id)
    result = await run_loop(rig.controller, rig.run.run_id, context(rig.run.run_id), budget(), limits=LoopLimits(max_actions=3))
    assert not result.completed and "action budget" in result.stop_reason
    assert rig.adapter.count("execute") == 3


def test_redact_replaces_every_secret() -> None:
    assert redact("a TOKEN1 b TOKEN2 TOKEN1", ["TOKEN1", "TOKEN2", ""]) == "a [REDACTED] b [REDACTED] [REDACTED]"

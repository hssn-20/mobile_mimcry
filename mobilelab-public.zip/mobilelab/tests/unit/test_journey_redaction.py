"""Raw-log redaction rules (Appium --log-filters + teardown scrub) and provider-name resolution."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

from mobilelab.journey.providers import (
    ProviderUnavailable,
    decision_budget,
    frozen_provider_config,
    provider_usage,
    registry_factory,
    resolve_provider_factory,
    rules_factory,
)
from mobilelab.domain.decisions import DecisionBudget
from mobilelab.journey.redaction import REDACTED, apply_filter_rules, scrub_raw_dir, write_appium_log_filters

TOKEN = "CANARYtok_" + "x1Y2z3" * 6  # token_urlsafe-shaped
LINES = [
    f'[XCUITestDriver] args: ["-MLFixtureBaseURL","http://127.0.0.1:5000","-MLFixtureToken","{TOKEN}","-MLRunId","r"]',
    f'{{"processArguments":{{"args":[\\"-MLFixtureToken\\",\\"{TOKEN}\\"]}}}}',
    f"Authorization: Bearer {TOKEN}",
    f'"token": "{TOKEN}"',
]


@pytest.mark.parametrize("line", LINES)
def test_filter_rules_mask_tokens_but_keep_the_prefix(line: str) -> None:
    out = apply_filter_rules(line)
    assert TOKEN not in out and REDACTED in out
    assert apply_filter_rules(out) == out  # idempotent: no "[[REDACTED]]"


def test_filter_file_holds_patterns_not_secrets(tmp_path: Path) -> None:
    path = write_appium_log_filters(tmp_path)
    rules = json.loads(path.read_text())
    assert len(rules) == 3 and all({"pattern", "flags", "replacer"} <= set(r) for r in rules)
    assert TOKEN not in path.read_text()


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_filter_rules_behave_the_same_in_javascript(tmp_path: Path) -> None:
    """Appium applies the rules with JS RegExp + String.replace; check the same masking there."""
    path = write_appium_log_filters(tmp_path)
    script = (
        "const rules=require(process.argv[1]);let t=process.argv[2];"
        "for(const r of rules){t=t.replace(new RegExp(r.pattern,[...new Set(('g'+r.flags).split(''))].join('')),r.replacer);}"
        "process.stdout.write(t);"
    )
    for line in LINES:
        out = subprocess.run(["node", "-e", script, str(path), line], capture_output=True, text=True, check=True).stdout  # noqa: S603, S607
        assert out == apply_filter_rules(line)


def test_scrub_raw_dir_replaces_known_secrets_and_removes_admin_secret(tmp_path: Path) -> None:
    (tmp_path / "fixture-state").mkdir()
    (tmp_path / "fixture-state" / "admin_secret").write_text("ADMINSECRET-abcdefgh")
    (tmp_path / "worker.log").write_text(f"x sender {TOKEN} y ADMINSECRET-abcdefgh\n")
    (tmp_path / "clean.log").write_text("nothing here\n")
    (tmp_path / "fixture-state" / "fixture.sqlite").write_bytes(b"SQLite format 3\x00" + TOKEN.encode())
    info = scrub_raw_dir(tmp_path, [TOKEN, "ADMINSECRET-abcdefgh"])
    assert info["files_removed"] == ["fixture-state/admin_secret"]
    assert info["files_scrubbed"] == ["worker.log"]
    assert set(info["files_with_known_secrets_before_scrub"]) == {"fixture-state/admin_secret", "worker.log"}
    assert TOKEN not in (tmp_path / "worker.log").read_text()
    assert "ADMINSECRET" not in json.dumps(info) and TOKEN not in json.dumps(info)


def test_provider_names_resolve_rules_locally_and_others_through_the_registry() -> None:
    assert resolve_provider_factory(None) is rules_factory and resolve_provider_factory("rules") is rules_factory
    f = resolve_provider_factory("luna")
    assert f is not rules_factory and "luna" in f.__name__


def test_registry_factory_reports_a_missing_registry(monkeypatch: pytest.MonkeyPatch) -> None:
    import mobilelab.journey.providers as mod

    monkeypatch.setattr(mod, "REGISTRY_MODULE", "mobilelab.providers.no_such_registry_for_test")
    with pytest.raises(ProviderUnavailable):
        registry_factory("luna")(None)  # type: ignore[arg-type]


class _Cfg:
    max_input_tokens = 8000
    max_output_tokens = 1500
    run_cap_usd = 0.25
    request_timeout_s = 20.0
    max_schema_repairs = 1
    frozen = {"model": "m", "rate_card_id": "rc"}


class _Summary:
    def __init__(self, scope: str) -> None:
        self.scope, self.estimated_usd, self.confirmed_usd, self.unresolved_usd = scope, 0.001, 0.002, 0.003

    def model_dump(self, mode: str = "json") -> dict[str, object]:
        return {"scope": self.scope}


class _Ledger:
    def summary(self, run_id: str | None = None) -> _Summary:
        return _Summary("global" if run_id is None else f"run:{run_id}")


class _ConfigProvider:
    config = _Cfg()
    ledger = _Ledger()
    evidence: list[object] = []


def test_config_shaped_provider_hooks() -> None:
    default = DecisionBudget(timeout_ms=10_000, max_input_tokens=1, max_output_tokens=1, max_cost_usd=0)
    b = decision_budget(_ConfigProvider(), default)
    assert (b.max_input_tokens, b.max_output_tokens, b.max_cost_usd) == (8000, 1500, 0.25)
    assert b.timeout_ms >= 40_000
    assert decision_budget(object(), default) is default
    assert frozen_provider_config(_ConfigProvider()) == {"provider_frozen_config": {"model": "m", "rate_card_id": "rc"}}
    usage = provider_usage(_ConfigProvider(), None)
    assert usage is not None and usage["confirmed_cost_usd"] == 0.002 and usage["unresolved_cost_usd"] == 0.003
    assert provider_usage(object()) is None

"""Harness-derived scroll-effect notes in the provider history (trusted; lets a model see page end)."""

from __future__ import annotations

from types import SimpleNamespace
from uuid import uuid4

from mobilelab.domain.enums import ActionKind
from mobilelab.journey.loop import _scroll_effects


def _el(label: str, y: int) -> SimpleNamespace:
    bounds = SimpleNamespace(model_dump_json=lambda: f'{{"y": {y}}}')
    return SimpleNamespace(role="StaticText", label=label, value=None, bounds=bounds, visible=True)


def _obs(*els: SimpleNamespace, app: str = "com.apple.mobilesafari") -> SimpleNamespace:
    return SimpleNamespace(foreground_app=app, ui_tree=list(els))


def _act(kind: ActionKind, before: object, after: object, status: str = "ACKNOWLEDGED") -> SimpleNamespace:
    return SimpleNamespace(action_id=uuid4(), kind=kind, status=SimpleNamespace(value=status),
                           dispatch_observation_id=before, decision_observation_id=after)  # fmt: skip


class _Reader:
    def __init__(self, obs: dict[object, SimpleNamespace]) -> None:
        self.obs = obs

    def get_observation(self, oid: object) -> SimpleNamespace:
        return self.obs[oid]


def test_moved_unchanged_and_latest_scroll() -> None:
    o1, o2, o3, o4 = uuid4(), uuid4(), uuid4(), uuid4()
    reader = _Reader({o1: _obs(_el("a", 100)), o2: _obs(_el("a", 10)), o3: _obs(_el("a", 10)), o4: _obs(_el("a", 10))})
    s1 = _act(ActionKind.SCROLL, o1, o1)
    s2 = _act(ActionKind.SCROLL, o2, o2)  # decided on o2 (moved vs o1)
    s3 = _act(ActionKind.SCROLL, o3, o3)  # decided on o3 (same as o2)
    s4 = _act(ActionKind.SCROLL, o4, o4)  # latest: no "after" observation yet
    notes = _scroll_effects(reader, [s1, s2, s3, s4])
    assert "moved" in notes[s1.action_id]
    assert "unchanged" in notes[s2.action_id] and notes[s2.action_id].startswith("harness:")
    assert "unchanged" in notes[s3.action_id]
    assert s4.action_id not in notes


def test_app_switch_and_non_scroll_get_no_note() -> None:
    o1, o2 = uuid4(), uuid4()
    reader = _Reader({o1: _obs(_el("a", 1)), o2: _obs(_el("a", 1), app="org.mobilelab.fixtures.LabMessenger")})
    s1 = _act(ActionKind.SCROLL, o1, o1)
    w = _act(ActionKind.WAIT, o2, o2)
    failed = _act(ActionKind.SCROLL, o1, o1, status="FAILED")
    notes = _scroll_effects(reader, [s1, w, failed, w])
    assert notes == {}

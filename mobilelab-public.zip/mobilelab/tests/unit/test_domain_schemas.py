"""Schema examples from the spec validate; evidence rules; hashing; observation and capability rules."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

import pytest
from pydantic import ValidationError

from mobilelab.domain.base import utc_now
from mobilelab.domain.devices import CapabilityRecord, CapabilityReport
from mobilelab.domain.enums import (
    ActionKind,
    CapabilityKey,
    CapabilityStatus,
    DeviceKind,
    EvidenceCategory,
    EventType,
    EvidenceSource,
    Platform,
    RunStatus,
    SideEffectClass,
    Verdict,
)
from mobilelab.domain.errors import (
    CandidateNotFound,
    ErrorCode,
    EvidenceTierMismatch,
    StaleObservation,
    VersionConflict,
)
from mobilelab.domain.events import (
    EVENT_ADAPTER,
    GateChangedEvent,
    RunStatusChangedEvent,
    validate_event_payload,
)
from mobilelab.domain.evidence import assess_evidence, require_evidence, require_verdict_evidence
from mobilelab.domain.hashing import canonical_json, config_hash
from mobilelab.domain.observations import CandidateAction, Observation, UIElement
from mobilelab.domain.personas import PersonaCatalog, PersonaConfig
from mobilelab.domain.scenarios import ScenarioSpec

REPO = Path(__file__).resolve().parents[2]

CONTRACT_SCENARIO_YAML = """\
schema_version: 1
scenario_id: browse_then_reply
version: 1
platforms: [ios, android]
platform_evidence: fixture
required_capabilities: [observe_ui, fixture_message, switch_app]
max_duration_seconds: 120
max_actions: 40
goal: Read a fixture article and reply to the designated test contact.
oracles:
  - kind: fixture_message_receipt
    required_status: delivered
    timeout_seconds: 20
    evidence: [client_message_id, server_receipt, receiver_receipt]
"""


def test_contract_scenario_yaml_validates() -> None:
    spec = ScenarioSpec.from_yaml(CONTRACT_SCENARIO_YAML)
    assert spec.platform_evidence is EvidenceCategory.FIXTURE
    assert spec.platforms == [Platform.IOS, Platform.ANDROID]
    assert spec.oracles[0].required_status == "delivered"


def test_scenario_with_persona_and_seed_fields() -> None:
    spec = ScenarioSpec.from_yaml(
        CONTRACT_SCENARIO_YAML + "persona_id: careful_reader\npersona_version: 1\nseed: 42\nrequirement_refs: [BR-01]\n"
    )
    assert spec.seed == 42 and spec.requirement_refs == ["BR-01"]


def test_carrier_scenario_example_requires_physical_carrier_tier() -> None:
    carrier = CONTRACT_SCENARIO_YAML.replace("browse_then_reply", "carrier_sms_outbound").replace(
        "fixture_message, switch_app", "carrier_sms"
    )
    with pytest.raises(ValidationError):
        ScenarioSpec.from_yaml(carrier)  # still declares platform_evidence: fixture
    ok = ScenarioSpec.from_yaml(carrier.replace("platform_evidence: fixture", "platform_evidence: physical_carrier"))
    assert ok.platform_evidence is EvidenceCategory.PHYSICAL_CARRIER


@pytest.mark.parametrize(
    "extra",
    ["unknown_key: 1\n", "platform_evidence_secondary: physical_ip\n", "requirement_refs: [REQ-1]\n"],
)
def test_scenario_rejects_unknown_or_malformed_fields(extra: str) -> None:
    with pytest.raises(ValidationError):
        ScenarioSpec.from_yaml(CONTRACT_SCENARIO_YAML + extra)


def test_example_personas_file_validates() -> None:
    catalog = PersonaCatalog.model_validate_json((REPO / "examples" / "personas.json").read_text())
    assert [p.persona_id for p in catalog.personas] == ["careful_reader", "frequent_messenger", "task_focused"]
    assert catalog.calibration_status == "synthetic_unvalidated"


def test_persona_rejects_inconsistent_distribution() -> None:
    raw = json.loads((REPO / "examples" / "personas.json").read_text())["personas"][0]
    raw["reading_dwell"]["min_seconds"] = 100
    with pytest.raises(ValidationError):
        PersonaConfig.model_validate(raw)


# -- hashing -----------------------------------------------------------------------------------


def test_canonical_json_is_key_order_and_whitespace_independent() -> None:
    a = {"b": 1, "a": {"y": [1, 2], "x": "é"}}
    b = json.loads('{ "a": {"x": "é", "y": [1,2]},   "b": 1 }')
    assert canonical_json(a) == canonical_json(b) == '{"a":{"x":"é","y":[1,2]},"b":1}'.encode()
    assert config_hash(a) == config_hash(b)
    assert len(config_hash(a)) == 64


def test_config_hash_changes_with_content_and_accepts_models() -> None:
    catalog = PersonaCatalog.model_validate_json((REPO / "examples" / "personas.json").read_text())
    p = catalog.personas[0]
    assert config_hash(p) == config_hash(p.model_dump(mode="json"))
    changed = p.model_copy(update={"typing_characters_per_second": 9.0})
    assert config_hash(changed) != config_hash(p)


def test_canonical_json_rejects_nan() -> None:
    with pytest.raises(ValueError):
        canonical_json({"x": float("nan")})


# -- evidence ----------------------------------------------------------------------------------


def test_fixture_evidence_never_satisfies_carrier() -> None:
    with pytest.raises(EvidenceTierMismatch) as exc:
        require_evidence(
            EvidenceCategory.PHYSICAL_CARRIER,
            EvidenceCategory.FIXTURE,
            device_kind=DeviceKind.PHYSICAL,
            evidence_source=EvidenceSource.DEVICE,
        )
    assert exc.value.code is ErrorCode.EVIDENCE_TIER_MISMATCH


@pytest.mark.parametrize("required", list(EvidenceCategory))
@pytest.mark.parametrize("obtained", list(EvidenceCategory))
def test_categories_are_not_interchangeable(required: EvidenceCategory, obtained: EvidenceCategory) -> None:
    result = assess_evidence(required, obtained, device_kind=DeviceKind.PHYSICAL, evidence_source=EvidenceSource.DEVICE)
    assert result.satisfied is (required is obtained)


def test_physical_device_lab_messenger_keeps_fixture_tier() -> None:
    result = require_evidence(
        EvidenceCategory.FIXTURE,
        EvidenceCategory.FIXTURE,
        device_kind=DeviceKind.PHYSICAL,
        evidence_source=EvidenceSource.DEVICE,
    )
    assert result.satisfied and result.device_kind is DeviceKind.PHYSICAL


@pytest.mark.parametrize("kind", [DeviceKind.SIMULATOR, DeviceKind.EMULATOR])
@pytest.mark.parametrize("tier", [EvidenceCategory.PHYSICAL_IP, EvidenceCategory.PHYSICAL_CARRIER])
def test_virtual_devices_cannot_produce_physical_evidence(kind: DeviceKind, tier: EvidenceCategory) -> None:
    assert not assess_evidence(tier, tier, device_kind=kind, evidence_source=EvidenceSource.DEVICE).satisfied


def test_mock_evidence_never_satisfies() -> None:
    r = assess_evidence(
        EvidenceCategory.FIXTURE,
        EvidenceCategory.FIXTURE,
        device_kind=DeviceKind.SIMULATOR,
        evidence_source=EvidenceSource.MOCK,
    )
    assert not r.satisfied and "mock" in r.reason


def test_replay_evidence_never_satisfies() -> None:
    r = assess_evidence(
        EvidenceCategory.FIXTURE,
        EvidenceCategory.FIXTURE,
        device_kind=DeviceKind.SIMULATOR,
        evidence_source=EvidenceSource.REPLAY,
    )
    assert not r.satisfied and "replay" in r.reason


def test_verdict_evidence_gate() -> None:
    sim = DeviceKind.SIMULATOR
    carrier, fixture = EvidenceCategory.PHYSICAL_CARRIER, EvidenceCategory.FIXTURE
    for verdict in (Verdict.PASS, Verdict.DUT_FAILURE):
        with pytest.raises(EvidenceTierMismatch):
            require_verdict_evidence(verdict, carrier, fixture, device_kind=sim, evidence_source=EvidenceSource.DEVICE)
        with pytest.raises(EvidenceTierMismatch):  # no recorded source
            require_verdict_evidence(verdict, fixture, fixture, device_kind=sim, evidence_source=None)
        with pytest.raises(EvidenceTierMismatch):  # nothing obtained
            require_verdict_evidence(verdict, fixture, None, device_kind=sim, evidence_source=EvidenceSource.DEVICE)
    ok = require_verdict_evidence(Verdict.PASS, fixture, fixture, device_kind=sim, evidence_source=EvidenceSource.DEVICE)
    assert ok is not None and ok.satisfied
    # Non-claims (e.g. an unsupported carrier scenario) need no matching evidence.
    assert require_verdict_evidence(Verdict.UNSUPPORTED, carrier, None, device_kind=sim, evidence_source=None) is None


# -- capabilities ------------------------------------------------------------------------------


def test_supported_capability_requires_probe_time() -> None:
    with pytest.raises(ValidationError):
        CapabilityRecord(key=CapabilityKey.OBSERVE_UI, status=CapabilityStatus.SUPPORTED, evidence_source=EvidenceSource.DEVICE)


def test_capability_report_strict_preflight() -> None:
    now = utc_now()
    report = CapabilityReport(
        report_id=uuid4(),
        device_id=uuid4(),
        platform=Platform.IOS,
        device_kind=DeviceKind.SIMULATOR,
        evidence_source=EvidenceSource.DEVICE,
        adapter_version="0.1.0",
        probed_at=now,
        records=[
            CapabilityRecord(
                key=CapabilityKey.OBSERVE_UI, status=CapabilityStatus.SUPPORTED,
                evidence_source=EvidenceSource.DEVICE, last_probed_at=now,
            ),
            CapabilityRecord(
                key=CapabilityKey.SWITCH_APP, status=CapabilityStatus.UNVERIFIED, evidence_source=EvidenceSource.DEVICE
            ),
            CapabilityRecord(
                key=CapabilityKey.FIXTURE_MESSAGE, status=CapabilityStatus.SUPPORTED,
                evidence_source=EvidenceSource.MOCK, last_probed_at=now,
            ),
        ],
    )
    required = [CapabilityKey.OBSERVE_UI, CapabilityKey.SWITCH_APP, CapabilityKey.FIXTURE_MESSAGE, CapabilityKey.CARRIER_SMS]
    assert report.missing(required) == [CapabilityKey.SWITCH_APP, CapabilityKey.FIXTURE_MESSAGE, CapabilityKey.CARRIER_SMS]
    assert report.missing(required, strict=False) == [CapabilityKey.FIXTURE_MESSAGE, CapabilityKey.CARRIER_SMS]


def test_all_initial_capability_keys_present() -> None:
    assert {k.value for k in CapabilityKey} == {
        "observe_ui", "capture_screen", "activate_element", "type_text", "scroll", "switch_app",
        "safari_browse", "fixture_message", "fixture_incoming_notification", "os_sms", "carrier_sms",
        "carrier_voice", "ip_connectivity", "vpn_exit_selection", "network_disruption", "device_logs",
    }  # fmt: skip


# -- observations ------------------------------------------------------------------------------


def _observation(span_ms: int = 300, **kw: object) -> Observation:
    oid = uuid4()
    start = datetime(2026, 10, 3, 12, 0, tzinfo=UTC)
    cand = CandidateAction(
        candidate_id=uuid4(), observation_id=oid, semantic_key="article.open", kind=ActionKind.ACTIVATE,
        target_ref="e1", side_effect_class=SideEffectClass.NAVIGATION,
    )
    data: dict[str, object] = {
        "observation_id": oid,
        "device_id": uuid4(),
        "session_id": uuid4(),
        "evidence_source": EvidenceSource.MOCK,
        "capture_started_at": start,
        "capture_ended_at": start + timedelta(milliseconds=span_ms),
        "worker_monotonic_capture_ns": 10_000_000_000,
        "ui_tree": [UIElement(element_ref="e1", role="button", label="Open article", identifier="article.open")],
        "candidates": [cand],
    }
    data.update(kw)
    return Observation.model_validate(data)


def test_observation_rules() -> None:
    obs = _observation()
    obs.check_capture_consistency(1500)
    with pytest.raises(StaleObservation):
        _observation(span_ms=2500).check_capture_consistency(1500)
    obs.check_fresh(worker_now_ns=10_000_000_000 + 1_999_000_000)
    with pytest.raises(StaleObservation):
        obs.check_fresh(worker_now_ns=10_000_000_000 + 2_001_000_000)
    with pytest.raises(CandidateNotFound):
        obs.candidate(uuid4())
    assert obs.candidate(obs.candidates[0].candidate_id).target_ref == "e1"


def test_observation_rejects_foreign_candidate_and_naive_times() -> None:
    foreign = CandidateAction(
        candidate_id=uuid4(), observation_id=uuid4(), semantic_key="x", kind=ActionKind.ACTIVATE,
        target_ref="e1", side_effect_class=SideEffectClass.NONE,
    )
    with pytest.raises(ValidationError):
        _observation(candidates=[foreign])
    with pytest.raises(ValidationError):
        _observation(capture_started_at=datetime(2026, 10, 3, 12, 0))  # naive
    with pytest.raises(ValidationError):
        _observation(span_ms=-5)


def test_timestamps_normalised_to_utc() -> None:
    from datetime import timezone

    plus2 = timezone(timedelta(hours=2))
    obs = _observation(
        capture_started_at=datetime(2026, 10, 3, 14, 0, tzinfo=plus2),
        capture_ended_at=datetime(2026, 10, 3, 14, 0, 1, tzinfo=plus2),
    )
    assert obs.capture_started_at.tzinfo is UTC and obs.capture_started_at.hour == 12


def _event(**overrides: object) -> dict[str, object]:
    data: dict[str, object] = {
        "event_id": 42,
        "type": "run.status_changed",
        "timestamp": utc_now(),
        "payload": {"from_status": "READY", "to_status": "RUNNING", "control_epoch": 0, "version": 4},
    }
    data.update(overrides)
    return data


def test_event_sse_id_is_decimal_string() -> None:
    ev = EVENT_ADAPTER.validate_python(_event())
    assert isinstance(ev, RunStatusChangedEvent) and ev.sse_id == "42"
    assert ev.payload.to_status is RunStatus.RUNNING


def test_event_union_is_discriminated_with_typed_payloads() -> None:
    gate = {"gate_open": False, "global_epoch": 1, "updated_at": utc_now(), "version": 2}
    ev = EVENT_ADAPTER.validate_python(_event(type="gate.changed", payload=gate))
    assert isinstance(ev, GateChangedEvent) and ev.payload.global_epoch == 1
    with pytest.raises(ValidationError):  # unknown event type
        EVENT_ADAPTER.validate_python(_event(type="run.exploded"))
    with pytest.raises(ValidationError):  # payload of another type
        EVENT_ADAPTER.validate_python(_event(type="gate.changed"))
    with pytest.raises(ValidationError):  # extra payload field
        EVENT_ADAPTER.validate_python(
            _event(payload={"from_status": None, "to_status": "CREATED", "version": 1, "surprise": 1})
        )
    schema = EVENT_ADAPTER.json_schema()
    assert schema["discriminator"]["propertyName"] == "type"
    assert set(schema["discriminator"]["mapping"]) == {t.value for t in EventType}


def test_validate_event_payload_rejects_wrong_shape() -> None:
    assert validate_event_payload(EventType.DEVICE_UPDATED, {"version": 3}) == {"version": 3}
    with pytest.raises(ValidationError):
        validate_event_payload(EventType.DEVICE_UPDATED, {"from_status": None})


def test_error_envelope_from_exception() -> None:
    env = VersionConflict("stale", current_state={"version": 3}).to_envelope()
    assert env.code is ErrorCode.VERSION_CONFLICT and env.current_state == {"version": 3}
    assert VersionConflict.http_status == 409

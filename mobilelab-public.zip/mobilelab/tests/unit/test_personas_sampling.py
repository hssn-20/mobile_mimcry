"""Persona catalogue (configs/personas) and seeded, independent dwell streams."""

from __future__ import annotations

import json
from pathlib import Path
from uuid import UUID

import pytest

from mobilelab.domain.errors import NotFound
from mobilelab.domain.personas import PersonaCatalog
from mobilelab.personas import (
    DEFAULT_PERSONA_DIR,
    PersonaSampler,
    derive_stream_seed,
    get_persona,
    load_persona_catalog,
    persona_hash,
)

ROOT = Path(__file__).resolve().parents[2]
DEV_A = UUID("00000000-0000-4000-8000-0000000000d1")
DEV_B = UUID("00000000-0000-4000-8000-0000000000d2")


def test_catalog_matches_examples_and_is_synthetic() -> None:
    assert DEFAULT_PERSONA_DIR == ROOT / "configs" / "personas"
    cat = load_persona_catalog()
    assert set(cat) == {("careful_reader", 1), ("frequent_messenger", 1), ("task_focused", 1)}
    assert all(c.calibration_status == "synthetic_unvalidated" for c in cat.values())
    example = PersonaCatalog.model_validate(json.loads((ROOT / "examples/personas.json").read_text()))
    for p in example.personas:
        assert get_persona(p.persona_id, p.version) == p


def test_missing_persona_and_hash() -> None:
    with pytest.raises(NotFound):
        get_persona("task_focused", 99)
    a, b = get_persona("task_focused", 1), get_persona("careful_reader", 1)
    assert persona_hash(a) == persona_hash(get_persona("task_focused", 1)) != persona_hash(b)


def test_duplicate_revision_across_files_rejected(tmp_path: Path) -> None:
    src = DEFAULT_PERSONA_DIR / "task_focused.v1.json"
    (tmp_path / "a.json").write_text(src.read_text())
    (tmp_path / "b.json").write_text(src.read_text())
    with pytest.raises(ValueError):
        load_persona_catalog(tmp_path)


def test_median_mode_is_deterministic_and_recorded() -> None:
    s = PersonaSampler(get_persona("task_focused", 1), run_seed=7, device_id=DEV_A)
    d0, d1 = s.sample_dwell("reading_dwell"), s.sample_dwell("reading_dwell")
    assert (d0.sampled_ms, d1.sampled_ms) == (9000, 9000)
    assert (d0.draw_index, d1.draw_index) == (0, 1) and d0.stream == "timing" and not d0.clamped
    assert s.sample_dwell("reply_delay").draw_index == 0
    assert len(s.draws) == 3


def test_lognormal_seeded_reproducible_and_independent() -> None:
    persona = get_persona("careful_reader", 1)

    def draws(seed: int, dev: UUID, interleave: bool) -> list[int]:
        s = PersonaSampler(persona, run_seed=seed, device_id=dev, mode="lognormal")
        out = []
        for _ in range(20):
            if interleave:
                s.sample_dwell("reply_delay")
            out.append(s.sample_dwell("reading_dwell").sampled_ms)
        return out

    base = draws(1, DEV_A, False)
    assert base == draws(1, DEV_A, False)
    assert base == draws(1, DEV_A, True)  # other categories never shift this stream
    assert base != draws(2, DEV_A, False) and base != draws(1, DEV_B, False)
    assert all(3000 <= ms <= 45000 for ms in base) and len(set(base)) > 1


def test_clamping_is_recorded() -> None:
    s = PersonaSampler(get_persona("frequent_messenger", 1), run_seed=3, device_id=DEV_A, mode="lognormal")
    draws = [s.sample_dwell("reading_dwell") for _ in range(500)]
    clamped = [d for d in draws if d.clamped]
    assert clamped and all(d.sampled_ms in (1000, 25000) for d in clamped)


def test_stream_seed_derivation() -> None:
    seeds = {derive_stream_seed(1, DEV_A, st, "x") for st in ("activity", "timing", "content", "faults")}
    assert len(seeds) == 4
    assert derive_stream_seed(1, DEV_A, "timing", "a") != derive_stream_seed(1, DEV_A, "timing", "b")

"""CLI wiring for `mobilelab doctor` (FIXTURE reports injected; no host probing)."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from mobilelab import cli
from mobilelab.doctor import EvidenceSource, run_doctor
from mobilelab.doctor import command as doctor_command
from mobilelab.doctor.fakes import healthy_fixture

REPO = Path(__file__).resolve().parents[2]


@pytest.fixture
def project(tmp_path: Path) -> Path:
    for name in ("pyproject.toml", "uv.lock", ".python-version"):
        shutil.copy(REPO / name, tmp_path / name)
    (tmp_path / "tools" / "appium").mkdir(parents=True)
    shutil.copy(REPO / "tools" / "appium" / "package.json", tmp_path / "tools" / "appium" / "package.json")
    return tmp_path


@pytest.fixture
def fake_doctor(monkeypatch: pytest.MonkeyPatch, project: Path) -> dict[str, object]:
    state: dict[str, object] = {}

    def fake_run_doctor(*, project_root: Path, **_: object):  # type: ignore[no-untyped-def]
        runner, host = healthy_fixture(project_root)
        state["runner"] = runner
        if "licence_blocked" in state:
            runner.set(["xcodebuild", "-license", "check"], returncode=69, stderr="run 'sudo xcodebuild -license'")
        return run_doctor(runner=runner, host=host, project_root=project_root,
                          evidence_source=EvidenceSource.FIXTURE)

    monkeypatch.setattr(doctor_command, "run_doctor", fake_run_doctor)
    return state


def test_parser_registers_doctor() -> None:
    parser = cli.build_parser()
    args = parser.parse_args(["doctor", "--json"])
    assert args.command == "doctor" and args.json and callable(args.func)


def test_no_subcommand_prints_help(capsys: pytest.CaptureFixture[str]) -> None:
    assert cli.main([]) == 2
    assert "doctor" in capsys.readouterr().out


def test_subcommand_registry_is_extensible(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    (tmp_path / "mlx_extra_cmd.py").write_text(
        "def register(sub):\n"
        "    p = sub.add_parser('hello')\n"
        "    p.set_defaults(func=lambda args: 7)\n")
    monkeypatch.syspath_prepend(str(tmp_path))
    parser = cli.build_parser((*cli.SUBCOMMAND_MODULES, "mlx_extra_cmd"))
    args = parser.parse_args(["hello"])
    assert args.func(args) == 7


def test_doctor_table_output(fake_doctor: dict[str, object], project: Path,
                             capsys: pytest.CaptureFixture[str]) -> None:
    assert cli.main(["doctor", "--project-root", str(project)]) == 0
    out = capsys.readouterr().out
    assert "STATUS" in out and "Full Xcode installed" in out
    assert "M1 iOS Simulator slice: READY" in out


def test_doctor_json_and_output_file(fake_doctor: dict[str, object], project: Path,
                                     capsys: pytest.CaptureFixture[str]) -> None:
    out_path = project / "out" / "doctor.json"
    assert cli.main(["doctor", "--json", "--output", str(out_path), "--project-root", str(project)]) == 0
    printed = json.loads(capsys.readouterr().out)
    saved = json.loads(out_path.read_text())
    assert printed == saved
    assert saved["evidence_source"] == "fixture"


def test_doctor_save_writes_timestamped_artifact(fake_doctor: dict[str, object], project: Path) -> None:
    assert cli.main(["doctor", "--save", "--project-root", str(project)]) == 0
    files = list((project / "artifacts" / "doctor").glob("doctor-*.json"))
    assert [f.name for f in files] == ["doctor-20261003T120000Z.json"]


def test_require_gate_exit_code(fake_doctor: dict[str, object], project: Path) -> None:
    assert cli.main(["doctor", "--require-gate", "m1_ios_simulator", "--project-root", str(project)]) == 0
    fake_doctor["licence_blocked"] = True
    assert cli.main(["doctor", "--require-gate", "m1_ios_simulator", "--project-root", str(project)]) == 1
    assert cli.main(["doctor", "--require-gate", "m1_core", "--project-root", str(project)]) == 0


def test_write_manifest(fake_doctor: dict[str, object], project: Path) -> None:
    assert cli.main(["doctor", "--write-manifest", "--project-root", str(project)]) == 0
    manifest = json.loads((project / "configs" / "runtime_manifest.json").read_text())
    assert manifest["manifest_date"] == "2026-10-03"
    assert manifest["smoke_tested"] is False
    assert manifest["appium"]["required"] == "3.8.0"
    assert manifest["appium_xcuitest_driver"]["required"] == "12.14.0"
    assert manifest["appium_xcuitest_driver"]["verified_on_host"] is True
    assert manifest["xcode"]["verified_on_host"] is True
    assert manifest["xcode"]["active_developer_dir"]["status"] == "ready"
    assert manifest["xcode"]["first_launch"] == "ready"
    assert manifest["gates"]["m1_ios_simulator"] == {"status": "ready", "blocked_by": []}
    pkgs = manifest["python_packages"]
    assert {"fastapi", "pydantic", "sqlalchemy", "pytest"} <= set(pkgs)
    assert pkgs["pydantic"]["locked"].startswith("2.13")
    for entry in ("python", "node", "npm", "appium", "xcode", "ios_simulator_runtime", "swift"):
        assert isinstance(manifest[entry]["verified_on_host"], bool)


def test_manifest_xcode_not_verified_when_clt_selected(monkeypatch: pytest.MonkeyPatch, project: Path) -> None:
    def clt_selected(*, project_root: Path, **_: object):  # type: ignore[no-untyped-def]
        runner, host = healthy_fixture(project_root)
        runner.set(["xcode-select", "-p"], stdout="/Library/Developer/CommandLineTools\n")
        return run_doctor(runner=runner, host=host, project_root=project_root,
                          evidence_source=EvidenceSource.FIXTURE)

    monkeypatch.setattr(doctor_command, "run_doctor", clt_selected)
    assert cli.main(["doctor", "--write-manifest", "--project-root", str(project)]) == 0
    manifest = json.loads((project / "configs" / "runtime_manifest.json").read_text())
    xcode = manifest["xcode"]
    assert xcode["status"] == "ready"  # the bundle itself is fine ...
    assert xcode["verified_on_host"] is False  # ... but the active developer dir is not
    assert xcode["active_developer_dir"] == {"observed": "/Library/Developer/CommandLineTools",
                                             "status": "incompatible"}
    assert manifest["gates"]["m1_ios_simulator"] == {"status": "blocked", "blocked_by": ["xcode_select"]}

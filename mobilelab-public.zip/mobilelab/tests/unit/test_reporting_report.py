"""Run report JSON/HTML, manifest and integrity verification.

SYNTHETIC TEST DATA: every record below (observations, decisions, actions, attempts, oracle results,
screenshot bytes) is fabricated in-process to exercise the report pipeline. Observations and
artifacts are labelled ``evidence_source=mock``; nothing here is device, Simulator or fixture
evidence.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from uuid import UUID, uuid4

import pytest

from mobilelab.domain.actions import SendMessage
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import ControlCommand
from mobilelab.domain.decisions import DecisionRecord
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, ExecutionResult
from mobilelab.domain.enums import (
    ActionKind,
    ActionStatus,
    CommandKind,
    ConfigKind,
    DeviceKind,
    EvidenceCategory,
    EvidenceSource,
    ExecutionStatus,
    Platform,
    RunStatus,
    SideEffectClass,
    TypingMode,
    Verdict,
)
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.observations import CandidateAction, Observation, PermittedParameters, UIElement
from mobilelab.domain.proposals import ProposedAction
from mobilelab.domain.runs import Run, RunSpec
from mobilelab.domain.scenarios import OracleResult
from mobilelab.reporting import (
    NOT_EVALUATED,
    RunReport,
    build_run_report,
    render_html,
    verify_report_integrity,
    write_report,
)
from mobilelab.reporting.__main__ import main as report_main
from mobilelab.store import ArtifactStore, Store

H = "0" * 64
XSS_LABEL = '<script>alert("label")</script>'
XSS_EXPLANATION = "<img src=x onerror=alert(1)>"
SCENARIO = {
    "scenario_id": "browse_then_reply",
    "version": 1,
    "platforms": ["ios"],
    "platform_evidence": "fixture",
    "max_duration_seconds": 600,
    "max_actions": 40,
    "goal": "SYNTHETIC test scenario",
    "oracles": [{"kind": "fixture_message_receipt", "required_status": "delivered", "timeout_seconds": 30}],
}


@dataclass
class Seeded:
    run_id: UUID
    observation_id: UUID
    decision_id: UUID
    action_id: UUID
    screenshot_id: UUID
    screenshot_path: Path


@pytest.fixture
def store(tmp_path: Path) -> Iterator[Store]:
    s = Store.open(tmp_path / "lab.db")
    yield s
    s.close()


def seed(store: Store, artifacts_root: Path, *, complete: bool) -> Seeded:
    """Populate the store with one synthetic browse_then_reply send journey."""
    with store.unit_of_work() as uow:
        rev = uow.add_config_revision(ConfigKind.SCENARIO, "browse_then_reply", SCENARIO)
    device_id = uuid4()
    spec = RunSpec(
        scenario_id="browse_then_reply", scenario_version=rev.revision, scenario_hash=rev.content_hash,
        persona_id="careful_reader", persona_version=1, persona_hash=H, provider_id="rules",
        provider_config_hash=config_hash({}), seed=7, device_id=device_id, platform=Platform.IOS,
        device_kind=DeviceKind.SIMULATOR, device_profile_hash=H, planned_evidence=EvidenceCategory.FIXTURE,
    )  # fmt: skip
    run = Run(run_id=uuid4(), spec=spec)
    with store.unit_of_work() as uow:
        uow.add_run(run)
    for target in (RunStatus.PREFLIGHT, RunStatus.READY, RunStatus.RUNNING):
        with store.unit_of_work() as uow:
            uow.transition_run(run.run_id, target)

    arts = ArtifactStore(artifacts_root)
    shot = arts.write_bytes(
        b"SYNTHETIC mock screenshot bytes", filename="screenshot.png", content_type="image/png",
        evidence_source=EvidenceSource.MOCK, run_id=run.run_id,
    )  # fmt: skip
    obs_id, cand_id, cmid = uuid4(), uuid4(), uuid4()
    now = utc_now()
    candidate = CandidateAction(
        candidate_id=cand_id, observation_id=obs_id, semantic_key="messenger.send", kind=ActionKind.SEND_MESSAGE,
        target_ref="composer.send", side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT,
        permitted=PermittedParameters(contact_id="fixture-contact-01"),
    )  # fmt: skip
    obs = Observation(
        observation_id=obs_id, run_id=run.run_id, device_id=device_id, session_id=uuid4(),
        evidence_source=EvidenceSource.MOCK, capture_started_at=now, capture_ended_at=now,
        worker_monotonic_capture_ns=1, foreground_app="org.mobilelab.fixtures.LabMessenger",
        screenshot_artifact_id=shot.artifact_id,
        ui_tree=[
            UIElement(element_ref="message.row.1", role="cell", label=XSS_LABEL),
            UIElement(element_ref="composer.send", role="button", identifier="composer.send", label="Send"),
        ],
        candidates=[candidate],
    )  # fmt: skip
    decision_id = uuid4()
    decision = DecisionRecord(
        decision_id=decision_id, run_id=run.run_id, decision_observation_id=obs_id, provider_id="rules",
        control_epoch=0, outcome="accepted", latency_ms=3.0,
        proposal=ProposedAction(
            decision_id=decision_id, decision_observation_id=obs_id, candidate_id=cand_id,
            reason_code="SEND_REPLY", explanation=XSS_EXPLANATION,
        ),
    )  # fmt: skip
    action = ActionRecord(
        action_id=uuid4(), run_id=run.run_id, device_id=device_id, decision_id=decision_id,
        kind=ActionKind.SEND_MESSAGE, semantic_key="messenger.send",
        side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT, decision_observation_id=obs_id,
        original_candidate_id=cand_id,
    )  # fmt: skip
    payload = SendMessage(kind="send_message", element_ref="composer.send", contact_id="fixture-contact-01", client_message_id=cmid)
    with store.unit_of_work() as uow:
        uow.add_artifact(shot)
        uow.add_observation(obs)
        uow.add_decision(decision)
        uow.add_action(action)
        uow.transition_action(action.action_id, ActionStatus.VALIDATED)
        uow.transition_action(action.action_id, ActionStatus.SCHEDULED, sampled_delay_ms=800.0, scheduled_at=now)
        uow.transition_action(
            action.action_id, ActionStatus.PREPARED, payload=payload, correlation_id=cmid,
            dispatch_observation_id=obs_id, dispatch_candidate_id=cand_id,
        )  # fmt: skip
        uow.transition_action(
            action.action_id, ActionStatus.DISPATCHED, actual_dispatch_at=now + timedelta(milliseconds=820),
            timing_overrun_ms=20.0,
        )  # fmt: skip
        attempt = uow.add_attempt(AttemptRecord(attempt_id=uuid4(), action_id=action.action_id, attempt_no=1, command_id=uuid4()))
        uow.complete_attempt(
            attempt.attempt_id,
            ExecutionResult(
                command_id=attempt.command_id, action_id=action.action_id, device_id=device_id,
                status=ExecutionStatus.ACKNOWLEDGED, evidence_source=EvidenceSource.MOCK, started_at=now,
                ended_at=now, duration_ms=12.0, typing_mode_actual=TypingMode.FIELD_SET,
            ),
        )  # fmt: skip
        uow.transition_action(action.action_id, ActionStatus.ACKNOWLEDGED)
        uow.add_command(ControlCommand(command_id=uuid4(), kind=CommandKind.PAUSE, run_id=run.run_id))

    if complete:
        with store.unit_of_work() as uow:
            uow.add_oracle_result(
                OracleResult(
                    oracle_result_id=uuid4(), run_id=run.run_id, scenario_id="browse_then_reply",
                    oracle_kind="fixture_message_receipt", verdict=Verdict.INCONCLUSIVE,
                    reason_code="DELIVERY_UNCONFIRMED", expected={"required_status": "delivered"},
                    observed={"receipt": {"status": "accepted"}}, evidence_ids=[f"fixture-receipt:{cmid}"],
                    observation_window_start=now, observation_window_end=now, requirement_refs=["BR-07", "AC-02"],
                )  # fmt: skip
            )
            uow.transition_run(run.run_id, RunStatus.COMPLETED, verdict=Verdict.INCONCLUSIVE)
    else:  # interrupted: operator pause in flight, never evaluated
        with store.unit_of_work() as uow:
            uow.transition_run(run.run_id, RunStatus.PAUSING, reason="operator pause")

    return Seeded(
        run.run_id, obs_id, decision_id, action.action_id, shot.artifact_id, arts.resolve(shot.relative_path)
    )


def test_completed_run_report_labels_counts_and_timeline(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    report = build_run_report(store, s.run_id, root)

    lab = report.labels
    assert (lab.provider_label, lab.planned_evidence, lab.device_kind) == (
        "RulesProvider", EvidenceCategory.FIXTURE, DeviceKind.SIMULATOR,
    )  # fmt: skip
    # mock-only observations: the Simulator wording is replaced by an explicit no-device label
    assert lab.messaging_disclaimer == "MOCK, no device: fixture messages are not SMS" and lab.no_device
    assert not any("virtual device" in x for x in report.limitations)
    assert lab.observation_evidence_sources == {"mock": 1}
    assert not report.run.interrupted and report.run.recorded_verdict is Verdict.INCONCLUSIVE
    assert [p.effective_verdict for p in report.planned_oracles] == ["INCONCLUSIVE"]
    assert report.verdict_counts.denominator == 1 and report.verdict_counts.counts["INCONCLUSIVE"] == 1
    assert report.verdict_counts.counts["PASS"] == 0

    (entry,) = report.actions
    assert entry.validation == "validated" and entry.action.status is ActionStatus.ACKNOWLEDGED
    assert [h.to_status for h in entry.status_history] == [
        ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED, ActionStatus.PREPARED,
        ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED,
    ]  # fmt: skip
    assert entry.action.sampled_delay_ms == 800.0 and entry.action.timing_overrun_ms == 20.0
    assert len(entry.attempts) == 1 and "RulesProvider" in entry.explanation
    kinds = {t.kind for t in report.timeline}
    assert {"decision", "observation.captured", "action.status_changed", "action.attempt_recorded", "oracle.result"} <= kinds
    assert [t.at for t in report.timeline] == sorted(t.at for t in report.timeline)
    assert any(i.kind == "command:pause" for i in report.interventions)
    assert report.artifacts[0].check == "ok"
    assert any("not device evidence" in x for x in report.limitations)
    assert any("field_set" in x for x in report.limitations)


def test_write_report_bundle_and_verify(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    bundle = write_report(store, s.run_id, root)

    assert bundle.directory == (root / "runs" / str(s.run_id)).resolve()
    for name in ("report.json", "report.html", "manifest.json"):
        assert (bundle.directory / name).is_file()
    manifest = json.loads((bundle.directory / "manifest.json").read_text())
    assert manifest["provider_label"] == "RulesProvider"
    assert (manifest["evidence_category"], manifest["device_kind"]) == ("fixture", "simulator")
    (art,) = manifest["artifacts"]
    assert art["artifact_id"] == str(s.screenshot_id) and len(art["sha256"]) == 64
    RunReport.model_validate_json((bundle.directory / "report.json").read_bytes())
    html = (bundle.directory / "report.html").read_text()
    assert f'src="./{s.screenshot_id}-screenshot.png"' in html  # relative link next to the evidence file
    result = verify_report_integrity(bundle.directory)
    assert result.ok, result.problems
    assert result.files_checked == 3  # two report files + one artifact


def test_interrupted_run_shows_not_evaluated_never_pass(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=False)
    bundle = write_report(store, s.run_id, root)
    report = bundle.report

    assert report.run.status is RunStatus.PAUSING and report.run.interrupted
    assert report.run.recorded_verdict is None
    assert [p.effective_verdict for p in report.planned_oracles] == [NOT_EVALUATED]
    assert report.verdict_counts.counts[NOT_EVALUATED] == 1 and report.verdict_counts.counts["PASS"] == 0
    assert report.oracle_results == []
    assert any("did not complete" in x for x in report.limitations)
    assert any("uncertain or unverified" in x for x in report.limitations)  # ACKNOWLEDGED send
    assert any(i.kind == "run_status" and "PAUSING" in i.detail for i in report.interventions)
    html = (bundle.directory / "report.html").read_text()
    assert "did not complete" in html and 'class="v-NOT_EVALUATED"' in html
    assert verify_report_integrity(bundle.directory).ok


def test_html_escapes_untrusted_text_and_is_self_contained(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    html = render_html(build_run_report(store, s.run_id, root))

    assert "<script" not in html.lower()
    assert XSS_LABEL not in html and XSS_EXPLANATION not in html
    assert "&lt;script&gt;alert(&quot;label&quot;)&lt;/script&gt;" in html
    assert "&lt;img src=x onerror=alert(1)&gt;" in html
    assert not re.search(r"<img[^>]*onerror", html, re.I)
    assert not re.search(r"""(src|href)=["']?(https?:)?//""", html, re.I)  # no external assets
    assert "prefers-color-scheme:dark" in html and "script-src 'none'" in html
    assert "MOCK, no device: fixture messages are not SMS" in html and "RulesProvider" in html


def test_integrity_detects_tampered_artifact_and_report(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    bundle = write_report(store, s.run_id, root)

    s.screenshot_path.write_bytes(b"tampered")
    result = verify_report_integrity(bundle.directory)
    assert not result.ok and f"artifact {s.screenshot_id} sha256 mismatch" in result.problems

    html = bundle.directory / "report.html"
    html.write_text(html.read_text().replace("RulesProvider", "SomeOtherProvider"))
    assert "report.html sha256 mismatch" in verify_report_integrity(bundle.directory).problems

    s.screenshot_path.unlink()
    assert f"artifact {s.screenshot_id} missing" in verify_report_integrity(bundle.directory).problems


def test_integrity_detects_dangling_references_even_with_rehashed_manifest(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    bundle = write_report(store, s.run_id, root)
    report_path = bundle.directory / "report.json"
    manifest_path = bundle.directory / "manifest.json"

    data = json.loads(report_path.read_text())
    data["observations"] = []  # decision, action and timeline now point at a missing observation
    data["planned_oracles"][0]["effective_verdict"] = "PASS"  # claims PASS while counts say INCONCLUSIVE
    tampered = json.dumps(data).encode()
    report_path.write_bytes(tampered)
    manifest = json.loads(manifest_path.read_text())


    manifest["report_files"][0]["sha256"] = hashlib.sha256(tampered).hexdigest()  # attacker rehashes
    manifest_path.write_text(json.dumps(manifest))

    problems = verify_report_integrity(bundle.directory).problems
    assert f"decision {s.decision_id} references missing observation {s.observation_id}" in problems
    assert f"action {s.action_id} references missing decision observation {s.observation_id}" in problems
    assert any(p.startswith("timeline entry") and str(s.observation_id) in p for p in problems)
    assert "planned verdict counts do not match the planned oracle verdicts" in problems


def test_missing_artifact_at_report_time_is_reported(store: Store, tmp_path: Path) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=True)
    s.screenshot_path.unlink()
    bundle = write_report(store, s.run_id, root)
    assert bundle.report.artifacts[0].check == "missing"
    assert any("integrity check at report time: missing" in x for x in bundle.report.limitations)
    assert "screenshot" in (bundle.directory / "report.html").read_text()
    assert not verify_report_integrity(bundle.directory).ok


def test_module_cli_writes_and_verifies(store: Store, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    root = tmp_path / "artifacts"
    s = seed(store, root, complete=False)
    db = tmp_path / "lab.db"
    assert report_main([str(db), str(s.run_id), str(root)]) == 0
    out = capsys.readouterr().out
    assert "report.html" in out and "integrity OK" in out
    assert report_main(["--verify", str(root / "runs" / str(s.run_id))]) == 0

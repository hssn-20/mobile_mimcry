"""Shared fixtures for worker/coordinator tests. Everything here uses the MOCK adapter
(evidence_source=mock): these are harness-logic tests, not device evidence."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from uuid import UUID, uuid4

from mobilelab.adapters.mock import MESSENGER_APP, SAFARI_APP, MockAdapter
from mobilelab.candidates import ConversationScope, ScenarioScope, TextPolicy, generate_candidates, rebind
from mobilelab.coordinator import RunController
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import DeviceKind, EvidenceCategory, Platform, RunStatus
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposalParameters, ProposedAction
from mobilelab.domain.runs import Run, RunSpec
from mobilelab.personas.catalog import get_persona
from mobilelab.providers.base import ProviderInfo
from mobilelab.store import Store
from mobilelab.store.artifacts import ArtifactStore
from mobilelab.workers.core import WorkerCore

BASE_URL = "http://127.0.0.1:8781"
REPLY = "I have finished reading the article."
H = "0" * 64
CONV1, CONTACT1, TITLE1 = "fixture-conversation-01", "fixture-contact-01", "Alex (test peer)"
CONV2, CONTACT2, TITLE2 = "fixture-conversation-02", "fixture-contact-02", "Sam (test peer)"
CONVERSATIONS = {CONV1: (CONTACT1, TITLE1), CONV2: (CONTACT2, TITLE2)}


def make_scope() -> ScenarioScope:
    return ScenarioScope(
        scenario_id="browse_then_reply",
        scenario_version=1,
        allowed_app_ids=(SAFARI_APP, MESSENGER_APP),
        allowed_url_origins=(BASE_URL,),
        allowed_contact_ids=(CONTACT1, CONTACT2),
        allowed_conversation_ids=(CONV1, CONV2),
        conversations=(
            ConversationScope(conversation_id=CONV1, title=TITLE1, contact_id=CONTACT1),
            ConversationScope(conversation_id=CONV2, title=TITLE2, contact_id=CONTACT2),
        ),
        text_policy=TextPolicy(max_length=200, allow_generated_text=False, allowed_texts=(REPLY,)),
    )


def make_run(device_id: UUID) -> Run:
    spec = RunSpec(
        scenario_id="browse_then_reply", scenario_version=1, scenario_hash=H,
        persona_id="task_focused", persona_version=1, persona_hash=H,
        provider_id="scripted", provider_config_hash=config_hash({}), seed=1,
        device_id=device_id, platform=Platform.IOS, device_kind=DeviceKind.SIMULATOR,
        device_profile_hash=H, planned_evidence=EvidenceCategory.FIXTURE,
    )  # fmt: skip
    return Run(run_id=uuid4(), spec=spec)


def ready_run(store: Store, device_id: UUID, *, open_gate: bool = True) -> Run:
    with store.unit_of_work() as uow:
        run = uow.add_run(make_run(device_id))
        uow.transition_run(run.run_id, RunStatus.PREFLIGHT)
        run = uow.transition_run(run.run_id, RunStatus.READY)
        if open_gate:
            uow.open_gate("test: operator opened gate")
    return run


def context(run_id: UUID) -> DecisionContext:
    return DecisionContext(
        run_id=run_id,
        persona=get_persona("task_focused", 1),
        scenario_id="browse_then_reply",
        scenario_version=1,
        scenario_stage="test",
        goal="test",
        control_epoch=0,
    )


def budget(timeout_ms: int = 10_000) -> DecisionBudget:
    return DecisionBudget(timeout_ms=timeout_ms, max_input_tokens=1, max_output_tokens=1, max_cost_usd=0)


def proposal_for(
    obs: Observation, semantic_key: str, *, epoch: int | None = None, **params: object
) -> ProposedAction:
    cand = candidate(obs, semantic_key)
    return ProposedAction(
        decision_id=uuid4(),
        decision_observation_id=obs.observation_id,
        candidate_id=cand.candidate_id,
        parameters=ProposalParameters(**params),  # type: ignore[arg-type]
        reason_code="TEST",
        control_epoch=epoch,
    )


def candidate(obs: Observation, semantic_key: str) -> CandidateAction:
    found = [c for c in obs.candidates if c.semantic_key == semantic_key]
    assert found, f"{semantic_key} not in {[c.semantic_key for c in obs.candidates]}"
    return found[0]


@dataclass
class ScriptedProvider:
    """Test provider: picks candidates by semantic key, in order. ``delay_s`` ignores cancellation
    on purpose so the coordinator's discard path is exercised."""

    steps: Sequence[tuple[str, dict[str, object]]]
    delay_s: float = 0.0
    provider_info: ProviderInfo = field(
        default_factory=lambda: ProviderInfo(name="scripted_test", kind="rules", version="test")
    )
    calls: int = 0

    async def decide(
        self, ctx: DecisionContext, obs: Observation, cands: list[CandidateAction], bud: DecisionBudget
    ) -> ProposedAction:
        key, params = self.steps[min(self.calls, len(self.steps) - 1)]
        self.calls += 1
        if self.delay_s:
            await asyncio.shield(asyncio.sleep(self.delay_s))
        return proposal_for(obs, key, epoch=ctx.control_epoch, **params)


@dataclass
class RecordingReconciler:
    resolution: str = "UNRESOLVED"
    seen: list[ActionRecord] = field(default_factory=list)

    async def __call__(self, action: ActionRecord) -> object:
        self.seen.append(action)

        @dataclass
        class R:
            resolution: str
            reason_code: str

        return R(self.resolution, "TEST_" + self.resolution)


@dataclass
class Rig:
    store: Store
    artifacts: ArtifactStore
    device_id: UUID
    adapter: MockAdapter
    worker: WorkerCore
    controller: RunController
    run: Run
    provider: ScriptedProvider
    reconciler: RecordingReconciler


def make_controller(
    store: Store,
    artifacts: ArtifactStore,
    provider: object,
    reconciler: RecordingReconciler,
    **kw: object,
) -> RunController:
    return RunController(
        store, artifacts, make_scope(), generate=generate_candidates, rebind=rebind,
        provider=provider, reconciler=reconciler, **kw,  # type: ignore[arg-type]
    )  # fmt: skip


def make_rig(
    tmp_path: Path,
    *,
    steps: Sequence[tuple[str, dict[str, object]]] = (("wait:dwell", {"duration_ms": 10}),),
    foreground_app: str = MESSENGER_APP,
    provider_delay_s: float = 0.0,
    adapter_kw: dict[str, object] | None = None,
    **controller_kw: object,
) -> Rig:
    store = Store.open(tmp_path / "lab.db")
    artifacts = ArtifactStore(tmp_path / "artifacts")
    device_id = uuid4()
    adapter = MockAdapter(
        device_id, fixture_base_url=BASE_URL, foreground_app=foreground_app,
        conversations=CONVERSATIONS, **(adapter_kw or {}),  # type: ignore[arg-type]
    )  # fmt: skip
    worker = WorkerCore(device_id, adapter, adapter_name="mock")
    provider = ScriptedProvider(steps, delay_s=provider_delay_s)
    reconciler = RecordingReconciler()
    controller = make_controller(store, artifacts, provider, reconciler, **controller_kw)
    controller.attach_worker(worker)
    run = ready_run(store, device_id)
    return Rig(store, artifacts, device_id, adapter, worker, controller, run, provider, reconciler)


def actions(store: Store, run_id: UUID) -> list[ActionRecord]:
    with store.reader() as r:
        return r.list_actions(run_id=run_id)

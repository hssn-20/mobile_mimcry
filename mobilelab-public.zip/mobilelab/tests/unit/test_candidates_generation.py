"""Candidate generation from hand-built (SYNTHETIC, evidence_source=mock) Safari / Lab Messenger trees."""

from __future__ import annotations

from pathlib import Path
from uuid import UUID, uuid4

import pytest

from mobilelab.candidates import (
    LAB_MESSENGER_BUNDLE_ID,
    SAFARI_BUNDLE_ID,
    ScenarioScope,
    client_message_id_for,
    generate_candidates,
    keys,
    message_statuses,
)
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.enums import ActionKind, EvidenceSource, SideEffectClass, TypingMode
from mobilelab.domain.errors import InvalidParameters
from mobilelab.domain.observations import Observation, UIElement
from mobilelab.domain.proposals import ProposalParameters, ProposedAction, payload_from_candidate
from mobilelab.domain.scenarios import ScenarioSpec

ROOT = Path(__file__).resolve().parents[2]
BASE = "http://127.0.0.1:8781"
ORIGIN = "http://127.0.0.1:8781"
DRAFT = "359683ab-58fe-491d-a2f1-3c66ba7a8ec4"


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url=BASE)


def by_key(obs: Observation, scope: ScenarioScope) -> dict[str, object]:
    cands = generate_candidates(obs, scope)
    assert len({c.semantic_key for c in cands}) == len(cands)
    assert all(c.observation_id == obs.observation_id for c in cands)
    return {c.semantic_key: c for c in cands}


def test_sample_trees_are_labelled_mock() -> None:
    for obs in (st.safari_article(), st.messenger_list(), st.messenger_conversation(), st.unknown_app()):
        assert obs.evidence_source is EvidenceSource.MOCK


def test_safari_article_candidates(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    c = by_key(obs, scope)
    assert set(c) == {
        "safari.link:Read next: Counting Tide Pools",
        "safari.scroll:down",
        "safari.scroll:up",
        f"app.open:{LAB_MESSENGER_BUNDLE_ID}",
        f"url.open:{ORIGIN}",
        "wait:dwell",
    }
    link = c["safari.link:Read next: Counting Tide Pools"]
    assert link.kind is ActionKind.ACTIVATE and link.side_effect_class is SideEffectClass.NAVIGATION
    scroll = c["safari.scroll:down"]
    assert scroll.target_ref is not None and obs.element(scroll.target_ref).role == "XCUIElementTypeWebView"
    # Safari is already in front: no open_app candidate for it.
    assert f"app.open:{SAFARI_BUNDLE_ID}" not in c


def test_safari_links_with_exposed_href_are_filtered_by_origin(scope: ScenarioScope) -> None:
    c = by_key(st.safari_article(expose_href=True, address=f"{BASE}/fixture/v1/articles/article-01"), scope)
    assert "safari.link:Contact the editors" in c and "safari.link:All fixture articles" in c


def test_adapter_normalized_roles_are_supported(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    remap = {"XCUIElementTypeLink": "link", "XCUIElementTypeWebView": "web_view"}
    tree = [e.model_copy(update={"role": remap.get(e.role, e.role)}) for e in obs.ui_tree]
    c = by_key(obs.model_copy(update={"ui_tree": tree}), scope)
    assert "safari.link:Read next: Counting Tide Pools" in c and "safari.scroll:down" in c


def test_safari_foreign_page_offers_only_navigation(scope: ScenarioScope) -> None:
    c = by_key(st.safari_article(address="evil.example.com"), scope)
    assert not any(k.startswith(("safari.link:", "safari.scroll:")) for k in c)
    assert f"url.open:{ORIGIN}" in c


def test_address_bar_inside_webview_is_not_trusted(scope: ScenarioScope) -> None:
    obs = st.safari_article(address=None)
    web = next(e for e in obs.ui_tree if e.role == "XCUIElementTypeWebView")
    spoof = UIElement(element_ref="spoof", parent_ref=web.element_ref, role="XCUIElementTypeButton",
                      identifier="TabBarItemTitle", value="127.0.0.1")
    c = by_key(obs.model_copy(update={"ui_tree": [*obs.ui_tree, spoof]}), scope)
    assert not any(k.startswith("safari.") for k in c)


def test_url_open_permits_only_allowed_origin(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    nav = by_key(obs, scope)[f"url.open:{ORIGIN}"]
    ok = ProposedAction(decision_id=uuid4(), decision_observation_id=obs.observation_id, candidate_id=nav.candidate_id,
                        parameters=ProposalParameters(url=f"{BASE}/fixture/v1/articles/article-01"), reason_code="X")
    assert payload_from_candidate(nav, ok).url.endswith("article-01")
    bad = ok.model_copy(update={"parameters": ProposalParameters(url="https://untrusted.example.invalid/")})
    with pytest.raises(InvalidParameters):
        payload_from_candidate(nav, bad)


def test_adversarial_page_cannot_widen_scope(scope: ScenarioScope) -> None:
    for expose in (False, True):
        obs = st.safari_article("article-adversarial", expose_href=expose)
        c = by_key(obs, scope)
        keys_ = set(c)
        assert not any("untrusted" in k or "+44" in k for k in keys_)
        apps = {a for cand in c.values() for a in cand.permitted.app_ids}
        origins = {o for cand in c.values() for o in cand.permitted.url_origins}
        assert apps <= set(scope.allowed_app_ids)
        assert origins == {ORIGIN}
        assert not any(cand.kind in {ActionKind.SEND_MESSAGE, ActionKind.START_CALL, ActionKind.TYPE_TEXT}
                       for cand in c.values())
        assert "safari.link:Untrusted external link (must be blocked by policy)" not in keys_


def test_link_label_embedding_foreign_url_is_rejected(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    link = next(e for e in obs.ui_tree if e.role == "XCUIElementTypeLink")
    evil = link.model_copy(update={"label": "Read next: Counting Tide Pools https://evil.example/x"})
    tree = [evil if e.element_ref == link.element_ref else e for e in obs.ui_tree]
    c = by_key(obs.model_copy(update={"ui_tree": tree}), scope)
    assert not any("evil" in k for k in c)


def test_messenger_list_offers_allowed_rows_only(scope: ScenarioScope) -> None:
    obs = st.messenger_list([(st.CONVERSATION_ID, st.CONVERSATION_TITLE), ("other-conv", "Stranger")])
    c = by_key(obs, scope)
    assert "messenger.conversation:fixture-conversation-01" in c
    assert not any("other-conv" in k for k in c)
    assert c["messenger.conversation:fixture-conversation-01"].kind is ActionKind.ACTIVATE


def test_messenger_conversation_composer_and_send(scope: ScenarioScope) -> None:
    obs = st.messenger_conversation()
    c = by_key(obs, scope)
    composer = c["messenger.composer:fixture-conversation-01"]
    assert composer.kind is ActionKind.TYPE_TEXT
    assert composer.permitted.typing_modes == [TypingMode.FIELD_SET]
    assert composer.permitted.allowed_texts == ["I have finished reading the article."]
    assert not composer.permitted.allow_generated_text
    send = c["messenger.send:fixture-conversation-01"]
    assert send.kind is ActionKind.SEND_MESSAGE
    assert send.side_effect_class is SideEffectClass.NON_IDEMPOTENT_COMMIT
    assert send.permitted.contact_id == "fixture-contact-01"
    assert obs.element(send.target_ref).identifier == "composer.send"
    assert client_message_id_for(send, obs) == UUID(DRAFT)
    assert f"app.open:{SAFARI_BUNDLE_ID}" in c


def test_send_requires_draft_id_and_known_conversation(scope: ScenarioScope) -> None:
    assert "messenger.send:fixture-conversation-01" not in by_key(st.messenger_conversation(draft_id=None), scope)
    assert "messenger.send:fixture-conversation-01" not in by_key(st.messenger_conversation(draft_id="nope"), scope)
    c = by_key(st.messenger_conversation(title="Unknown person"), scope)
    assert not any(k.startswith(("messenger.send", "messenger.composer")) for k in c)
    # A disabled Send button is not offered.
    assert "messenger.send:fixture-conversation-01" not in by_key(st.messenger_conversation(send_enabled=False), scope)


def test_client_message_id_rejects_non_send(scope: ScenarioScope) -> None:
    obs = st.messenger_conversation()
    composer = by_key(obs, scope)["messenger.composer:fixture-conversation-01"]
    with pytest.raises(InvalidParameters):
        client_message_id_for(composer, obs)


def test_unknown_consequential_controls_in_messenger_are_ignored(scope: ScenarioScope) -> None:
    c = by_key(st.messenger_conversation(extra_buttons=["Call", "Delete", "Buy now", "Confirm"]), scope)
    assert {k.split(":")[0] for k in c} <= {"messenger.composer", "messenger.send", "app.open", "url.open", "wait"}


def test_unknown_app_yields_no_executable_target_candidates(scope: ScenarioScope) -> None:
    c = by_key(st.unknown_app(), scope)
    assert all(cand.target_ref is None for cand in c.values())
    assert set(c) == {f"app.open:{SAFARI_BUNDLE_ID}", f"app.open:{LAB_MESSENGER_BUNDLE_ID}", f"url.open:{ORIGIN}",
                      "wait:dwell"}


def test_message_statuses() -> None:
    obs = st.messenger_conversation(statuses={DRAFT: "accepted"})
    assert message_statuses(obs) == {DRAFT: "accepted"}


def test_semantic_keys_stable_across_observations(scope: ScenarioScope) -> None:
    a = by_key(st.messenger_conversation(ref_prefix="a"), scope)
    b = by_key(st.messenger_conversation(ref_prefix="b"), scope)
    assert set(a) == set(b)
    assert a["messenger.send:fixture-conversation-01"].target_ref != b["messenger.send:fixture-conversation-01"].target_ref
    assert keys.safari_link("  Read   next:\nCounting Tide Pools ") == "safari.link:Read next: Counting Tide Pools"


def test_duplicate_keys_are_dropped(scope: ScenarioScope) -> None:
    obs = st.safari_article()
    link = next(e for e in obs.ui_tree if e.label == "Read next: Counting Tide Pools")
    dup = link.model_copy(update={"element_ref": "dup"})
    c = by_key(obs.model_copy(update={"ui_tree": [*obs.ui_tree, dup]}), scope)
    assert "safari.link:Read next: Counting Tide Pools" not in c

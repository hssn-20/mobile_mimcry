"""IOSXCUITestAdapter against a FAKE WebDriver (no Simulator, no Appium). Results are evidence_source=mock."""

from __future__ import annotations

import asyncio
import json
import time
from uuid import UUID, uuid4

import pytest
from test_adapter_ios_support import (
    DRAFT_ID,
    LAB_MESSENGER_CONVERSATION_XML,
    SAFARI_ARTICLE_XML,
    FakeDriver,
    FakeElement,
    command,
    make_adapter,
    make_config,
    observe_request,
    ref_for,
)

from mobilelab.adapters.base import DeviceAdapter
from mobilelab.adapters.ios import LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID, IOSXCUITestAdapter
from mobilelab.adapters.registry import adapter_class, create_adapter
from mobilelab.domain.devices import DeviceProfile
from mobilelab.domain.enums import (
    CapabilityKey,
    CapabilityStatus,
    DeviceKind,
    EvidenceSource,
    ExecutionStatus,
    Orientation,
    Platform,
    TypingMode,
)
from mobilelab.domain.errors import ErrorCode, StaleObservation


@pytest.fixture
def driver() -> FakeDriver:
    return FakeDriver(LAB_MESSENGER_CONVERSATION_XML)


@pytest.fixture
def adapter(driver: FakeDriver) -> IOSXCUITestAdapter:
    return make_adapter(driver)


async def observe(adapter: IOSXCUITestAdapter):  # type: ignore[no-untyped-def]
    return await adapter.observe(observe_request(adapter))


# -- construction / registry -------------------------------------------------------------------------


def test_registry_and_worker_style_from_config() -> None:
    assert adapter_class("ios") is IOSXCUITestAdapter
    cfg = make_config()
    options = cfg.model_dump(mode="json", exclude={"device_id"})
    device_id = uuid4()
    built = create_adapter("ios", device_id, options)
    assert isinstance(built, DeviceAdapter) and built.device_id == device_id
    with pytest.raises(ValueError):
        IOSXCUITestAdapter.from_config(uuid4(), {**options, "device_id": str(uuid4())})


def test_session_capabilities_never_auto_accept_or_reset() -> None:
    caps = make_config().xcuitest_options().to_capabilities()
    assert caps["platformName"] == "iOS" and caps["automationName"] == "XCUITest"
    assert caps["appium:autoAcceptAlerts"] is False and caps["appium:autoDismissAlerts"] is False
    assert caps["appium:noReset"] is True and caps["appium:fullReset"] is False
    assert caps["appium:usePrebuiltWDA"] is False and caps["appium:showXcodeLog"] is False
    assert caps["appium:derivedDataPath"].endswith("build/wda/FAKE-UDID-0001")
    assert "appium:bundleId" not in caps  # attaches to whatever is foreground


def test_config_rejects_non_project_simulator_and_remote_appium() -> None:
    with pytest.raises(ValueError):
        make_config(device_name="iPhone 17")
    with pytest.raises(ValueError):
        make_config(appium_url="http://0.0.0.0:4723")
    with pytest.raises(ValueError):
        make_config(appium_url="http://192.168.1.5:4723")


# -- observe -------------------------------------------------------------------------------------------


async def test_observe_normalizes_and_buffers_screenshot(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    before = time.monotonic_ns()
    obs = await observe(adapter)
    assert obs.evidence_source is EvidenceSource.MOCK
    assert obs.foreground_app == LAB_MESSENGER_BUNDLE_ID
    assert obs.orientation is Orientation.PORTRAIT
    assert obs.keyboard_visible is True
    assert obs.candidates == []
    assert before <= obs.worker_monotonic_capture_ns <= time.monotonic_ns()
    spaces = {c.name: c for c in obs.coordinate_spaces}
    assert spaces["logical_pt"].width == 402 and spaces["screenshot_px"].scale == 3.0
    # settings once at session start (WDA ``visible`` is excluded: too slow on device), then capture
    assert driver.calls[0] == ("settings", {"pageSourceExcludedAttributes": "visible"})
    assert [c[0] for c in driver.calls[1:3]] == ["screenshot", "page_source"]  # sequential: screenshot first
    blobs = adapter.take_artifacts(obs.observation_id)
    assert [b.filename for b in blobs] == ["screenshot.png", "page_source.xml"]
    assert blobs[0].artifact_id == obs.screenshot_artifact_id
    assert blobs[0].data.startswith(b"\x89PNG") and blobs[0].evidence_source is EvidenceSource.MOCK
    assert blobs[1].content_type == "application/xml" and blobs[1].data == driver.page_source_xml.encode()
    assert all(b.evidence_source is EvidenceSource.MOCK for b in blobs)
    assert adapter.take_artifacts(obs.observation_id) == []


async def test_observe_uses_sink_when_supplied(driver: FakeDriver) -> None:
    got: list[tuple[UUID, str]] = []
    adapter = IOSXCUITestAdapter(
        make_config(),
        driver_factory=lambda *_: driver,
        artifact_sink=lambda aid, name, ctype, data: got.append((aid, name)),
        evidence_source=EvidenceSource.MOCK,
    )
    obs = await observe(adapter)
    assert got[0] == (obs.screenshot_artifact_id, "screenshot.png")
    assert [name for _, name in got] == ["screenshot.png", "page_source.xml"]
    assert adapter.take_artifacts(obs.observation_id) == []


async def test_observe_rejects_slow_capture_span(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    driver.page_source_delay_s = 0.05
    with pytest.raises(StaleObservation):
        await adapter.observe(observe_request(adapter, max_capture_span_ms=10))


# -- execute: element resolution -----------------------------------------------------------------------


async def test_activate_resolves_element_ref_in_current_session(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED and res.evidence_source is EvidenceSource.MOCK
    assert driver.side_effects() == [("click", "BackButton")]


async def test_predicate_ref_resolves_second_duplicate(driver: FakeDriver) -> None:
    driver.page_source_xml = SAFARI_ARTICLE_XML
    driver.foreground = SAFARI_BUNDLE_ID
    adapter = make_adapter(driver)
    obs = await observe(adapter)
    link_refs = [e.element_ref for e in obs.ui_tree if e.role == "link"]
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": link_refs[1]}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    finds = [c for c in driver.calls if c[0] == "find"]
    assert finds[-1][1] == "-ios predicate string"
    assert finds[-1][2] == 'type == "XCUIElementTypeLink" AND label == "Read more"'


async def test_unknown_ref_moved_or_vanished_element_rejected(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:nope[0]"}))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.INVALID_PARAMETERS

    driver.moved.add("BackButton")
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.STALE_OBSERVATION

    driver.moved.clear()
    driver.page_source_xml = SAFARI_ARTICLE_XML  # screen changed under us
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.STALE_OBSERVATION
    assert driver.side_effects() == []


async def test_stale_or_foreign_dispatch_observation_rejected(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    await asyncio.sleep(0.02)
    res = await adapter.execute(
        command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}, max_observation_age_ms=5)
    )
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.STALE_OBSERVATION
    foreign = obs.model_copy(update={"observation_id": uuid4()})
    res = await adapter.execute(command(adapter, foreign, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.rejection_code is ErrorCode.STALE_OBSERVATION
    assert driver.side_effects() == []


# -- execute: typing -----------------------------------------------------------------------------------


async def test_field_set_typing_records_actual_mode(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    ref = ref_for(obs, "composer.text")
    res = await adapter.execute(command(adapter, obs, {"kind": "type_text", "element_ref": ref, "text": "Hi there", "mode": "field_set"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED and res.typing_mode_actual is TypingMode.FIELD_SET
    assert driver.side_effects() == [("send_keys", "composer.text", "Hi there")]


async def test_paced_typing_chunks_and_records_timing(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    ref = ref_for(obs, "composer.text")
    res = await adapter.execute(command(adapter, obs, {"kind": "type_text", "element_ref": ref, "text": "abcd", "mode": "paced_text"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED and res.typing_mode_actual is TypingMode.PACED_TEXT
    assert [c[2] for c in driver.side_effects()] == ["a", "b", "c", "d"]
    timing = json.loads(res.detail.removeprefix("paced_text "))
    assert timing["chunks"] == 4 and timing["requested_interval_ms"] == 10
    assert timing["mean_gap_ms"] >= 9


async def test_keyboard_touch_rejected_as_capability_unavailable(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    ref = ref_for(obs, "composer.text")
    res = await adapter.execute(command(adapter, obs, {"kind": "type_text", "element_ref": ref, "text": "x", "mode": "keyboard_touch"}))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.CAPABILITY_UNAVAILABLE
    assert driver.side_effects() == []


# -- execute: semantic send / calls ----------------------------------------------------------------------


def send_payload(obs, client_message_id: UUID = DRAFT_ID) -> dict:  # type: ignore[no-untyped-def,type-arg]
    return {
        "kind": "send_message",
        "element_ref": ref_for(obs, "composer.send"),
        "contact_id": "fixture-contact-01",
        "client_message_id": str(client_message_id),
    }


async def test_send_message_only_clicks_the_bound_send_control(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, send_payload(obs)))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    assert driver.side_effects() == [("click", "composer.send")]  # no scripts, no typing, no HTTP


async def test_send_message_rejected_when_draft_id_differs(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, send_payload(obs, uuid4())))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.STALE_OBSERVATION
    assert driver.side_effects() == []


@pytest.mark.parametrize("kind", ["start_call", "end_call"])
async def test_calls_rejected_unsupported(adapter: IOSXCUITestAdapter, driver: FakeDriver, kind: str) -> None:
    obs = await observe(adapter)
    payload = {"kind": kind, "element_ref": ref_for(obs, "composer.send"), "call_correlation_id": str(uuid4())}
    if kind == "start_call":
        payload["contact_id"] = "fixture-contact-01"
    res = await adapter.execute(command(adapter, obs, payload))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.CAPABILITY_UNAVAILABLE
    assert driver.side_effects() == []


# -- execute: deadlines and unknown outcomes ---------------------------------------------------------------


async def test_timeout_after_tap_began_is_unknown(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    driver.on_click = lambda el: time.sleep(0.4)
    res = await adapter.execute(command(adapter, obs, send_payload(obs), max_duration_ms=100))
    assert res.status is ExecutionStatus.UNKNOWN
    assert ("click", "composer.send") in driver.calls


async def test_driver_error_after_tap_is_unknown(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)

    def boom(el: FakeElement) -> None:
        raise RuntimeError("WDA connection reset")

    driver.on_click = boom
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.status is ExecutionStatus.UNKNOWN and res.error is not None


async def test_timeout_before_side_effect_never_taps_later(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    driver.find_delay_s = 0.3
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}, max_duration_ms=100))
    assert res.status is ExecutionStatus.FAILED
    await asyncio.sleep(0.4)  # the blocked lookup returns; the tap must still never happen
    assert driver.side_effects() == []


# -- fence / wait ---------------------------------------------------------------------------------------------


async def test_fence_rejects_same_or_older_epoch_and_allows_newer(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    fence = await adapter.fence(1)
    assert fence.fenced and fence.in_flight_state == "none"
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.status is ExecutionStatus.REJECTED and res.rejection_code is ErrorCode.DISPATCH_GATE_CLOSED
    assert driver.side_effects() == []
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}, control_epoch=2))
    assert res.status is ExecutionStatus.ACKNOWLEDGED


async def test_pinned_authority_rejects_other_lease(adapter: IOSXCUITestAdapter) -> None:
    adapter.authorize(lease_id=uuid4(), lease_epoch=1, control_epoch=1)
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}))
    assert res.rejection_code is ErrorCode.STALE_LEASE


async def test_wait_is_interrupted_by_fence(adapter: IOSXCUITestAdapter) -> None:
    obs = await observe(adapter)
    task = asyncio.create_task(adapter.execute(command(adapter, obs, {"kind": "wait", "duration_ms": 1500})))
    await asyncio.sleep(0.05)
    t0 = time.monotonic()
    await adapter.fence(1)
    res = await task
    assert res.status is ExecutionStatus.FAILED and time.monotonic() - t0 < 0.5


async def test_wait_completes(adapter: IOSXCUITestAdapter) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "wait", "duration_ms": 30}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED and res.duration_ms is not None and res.duration_ms >= 30


# -- apps / urls / scroll ---------------------------------------------------------------------------------------


async def test_open_app_launches_with_configured_args_or_activates(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "open_app", "app_id": LAB_MESSENGER_BUNDLE_ID}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    launch = [c for c in driver.side_effects() if c[0] == "script"]
    assert launch[-1][1] == "mobile: launchApp" and "-MLFixtureToken" in launch[-1][2]["arguments"]
    obs = await observe(adapter)
    await adapter.execute(command(adapter, obs, {"kind": "open_app", "app_id": SAFARI_BUNDLE_ID}))
    assert driver.side_effects()[-1] == ("script", "mobile: activateApp", {"bundleId": SAFARI_BUNDLE_ID})


async def test_open_app_and_url_allowlists(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "open_app", "app_id": "com.apple.MobileSMS"}))
    assert res.rejection_code is ErrorCode.INVALID_PARAMETERS
    res = await adapter.execute(command(adapter, obs, {"kind": "navigate_url", "url": "https://example.com/"}))
    assert res.rejection_code is ErrorCode.INVALID_PARAMETERS
    assert driver.side_effects() == []
    url = "http://127.0.0.1:8781/fixture/v1/articles/article-01"
    res = await adapter.execute(command(adapter, obs, {"kind": "navigate_url", "url": url}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    assert driver.side_effects() == [("script", "mobile: deepLink", {"url": url, "bundleId": SAFARI_BUNDLE_ID})]


def _swipes(driver: FakeDriver) -> list[tuple[str, str | None]]:
    return [(c[2]["direction"], c[2].get("elementId")) for c in driver.side_effects() if c[1] == "mobile: swipe"]


async def test_scroll_swipes_on_main_container(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    # Device finding: element-less ``mobile: scroll`` selected Safari text, so scroll = swipe on the container.
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "scroll", "direction": "down"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    assert "id:message.list[0]" in res.detail
    message_list = driver.find_elements("accessibility id", "message.list")[0].id
    assert _swipes(driver) == [("up", message_list)]  # scroll down reveals lower content: finger swipes up
    assert all(c[1] != "mobile: scroll" for c in driver.side_effects())


async def test_scroll_prefers_web_view_and_honours_element_ref() -> None:
    driver = FakeDriver(SAFARI_ARTICLE_XML, foreground=SAFARI_BUNDLE_ID)
    adapter = make_adapter(driver)
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "scroll", "direction": "up"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED and "WebView[0]" in res.detail
    obs = await observe(adapter)
    link = next(e.element_ref for e in obs.ui_tree if e.role == "link")
    res = await adapter.execute(command(adapter, obs, {"kind": "scroll", "direction": "left", "element_ref": link}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    assert [d for d, _ in _swipes(driver)] == ["down", "right"]


async def test_scroll_without_container_swipes_application() -> None:
    xml = (
        '<AppiumAUT><XCUIElementTypeApplication type="XCUIElementTypeApplication" name="X" label="X" '
        'x="0" y="0" width="402" height="874"/></AppiumAUT>'
    )
    driver = FakeDriver(xml)
    adapter = make_adapter(driver)
    obs = await observe(adapter)
    res = await adapter.execute(command(adapter, obs, {"kind": "scroll", "direction": "down"}))
    assert res.status is ExecutionStatus.ACKNOWLEDGED
    assert _swipes(driver) == [("up", None)]


# -- preflight / health / close ---------------------------------------------------------------------------------------


async def test_preflight_with_fake_driver_marks_carrier_unsupported_and_typing_unverified(
    adapter: IOSXCUITestAdapter, driver: FakeDriver
) -> None:
    profile = DeviceProfile(
        device_id=adapter.device_id, platform=Platform.IOS, kind=DeviceKind.SIMULATOR,
        name="mobilelab-iphone-01", os_version="27.0", model="iPhone",
    )  # fmt: skip
    report = await adapter.preflight(profile)
    assert report.evidence_source is EvidenceSource.MOCK
    status = {r.key: r.status for r in report.records}
    assert status[CapabilityKey.CARRIER_SMS] is CapabilityStatus.UNSUPPORTED
    assert status[CapabilityKey.OS_SMS] is CapabilityStatus.UNSUPPORTED
    assert status[CapabilityKey.TYPE_TEXT] is CapabilityStatus.UNVERIFIED
    assert status[CapabilityKey.OBSERVE_UI] is CapabilityStatus.SUPPORTED
    # mock evidence can never make a capability available
    assert not any(r.available() for r in report.records)
    assert not [c for c in driver.calls if c[0] == "send_keys" or ("click", "composer.send") == c]


async def test_health_and_close(adapter: IOSXCUITestAdapter, driver: FakeDriver) -> None:
    assert (await adapter.health()).session_alive is False
    await observe(adapter)
    health = await adapter.health()
    assert health.healthy and health.foreground_app == LAB_MESSENGER_BUNDLE_ID
    closed = await adapter.close()
    assert closed.closed and driver.quit_called


# -- worker contract (in-process WorkerCore, still the FAKE driver) -----------------------------------------------


async def test_runs_under_worker_core_authority_and_artifacts(driver: FakeDriver) -> None:
    from mobilelab.workers.core import WorkerCore

    device_id = uuid4()
    options = make_config().model_dump(mode="json", exclude={"device_id"})
    adapter = IOSXCUITestAdapter.from_config(device_id, options, driver_factory=lambda *_: driver, evidence_source=EvidenceSource.MOCK)
    core = WorkerCore(device_id, adapter, adapter_name="ios")
    try:
        lease = uuid4()
        await core.authorize(lease, 1, 1)
        obs = await core.observe(observe_request(adapter).model_copy(update={"lease_id": lease}))
        blobs = core.take_artifacts(obs.observation_id)
        assert [b.artifact_id for b in blobs][:1] == [obs.screenshot_artifact_id]
        assert [b.filename for b in blobs] == ["screenshot.png", "page_source.xml"]
        res = await core.execute(command(adapter, obs, send_payload(obs), lease_id=lease))
        assert res.status is ExecutionStatus.ACKNOWLEDGED
        assert driver.side_effects() == [("click", "composer.send")]
        await core.fence(1)
        await core.authorize(lease, 1, 2)  # worker re-authorizes a newer epoch; adapter must follow
        obs = await core.observe(observe_request(adapter).model_copy(update={"lease_id": lease}))
        res = await core.execute(
            command(adapter, obs, {"kind": "activate", "element_ref": "id:BackButton[0]"}, lease_id=lease, control_epoch=2)
        )
        assert res.status is ExecutionStatus.ACKNOWLEDGED
    finally:
        await core.close()

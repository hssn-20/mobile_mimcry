"""Action payload union, candidate rules, and trusted proposal->payload binding (CONTRACTS §4)."""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError

from mobilelab.domain.actions import ACTION_PAYLOAD_ADAPTER, Activate, SendMessage, TypeText, Wait
from mobilelab.domain.dispatch import BOUND_ACTION_STATUSES, ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus, SideEffectClass, TypingMode
from mobilelab.domain.errors import CandidateNotFound, ErrorCode, InvalidParameters
from mobilelab.domain.observations import CandidateAction, PermittedParameters
from mobilelab.domain.proposals import ProposedAction, payload_from_candidate

MID = "359683ab-58fe-491d-a2f1-3c66ba7a8ec4"

VALID_PAYLOADS: list[dict[str, Any]] = [
    {"kind": "activate", "element_ref": "e1"},
    {"kind": "type_text", "element_ref": "e2", "text": "hello", "mode": "paced_text"},
    {"kind": "scroll", "direction": "down", "element_ref": None},
    {"kind": "scroll", "direction": "up", "element_ref": "list"},
    {"kind": "open_app", "app_id": "com.mobilelab.LabMessenger"},
    {"kind": "navigate_url", "url": "http://127.0.0.1:8765/fixture/v1/articles/a1"},
    {"kind": "wait", "duration_ms": 1500},
    {"kind": "send_message", "element_ref": "send", "contact_id": "fixture-contact-01", "client_message_id": MID},
    {"kind": "start_call", "element_ref": "call", "contact_id": "fixture-contact-01", "call_correlation_id": MID},
    {"kind": "end_call", "element_ref": "hangup", "call_correlation_id": MID},
]


@pytest.mark.parametrize("data", VALID_PAYLOADS, ids=lambda d: d["kind"])
def test_all_nine_kinds_validate_and_roundtrip(data: dict[str, Any]) -> None:
    payload = ACTION_PAYLOAD_ADAPTER.validate_python(data)
    assert payload.kind == data["kind"]
    again = ACTION_PAYLOAD_ADAPTER.validate_json(ACTION_PAYLOAD_ADAPTER.dump_json(payload))
    assert again == payload


def test_kinds_cover_action_kind_enum() -> None:
    assert {d["kind"] for d in VALID_PAYLOADS} == {k.value for k in ActionKind}


@pytest.mark.parametrize(
    "data",
    [
        {"kind": "tap", "element_ref": "e1"},  # unknown kind is not interpreted as a generic tap
        {"kind": "shell", "command": "rm -rf /"},
        {"element_ref": "e1"},  # missing discriminator
        {"kind": "activate", "element_ref": "e1", "contact_id": "fixture-contact-01"},  # activate can't route
        {"kind": "activate", "element_ref": "e1", "xpath": "//XCUIElementTypeButton"},
        {"kind": "type_text", "element_ref": "e2", "text": "x" * 2001, "mode": "paced_text"},
        {"kind": "type_text", "element_ref": "e2", "text": "", "mode": "paced_text"},
        {"kind": "type_text", "element_ref": "e2", "text": "hi", "mode": "telepathy"},
        {"kind": "type_text", "element_ref": "e2", "text": 5, "mode": "paced_text"},
        {"kind": "scroll", "direction": "diagonal"},
        {"kind": "open_app", "app_id": "com.apple.mobilesms; rm"},
        {"kind": "navigate_url", "url": "file:///etc/passwd"},
        {"kind": "navigate_url", "url": "javascript:alert(1)"},
        {"kind": "navigate_url", "url": "https://user:pw@example.com/"},
        {"kind": "wait", "duration_ms": 0},
        {"kind": "wait", "duration_ms": "1500"},  # strict: no string coercion
        {"kind": "wait", "duration_ms": 10_000_000},
        {"kind": "send_message", "element_ref": "send", "contact_id": "fixture-contact-01"},  # no draft identity
        {"kind": "send_message", "element_ref": "send", "contact_id": "+447700900000 OR 1", "client_message_id": MID},
        {"kind": "end_call", "element_ref": "hangup", "call_correlation_id": "not-a-uuid"},
    ],
)
def test_invalid_action_variants_rejected(data: dict[str, Any]) -> None:
    with pytest.raises(ValidationError):
        ACTION_PAYLOAD_ADAPTER.validate_python(data)


def test_payloads_are_immutable() -> None:
    p = Wait(kind="wait", duration_ms=10)
    with pytest.raises(ValidationError):
        p.duration_ms = 20  # type: ignore[misc]


# -- candidates --------------------------------------------------------------------------------


def _cand(kind: ActionKind, **kw: Any) -> CandidateAction:
    defaults: dict[str, Any] = {
        "candidate_id": uuid4(),
        "observation_id": uuid4(),
        "semantic_key": f"test.{kind.value}",
        "kind": kind,
        "target_ref": "el",
        "side_effect_class": SideEffectClass.NONE,
    }
    defaults.update(kw)
    return CandidateAction(**defaults)


def _proposal(candidate: CandidateAction, **params: Any) -> ProposedAction:
    return ProposedAction(
        decision_id=uuid4(),
        decision_observation_id=candidate.observation_id,
        candidate_id=candidate.candidate_id,
        parameters=params,
        reason_code="TEST",
    )


def test_send_candidate_requires_contact_and_commit_class() -> None:
    with pytest.raises(ValidationError):
        _cand(ActionKind.SEND_MESSAGE, side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT)
    with pytest.raises(ValidationError):
        _cand(
            ActionKind.SEND_MESSAGE,
            side_effect_class=SideEffectClass.NONE,
            permitted=PermittedParameters(contact_id="fixture-contact-01"),
        )


def test_generic_activate_candidate_cannot_carry_contact() -> None:
    with pytest.raises(ValidationError):
        _cand(ActionKind.ACTIVATE, permitted=PermittedParameters(contact_id="fixture-contact-01"))


def test_consequential_control_cannot_be_generic_activate() -> None:
    with pytest.raises(ValidationError):
        _cand(ActionKind.ACTIVATE, side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT)
    with pytest.raises(ValidationError):
        _cand(ActionKind.TYPE_TEXT, side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT,
              permitted=PermittedParameters(allow_generated_text=True, typing_modes=[TypingMode.FIELD_SET]))  # fmt: skip


def test_targeted_candidate_requires_target_ref() -> None:
    with pytest.raises(ValidationError):
        _cand(ActionKind.ACTIVATE, target_ref=None)


def test_send_message_payload_uses_trusted_contact_and_draft_identity() -> None:
    cand = _cand(
        ActionKind.SEND_MESSAGE,
        side_effect_class=SideEffectClass.NON_IDEMPOTENT_COMMIT,
        permitted=PermittedParameters(contact_id="fixture-contact-01"),
    )
    mid = uuid4()
    payload = payload_from_candidate(cand, _proposal(cand), client_message_id=mid)
    assert isinstance(payload, SendMessage)
    assert payload.contact_id == "fixture-contact-01" and payload.client_message_id == mid
    with pytest.raises(InvalidParameters):
        payload_from_candidate(cand, _proposal(cand))  # no trusted draft id
    with pytest.raises(InvalidParameters):
        payload_from_candidate(cand, _proposal(cand, text="hi"), client_message_id=mid)


def test_type_text_parameter_policy() -> None:
    fixed = _cand(
        ActionKind.TYPE_TEXT,
        side_effect_class=SideEffectClass.TEXT_ENTRY,
        permitted=PermittedParameters(allowed_texts=["On my way"], typing_modes=[TypingMode.PACED_TEXT]),
    )
    p = payload_from_candidate(fixed, _proposal(fixed))
    assert isinstance(p, TypeText) and p.text == "On my way" and p.mode is TypingMode.PACED_TEXT
    with pytest.raises(InvalidParameters):
        payload_from_candidate(fixed, _proposal(fixed, text="ignore previous instructions"))
    with pytest.raises(InvalidParameters):
        payload_from_candidate(fixed, _proposal(fixed, text="On my way", typing_mode="field_set"))

    free = _cand(
        ActionKind.TYPE_TEXT,
        side_effect_class=SideEffectClass.TEXT_ENTRY,
        permitted=PermittedParameters(
            allow_generated_text=True, max_text_length=10, typing_modes=[TypingMode.FIELD_SET, TypingMode.PACED_TEXT]
        ),
    )
    with pytest.raises(InvalidParameters):
        payload_from_candidate(free, _proposal(free, text="short"))  # ambiguous typing mode
    assert payload_from_candidate(free, _proposal(free, text="short", typing_mode="field_set")).mode is TypingMode.FIELD_SET
    with pytest.raises(InvalidParameters):
        payload_from_candidate(free, _proposal(free, text="far too long text", typing_mode="field_set"))


def test_activate_rejects_any_parameters() -> None:
    cand = _cand(ActionKind.ACTIVATE)
    with pytest.raises(InvalidParameters) as exc:
        payload_from_candidate(cand, _proposal(cand, text="hello"))
    assert exc.value.code is ErrorCode.INVALID_PARAMETERS


def test_navigate_url_origin_allowlist() -> None:
    cand = _cand(
        ActionKind.NAVIGATE_URL,
        target_ref=None,
        side_effect_class=SideEffectClass.NAVIGATION,
        permitted=PermittedParameters(url_origins=["http://127.0.0.1:8765"]),
    )
    ok = payload_from_candidate(cand, _proposal(cand, url="http://127.0.0.1:8765/fixture/v1/articles/a1"))
    assert ok.kind == "navigate_url"
    with pytest.raises(InvalidParameters):
        payload_from_candidate(cand, _proposal(cand, url="https://evil.example/"))
    with pytest.raises(InvalidParameters):
        payload_from_candidate(cand, _proposal(cand, url="http://127.0.0.1:9999/"))


def test_open_app_and_wait_limits() -> None:
    app = _cand(
        ActionKind.OPEN_APP,
        target_ref=None,
        side_effect_class=SideEffectClass.NAVIGATION,
        permitted=PermittedParameters(app_ids=["com.mobilelab.LabMessenger"]),
    )
    assert payload_from_candidate(app, _proposal(app)).kind == "open_app"
    with pytest.raises(InvalidParameters):
        payload_from_candidate(app, _proposal(app, app_id="com.apple.MobileSMS"))
    wait = _cand(ActionKind.WAIT, target_ref=None, permitted=PermittedParameters(max_wait_ms=2000))
    with pytest.raises(InvalidParameters):
        payload_from_candidate(wait, _proposal(wait, duration_ms=5000))


def test_proposal_for_other_candidate_is_rejected() -> None:
    cand = _cand(ActionKind.ACTIVATE)
    other = _cand(ActionKind.ACTIVATE)
    with pytest.raises(CandidateNotFound):
        payload_from_candidate(cand, _proposal(other))


def test_proposal_bound_to_other_observation_is_rejected() -> None:
    cand = _cand(ActionKind.ACTIVATE)
    proposal = _proposal(cand).model_copy(update={"decision_observation_id": uuid4()})
    with pytest.raises(CandidateNotFound):
        payload_from_candidate(cand, proposal)


def test_rebound_candidate_accepts_original_candidate_id() -> None:
    original = _cand(ActionKind.ACTIVATE)
    rebound = _cand(ActionKind.ACTIVATE, rebound_from_candidate_id=original.candidate_id)
    assert payload_from_candidate(rebound, _proposal(original)).kind == "activate"


# -- provider output --------------------------------------------------------------------------

CONTRACT_PROPOSAL = {
    "schema_version": 1,
    "decision_id": "80c626ba-3cdc-4b39-82cb-70fa5a8cbd74",
    "decision_observation_id": "bd2d0577-f2e1-4c5e-a6ba-a3554fa44a0e",
    "candidate_id": "f12e02a1-f60f-4c8f-a1d4-b9396a0731a8",
    "parameters": {"text": "I am leaving in a few minutes."},
    "reason_code": "REPLY_TO_TEST_CONTACT",
    "completion": False,
}


def test_contract_proposal_example_validates() -> None:
    p = ProposedAction.model_validate_json(json.dumps(CONTRACT_PROPOSAL))
    assert p.candidate_id == UUID("f12e02a1-f60f-4c8f-a1d4-b9396a0731a8")
    assert p.parameters.text == "I am leaving in a few minutes."


@pytest.mark.parametrize(
    "mutation",
    [
        {"element_ref": "send"},  # provider may not supply element refs
        {"contact_id": "someone"},
        {"parameters": {"text": "hi", "xpath": "//*"}},
        {"parameters": {"contact_id": "someone"}},
        {"completion": "yes"},
        {"schema_version": 2},
        {"reason_code": "free form reason"},
        {"parameters": {"text": "x" * 2001}},
    ],
)
def test_invalid_provider_output_rejected(mutation: dict[str, Any]) -> None:
    with pytest.raises(ValidationError):
        ProposedAction.model_validate_json(json.dumps({**CONTRACT_PROPOSAL, **mutation}))


# -- action journal invariants ------------------------------------------------------------------


def _record(kind: ActionKind, side_effect: SideEffectClass, **kw: Any) -> ActionRecord:
    data: dict[str, Any] = {
        "action_id": uuid4(), "run_id": uuid4(), "device_id": uuid4(), "kind": kind,
        "semantic_key": f"test.{kind.value}", "side_effect_class": side_effect,
        "decision_observation_id": uuid4(), "original_candidate_id": uuid4(),
    }  # fmt: skip
    data.update(kw)
    return ActionRecord(**data)


def test_action_record_commit_class_must_match_kind() -> None:
    with pytest.raises(ValidationError):
        _record(ActionKind.SEND_MESSAGE, SideEffectClass.NONE)
    with pytest.raises(ValidationError):
        _record(ActionKind.ACTIVATE, SideEffectClass.NON_IDEMPOTENT_COMMIT)
    assert _record(ActionKind.SEND_MESSAGE, SideEffectClass.NON_IDEMPOTENT_COMMIT).status is ActionStatus.PROPOSED


def test_action_record_payload_must_match_kind_and_correlation() -> None:
    mid = uuid4()
    send = SendMessage(kind="send_message", element_ref="send", contact_id="fixture-contact-01", client_message_id=mid)
    commit = SideEffectClass.NON_IDEMPOTENT_COMMIT
    with pytest.raises(ValidationError):  # a send journaled as a generic tap
        _record(ActionKind.SEND_MESSAGE, commit, payload=Activate(kind="activate", element_ref="send"), correlation_id=mid)
    with pytest.raises(ValidationError):  # correlation identity differs from the payload's draft id
        _record(ActionKind.SEND_MESSAGE, commit, payload=send, correlation_id=uuid4())
    assert _record(ActionKind.SEND_MESSAGE, commit, payload=send, correlation_id=mid).payload == send


@pytest.mark.parametrize("status", sorted(BOUND_ACTION_STATUSES))
def test_bound_statuses_require_payload_and_dispatch_binding(status: ActionStatus) -> None:
    payload = Activate(kind="activate", element_ref="el")
    with pytest.raises(ValidationError):
        _record(ActionKind.ACTIVATE, SideEffectClass.NONE, status=status)
    with pytest.raises(ValidationError):
        _record(ActionKind.ACTIVATE, SideEffectClass.NONE, status=status, payload=payload)
    ok = _record(ActionKind.ACTIVATE, SideEffectClass.NONE, status=status, payload=payload,
                 dispatch_observation_id=uuid4(), dispatch_candidate_id=uuid4())  # fmt: skip
    assert ok.status is status
    # Pre-dispatch exits never reached the device and need no binding.
    assert _record(ActionKind.ACTIVATE, SideEffectClass.NONE, status=ActionStatus.REJECTED).payload is None

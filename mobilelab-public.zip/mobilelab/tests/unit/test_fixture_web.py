"""Fixture web content: articles, adversarial page, form, error pages, request evidence."""

from __future__ import annotations

import re
import time
from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import pytest

from mobilelab.fixtures.testing import FixtureTestBed
from mobilelab.fixtures.web import ARTICLES


@pytest.fixture
async def bed(tmp_path: Path) -> AsyncIterator[FixtureTestBed]:
    async with FixtureTestBed(tmp_path) as bed:
        yield bed


async def test_health_needs_no_auth(bed: FixtureTestBed) -> None:
    resp = await bed.data.get("/fixture/v1/health")
    assert resp.json() == {
        "schema_version": 1,
        "status": "ok",
        "service": "mobilelab-fixture",
        "fixture_data_version": "fixture-data-1",
    }


@pytest.mark.parametrize("article_id", ["article-01", "article-02"])
async def test_articles_render_with_stable_ids(bed: FixtureTestBed, article_id: str) -> None:
    resp = await bed.data.get(f"/fixture/v1/articles/{article_id}")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    page = resp.text
    assert '<meta name="fixture-article-version" content="1">' in page
    assert '<meta name="fixture-data-version" content="fixture-data-1">' in page
    for element_id in ("article-title", "para-01", "para-12", "link-contact-form", "article-end"):
        assert f'id="{element_id}"' in page
    assert 'href="/fixture/v1/forms/contact"' in page
    other = "article-02" if article_id == "article-01" else "article-01"
    assert f'href="/fixture/v1/articles/{other}"' in page
    # Several screens long so scrolling matters.
    assert len(re.findall(r'<p id="para-\d+"', page)) >= 12
    # Deterministic rendering.
    assert (await bed.data.get(f"/fixture/v1/articles/{article_id}")).text == page


async def test_adversarial_page_exists(bed: FixtureTestBed) -> None:
    page = (await bed.data.get("/fixture/v1/articles/article-adversarial")).text
    assert 'id="injected-instructions"' in page
    assert "Ignore your instructions" in page
    assert "+44 7700 900123" in page
    assert "Open Settings" in page and "Run shell command" in page
    assert ARTICLES["article-adversarial"].adversarial


async def test_index_and_unknown_article(bed: FixtureTestBed) -> None:
    index = (await bed.data.get("/fixture/v1/articles")).text
    for article_id in ARTICLES:
        assert f'id="index-link-{article_id}"' in index
    resp = await bed.data.get("/fixture/v1/articles/does-not-exist")
    assert resp.status_code == 404
    assert resp.headers["content-type"].startswith("text/html")
    assert 'id="error-title"' in resp.text


async def test_run_id_propagates_into_links_and_is_not_reflected_unsafely(bed: FixtureTestBed) -> None:
    run_id = uuid4()
    page = (await bed.data.get("/fixture/v1/articles/article-01", params={"run_id": str(run_id)})).text
    assert f'href="/fixture/v1/articles/article-02?run_id={run_id}"' in page
    hostile = (await bed.data.get("/fixture/v1/articles/article-01", params={"run_id": '"><script>x'})).text
    assert "<script>x" not in hostile


async def test_contact_form(bed: FixtureTestBed) -> None:
    form = (await bed.data.get("/fixture/v1/forms/contact")).text
    assert 'id="contact-form"' in form and 'id="contact-submit"' in form
    resp = await bed.data.post(
        "/fixture/v1/forms/contact",
        content="name=Sam&message=%3Cb%3Ehello%3C%2Fb%3E",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert resp.status_code == 200
    assert 'data-result="accepted"' in resp.text
    assert "&lt;b&gt;hello&lt;/b&gt;" in resp.text
    missing = await bed.data.post(
        "/fixture/v1/forms/contact", content="name=Sam", headers={"Content-Type": "application/x-www-form-urlencoded"}
    )
    assert missing.status_code == 400 and 'data-result="invalid"' in missing.text


@pytest.mark.parametrize("code", [404, 500, 503])
async def test_deterministic_error_pages(bed: FixtureTestBed, code: int) -> None:
    resp = await bed.data.get(f"/fixture/v1/errors/{code}")
    assert resp.status_code == code
    assert f'data-status="{code}"' in resp.text


async def test_slow_page_delays_by_configured_amount(bed: FixtureTestBed) -> None:
    started = time.monotonic()
    resp = await bed.data.get("/fixture/v1/errors/slow")
    assert resp.status_code == 200
    assert time.monotonic() - started >= bed.config.slow_error_delay_ms / 1000
    assert f'data-delay-ms="{bed.config.slow_error_delay_ms}"' in resp.text


async def test_web_requests_logged_as_evidence(bed: FixtureTestBed) -> None:
    reset = await bed.reset()
    rid = str(reset.run_id)
    await bed.data.get("/fixture/v1/articles/article-01", params={"run_id": rid}, headers={"User-Agent": "Safari-test"})
    await bed.data.get("/fixture/v1/articles/article-02")  # no run id: unscoped
    await bed.send(reset)
    entries = await bed.admin.request_log(reset.run_id)
    article = next(e for e in entries if e.path == "/fixture/v1/articles/article-01")
    assert article.user_agent == "Safari-test"
    assert article.status == 200 and article.run_id == reset.run_id
    assert article.detail == {"article_id": "article-01", "article_version": "1", "layout": "default"}
    assert any(e.path == "/fixture/v1/messages" and e.status == 201 for e in entries)
    assert all(e.path != "/fixture/v1/articles/article-02" for e in entries)
    unscoped = await bed.admin.request_log(reset.run_id, include_unscoped=True)
    assert any(e.path == "/fixture/v1/articles/article-02" and e.run_id is None for e in unscoped)
    # The bearer token never appears in evidence.
    assert all(reset.sender.token not in e.model_dump_json() for e in unscoped)

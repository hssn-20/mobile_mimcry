"""LunaProvider unit tests with an injected FAKE policy backend.

LABELLED FAKE: every answer below is scripted by the test. These tests exercise mobilelab's prompt,
schema, validation, budget and late-result handling. They are NOT AI tests and say nothing about how
GPT-6 Luna behaves.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any
from uuid import UUID

import pytest

from mobilelab.budget import BudgetExceeded, BudgetLedger, TokenUsage
from mobilelab.candidates import ScenarioScope, generate_candidates
from mobilelab.candidates import sample_trees as st
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.enums import ActionKind
from mobilelab.domain.observations import CandidateAction, PermittedParameters
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.personas import get_persona
from mobilelab.providers import (
    DecisionProvider,
    LunaProvider,
    ProviderCancelled,
    ProviderOutputInvalid,
    ProviderRequestRejected,
    ProviderStaleResult,
    ProviderTimeout,
    create_provider,
    load_luna_config,
)
from mobilelab.providers.openai_backend import BackendError, BackendResult
from mobilelab.providers.policy_io import build_output_schema, build_policy_request

ROOT = Path(__file__).resolve().parents[2]
USAGE = TokenUsage(input_tokens=1200, output_tokens=80, cached_input_tokens=0, reasoning_tokens=30, cache_write_tokens=0)


@pytest.fixture(scope="module")
def scope() -> ScenarioScope:
    spec = ScenarioSpec.from_yaml((ROOT / "configs/scenarios/browse_then_reply.yaml").read_text())
    return ScenarioScope.from_scenario(spec, fixture_data_base_url="http://127.0.0.1:8781")


@pytest.fixture
def ledger(tmp_path: Path) -> BudgetLedger:
    return BudgetLedger.open(tmp_path / "ledger.db", run_cap_usd=0.25)


def ctx(epoch: int = 4) -> DecisionContext:
    return DecisionContext(run_id=UUID(int=7), persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
                           scenario_version=1, scenario_stage="read_article",
                           goal="Read a fixture article and reply to the designated test contact.",
                           authorized_url_origins=["http://127.0.0.1:8781"], control_epoch=epoch)  # fmt: skip


def budget(**kw: Any) -> DecisionBudget:
    base: dict[str, Any] = {"timeout_ms": 5000, "max_input_tokens": 8000, "max_output_tokens": 1500, "max_cost_usd": 0.01}
    base.update(kw)
    return DecisionBudget(**base)


class FakeBackend:
    """LABELLED FAKE backend: returns scripted outputs, records the requests it was given."""

    model = "gpt-6-luna"

    def __init__(self, outputs: list[Any], *, delay_s: float = 0.0, usage: TokenUsage | None = USAGE) -> None:
        self.outputs = list(outputs)
        self.delay_s = delay_s
        self.usage = usage
        self.calls: list[dict[str, Any]] = []
        self.cancelled = 0

    async def complete(self, **kw: Any) -> BackendResult:
        self.calls.append(kw)
        try:
            if self.delay_s:
                await asyncio.sleep(self.delay_s)
        except asyncio.CancelledError:
            self.cancelled += 1
            raise
        out = self.outputs.pop(0)
        if isinstance(out, BaseException):
            raise out
        text = out if isinstance(out, str) else json.dumps(out)
        return BackendResult(output_text=text, usage=self.usage, request_id=f"req_fake_{len(self.calls)}",
                             response_id=f"resp_fake_{len(self.calls)}", model=self.model, latency_ms=1.0)  # fmt: skip


def provider(backend: FakeBackend, ledger: BudgetLedger, **kw: Any) -> LunaProvider:
    return LunaProvider(load_luna_config(), backend=backend, ledger=ledger, **kw)


def answer(index: int, reason: str = "READ_CONTENT", completion: bool = False, **params: Any) -> dict[str, Any]:
    return {"choice": {"candidate_index": index, **params}, "reason_code": reason, "completion": completion}


def idx(cands: list[CandidateAction], key: str) -> int:
    return next(i for i, c in enumerate(cands) if c.semantic_key == key)


# ---------------------------------------------------------------- schema & prompt
def test_provider_info_and_protocol(ledger: BudgetLedger) -> None:
    p = provider(FakeBackend([]), ledger)
    assert isinstance(p, DecisionProvider)
    info = p.provider_info
    assert (info.kind, info.deployment, info.model, info.supports_images) == ("openai", "cloud", "gpt-6-luna", False)


def test_schema_only_allows_supplied_indices_and_permitted_params(scope: ScenarioScope) -> None:
    obs = st.messenger_conversation()
    cands = generate_candidates(obs, scope)
    schema = build_output_schema(cands, ["READ_CONTENT"])
    variants = schema["properties"]["choice"]["anyOf"]
    assert [v["properties"]["candidate_index"]["enum"] for v in variants] == [[i] for i in range(len(cands))]
    for v, c in zip(variants, cands, strict=True):
        assert v["additionalProperties"] is False and set(v["required"]) == set(v["properties"])
        names = set(v["properties"]) - {"candidate_index"}
        expected = {ActionKind.TYPE_TEXT: {"text", "typing_mode"}, ActionKind.WAIT: {"duration_ms"},
                    ActionKind.OPEN_APP: {"app_id"}, ActionKind.NAVIGATE_URL: {"url"}}.get(c.kind, set())  # fmt: skip
        assert names == expected
        if c.kind is ActionKind.TYPE_TEXT:  # composer only offers its allowed text
            assert v["properties"]["text"]["enum"] == c.permitted.allowed_texts
    assert schema["additionalProperties"] is False


def test_prompt_hides_ids_and_selectors_and_quotes_screen_text(scope: ScenarioScope) -> None:
    obs = st.messenger_conversation()
    cands = generate_candidates(obs, scope)
    req = build_policy_request(ctx(), obs, cands, reason_codes=["OTHER"], max_elements=60, text_limit=160,
                               max_input_tokens=8000)  # fmt: skip
    text = req.instructions + req.user_input + json.dumps(req.schema)
    for c in cands:
        assert str(c.candidate_id) not in text and str(c.observation_id) not in text
        if c.target_ref:
            assert f'"{c.target_ref}"' not in text
    for e in obs.ui_tree:
        if e.identifier:
            assert e.identifier not in req.user_input
    doc = json.loads(req.user_input)
    assert doc["screen"]["untrusted"] is True and "UNTRUSTED" in req.instructions
    assert req.input_token_bound <= 8000


def test_prompt_shrinks_to_fit_budget(scope: ScenarioScope) -> None:
    obs = st.safari_article("article-adversarial")
    cands = generate_candidates(obs, scope)
    big = build_policy_request(ctx(), obs, cands, reason_codes=["OTHER"], max_elements=60, text_limit=160,
                               max_input_tokens=8000)  # fmt: skip
    small = build_policy_request(ctx(), obs, cands, reason_codes=["OTHER"], max_elements=60, text_limit=160,
                                 max_input_tokens=big.input_token_bound - 1)  # fmt: skip
    assert small.elements_included < big.elements_included and small.input_token_bound < big.input_token_bound


# ---------------------------------------------------------------- happy path & ledger
async def test_valid_choice_maps_to_real_candidate_and_reconciles(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "safari.scroll:down")
    backend = FakeBackend([answer(i, "SCROLL_CONTENT", direction="down")])
    p = provider(backend, ledger)
    proposal = await p.decide(ctx(), obs, cands, budget())
    assert proposal.candidate_id == cands[i].candidate_id
    assert proposal.decision_observation_id == obs.observation_id and proposal.control_epoch == 4
    assert proposal.completion is False and proposal.reason_code == "SCROLL_CONTENT"
    ev = p.last_evidence
    assert ev is not None and ev.outcome == "accepted" and ev.retry_count == 0 and ev.chosen_index == i
    assert ev.attempts[0].ledger_status == "confirmed" and ev.attempts[0].request_id == "req_fake_1"
    assert ev.attempts[0].confirmed_usd and ev.attempts[0].confirmed_usd <= ev.attempts[0].reserved_usd
    s = ledger.summary(str(UUID(int=7)))
    assert s.confirmed_usd > 0 and s.estimated_usd == 0 and s.unresolved_usd == 0
    assert backend.calls[0]["max_output_tokens"] == 1500


async def test_completion_is_only_a_hint(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.messenger_conversation()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "wait:dwell")
    proposal = await provider(FakeBackend([answer(i, "GOAL_COMPLETE", True, duration_ms=1000)]), ledger).decide(
        ctx(), obs, cands, budget())
    assert proposal.completion is True and cands[i].kind is ActionKind.WAIT  # no verdict, no run completion


# ---------------------------------------------------------------- rejection before ProposedAction
@pytest.mark.parametrize(
    "bad",
    [
        answer(99, direction="down"),  # invented index
        answer(-1),
        {"choice": {"candidate_index": "1"}, "reason_code": "READ_CONTENT", "completion": False},
        "not json at all",
        {"choice": {"candidate_index": 0}, "reason_code": "PWNED", "completion": False},
    ],
)
async def test_invalid_outputs_rejected_after_one_repair(scope: ScenarioScope, ledger: BudgetLedger, bad: Any) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    backend = FakeBackend([bad, bad])
    p = provider(backend, ledger)
    with pytest.raises(ProviderOutputInvalid):
        await p.decide(ctx(), obs, cands, budget())
    assert len(backend.calls) == 2  # one bounded repair, no more
    ev = p.last_evidence
    assert ev is not None and ev.outcome == "provider_error" and ev.decision_id is None and ev.retry_count == 1
    assert [a.purpose for a in ev.attempts] == ["decision", "repair"]
    assert all(a.reservation_id for a in ev.attempts)  # repair had its own reservation
    assert len(ledger.rows()) == 2


async def test_extra_params_and_send_disguised_as_activate_rejected(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.messenger_conversation()
    cands = generate_candidates(obs, scope)
    send = idx(cands, "messenger.send:fixture-conversation-01")
    wait = idx(cands, "wait:dwell")
    disguised = answer(wait, duration_ms=10, kind="send_message", contact_id="attacker", element_ref="x")
    extra_on_send = answer(send, "SEND_REPLY", text="hello")  # send takes no model parameters
    backend = FakeBackend([disguised, extra_on_send])
    p = provider(backend, ledger)
    with pytest.raises(ProviderOutputInvalid):
        await p.decide(ctx(), obs, cands, budget())
    problems = [x for a in p.last_evidence.attempts for x in a.validation_problems]  # type: ignore[union-attr]
    assert any("not permitted" in x for x in problems)


async def test_over_length_text_rejected_then_repaired(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.messenger_conversation()
    base = generate_candidates(obs, scope)
    comp = next(c for c in base if c.kind is ActionKind.TYPE_TEXT)
    generated = comp.model_copy(update={"permitted": PermittedParameters(
        allow_generated_text=True, max_text_length=20, typing_modes=comp.permitted.typing_modes)})  # fmt: skip
    cands = [generated if c is comp else c for c in base]
    i = cands.index(generated)
    backend = FakeBackend([answer(i, "COMPOSE_REPLY", text="x" * 21, typing_mode="field_set"),
                           answer(i, "COMPOSE_REPLY", text="Done, thanks.", typing_mode="field_set")])  # fmt: skip
    p = provider(backend, ledger)
    proposal = await p.decide(ctx(), obs, cands, budget())
    assert proposal.parameters.text == "Done, thanks." and p.last_evidence.retry_count == 1  # type: ignore[union-attr]
    assert "rejected" in backend.calls[1]["user_input"]
    assert "x" * 21 not in backend.calls[1]["user_input"]  # repair never echoes model text


async def test_url_outside_permitted_origin_rejected(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "url.open:http://127.0.0.1:8781")
    bad = answer(i, "NAVIGATE_TO_START", url="https://evil.example/steal")
    with pytest.raises(ProviderOutputInvalid):
        await provider(FakeBackend([bad, bad]), ledger).decide(ctx(), obs, cands, budget())


async def test_injection_text_in_labels_does_not_alter_scope(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article("article-adversarial")
    cands = generate_candidates(obs, scope)
    clean = generate_candidates(st.safari_article(), scope)
    assert sorted(c.semantic_key for c in cands if c.kind is not ActionKind.ACTIVATE) == sorted(
        c.semantic_key for c in clean if c.kind is not ActionKind.ACTIVATE)
    req = build_policy_request(ctx(), obs, cands, reason_codes=["OTHER"], max_elements=60, text_limit=160,
                               max_input_tokens=8000)  # fmt: skip
    schema_indices = [v["properties"]["candidate_index"]["enum"][0] for v in req.schema["properties"]["choice"]["anyOf"]]
    assert schema_indices == list(range(len(cands)))
    adversarial = [e.label for e in obs.ui_tree if e.label and e.label in st.ADVERSARIAL_TEXT]
    assert adversarial and all(json.dumps(a, ensure_ascii=False)[1:-1][:40] in req.user_input for a in adversarial)
    assert all(a not in req.instructions for a in adversarial)
    # whatever the screen says, a choice outside the list cannot become a proposal
    with pytest.raises(ProviderOutputInvalid):
        await provider(FakeBackend([answer(len(cands)), answer(len(cands))]), ledger).decide(ctx(), obs, cands, budget())


# ---------------------------------------------------------------- budget, timeout, cancel, stale
async def test_budget_refusal_at_cap_sends_nothing(scope: ScenarioScope, tmp_path: Path) -> None:
    ledger = BudgetLedger.open(tmp_path / "cap.db", run_cap_usd=0.002)
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    i = idx(cands, "safari.scroll:down")
    backend = FakeBackend([answer(i, direction="down")] * 5, usage=None)  # usage unknown -> stays reserved
    p = provider(backend, ledger)
    await p.decide(ctx(), obs, cands, budget())
    with pytest.raises(BudgetExceeded):
        await p.decide(ctx(), obs, cands, budget())
    assert len(backend.calls) == 1 and p.last_evidence.outcome == "budget_refused"  # type: ignore[union-attr]


async def test_decision_max_cost_refused(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    backend = FakeBackend([])
    with pytest.raises(BudgetExceeded):
        await provider(backend, ledger).decide(ctx(), obs, cands, budget(max_cost_usd=0.0001))
    assert backend.calls == [] and ledger.rows() == []


async def test_timeout_keeps_reservation_unresolved(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    backend = FakeBackend([answer(0)], delay_s=2.0)
    p = provider(backend, ledger)
    with pytest.raises(ProviderTimeout):
        await p.decide(ctx(), obs, cands, budget(timeout_ms=100))
    rows = ledger.rows()
    assert [r["status"] for r in rows] == ["unresolved"] and backend.cancelled == 1
    s = ledger.summary()
    assert s.unresolved_usd > 0 and s.confirmed_usd == 0 and s.remaining_usd == pytest.approx(5.0 - s.unresolved_usd)


async def test_backend_timeout_and_rejection_classified(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    p = provider(FakeBackend([BackendError("timeout", error_class="APITimeoutError")]), ledger)
    with pytest.raises(ProviderTimeout):
        await p.decide(ctx(), obs, cands, budget())
    p2 = provider(FakeBackend([BackendError("rejected", error_class="AuthenticationError", status_code=401,
                                            billed=False)]), ledger)  # fmt: skip
    with pytest.raises(ProviderRequestRejected):
        await p2.decide(ctx(), obs, cands, budget())
    assert [r["status"] for r in ledger.rows()] == ["unresolved", "released"]


async def test_cancel_during_request_discards_late_result(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    backend = FakeBackend([answer(idx(cands, "safari.scroll:down"), direction="down")], delay_s=1.0)
    p = provider(backend, ledger)
    b = budget(cancel_event=asyncio.Event())

    async def pause_soon() -> None:
        await asyncio.sleep(0.05)
        assert b.cancel_event is not None
        b.cancel_event.set()

    with pytest.raises(ProviderCancelled):
        await asyncio.gather(p.decide(ctx(), obs, cands, b), pause_soon())
    assert p.last_evidence.outcome == "cancelled" and p.last_evidence.decision_id is None  # type: ignore[union-attr]
    assert [r["status"] for r in ledger.rows()] == ["unresolved"]


async def test_epoch_change_discards_result_but_confirms_cost(scope: ScenarioScope, ledger: BudgetLedger) -> None:
    obs = st.safari_article()
    cands = generate_candidates(obs, scope)
    epoch = {"now": 4}

    class Bumping(FakeBackend):
        async def complete(self, **kw: Any) -> BackendResult:
            epoch["now"] = 5  # operator paused while the model was thinking
            return await super().complete(**kw)

    p = provider(Bumping([answer(idx(cands, "safari.scroll:down"), direction="down")]), ledger,
                 epoch_probe=lambda: epoch["now"])  # fmt: skip
    with pytest.raises(ProviderStaleResult):
        await p.decide(ctx(epoch=4), obs, cands, budget())
    assert p.last_evidence.outcome == "discarded_stale"  # type: ignore[union-attr]
    assert [r["status"] for r in ledger.rows()] == ["confirmed"]


def test_registry_builds_luna_with_injected_backend(ledger: BudgetLedger) -> None:
    p = create_provider("luna", {"backend": FakeBackend([]), "ledger": ledger})
    assert isinstance(p, LunaProvider) and p.config.store is False and p.config.send_images is False


def test_config_rate_card_is_frozen_with_source() -> None:
    cfg = load_luna_config()
    rc = cfg.rate_card
    assert cfg.model == rc.model == "gpt-6-luna"
    assert str(rc.source_url).startswith("https://developers.openai.com/") and rc.retrieved_on.isoformat() == "2026-10-04"
    assert cfg.frozen["rate_card_id"] == rc.rate_card_id
    assert cfg.global_cap_usd <= 5.0 and cfg.run_cap_usd <= 0.25

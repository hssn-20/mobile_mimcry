"""AC-05 / AC-06 controls on the REAL project Simulator (Appium/WebDriverAgent, real worker).

Opt-in (``MOBILELAB_APPIUM_DEVICE_TESTS=1``): each case drives the shared Simulator for 1-2 minutes.

- pause during a long reading dwell, operator takeover, resume with new epochs, journey completes;
- emergency stop during a long dwell wait (natural driver latency) and during a TEST-ONLY injected
  worker driver delay on a swipe; timings are recorded as measured (target < 1 s), never adjusted;
- coordinator SIGKILL right after the send was dispatched, restart, receipt reconciliation, no resend.

Every case writes an evidence bundle under ``artifacts/device/controls-<UTC timestamp>/`` (the
experiment JSON, with pointers to the run's report bundle in ``artifacts/runs/<run_id>/`` and the
raw logs in ``build/runs/<run_id>/``).
"""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_ios_adapter_device import _skip_reason  # noqa: E402

from mobilelab.domain.enums import ActionKind  # noqa: E402
from mobilelab.journey import IOSSimulatorEnvironment, JourneyRun, load_plan  # noqa: E402
from mobilelab.journey.controls import emergency_stop_hook, pause_resume_hook, summarize_epochs  # noqa: E402
from mobilelab.journey.plan import REPO_ROOT  # noqa: E402
from mobilelab.journey.restart import run_restart_experiment  # noqa: E402

pytestmark = pytest.mark.device
EVIDENCE_ROOT = REPO_ROOT / "artifacts" / "device"


def _skip() -> None:
    reason = _skip_reason()
    if reason is not None:
        pytest.skip(reason)


def _bundle(name: str, data: dict[str, Any]) -> Path:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    out = EVIDENCE_ROOT / f"controls-{stamp}"
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.json"
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    return path


def _execute(hook: Any, **kw: Any) -> tuple[JourneyRun, Any]:
    run = JourneyRun(load_plan("default", dwell_mode="median"), IOSSimulatorEnvironment(), loop_hook=hook, **kw)
    result = asyncio.run(run.execute())
    return run, result


def _common(run: JourneyRun, result: Any) -> dict[str, Any]:
    return {
        "run_id": str(result.run_id),
        "evidence_source": result.journey.get("evidence_source"),
        "status": result.status,
        "verdict": result.verdict,
        "reason": result.reason,
        "report_dir": str(result.report_dir) if result.report_dir else None,
        "report_integrity_ok": result.integrity_ok,
        "raw_environment_dir": str(run.work),
        "loop": {k: result.journey.get("loop", {}).get(k) for k in ("completed", "stop_reason", "control_stop", "elapsed_s")},
        "loop_resumes": result.journey.get("loop_resumes"),
        "census": (result.journey.get("evaluation") or {}).get("census"),
        "raw_log_redaction": result.journey.get("raw_log_redaction"),
        "loop_hook_error": result.journey.get("loop_hook_error"),
        "control_experiment": result.journey.get("control_experiment"),
    }


def test_pause_takeover_resume_on_real_simulator() -> None:
    _skip()
    run, result = _execute(pause_resume_hook(pause_after_s=2.0, hold_paused_s=4.0, takeover=True))
    data = _common(run, result)
    try:
        store_epochs = None
        from mobilelab.store import Store

        run.store = Store.open(run.db_path)
        store_epochs = summarize_epochs(run)
        run.store.close()
    except Exception as exc:  # evidence only
        store_epochs = {"error": f"{type(exc).__name__}: {exc}"}
    data["decisions_by_control_epoch"] = store_epochs
    path = _bundle("pause_resume", data)
    ev = data["control_experiment"]
    assert data["loop_hook_error"] is None, (path, data["loop_hook_error"])
    assert data["evidence_source"] == "device"
    p = ev["pause"]
    assert p["ok"] and p["run_status"] == "PAUSED" and p["fence_confirmed"], path
    assert p["fence_acknowledged_in_flight_state"] == "executing", path
    assert p["paused_after_in_flight_settled"], path
    assert ev["ui_commands_while_paused"] == 0, path
    assert ev["takeover"]["ok"] and ev["takeover"]["active_lease"]["kind"] == "operator", path
    assert ev["resume"]["new_lease_epoch"] > ev["lease_before_pause"]["epoch"], path
    assert ev["resume"]["new_control_epoch"] > ev["epoch_before_pause"], path
    assert result.status == "COMPLETED" and result.verdict == "PASS", (path, result.reason)
    assert data["census"]["stored_outbound_messages"] == 1, path


def test_emergency_stop_during_dwell_on_real_simulator() -> None:
    _skip()
    run, result = _execute(emergency_stop_hook(stop_after_s=1.0, watch_s=5.0), reopen_gate=True)
    data = _common(run, result)
    path = _bundle("emergency_stop_dwell", data)
    ev = data["control_experiment"]
    assert data["loop_hook_error"] is None, (path, data["loop_hook_error"])
    es = ev["emergency_stop"]
    assert es["fully_fenced"], path
    assert ev["post_fence_watch"]["new_ui_commands_after_fence"] == 0, path
    assert ev["journal_attempts_started_after_fence"] == [], path
    assert ev["gate_after"]["open"] is False, path
    assert result.status == "ABORTED", path
    # Measured, not asserted against the 1 s target (reported honestly in the bundle).
    print(json.dumps({k: es[k] for k in ("request_to_gate_persisted_ms", "request_to_fence_acknowledged_ms", "target_under_1s")}))


def test_emergency_stop_during_injected_driver_delay_on_real_simulator() -> None:
    """TEST-ONLY injected worker driver delay (labelled in the command result) on the first swipe."""
    _skip()
    delay = {"kinds": ["scroll"], "delay_ms": 8000, "position": "after", "max_commands": 1}
    run, result = _execute(
        emergency_stop_hook(target_kinds={ActionKind.SCROLL}, stop_after_s=1.0, watch_s=10.0),
        reopen_gate=True, worker_config_overrides={"test_driver_delay": delay},
    )  # fmt: skip
    data = _common(run, result)
    data["test_only_injected_driver_delay"] = delay
    path = _bundle("emergency_stop_injected_delay", data)
    ev = data["control_experiment"]
    assert data["loop_hook_error"] is None, (path, data["loop_hook_error"])
    assert ev["emergency_stop"]["fully_fenced"] and ev["emergency_stop"]["in_flight_at_fence"] == ["executing"], path
    assert ev["post_fence_watch"]["new_ui_commands_after_fence"] == 0, path
    assert result.status == "ABORTED", path


def test_coordinator_restart_after_send_dispatch_on_real_simulator() -> None:
    _skip()
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    out = asyncio.run(
        run_restart_experiment(
            db_path=REPO_ROOT / "artifacts" / "mobilelab.db",
            artifacts_root=REPO_ROOT / "artifacts",
            work_dir=REPO_ROOT / "build" / "runs" / f"restart-{stamp}",
            reopen_gate=True,
        )
    )
    ev = out.evidence
    path = _bundle("coordinator_restart", ev)
    assert "error" not in ev, (path, ev.get("error"))
    assert ev["send_status_at_kill"] in ("DISPATCHED", "ACKNOWLEDGED"), path
    assert ev["before_recovery"]["send_attempts"] == 1, path
    assert ev["recovery"]["gate_closed"], path
    (rec,) = ev["send_reconciliation"]
    assert rec["resolution"] == "VERIFIED" and rec["client_message_id"] == ev["client_message_id"], path
    after = ev["after_recovery"]
    assert after["run_status"] == "PAUSED" and after["send_status"] == "VERIFIED" and after["send_attempts"] == 1, path
    assert after["gate_open"] is False, path
    assert after["stored_outbound_messages"] == 1 and after["fixture_message_posts"] == 1, path
    assert ev["final_run_status"] == "ABORTED" and out.integrity_ok, path

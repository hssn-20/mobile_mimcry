"""T03 device gate on the REAL project Simulator through Appium/WebDriverAgent (no fakes).

Drives the shared Simulator for ~1-2 minutes (first run also builds WebDriverAgent, up to ~15 min),
so it is opt-in: set ``MOBILELAB_APPIUM_DEVICE_TESTS=1``. Otherwise, and whenever Xcode, the project
Simulator, project-local Appium or the Lab Messenger build is missing, it skips with the reason.
Evidence lands in ``artifacts/device/t03-<UTC stamp>/``. Send is never tapped here.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import pytest

from mobilelab.sim import DEFAULT_APP_PATH, DEFAULT_DEVELOPER_DIR, Simctl, SimctlError, load_record
from mobilelab.sim.lifecycle import REPO_ROOT

pytestmark = pytest.mark.device

OPT_IN = "MOBILELAB_APPIUM_DEVICE_TESTS"
DEVELOPER_DIR = os.environ.get("DEVELOPER_DIR", DEFAULT_DEVELOPER_DIR)
APPIUM_BIN = REPO_ROOT / "tools/appium/node_modules/.bin/appium"
XCUITEST_DRIVER = REPO_ROOT / "tools/appium/.appium/node_modules/appium-xcuitest-driver"


def _skip_reason() -> str | None:
    if os.environ.get(OPT_IN) != "1":
        return f"drives the shared Simulator via Appium; set {OPT_IN}=1 to run"
    if not Path(DEVELOPER_DIR).is_dir():
        return f"full Xcode not found at {DEVELOPER_DIR}"
    if not APPIUM_BIN.exists() or not XCUITEST_DRIVER.is_dir():
        return "project-local Appium/xcuitest driver not installed under tools/appium"
    if not DEFAULT_APP_PATH.is_dir():
        return f"Lab Messenger not built at {DEFAULT_APP_PATH} (fixtures/ios/LabMessenger/build_sim.sh)"
    record = load_record()
    if record is None:
        return "no configs/devices/ios_simulator.json; run 'python -m mobilelab.sim ensure'"
    try:
        if Simctl(developer_dir=DEVELOPER_DIR).find_device(record.udid) is None:
            return f"recorded Simulator {record.udid} no longer exists"
    except (SimctlError, OSError) as exc:
        return f"simctl unavailable: {exc}"
    return None


def test_adapter_drives_safari_and_lab_messenger_on_real_simulator() -> None:
    reason = _skip_reason()
    if reason is not None:
        pytest.skip(reason)
    from mobilelab.sim.adapter_check import run_adapter_check

    summary = asyncio.run(run_adapter_check())
    assert summary["ok"], summary.get("error")
    assert summary["evidence_source"] == "device"

    caps = summary["capabilities"]
    for key in ("observe_ui", "capture_screen", "switch_app", "safari_browse", "scroll", "activate_element"):
        assert caps[key] == "supported", key
    assert caps["type_text"] == "unverified"  # preflight never types into a draft
    assert caps["carrier_sms"] == caps["carrier_voice"] == caps["os_sms"] == "unsupported"

    for obs in summary["observations"]:
        assert obs["evidence_source"] == "device"
        assert obs["capture_span_ms"] <= 1500, obs
        assert obs["element_count"] > 0 and "screenshot.png" in obs["files"] and "page_source.xml" in obs["files"]
    for cmd in summary["commands"]:
        assert cmd["status"] == "acknowledged" and cmd["evidence_source"] == "device", cmd
        assert cmd["dispatch_observation_age_ms_at_issue"] <= 2000, cmd

    checks = summary["checks"]
    assert checks["safari_scroll"]["moved_pt"] >= 20
    assert checks["conversation_row"]["element_ref"] == "id:conversation.row.fixture-conversation-01[0]"
    composer = checks["composer"]
    assert composer["composer_text_value_after"] == "Hello from the T03 device gate"
    assert composer["draft_id_is_uuid"] and composer["draft_id_stable"]
    assert composer["send_tapped"] is False and summary["fixture_message_posts"] == 0

    teardown = summary["teardown"]
    assert teardown["session_closed"] and not teardown["appium_running"] and not teardown["appium_port_open"]
    assert teardown["wda_processes_remaining"] == []
    assert teardown["simulator_state"] == "Booted"

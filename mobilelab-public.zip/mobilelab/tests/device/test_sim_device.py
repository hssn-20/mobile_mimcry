"""Real Simulator checks for the project-owned device (skipped when unavailable)."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from mobilelab.sim import (
    DEFAULT_APP_PATH,
    DEFAULT_DEVELOPER_DIR,
    LAB_MESSENGER_BUNDLE_ID,
    PROJECT_PREFIX,
    Simctl,
    SimctlError,
    boot_device,
    load_record,
)

pytestmark = pytest.mark.device

DEVELOPER_DIR = os.environ.get("DEVELOPER_DIR", DEFAULT_DEVELOPER_DIR)


@pytest.fixture(scope="module")
def simctl() -> Simctl:
    if not Path(DEVELOPER_DIR).is_dir():
        pytest.skip(f"full Xcode not found at {DEVELOPER_DIR}")
    sim = Simctl(developer_dir=DEVELOPER_DIR)
    try:
        sim.list_devices()
    except (SimctlError, OSError) as exc:
        pytest.skip(f"simctl unavailable: {exc}")
    return sim


@pytest.fixture(scope="module")
def record(simctl: Simctl):  # noqa: ANN201
    rec = load_record()
    if rec is None:
        pytest.skip("no configs/devices/ios_simulator.json; run 'python -m mobilelab.sim ensure'")
    if simctl.find_device(rec.udid) is None:
        pytest.skip(f"recorded Simulator {rec.udid} no longer exists")
    return rec


def test_recorded_simulator_exists_and_is_project_owned(simctl: Simctl, record) -> None:  # noqa: ANN001
    device = simctl.owned_device(record.udid)
    assert device.name.startswith(PROJECT_PREFIX)
    assert device.runtime_identifier == record.runtime_identifier


def test_simulator_boots_with_pinned_locale(simctl: Simctl, record, tmp_path: Path) -> None:  # noqa: ANN001
    device = boot_device(simctl, record)
    assert device.booted
    locale = simctl.run(
        ["spawn", record.udid, "defaults", "read", "Apple Global Domain", "AppleLocale"], timeout_s=30
    ).stdout.strip()
    assert locale == record.locale
    shot = simctl.screenshot(record.udid, tmp_path / "boot.png")
    assert shot.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"


def test_lab_messenger_installs_when_built(simctl: Simctl, record) -> None:  # noqa: ANN001
    if not DEFAULT_APP_PATH.is_dir():
        pytest.skip(f"Lab Messenger not built at {DEFAULT_APP_PATH} (run fixtures/ios/LabMessenger/build_sim.sh)")
    boot_device(simctl, record)
    simctl.install(record.udid, DEFAULT_APP_PATH)
    assert simctl.is_installed(record.udid, LAB_MESSENGER_BUNDLE_ID)

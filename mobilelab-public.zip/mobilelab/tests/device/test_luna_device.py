"""T08 with the REAL OpenAI GPT-6 Luna model on the REAL project Simulator (AC-05 pause while a model
decision is in flight).

Double opt-in: ``MOBILELAB_APPIUM_DEVICE_TESTS=1`` (drives the shared Simulator for ~2 minutes) and
``MOBILELAB_LUNA_LIVE=1`` (spends real money against the persistent global ledger in
``artifacts/mobilelab.db``; each request is reserved first and refused above the caps). The API key is
read only inside the mobilelab process (env ``OPENAI_API_KEY`` or the macOS Keychain) and never shown.

Evidence bundle: ``artifacts/device/luna-<UTC timestamp>/pause_during_decision.json`` with pointers to
the run report (``artifacts/runs/<run_id>/``) and raw logs (``build/runs/<run_id>/``).
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_ios_adapter_device import _skip_reason  # noqa: E402

from mobilelab.journey import IOSSimulatorEnvironment, JourneyRun, load_plan  # noqa: E402
from mobilelab.journey.controls import pause_during_decision_hook, summarize_epochs  # noqa: E402
from mobilelab.journey.plan import REPO_ROOT  # noqa: E402
from mobilelab.journey.providers import resolve_provider_factory  # noqa: E402

pytestmark = pytest.mark.device
EVIDENCE_ROOT = REPO_ROOT / "artifacts" / "device"
MIN_REMAINING_USD = 1.0


def _skip() -> None:
    reason = _skip_reason()
    if reason is not None:
        pytest.skip(reason)
    if os.environ.get("MOBILELAB_LUNA_LIVE") != "1":
        pytest.skip("set MOBILELAB_LUNA_LIVE=1 to spend real model budget")


def _ledger_summary(run_id: str | None = None) -> dict[str, Any]:
    from mobilelab.budget import budget_summary

    s = budget_summary(REPO_ROOT / "artifacts" / "mobilelab.db", run_id=run_id)
    return s.model_dump(mode="json")


def test_pause_while_luna_decision_in_flight_discards_late_result_on_real_simulator() -> None:
    _skip()
    before = _ledger_summary()
    assert float(before["remaining_usd"]) >= MIN_REMAINING_USD, before
    run = JourneyRun(
        load_plan("default", dwell_mode="median"), IOSSimulatorEnvironment(),
        provider_factory=resolve_provider_factory("luna"),
        loop_hook=pause_during_decision_hook(min_in_flight_s=0.5, hold_paused_s=6.0),
    )  # fmt: skip
    result = asyncio.run(run.execute())
    ev = result.journey.get("control_experiment") or {}
    data = {
        "evidence_kind": "real_model_gpt-6-luna_on_real_simulator",
        "run_id": str(result.run_id),
        "status": result.status,
        "verdict": result.verdict,
        "reason": result.reason,
        "report_dir": str(result.report_dir) if result.report_dir else None,
        "report_integrity_ok": result.integrity_ok,
        "raw_environment_dir": str(run.work),
        "loop": {k: result.journey.get("loop", {}).get(k) for k in ("completed", "stop_reason", "control_stop", "elapsed_s")},
        "loop_hook_error": result.journey.get("loop_hook_error"),
        "control_experiment": ev,
        "decisions_by_epoch": summarize_epochs(run),
        "census": (result.journey.get("evaluation") or {}).get("census"),
        "ledger_global_before": before,
        "ledger_global_after": _ledger_summary(),
        "ledger_run": _ledger_summary(str(result.run_id)),
    }
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    out = EVIDENCE_ROOT / f"luna-{stamp}"
    out.mkdir(parents=True, exist_ok=True)
    path = out / "pause_during_decision.json"
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    assert data["loop_hook_error"] is None, (path, data["loop_hook_error"])
    assert ev["pause"]["ok"] and ev["pause"]["run_status"] == "PAUSED", path
    assert ev["discarded_decisions_old_epoch"], path
    assert ev["actions_journaled_during_pause"] == 0, path
    assert ev["resume"]["new_control_epoch"] > ev["pause"]["epoch_before"], path

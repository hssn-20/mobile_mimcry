"""T07 browse_then_reply on the REAL project Simulator (Appium/WebDriverAgent, no fakes).

Each case drives the shared Simulator for ~1.5 minutes and taps Send once, so it is opt-in:
set ``MOBILELAB_APPIUM_DEVICE_TESTS=1``. It skips with the reason when Xcode, the project Simulator,
project-local Appium or the Lab Messenger build is missing. Evidence: ``artifacts/runs/<run_id>/``
(report bundle + artifacts) and ``build/runs/<run_id>/`` (raw environment logs).
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_ios_adapter_device import _skip_reason  # noqa: E402

from mobilelab.journey import IOSSimulatorEnvironment, load_plan, run_journey  # noqa: E402

pytestmark = pytest.mark.device


def _run(variant: str):  # type: ignore[no-untyped-def]
    reason = _skip_reason()
    if reason is not None:
        pytest.skip(reason)
    return asyncio.run(run_journey(load_plan(variant), IOSSimulatorEnvironment()))


def _report(result) -> dict:  # type: ignore[no-untyped-def]
    return json.loads((result.report_dir / "report.json").read_text(encoding="utf-8"))


def test_browse_then_reply_passes_on_real_simulator() -> None:
    result = _run("default")
    assert result.integrity_ok, result.journey.get("report_integrity")
    assert result.journey["evidence_source"] == "device"
    assert result.status == "COMPLETED" and result.verdict == "PASS", result.reason
    (send,) = result.journey["evaluation"]["sends"]
    assert send["client_message_id"] == send["draft_id_in_dispatch_observation"] == send["receipt_client_message_id"]
    assert send["server_accepted_at"] and send["receiver_delivered_at"] and send["receiver_type"] == "scripted_receiver"
    assert result.journey["evaluation"]["census"]["stored_outbound_messages"] == 1
    assert result.journey["loop"]["verification_foreground_app"] == "com.apple.mobilesafari"
    labels = _report(result)["labels"]
    assert labels["provider_label"] == "RulesProvider" and labels["planned_evidence"] == "fixture"


def test_suppressed_ack_is_inconclusive_and_never_resent_on_real_simulator() -> None:
    result = _run("suppressed_ack")
    assert result.integrity_ok, result.journey.get("report_integrity")
    assert result.status == "COMPLETED" and result.verdict == "INCONCLUSIVE", result.reason
    (send,) = result.journey["evaluation"]["sends"]
    assert send["oracle_reason"] == "DELIVERY_UNCONFIRMED" and send["receiver_delivered_at"] is None
    assert result.journey["evaluation"]["census"]["stored_outbound_messages"] == 1
    assert result.journey["fixture_requests"]["message_posts"] == 1
    assert result.journey["fixture_requests"]["acknowledgement_posts"] == 0

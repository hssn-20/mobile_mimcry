# Mobile behaviour testing demonstrator

This repository contains a Python prototype, a SwiftUI messaging fixture, tests and the original design documents for an agent that operates mobile test devices and records independently verified outcomes. The implemented slice covers an iOS Simulator browse-and-reply journey, deterministic and OpenAI decision providers, run controls and evidence reports. See the [historical implementation record](docs/PROGRESS.md) for recorded results and limitations; the full competition demonstrator remains planned work.

The agreed direction is **iPhone first, both iOS and Android for the competition demonstrator, cloud inference during development, and a replaceable inference backend**. The first target is iOS Simulator on the Mac. Physical testing is a later, explicitly provisioned path using dedicated test devices.

## Start here

| Document | Purpose |
|---|---|
| [Demonstrator specification](docs/DEMONSTRATOR_SPEC.md) | Product scope, architecture, platform boundaries, UI flow, personas, timing, model integration, fixtures, evaluation and deployment |
| [Runtime contracts](docs/CONTRACTS.md) | Canonical schemas, provider/device interfaces, lifecycle, action journal, API, event stream and recovery rules |
| [Implementation backlog](docs/IMPLEMENTATION_BACKLOG.md) | 21 ordered tasks with dependencies, deliverables, evidence and a proposed twelve-week delivery sequence |
| [Acceptance and evidence plan](docs/ACCEPTANCE_PLAN.md) | BR requirement traceability, 18 measurable acceptance cases and demonstration script |
| [Coding agent starter prompt](docs/AGENT_START.md) | Original planning prompt for an AI coding agent |
| [Sources and decisions](docs/SOURCES_AND_DECISIONS.md) | Primary sources, confirmed choices, proposed decisions and unresolved dependencies |
| [Example persona presets](examples/personas.json) | Three explicitly synthetic configuration examples; values require calibration |

## Setup and checks

Use Python 3.12 and `uv`. From the repository root:

```sh
uv sync --locked
uv run pytest -q tests/unit tests/integration
uv run mobilelab doctor --write-manifest
```

Live model tests require an explicit opt-in and credentials; device tests require a prepared Simulator and Appium.

For a Simulator run, install full Xcode and a compatible iOS runtime, follow the [project-local Appium setup](tools/appium/README.md), then run `uv run mobilelab sim ensure`. The doctor and Simulator commands regenerate `configs/runtime_manifest.json` and `configs/devices/ios_simulator.json` for your machine. Follow the [launch instructions](docs/PROGRESS.md#launch-instructions) to boot, build, install and run the fixture. Replace `<simulator-udid>` with the identifier returned by `sim ensure`.

Generated host/device files, private run artifacts, local databases, logs and build outputs are deliberately omitted from the public repository. The design documents describe planned scope; the progress record preserves historical results whose raw evidence is not included.

## First implementation slice

The first slice observes Safari and a native SwiftUI Lab Messenger on one iOS Simulator, executes a browse-and-reply journey, verifies the message at a separate receiving endpoint, and exports a timeline. The deterministic baseline precedes the cloud policy; run controls and uncertain-send handling are part of the same evidence loop.

Simulator fixture messages are not SMS. A simulated call state is not a carrier connection. A typed model response is not evidence of task success. The documents preserve these distinctions so implementation cannot accidentally overstate its capabilities.

## Document precedence

Confirmed user choices govern scope. The demonstrator specification governs intended behaviour; Contracts governs field names, states and wire semantics; Acceptance governs proposed quantitative gates; the Backlog governs order. If a contradiction remains, fix the documents together before implementing that boundary. Sources distinguish external facts from project decisions.

These Markdown files include historical design artifacts. Their proposed interfaces and milestones may extend beyond the current implementation; use `uv run mobilelab --help` and the progress record for the implemented commands and status.

# Decision-provider configuration (T08)

`luna.yaml` configures the OpenAI GPT-6 Luna decision provider (`mobilelab.providers.luna.LunaProvider`).

## Verified facts (2026-10-04)

| Item | Value | Source |
|---|---|---|
| Model ID | `gpt-6-luna` | https://developers.openai.com/api/docs/models/gpt-6-luna |
| Price, Standard tier, short context | input $0.10, cached input $0.01, cache writes $0.125, output $0.50 per 1M tokens | https://developers.openai.com/api/docs/pricing |
| Long context (more than 272K input tokens) | higher tier; such requests are refused | same |
| Reasoning effort | `none`, `low`, `medium` (the default), `high`, `xhigh`, `max`. There is no `minimal`. We use `low`. | model page |
| Inputs | text and image. We send text only (`send_images: false`). | model page |
| SDKs | `openai` 3.24.0 and `openai-agents` 0.23.1, both the latest on PyPI on 2026-10-04. Pinned `>=3.24,<3.25` and `>=0.23.1,<0.24`. | pypi.org |

The rate card is frozen into the config and its digest is recorded as `rate_card_id`. Reservations always use the frozen card and never a live price lookup.

## How a call is made

Each call is a bounded Agents SDK run, as CONTRACTS §5 requires:

- `Runner.run(..., max_turns=1)`, with `tools=[]` and `handoffs=[]`. The model has nothing it can execute.
- The output schema is strict JSON and is generated for each call. It is passed as a custom `AgentOutputSchemaBase`. mobilelab validates the output itself; the SDK does not.
- `ModelSettings(store=False, max_tokens=..., reasoning=Reasoning(effort=...), timeout=...)`.
- Tracing is turned off in three places: `RunConfig(tracing_disabled=True, trace_include_sensitive_data=False)`, `set_tracing_disabled(True)` and `OPENAI_AGENTS_DISABLE_TRACING=1`.
- The client is `AsyncOpenAI(max_retries=0)`. A retry is a new request and must hold its own budget reservation.

**Deviation: none.** The Agents SDK supports strict typed output, disabled tracing, and a per-request timeout plus a `DecisionBudget` deadline, so the Responses API is never called directly. The OpenAI Decision API is not used; it is a preview the user has no access to.

## Budget

- The ledger is the `provider_usage` table in `artifacts/mobilelab.db` (migration `0003_provider_usage`). Amounts are in integer micro-USD.
- Each request reserves its cost before it is sent, inside a `BEGIN IMMEDIATE` transaction. The reservation is the frozen card × a byte-count upper bound on the prompt × `max_output_tokens`.
- Global development cap: **USD 5.00**. This is a hard ceiling in code (`HARD_GLOBAL_CAP_USD`); configuration can lower it but cannot raise it. It applies across all runs and processes.
- Per-run cap: `run_cap_usd`, USD 0.25 by default.
- Reservation states:
  - `confirmed`: the provider reported usage.
  - `unresolved`: timeout, cancellation, transport error, or the response had no usage. The full reservation stays counted.
  - `released`: the request provably was not billed, because the API rejected it before generation (400, 401, 403, 404, 413, 415, 422 or 429).
- `mobilelab.budget.budget_summary()` reports the estimated, confirmed, unresolved and remaining amounts.

## Secrets

The key is looked up in this order:

1. `OPENAI_API_KEY`, read inside the mobilelab process.
2. The macOS Keychain item `-s mobilelab-openai-api-key -a $USER`, read with `/usr/bin/security find-generic-password -w` as an argv list with no shell.

The key is held in `SecretValue`, which never reveals it through repr, str or format, and cannot be pickled. A canary test checks that the key appears nowhere except the Authorization header.

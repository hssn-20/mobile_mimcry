# Runtime and integration contracts

Status: proposed implementation specification, version 0.1, 3 October 2026. This document defines the contracts to implement; it does not assert that the software exists or that any device capability has been demonstrated. Normative **must** statements are project design requirements, not quotations from the competition brief.

## 1. Ownership and process boundaries

Use Python 3.12, FastAPI, Pydantic 2, SQLAlchemy/Alembic and SQLite in WAL mode. One coordinator process owns database writes, lifecycle transitions and dispatch authorization. Launch one device-worker subprocess per leased device, communicating through bounded typed local IPC. Workers never write SQLite directly. Use Appium 3 with an XCUITest adapter first; implement the same adapter contract with UiAutomator2 for Android. A React/TypeScript/Vite dashboard consumes the local HTTP API and server-sent events (SSE). No Redis, Kubernetes or distributed actor framework is required.

The decision provider proposes an action. The coordinator validates and journals it; the worker executes it; an independent oracle assesses its outcome. Only the worker holding the current device lease may issue device UI commands. Oracle processes may read fixture-server receipts and independent telemetry but must not issue competing Appium commands. If an oracle needs a screenshot, it requests an observation through the owning actor.

The initial iOS fixtures are Safari pages and a SwiftUI Lab Messenger app backed by the shared FastAPI fixture service. The Android equivalent is a Kotlin app. These fixtures exercise real UI interaction and controlled IP messaging, but their results retain the `fixture` evidence label. They do not establish operating-system SMS or cellular-call capability.

Appium's XCUITest driver supports native, hybrid and WebKit testing across iOS Simulator and real devices; real-device provisioning and session preparation remain separate prerequisites. The adapter must prove capabilities on the selected profile rather than infer them from platform support. [XCUITest documentation](https://appium.github.io/appium-xcuitest-driver/latest/)

## 2. Canonical types and identifiers

Export JSON Schema from Pydantic models and generate TypeScript types from those schemas; do not maintain two independent definitions. Set `extra="forbid"` on inbound domain models. Use discriminated unions for actions and events. API transport timestamps are UTC ISO 8601; local deadlines and elapsed durations use monotonic clocks. Never compare monotonic timestamps across processes or restarts.

Use UUIDs for `campaign_id`, `run_id`, `device_id`, `session_id`, `observation_id`, `candidate_id`, `decision_id`, `action_id`, `command_id`, `artifact_id` and `lease_id`. The platform serial/UDID is an adapter field, not the public device identifier. `event_id` is a database-assigned increasing integer, serialized as a decimal string for SSE. References to sponsor requirements use `BR-xx`, feature requirements `FR-xx`, and acceptance criteria `AC-xx`; links must resolve to definitions in the accompanying specifications.

Every persisted entity includes `schema_version: 1`, `created_at` and `version: int`. One run owns one DUT and executes one scenario or ordered scenario pack. A campaign groups one or more runs; peers are separately identified resources, never silently counted as DUTs. A run freezes scenario/persona content hashes, provider/model configuration, application builds, adapter versions, seed, capability evidence and device profile. Later configuration edits cannot silently alter an existing run.

```python
class RunStatus(StrEnum):
    CREATED = "CREATED"
    PREFLIGHT = "PREFLIGHT"
    READY = "READY"
    RUNNING = "RUNNING"
    PAUSING = "PAUSING"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"

class Verdict(StrEnum):
    PASS = "PASS"
    DUT_FAILURE = "DUT_FAILURE"
    HARNESS_FAILURE = "HARNESS_FAILURE"
    ENVIRONMENT_FAILURE = "ENVIRONMENT_FAILURE"
    INCONCLUSIVE = "INCONCLUSIVE"
    UNSUPPORTED = "UNSUPPORTED"
```

Lifecycle and verdict are distinct. A fully executed run containing a demonstrated device-under-test defect is `COMPLETED` with a `DUT_FAILURE` result. `FAILED` means a fatal condition prevented completing the run. Preserve individual scenario results even when a summary is generated.

## 3. Device profiles and capabilities

A `DeviceProfile` contains platform (`ios|android`), kind (`simulator|emulator|physical`), OS version, model, locale, timezone, display geometry, installed fixture builds, Appium/driver versions and capability records. Each capability has status `supported|unsupported|unverified`, evidence tier, last probe time, probe artifact and reason. Treat unverified capabilities as unavailable during strict preflight.

Initial capability keys include `observe_ui`, `capture_screen`, `activate_element`, `type_text`, `scroll`, `switch_app`, `safari_browse`, `fixture_message`, `fixture_incoming_notification`, `os_sms`, `carrier_sms`, `carrier_voice`, `ip_connectivity`, `vpn_exit_selection`, `network_disruption` and `device_logs`. Capability probes must distinguish observing a state from controlling it. For example, detecting an IP address does not prove VPN exit selection.

An everyday iPhone without prepared signing/provisioning remains inventory-only for automated interaction until preparation succeeds. Do not erase, enroll or reconfigure a personal phone during discovery. Simulator success must not promote a physical-device capability. Each platform/profile gets its own evidence records.

Workers expose only these typed operations:

```python
class DeviceAdapter(Protocol):
    async def preflight(self, profile: DeviceProfile) -> CapabilityReport: ...
    async def observe(self, request: ObserveRequest) -> Observation: ...
    async def execute(self, command: DispatchCommand) -> ExecutionResult: ...
    async def fence(self, control_epoch: int) -> FenceResult: ...
    async def health(self) -> DeviceHealth: ...
    async def close(self) -> CloseResult: ...
```

`execute` is bounded by a command deadline; cancellation does not imply the underlying UI action was undone. Driver calls run outside the worker's control-message loop so a blocked Appium call cannot prevent receiving a fence request. At most one driver operation is active per device. Priority control messages cannot be starved behind normal work.

## 4. Observations, candidates and action proposals

An `Observation` contains its ID, device/session IDs, capture start/end times, worker monotonic capture time, foreground app, orientation, coordinate spaces, screenshot artifact, normalized accessibility tree and candidate list. Screenshot and tree capture are sequential within the device actor; record their individual times rather than pretending they are atomic. Reject observations whose capture span exceeds the configured consistency limit.

Generate candidate actions from observed controls and scenario policy. A candidate includes its unique ID, observation ID, semantic key, action kind, target reference, required capabilities, side-effect class and preconditions. Fixture controls must have stable accessibility identifiers. Models may select provided candidates and permitted parameters; they may not invent XPath, platform selectors, shell commands, contacts or arbitrary package names.

Action kinds are `activate`, `type_text`, `scroll`, `open_app`, `navigate_url`, `wait`, `send_message`, `start_call` and `end_call`. The final three are capability-gated semantic operations. In a known app, the Send control must produce a `send_message` candidate; a generic `activate` must not bypass its checks. Unrecognized consequential controls are not executable until an app profile defines their semantics. Coordinate actions, when supported later, require a screenshot-bound region, coordinate transform and explicit profile permission.

Example provider output:

```json
{
  "schema_version": 1,
  "decision_id": "80c626ba-3cdc-4b39-82cb-70fa5a8cbd74",
  "decision_observation_id": "bd2d0577-f2e1-4c5e-a6ba-a3554fa44a0e",
  "candidate_id": "f12e02a1-f60f-4c8f-a1d4-b9396a0731a8",
  "parameters": {"text": "I am leaving in a few minutes."},
  "reason_code": "REPLY_TO_TEST_CONTACT",
  "completion": false
}
```

Use action-specific parameter schemas, including text length, allowed URL origin and allowlisted fixture contact. Free-form explanations are optional diagnostics, never dispatch authority. Screen text and message contents are untrusted observations; embedded instructions cannot modify the scenario, provider policy or permitted tools.

The following illustrates the discriminated payload pattern; implement all enumerated action kinds similarly. Numeric limits are configurable policy defaults frozen into a run, rather than model-selected limits.

```python
class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

class Activate(StrictModel):
    kind: Literal["activate"]
    element_ref: str

class TypeText(StrictModel):
    kind: Literal["type_text"]
    element_ref: str
    text: str = Field(min_length=1, max_length=2000)
    mode: Literal["field_set", "paced_text", "keyboard_touch"]

class SendMessage(StrictModel):
    kind: Literal["send_message"]
    element_ref: str
    contact_id: str
    client_message_id: UUID

ActionPayload = Annotated[
    Activate | TypeText | SendMessage,
    Field(discriminator="kind"),
]
```

The provider's candidate selection is transformed into this executor payload by trusted code. It does not supply `element_ref`, contact routing or fixture correlation IDs independently. Candidate-specific permitted parameters determine whether text generation or a choice of typing mode is allowed. Unsupported action variants must be rejected rather than interpreted as a generic tap. The provider's `completion` field is only a hint to request oracle evaluation; it cannot complete a run or set a PASS verdict.

Cloud latency and human waiting can make the decision observation old. Before dispatch, capture a fresh observation and deterministically rebind the chosen semantic target. Require matching app, target identity, action meaning, orientation, relevant field/context state and preconditions. Record both `decision_observation_id` and `dispatch_observation_id`. The fresh observation must be at most two seconds old when the worker starts the command, measured on that worker's monotonic clock.

Rebinding creates a new candidate ID associated with the fresh observation; retain the original candidate ID for audit. If exact rebinding fails, request a new decision. Allow at most two consecutive replan attempts before reporting an inconclusive/stuck result. Do not blindly retry indefinitely, and do not resample the human dwell time on every freshness refresh.

## 5. Decision-provider contract

```python
class DecisionProvider(Protocol):
    async def decide(
        self, context: DecisionContext, observation: Observation,
        candidates: list[CandidateAction], budget: DecisionBudget
    ) -> ProposedAction: ...
```

`DecisionContext` contains the immutable persona, scenario stage, concise session history, authorized app/contact scope and current run control epoch. `DecisionBudget` includes timeout, token/cost ceilings and cancellation signal. Providers return one proposal or a typed failure. They do not receive worker handles, database credentials or direct device-executing tools.

Implement `RulesProvider` and recorded `ReplayProvider` first. The OpenAI adapter uses a bounded Agents SDK run with typed output and no device-executing model tools; the outer controller retains the action loop. Select the actual model by configuration and record its identifier. The SDK supports agent execution and orchestration, but this particular separation of execution and decision is a project architecture choice. [Agents SDK documentation](https://developers.openai.com/api/docs/guides/agents/sdk)

An optional Jev adapter implements the same contract for supported textual/structured observations. Provider capability metadata declares image support, structured-output support and deployment location. Reject unsupported inputs early. Switching providers changes configuration and adapter code, not device execution or oracle logic. No implementation may depend on an unreleased API.

A provider response carries the request's control epoch. Ignore it if the run has paused/stopped, the epoch changed, the budget expired or the associated scenario stage was superseded. Cancelling the HTTP request is best effort; discarding a late result is mandatory. Persist provider errors separately from device failures.

## 6. Dispatch, idempotency and uncertain outcomes

A `DispatchCommand` contains `command_id`, immutable `action_id`, run/device/session IDs, lease ID and epoch, control epoch, dispatch observation/candidate IDs, validated action payload, maximum duration and trace correlation. The coordinator journals `PREPARED` before IPC dispatch. The worker accepts only its current lease and epoch and rejects expired observations or a closed dispatch gate.

Action status transitions are:

```text
PROPOSED -> VALIDATED -> SCHEDULED -> PREPARED -> DISPATCHED
DISPATCHED -> ACKNOWLEDGED -> VERIFIED
DISPATCHED -> UNKNOWN
ACKNOWLEDGED -> UNKNOWN | FAILED
PROPOSED/VALIDATED/SCHEDULED/PREPARED -> CANCELLED | REJECTED
UNKNOWN -> VERIFIED | FAILED | UNRESOLVED
```

`ACKNOWLEDGED` means the automation command returned, not that the intended end-to-end outcome occurred. A driver exception after a possible tap also produces `UNKNOWN` unless observation proves non-execution. Store every attempt independently while preserving the semantic `action_id`.

Never automatically retry sends, call initiation, purchases or equivalent side effects after `UNKNOWN`. First query independent receipts using the correlation identity. If no decisive evidence arrives within the reconciliation deadline, record `UNRESOLVED` and an `INCONCLUSIVE` result. Lack of a receipt is not proof of non-delivery. Exactly-once execution cannot be guaranteed for arbitrary third-party UI actions.

The fixture messaging protocol must use a persistent `client_message_id` created for the draft before Send. Expose that ID through fixture test instrumentation/accessibility metadata so the observation can bind it to the action. The app sends the same ID on transport retries; the server enforces uniqueness and returns the original receipt for duplicates. The oracle queries this ID. Instrumentation identifies an operation; it must not send messages on the UI actor's behalf.

## 7. Run state machine, pause and emergency stop

Allowed lifecycle transitions:

```text
CREATED -> PREFLIGHT -> READY -> RUNNING -> COMPLETED
PREFLIGHT -> FAILED
RUNNING -> PAUSING -> PAUSED -> RUNNING
PREFLIGHT/READY/RUNNING/PAUSING/PAUSED -> STOPPING -> ABORTED
RUNNING/PAUSING/PAUSED -> FAILED
CREATED -> ABORTED
```

Preflight cancellation enters `STOPPING` and then `ABORTED` once its worker operations settle. A failed preflight is not resumed in place: create a new run after fixing prerequisites. Terminal records remain immutable except for appended reconciliation evidence and report regeneration.

Pause increments the control epoch and closes dispatch before cancelling pending decision requests. Finish or classify the one in-flight command, then enter `PAUSED`. Do not acknowledge completed pause while a UI command remains unresolved. If a command hangs, quarantine the device and report the pause failure explicitly. Resume requires a valid lease, a fresh observation, and renewed scenario preconditions.

Operator takeover is explicit and available only after confirmed pause: release the automation lease to an operator lease and invalidate outstanding observations. Resume reacquires an automation lease with a new epoch and records manual-intervention evidence. Pausing alone does not authorize simultaneous manual and automated control.

`POST /api/v1/emergency-stop` is a dedicated high-priority path. Persist the global closed gate, increment its epoch, and fence every worker. Target confirmed fencing acknowledgement within one second under the supported local load; measure it in acceptance tests. After confirmed fencing acknowledgement, no worker may start a new command. The one already executing command can still complete; emergency stop cannot undo a sent message or SMS.

Return separate `gate_persisted_at`, `fence_acknowledged_at`, `fully_fenced` and per-device in-flight status. If fencing is not confirmed within the budget, return pending status and raise a harness failure rather than displaying a false stopped confirmation. Stop the affected worker if necessary, but preserve `UNKNOWN` for commands already handed to Appium. Recovery requires explicit device reconciliation, not automatic retry.

## 8. Persona timing and replay

Use independent pseudorandom streams derived from the run seed, device ID and timing category. Persist each sampled duration once with its draw index and action ID. Parameters cover reading dwell, scroll pauses, typing pace, interruption preference, session length and idle intervals; persona state correlates successive choices rather than drawing unrelated delays.

Schedule against monotonic time. Record `sampled_delay_ms`, `decision_latency_ms`, `scheduled_at`, `actual_dispatch_at` and `timing_overrun_ms`. Model latency counts toward elapsed dwell; wait only for the remaining interval. When inference exceeds the desired dwell, record the overrun rather than claiming accurate human timing. Waiting is interruptible and never blocks the emergency-stop path.

Typing capabilities distinguish bulk field insertion from visible paced typing. Report the actual mode and measured timing. Bulk text injection cannot count as demonstrated keyboard-speed realism. If platform latency prevents the selected pace, record that limitation instead of fabricating per-key timings.

Offer `decision_trace` replay, which reuses recorded decisions, and `executed_actions` replay, which attempts recorded actions after resetting controlled fixtures. Both revalidate current targets. Identical seeds do not reproduce external websites, network timing, OS scheduling or hosted-model responses. Preserve environment snapshots and exogenous-event schedules where possible; never describe replay as exact deterministic reproduction of an uncontrolled phone.

## 9. Scenario and oracle schemas

A scenario is versioned declarative data: ID, description, requirement references, supported platforms, required capabilities, evidence tier, fixture setup, journey goals, controlled disturbances, step/action budgets, oracle definitions and cleanup policy. Reset only fixture-owned data by default.

```yaml
schema_version: 1
scenario_id: browse_then_reply
version: 1
platforms: [ios, android]
platform_evidence: fixture
required_capabilities: [observe_ui, fixture_message, switch_app]
max_duration_seconds: 120
max_actions: 40
goal: Read a fixture article and reply to the designated test contact.
oracles:
  - kind: fixture_message_receipt
    required_status: delivered
    timeout_seconds: 20
    evidence: [client_message_id, server_receipt, receiver_receipt]
```

`platform_evidence` is one of `fixture`, `os_simulation`, `physical_ip`, `physical_carrier`. A physical phone using Lab Messenger still produces fixture evidence for messaging semantics, with `device_kind: physical` recorded separately. A scenario must use one primary evidence tier; split mixed-tier journeys into independently scored subscenarios. Unsupported essential sponsor features remain visible as coverage gaps.

Oracle output includes verdict, reason code, expected/observed values, evidence IDs, observation window, requirement links and classification confidence where relevant. A screenshot of “Sent” is UI evidence; it is not a receiver receipt. Oracle exceptions become `HARNESS_FAILURE`; unavailable expected infrastructure becomes `ENVIRONMENT_FAILURE`; ambiguous evidence becomes `INCONCLUSIVE`. Reserve `DUT_FAILURE` for a supported test whose trustworthy observations violate the defined expectation.

## 10. Local HTTP and event API

Bind locally by default. Require a local session token for mutations, restrict browser origins and reject unauthenticated cross-origin writes. Provider secrets remain server-side. Paginate collections with opaque cursors.

| Endpoint | Contract |
|---|---|
| `GET /api/v1/devices` | Inventory, lease state and capability summaries |
| `POST /api/v1/devices/discover` | Read-only discovery job; no device reset |
| `GET/POST /api/v1/personas` | List/create immutable persona revisions |
| `GET/POST /api/v1/scenarios` | List/create validated scenario revisions |
| `GET/POST /api/v1/campaigns` | Group scheduled run configurations |
| `GET/POST /api/v1/runs` | List/create frozen run specifications |
| `GET /api/v1/runs/{id}` | Status, version, results and progress |
| `POST /api/v1/runs/{id}/preflight` | Validate dependencies and capability evidence |
| `POST /api/v1/runs/{id}/start` | Acquire lease and start a ready run |
| `POST /api/v1/runs/{id}/pause` | Request pause; return command resource |
| `POST /api/v1/runs/{id}/resume` | Revalidate paused run and reacquire lease |
| `POST /api/v1/runs/{id}/stop` | Close dispatch and abort after settling |
| `POST /api/v1/runs/{id}/takeover` | Grant manual control after confirmed pause |
| `POST /api/v1/emergency-stop` | Persist and propagate global fence |
| `GET /api/v1/commands/{id}` | Poll asynchronous control completion |
| `GET /api/v1/events` | SSE, optionally filtered by run/device |
| `GET /api/v1/artifacts` | Paginated artifact metadata |
| `GET /api/v1/artifacts/{id}` | Authorized content download |

Mutating requests accept `Idempotency-Key`; identical key/path/body returns the original resource or command, while key reuse with different content returns `409`. Optional `expected_version` provides optimistic concurrency; mismatches return `409` with current state. Invalid schemas return `422`; capability failures return a structured `CAPABILITY_UNAVAILABLE` error. Long operations return `202` and a command ID. Repeated pause/stop requests must not issue repeated UI commands.

SSE supports `Last-Event-ID`. Events contain `event_id`, `type`, `timestamp`, run/device/action IDs and a versioned payload. Commit state changes and corresponding events in the same transaction; publish only after commit. Heartbeats have no event ID. If a requested cursor predates retention, emit `resync_required` and require fetching the current snapshot.

## 11. Persistence and recovery invariants

Required tables are device profiles/capabilities, configuration revisions, campaigns, runs, leases, observations, decisions, actions/attempts, oracle results, commands, events, artifacts and idempotency records. Store large images/logs in the run artifact directory with SHA-256 digest, byte size, content type and relative path in SQLite. Write to a temporary file and rename atomically before committing its metadata. Never expose arbitrary filesystem paths through artifact endpoints.

On coordinator restart, keep the global gate closed. Previously active runs enter recovery/`PAUSING` until fencing and reconciliation establish quiescence; a special recovery transition into PAUSING is allowed from a previously persisted RUNNING or PAUSING state. Invalidate old worker leases; reconcile `DISPATCHED` and `ACKNOWLEDGED` actions as potentially executed. Do not replay them automatically. Resume only after device health, foreground state and receipts are reconciled. A single-host process lock prevents two coordinators from owning the same database/device set.

Reserve provider cost atomically before each concurrent request using a frozen rate card and request token limits. Keep unresolved usage reserved after a timeout; retries require their own reservation. Usage accounting reports estimated, confirmed and unresolved amounts separately. Workers never invoke models or independently spend the campaign budget.

Acceptance checks must exercise: rejection of stale observation/lease/epoch; pause during a slow provider response; emergency stop during driver latency; timeout after a fixture message was accepted; coordinator restart after dispatch; oracle outage; unsupported carrier scenario; and SSE reconnection without event loss. Required invariants are one active UI command per device, no direct model execution, no new dispatch after confirmed fencing, no blind side-effect retry, and no substitution of fixture evidence for carrier evidence.

## 12. Fixture service protocol

Run fixture data endpoints separately from control endpoints. Mobile clients receive a per-run test identity/token scoped to allowed conversations, never the fixture administrator secret. The receiver has its own identity. The acting model cannot call these endpoints as a substitute for interacting with the native UI. The app's normal transport and a separately authenticated receiving peer perform the actual exchange.

| Endpoint | Behaviour |
|---|---|
| `GET /fixture/v1/articles/{id}` | Versioned controlled page with known content and link targets |
| `GET /fixture/v1/conversations` | Conversations visible to the authenticated test identity |
| `GET /fixture/v1/conversations/{id}/messages?after={cursor}` | Ordered, paginated messages; foreground polling works on both platforms |
| `POST /fixture/v1/messages` | Accept one draft identity; return a durable server receipt |
| `POST /fixture/v1/messages/{id}/acknowledgements` | Receiver-only acknowledgement of delivery or display |
| `GET /fixture/v1/receipts/{client_message_id}` | Authorized reconciliation of a known operation |
| `GET /fixture/v1/health` | Service readiness without control credentials |
| `POST /fixture-admin/v1/runs/{id}/reset` | Controller-only reset of that run's fixture namespace |
| `POST /fixture-admin/v1/runs/{id}/faults` | Controller-only preconfigured fault schedule; separate listener/auth |

Example sender request, generated by the app after UI Send:

```json
{
  "schema_version": 1,
  "run_id": "458de165-ab49-467e-8f19-e80d574e97cb",
  "conversation_id": "fixture-conversation-01",
  "client_message_id": "359683ab-58fe-491d-a2f1-3c66ba7a8ec4",
  "sequence": 1,
  "body": "I have finished reading the article."
}
```

The server derives the sender from its token and enforces uniqueness on `(run_id, sender_id, client_message_id)`. Identical duplicate payloads return the original receipt; a changed body/conversation under the same identity returns `409`. `201` means durable server acceptance only. The server must not manufacture receiver delivery/display timestamps. `delivered` requires the authenticated receiver to fetch and acknowledge the message; `displayed` additionally requires receiver-app UI evidence. A scripted receiver can establish delivery but cannot imply a human read the message.

Receipts include message identity, server accepted time, receiver delivered time or null, displayed time or null, receiver type, and correlation evidence IDs. Use server/receiver clock-offset metadata when comparing clocks; local elapsed-time gates rely on the coordinator's observation windows. Token expiry and denied conversation access produce distinct errors from transport timeout.

Initial fault modes are delayed response, accepted-but-response-dropped, recipient unavailable, malformed fixture response and injected client crash. Each has an explicit layer, activation window and independent ground-truth event. The app must retain its draft identity across offline retries and process restarts. Cancelling a run stops new fixture sends but retains previous receipts for reconciliation.

Fixture UI test metadata is deliberately artificial. Store it in the evidence manifest and do not claim this ease of correlation exists in third-party messaging apps. External-app and carrier adapters require different independently validated oracles.

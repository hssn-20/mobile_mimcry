# Implementation backlog

This backlog is ordered for an AI coding agent working in small, reviewable increments. It implements [the specification](DEMONSTRATOR_SPEC.md) using [the canonical contracts](CONTRACTS.md). It is a proposed work plan, not completed work. Every item starts **Not started**. A task is Done only when its stated evidence exists; unavailable hardware or credentials must remain visible dependencies.

## 1 Feature identifiers

| ID | Feature |
|---|---|
| FR-01 | Host and device discovery with capability evidence |
| FR-02 | iOS Simulator observation and validated UI execution |
| FR-03 | Durable campaign/run lifecycle and device ownership |
| FR-04 | Fixture browsing, messaging and independent acknowledgements |
| FR-05 | Bounded model proposals and provider replacement |
| FR-06 | Versioned personas, session memory and human timing |
| FR-07 | Outcome classification, fault campaigns and evidence reports |
| FR-08 | Dashboard, pause, takeover and emergency fencing |
| FR-09 | Android adapter and equivalent native fixtures |
| FR-10 | Physical-device onboarding and app capability probes |
| FR-11 | Native SMS and call scenarios with verified transport |
| FR-12 | Configurable VPN exits and network assertions |
| FR-13 | Unattended policy calibration and held-out evaluation |
| FR-14 | Multi-device scheduling, recovery and resource budgets |
| FR-15 | Guided installation, operator trials and release evidence |

Acceptance IDs and sponsor requirement links are defined in [Acceptance plan](ACCEPTANCE_PLAN.md). Implementors must link task evidence to the relevant cases rather than create a second competing definition of success.

## 2 Repository layout to create

```text
README.md                         # retain links to this design package
pyproject.toml / uv.lock
src/mobilelab/
  api/                            # HTTP, auth, commands, SSE
  domain/                         # strict schemas and state transitions
  coordinator/                    # per-run loops, leases, budgets, fences
  workers/                        # subprocess protocol and worker entrypoint
  adapters/                       # ios, android, mock (explicitly labelled)
  providers/                      # rules, replay, openai, later jev/local
  personas/                       # transition and timing engine
  oracles/                        # UI, receipt, network, crash assertions
  fixtures/                       # fixture data server and peer
  training/                       # bounded policy calibration jobs
  reporting/                      # manifests, HTML and JSON export
  cli.py
apps/dashboard/                   # React, TypeScript, Vite
fixtures/ios/LabMessenger/
fixtures/ios/LabBrowser/           # physical personal-phone profile only
fixtures/android/LabMessenger/
configs/personas/
configs/scenarios/
tests/unit/ tests/integration/ tests/device/
docs/                             # keep this design package
artifacts/                        # ignored runtime evidence, never secrets
```

Layout is a starting design. Keep functional boundaries even if a small implementation combines files. Do not scaffold hundreds of empty classes. Generate dashboard domain types from canonical Pydantic schemas. Examples in this package are design input, not yet an executable configuration API.

## 3 Milestone zero and first vertical slice

### T01 Record decisions and run a read-only host preflight

Dependencies: none. Features: FR-01.

Implement `mobilelab doctor` with structured and human-readable output for architecture, active/full Xcode, licences requiring manual completion, Simulator runtimes, Python, Node, Appium, drivers and reachable devices. Resolve a released compatible version set and write a runtime manifest. Inventory physical devices without installing helpers or changing settings. Report missing prerequisites precisely.

Done evidence: saved manifest and a doctor run on the actual Mac; missing-Xcode/runtime fixtures produce actionable diagnostics. Do not silently download Xcode, accept licences or alter signing. Separately record outstanding sponsor/device decisions.

### T02 Define domain schemas and lifecycle transitions

Dependencies: T01. Features: FR-03.

Implement contracts, capability records, primary evidence category plus physical-device kind, typed errors and transition validation. Add the SQLite migration, configuration hashes and single-coordinator lock. Generate JSON Schema and TypeScript types. Add tests for forbidden transitions, stale versions and fixture-versus-carrier evidence mismatch.

Done evidence: schema examples validate; invalid action variants and conflicting leases fail; migrations create a fresh database. No device required.

### T03 Build a project-owned Simulator observation adapter

Dependencies: T01–T02. Features: FR-02.

Boot a selected project-owned Simulator by UUID, establish Appium/WDA, capture screenshot and tree, and normalize candidates. Pin locale, orientation and fixture state. Assign unique ports and derived-data paths. Keep Appium loopback-only; do not enable blanket alert acceptance or destructive reset flags.

Done evidence: real Simulator artifact, foreground app and screenshot/tree timestamps, successful session teardown. A mocked adapter result is insufficient. If toolchain setup is blocked, complete adapter unit tests and mark this device gate blocked.

### T04 Implement one worker and the control fence before autonomy

Dependencies: T02–T03. Features: FR-03, FR-08.

Add bounded IPC, per-device command serialization, priority fencing, lease/control epochs and durable action journal. Implement observe, activate, scroll, allowed-app switch and text entry. Model direct execution remains impossible. Exercise a delayed driver command and a restart after dispatch.

Done evidence: stale command rejection, one active command per device, visible pending fence versus confirmed fence, no action after confirmed fencing. Unknown in-flight side effects survive a crash without automatic retry.

### T05 Create fixture web content, server and receiver

Dependencies: T02. Can run alongside T03–T04. Features: FR-04.

Provide two short articles, links, a form and deterministic errors. Create test identities, conversations, persistent message IDs, server receipts and an independent receiver acknowledgement. Separate fixture administration and data endpoints. Include a fault that suppresses only the acknowledgement after accepting the message.

Done evidence: idempotent fixture message storage and distinct accepted/delivered/displayed states; receiver outage gives unknown delivery instead of a fabricated pass. Device-reachable URL configuration works without assuming phone localhost equals Mac localhost.

### T06 Build the SwiftUI Lab Messenger

Dependencies: T05; signing-free Simulator target first. Features: FR-04.

Implement conversation list, message view, composer, send, delivery state and visible errors. Add stable accessibility identifiers. Generate the draft's persistent `client_message_id` before Send and expose its test correlation metadata without allowing the harness to bypass the UI. Restrict configuration to test accounts/origins.

Done evidence: Simulator UI sends through the normal app transport, server and receiver record the same identity, transport retry does not duplicate the message. Do not build a fake Apple Messages clone.

### T07 Complete a deterministic browse and reply journey

Dependencies: T04–T06. Features: FR-02, FR-04, FR-07.

Use RulesProvider, one Simulator, Safari and Lab Messenger. Observe, browse, scroll, switch, compose, send, verify and return. Add minimal HTML/JSON report generation before building the full dashboard. Run the suppressed-acknowledgement variant and reconcile the existing message rather than resend.

Done evidence: a real successful run and an ambiguous-delivery run with complete timelines. Report labels say RulesProvider and fixture. This is the first user-visible development milestone.

## 4 Agent behaviour and operator controls

### T08 Implement the OpenAI policy adapter

Dependencies: T07. Features: FR-05.

Verify current SDK schemas, then use a bounded typed-output invocation. No model-executing phone tools. Configure model explicitly, suppress external tracing by default, reserve campaign budget atomically and record usage uncertainty. Implement timeouts, late-result rejection and one bounded schema repair. Without an API key, complete the interface and replay tests, but keep live-provider acceptance open.

Done evidence: real model selects valid observed candidates and handles a changed fixture screen without hardcoded scripted navigation; invalid targets cannot reach the worker. Store redacted provider evidence, never keys.

### T09 Implement persona state and the timing scheduler

Dependencies: T07; can precede live-provider completion. Features: FR-06.

Load three versioned synthetic profiles, semi-Markov activities, scoped memory and independent seeded random streams. Use cancellable monotonic timing. Reobserve/rebind after delay without resampling dwell indefinitely. Track requested versus actual typing mode and dispatch lateness. No overdue catch-up bursts.

Done evidence: replayable policy/timing unit tests, distinct measured activity patterns, pause during a long dwell and explicit lateness under a slow model. Mark all initial profiles synthetic.

### T10 Add independent oracles and fault classification

Dependencies: T07–T09. Features: FR-07.

Implement message receipt, visible state, no-progress, crash and fixture network assertions with separate evidence. Score known injections after the acting policy has finished. Distinguish DUT, harness, environment, inconclusive and unsupported results. Do not provide hidden fault labels to the actor.

Done evidence: representative defects plus healthy controls classified correctly, oracle failure never becomes a DUT defect, missing receipts never become false success.

### T11 Build the dashboard and local launcher

Dependencies: T07; integrate T08–T10 incrementally. Features: FR-08.

Create device inventory, campaign form, live cards, timeline and report download. Add capability-gated Start, pause/resume/stop, takeover and global emergency stop. SSE reconnects from event cursor. Show mock/rules/cloud mode, peer type, evidence tier and pending controls explicitly. Add local session-token and origin protection.

Done evidence: operator can complete the fixture journey without editing JSON; refresh/reconnect preserves correct state; slow device/model does not freeze the controls.

## 5 Both-platform and physical evidence

### T12 Implement Android adapter and Kotlin fixture

Dependencies: T02, T05, T07; common contracts frozen first. Features: FR-09.

Implement UiAutomator2/ADB discovery and the common primitives against a pinned AVD. Reuse message protocol and oracle definitions, not iOS selectors. Make native Android Back explicit. Record helper settings and emulator image. Build Kotlin Lab Messenger and run the same fixture journey.

Done evidence: Android-specific device tests plus equivalent iOS/Android reports. Console injections remain labelled OS simulation.

### T13 Conduct early telephony capability spikes

Dependencies: T01 for planning, T03/T12 for execution. Features: FR-11.

Start investigation during milestone zero; do not wait until week ten to discover a blocker. Probe selected Simulator/AVD system-app availability and documented routes. Prepare separate outgoing SMS, incoming SMS, outgoing call, incoming call and connection/termination capabilities. Test only configured endpoints.

Done evidence: per-platform capability matrix with recorded proof or explicit unavailability. Android incoming-event injection is never counted as outgoing send/call proof. Hardware-dependent paths remain open until T14/T16.

### T14 Add guided physical onboarding and isolated fixtures

Dependencies: T07, T11. Features: FR-10.

Document signing/trust/developer steps and expiration handling. Add project-owned WKWebView Lab Browser for the everyday-iPhone profile. Default that profile to RulesProvider with local-only content capture; reject personal app launch and unexpected overlays. Inventory/restore driver-altered settings or defer the run. Add Android USB authorization onboarding.

Done evidence: dedicated-device smoke where available; everyday phone only after explicit setup choices with settings restoration established. Signing keys stay in local Apple tooling. No destructive reset.

### T15 Add VPN exit and network profiles

Dependencies: T10 and suitable provisioned network/device. Features: FR-12.

Select existing approved exit profiles A/B through an environment adapter. Verify from device-originated requests at the observer, keeping control traffic independent. Distinguish proxy, fixture delay, IP-path loss and actual connectivity changes. Record Simulator host-network coupling. Add restoration and mismatch scenarios.

Done evidence: separate per-exit route assertions, deliberately wrong exit detected, defined DNS/IPv6 scope and limitations. A UI indicator or host IP check is insufficient. No new VPN protocol implementation.

### T16 Validate native SMS and call endpoints

Dependencies: T13–T14 plus dedicated handsets/SIMs and peers. Features: FR-11.

Create app-specific journeys and allowlisted numbers. Verify transport actually used, peer delivery or call establishment and hangup. Reconcile uncertain sends/calls. Disallow paid/premium/emergency destinations by the exact test-destination allowlist. Do not read personal inboxes or contacts.

Done evidence: receiving-end traces and truthful platform matrix. If an OS workflow is unsupported, record the gap and seek a scope decision; fixtures cannot make this item Done.

## 6 Validation and delivery

### T17 Add bounded unattended policy calibration

Dependencies: T08–T10. Features: FR-13.

Implement reset/explore/collect/update/holdout/publish-or-reject with episode/action/cost bounds. Version data, rules and evaluation split. Tune a limited navigation policy rather than foundation-model weights. Demonstrate the resulting policy is used in a subsequent run.

Done evidence: unattended completion or honest rejection, reproducible manifest, no holdout leakage, no self-expanded permissions. Confirm sponsor interpretation separately.

### T18 Calibrate and evaluate persona behaviour

Dependencies: T09 and a consented reference collection protocol. Features: FR-06, FR-13.

Collect bounded test-device sessions; separate participants between calibration and holdout. Fit timing/activity parameters and report task mix, dwell, typing mode, interruptions and switching with small-sample limitations. Keep directed fault campaigns out of ordinary-use realism scores.

Done evidence: provenance and held-out comparison; either labelled calibrated presets or continued synthetic status. Do not claim population realism from a handful of sessions.

### T19 Run mixed-platform capacity and recovery tests

Dependencies: T10–T12. Features: FR-14.

Add global concurrency admission, fairness, worker crash recovery, journal reconciliation, cost reservations and storage bounds. Capacity-probe the host and target three total virtual DUTs, including iOS and Android, for 30 minutes. Peers consume separately counted resources. Run the longer soak only on a documented capable host.

Done evidence: no cross-device actions/accounts, bounded budgets, complete reports on interrupted runs and no blind resend after restart. Insufficient host capacity is a recorded deployment gap, not a silently weakened pass.

### T20 Benchmark Jev and a local adapter if required

Dependencies: T08–T10. Features: FR-05. Optional for the first demo.

Evaluate Jev through its independent API and text candidate map. Include perception overhead, quality, timing, cost and uncertainty. Compare with existing baselines before selecting it. Implement a local provider only when a concrete deployable model/host is selected; run the same evaluation and egress tests.

Done evidence: reproducible provider comparison. An empty interface is not an implemented offline backend. A model's choice probabilities are not persona activity probabilities.

### T21 Package, validate usability and freeze release evidence

Dependencies: required tasks above and [acceptance gates](ACCEPTANCE_PLAN.md). Features: FR-15.

Build launcher, onboarding guide, source/license inventory, example campaign, report template and support bundle. Test initial setup separately from operation with unfamiliar evaluators. Freeze versions and execute the acceptance campaign. Export source and detailed technical report, including exclusions, unmet capabilities and deployment decisions.

Done evidence: demonstrable clean setup path, observed operator results, complete acceptance manifest and a sponsor demo using real recorded outcomes. Do not claim TRL 5 solely on the basis of software tests; validation in the agreed relevant environment remains required.

## 7 Indicative twelve week schedule

This schedule assumes approximately two implementation engineers with access to a reviewer and timely test devices/accounts. It is a planning hypothesis, not a cost quotation or guarantee. A single developer should reduce scope or revise time estimates after the initial spike.

| Window | Focus | Exit |
|---|---|---|
| Weeks 1–2 | T01–T07; begin T13 and signing/network decisions | Real iOS fixture vertical slice; feasibility risks exposed |
| Weeks 3–4 | T08–T11; begin T12 | Model-driven iOS run, personas, controls and oracles |
| Weeks 5–6 | T12–T16 according to hardware readiness | Android parity and measured hardware/network capabilities |
| Weeks 7–8 | T17–T18; start T19 | Calibration artifacts and mixed-platform results |
| Weeks 9–10 | Complete T19; T20 only if justified | Fault, endurance and provider evidence |
| Weeks 11–12 | T21 and outstanding acceptance remediation | Packaged, traceable demonstration |

Parallelize fixture services with device plumbing; Android with dashboard work once contracts stabilize; human-data preparation with implementation. Keep per-device control changes owned by one implementor at a time. Re-plan after each milestone based on evidence rather than continuing an infeasible schedule.

## 8 Coding task completion template

For each task record: status; implementation files; dependency versions; exact verification command; result and artifact path; assumptions; unresolved blockers; and next task. Distinguish unit/replay tests from actual Simulator, emulator, phone and provider tests. Never fabricate a successful run when a required tool or credential is unavailable.

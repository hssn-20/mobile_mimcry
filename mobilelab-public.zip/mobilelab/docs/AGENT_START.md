# Historical coding agent starter prompt

This is the original planning prompt for implementing the first slice with an AI coding agent. It records the initial approach; see [Progress](PROGRESS.md) for implementation status before using it for further work.

```text
Build the mobile behaviour testing demonstrator specified in this repository.

Read README.md, docs/DEMONSTRATOR_SPEC.md, docs/CONTRACTS.md,
docs/IMPLEMENTATION_BACKLOG.md, docs/ACCEPTANCE_PLAN.md and
docs/SOURCES_AND_DECISIONS.md before changing code. Follow any applicable
repository instructions. Preserve the confirmed user choices: iPhone first,
both iOS and Android in the competition demonstrator, cloud inference during
development with a replaceable backend, and no reliance on personal-phone
data.

Implement milestone M1 first, through tasks T01–T07. Start with a read-only
host/toolchain preflight and record actual versions and missing dependencies.
Then build the smallest working iOS Simulator observation/action/evidence
loop. Implement a deterministic RulesProvider, project-owned SwiftUI Lab
Messenger, a controlled web fixture and a separate message receiver. Execute
the browse-and-reply journey through real UI input and independently verify
delivery. Add minimal reporting before building the full dashboard.

Use the specified Python coordinator, bounded per-device subprocess worker,
strict Pydantic domain models and local SQLite store. Use Appium XCUITest/WDA
for iOS; keep the contracts platform-neutral for the later Android adapter.
Resolve and pin a compatible released toolchain; do not assume latest HEAD
or documentation examples match installed versions. Do not add Redis,
Kubernetes, a vector database or unrelated services.

Implement the device lease, stale-observation validation, priority fencing,
action journal and UNKNOWN-effect recovery before autonomous side effects.
The model must never execute arbitrary device commands. A timeout after Send
must reconcile receipts and must not blindly send a second message. Stop
request receipt and confirmed worker fencing are different states.

All first-run data must be synthetic. Do not automate personal Messages,
Phone, Contacts or Safari history. Do not change signing, erase devices,
accept software licences, alter VPN/system routing, or install tools outside
the project without the permissions required by the environment. Clearly
state any concrete prerequisite that needs the user, while completing work
that does not depend on it. Use project-owned Simulator instances only.

Write meaningful tests for lifecycle, ownership, stop, stale candidates,
unknown sends, idempotency, classification and evidence integrity. Use replay
or mocks for unavailable dependencies, but label them honestly. A mocked
driver test is not a Simulator test; a fake provider is not an AI test; a
fixture message is not SMS. Never fabricate successful device evidence.

Work in reviewable vertical slices. For each completed task record changed
files, verification commands, actual results and evidence locations. Maintain
a progress document linked to the backlog. If blocked by unavailable Xcode,
runtime, hardware or credentials, identify the precise missing prerequisite
and continue independent tasks. Keep dependent acceptance gates open.

At the end of the initial implementation, provide launch instructions,
remaining prerequisites, the real run/report evidence if achieved, and the
next task. Do not silently expand into later hardware, carrier, VPN or model
work until the first slice is reviewable. Recommend T08 onward based on the
observed state.
```

## Suggested follow-up after the first slice

Once T01–T07 pass, ask the agent to implement T08–T11: bounded OpenAI proposals, persona scheduling, fault classification and the dashboard. The Android work T12 can proceed in parallel after the common contracts stabilize. Start planning telephony and signing feasibility early, even though hardware execution may be blocked.

The suggested first checkpoint is intentionally smaller than the complete competition deliverable. Its purpose is to prove that the plumbing works before model behaviour and fleet UI make debugging harder.

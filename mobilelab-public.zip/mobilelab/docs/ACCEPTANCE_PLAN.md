# Acceptance and evidence plan

Version 0.1 · 3 October 2026 · Proposed tests; no results have been collected.

This plan accompanies [the demonstrator specification](DEMONSTRATOR_SPEC.md) and [runtime contracts](CONTRACTS.md). It defines evidence needed to accept implementation milestones. Every numerical threshold below is a proposed project gate, not a sponsor requirement, measured result or guarantee of exhaustive coverage. Freeze test versions and thresholds before the acceptance campaign; record later changes explicitly.

The first build uses one iOS Simulator on a macOS development host. The competition demonstrator includes iOS and Android. Physical-device signing is a separate prerequisite and is not an acceptance dependency for early milestones. Carrier testing requires dedicated provisioned hardware, test numbers and independent receiving endpoints. Cloud development is allowed by the project's design decision; sponsor acceptance of cloud processing remains unresolved.

## 1. Requirement traceability and release gates

The concise requirement register below paraphrases the [HMGCC challenge brief](https://www.plexal.com/wp-content/uploads/2026/09/Challenge-Form-Mobile-Mimicry-using-AI-v0.6.pdf). The tests and implementation interpretations are this project's proposals. The brief targets TRL 5 in twelve weeks; physical operation and efficient models are desirable.

| ID | Brief requirement | Project evidence | Acceptance cases |
|---|---|---|---|
| BR-01 | Virtual demonstration | Recorded Simulator/emulator journeys; sponsor decision on Simulator | AC-01–03, AC-11 |
| BR-02 | Source and technical report | Reproducible source package and evidence export | AC-14, AC-18 |
| BR-03 | Nontechnical installation and operation | Separate bootstrap and operator trials | AC-15 |
| BR-04 | Unsupervised training; operational intervention | Bounded unattended calibration and stop/takeover | AC-05–06, AC-10 |
| BR-05 | Explainable autonomy and cybersecurity | Action evidence, enforced permissions, negative cases | AC-04, AC-07–08, AC-14 |
| BR-06 | SMS | Platform-specific virtual/carrier evidence | AC-12 |
| BR-07 | Messaging apps | Native fixture first; named external app when agreed | AC-02–03, AC-12 |
| BR-08 | Voice calls | Independently observed connection and termination | AC-12 |
| BR-09 | Selectable personas | Versioned configurations and measured behaviour | AC-09–10 |
| BR-10 | Configurable VPN exits | Device-originated route observations | AC-13 |
| BR-11 | On-premises testing; no supplied training data | Deployment/data manifest and collection provenance | AC-10, AC-16 |

Requirement status is `not_started`, `in_progress`, `evidence_ready`, `accepted` or `blocked_dependency`, with an owner and evidence links. These are review statuses, not runtime verdicts. Sponsor-essential features remain visible when unsupported. Passing a milestone does not automatically accept every mapped requirement.

| Milestone | Required evidence |
|---|---|
| M0: infrastructure and feasibility | AC-01; identified signing, carrier, VPN, cloud and Simulator acceptance dependencies |
| M1: first vertical slice | One Simulator, Safari and SwiftUI Lab Messenger; AC-02, initial AC-04–07 and AC-14 |
| M2: controlled behaviour | Personas, provider, dashboard and fault checks; AC-03–10 |
| M3: both platforms | Android/Kotlin equivalent, telephony spikes, VPN and capacity findings; AC-11–13 |
| M4: competition package | Dedicated hardware where available, calibration, operator trials and complete evidence; AC-14–18; unresolved essentials explicitly gated |

## 2. Scenario manifests and evidence rules

Each immutable scenario manifest declares its ID/version, BR references, platform profiles, required capabilities, primary evidence category, fixture/data versions, persona, seed, provider/model, preconditions, peer topology, duration/action/cost ceilings, expected observations, oracle deadlines, disturbances and cleanup. Record the selected manifest's hash in every run. Reuse the schema in Contracts rather than creating an incompatible acceptance-only schema.

For example, `browse_then_reply` uses `platform_evidence: fixture`, requires observation, app switching and fixture messaging, and has a delivered-message oracle keyed by `client_message_id`. A separate `carrier_sms_outbound` scenario requires `carrier_sms`, a dedicated sender/receiver and `physical_carrier`. An acceptance catalogue may associate these manifests with AC IDs and planned repetitions; the executable manifest remains validated against its canonical schema.

Every run records both planned and obtained evidence:

| Category | What it establishes |
|---|---|
| `fixture` | Owned app/backend behaviour, including independently received fixture messages |
| `os_simulation` | Actual OS UI/events with simulated underlying services |
| `physical_ip` | A physical device's measured IP connectivity or routing behaviour |
| `physical_carrier` | A physical device and independently observed carrier communication |

A physical phone's Lab Messenger scenario can retain `fixture` as its primary category, with physical device metadata. Score VPN routing separately as `physical_ip`. These categories are not interchangeable quality levels. iOS Simulator fixtures cannot establish native SMS or cellular calls. Injecting an incoming Android emulator event cannot prove an outgoing agent action. Obtain sponsor agreement on Apple's Simulator as the virtual demonstration environment.

Use an independent receiver, route observer or deterministic assertion as the oracle. The acting model's success statement is never authoritative. An oracle may request UI evidence through the owning device worker; it must not compete for device control. Keep injected-fault ground truth unavailable to the acting policy, then compare it with the recorded classification.

Use exactly the runtime verdicts from Contracts:

| Verdict | Meaning |
|---|---|
| `PASS` | Required observations confirm the declared expectation |
| `DUT_FAILURE` | Trustworthy evidence shows the device/software violated that expectation |
| `HARNESS_FAILURE` | Controller, driver, policy integration or evaluator failed |
| `ENVIRONMENT_FAILURE` | Required external infrastructure failed outside the declared test condition |
| `INCONCLUSIVE` | Evidence cannot resolve the outcome |
| `UNSUPPORTED` | Required capability/evidence category is unavailable |

Record cancellation through lifecycle status and an explicit reason; do not invent a seventh verdict or report cancelled work as passed. Report planned, excluded, preflight-blocked, started, completed and unresolved counts. Acceptance reports retain every planned attempt, including capability failures. If a metric uses a restricted denominator, show the full allocation beside it. Never silently rerun failures until only passing attempts remain.

## 3. Numbered acceptance cases

### AC-01 — Readiness and feasibility register

**M0; BR-01, BR-03, BR-06, BR-08, BR-10–11.** Discover Mac capacity, full Xcode, runtime/tool versions and existing signing without changing the personal phone. Probe one project-created Simulator for screenshot, visible target, tap, typing, app switch and fixture reachability. Save capabilities with profile/version, probe time and evidence. Identify missing prerequisites with an actionable remedy. Record unverified carrier and VPN support as unavailable. Pass when the readiness report accurately distinguishes ready, missing and incompatible items; a blocked dependency remains blocked rather than a false successful probe.

### AC-02 — First complete iOS journey

**M1; BR-01, BR-07.** Start a clean project Simulator, read and scroll a controlled article in Safari, switch to SwiftUI Lab Messenger, compose a synthetic reply, send once and return to Safari. Use the deterministic provider initially. Require screenshots/tree observations, timed device commands, matching server acceptance and independent receiver acknowledgement. The peer may be a labelled receiver service. Repeat with the receiver acknowledgement deliberately withheld: preserve uncertain delivery and do not blindly send again. A real UI journey and honest uncertainty handling are required; mocked-driver success is insufficient.

### AC-03 — Functional baseline

**M2; BR-01, BR-07, BR-09.** Freeze 20 fault-free journeys across controlled browse/message/resume scenarios and seeds. Proposed gate: at least 18/20 (`90%`) independently verified completions. At M3 rerun a separately reported 20-journey set on each platform; do not conceal platform weakness in a combined average. Include baseline-provider and selected cloud-provider results separately. Count all 20 scheduled attempts, including harness/environment failures and unresolved outcomes. Display raw counts and a labelled small-sample 95% interval; passing this gate does not establish production reliability.

### AC-04 — Fresh observations and action authority

**M1–M2; BR-05.** Exercise an invented candidate, changed foreground app, changed recipient, stale observation, stale lease, stale control epoch and malformed action parameters. Reject each before device input. Verify a fresh dispatch observation, semantic rebinding and the configured two-second freshness limit on the worker's monotonic clock. A changed Send/Call context invalidates the old proposal. Confirm one active driver operation per device. Evidence must show the rejected proposal and absence of a corresponding executed command; schema validation alone is insufficient.

### AC-05 — Pause, takeover and emergency stop

**M1–M3; BR-04–05.** Test stop during idle wait, typing, slow model response and delayed driver execution; repeat under admitted fleet load. The proposed local goal is confirmed fencing acknowledgement within one second, with zero new commands starting after confirmed fencing. Report gate persistence and each worker's acknowledgement separately. A timeout is a visible harness failure, not a green stopped indicator. Already dispatched effects cannot be undone. Verify that late model replies are discarded, takeover waits for confirmed pause, and resume reacquires a lease and fresh observation. Include pending in-flight outcomes in the export.

### AC-06 — Recovery without duplicate effects

**M1–M2; BR-04–05.** Interrupt the coordinator after journalling, after dispatch and after a fixture send was accepted but before acknowledgement. Restart with the gate closed and reconcile receipts. The fixture server must retain its unique `client_message_id`; no duplicate delivery may result from transport retry. For arbitrary SMS/calls, unresolved execution stays inconclusive and is not automatically repeated. Test API idempotency-key conflict and stale worker rejection. Pass when the action journal preserves uncertainty and no old worker or replay starts unauthorized input.

### AC-07 — Permission and data boundaries

**M2; BR-05, BR-11.** Present fixture pages/messages requesting unauthorized contacts, domains, apps, shell commands, VPN changes and permission expansion. Exercise malformed provider output and attempts to disguise Send as a generic activation. Every enumerated forbidden proposal must be blocked before execution. Verify control/API authentication, local binding, artifact path containment and absence of secret canaries from logs, exports and browser storage. This establishes behaviour on the declared negative suite, not immunity to every attack. Record suite version and case count.

### AC-08 — Fault detection and attribution

**M2; BR-05.** Run five predefined DUT fault classes five times each: app crash, UI no-progress, lost delivery despite misleading sender UI, incorrect service-response handling, and unexpected app-state reset. Use controlled fixture defects with explicit violated expectations. Add 25 healthy controls. Proposed gates: detect at least 23/25 injected faults (`≥90%`) and falsely flag no more than 1/25 healthy controls as DUT failures (`≤5%`). Report per-class confusion counts and small-sample 95% intervals. Detection means evidence-backed `DUT_FAILURE`, not merely any non-pass result. Freeze injections before running; disclose invalid injections.

Separately test driver disconnect, provider timeout, receiver outage and missing oracle evidence. These must produce the appropriate harness, environment or inconclusive outcomes. A network outage is not itself a DUT defect; mishandling a declared recovery expectation may be. If an attempt cannot establish ground truth, keep it visible and report why the intended test was not scored. The gate remains incomplete until all 25 valid injections and 25 healthy controls are obtained; record replacement attempts without shrinking the planned denominator or deleting the original attempt.

### AC-09 — Persona selection and timing

**M2; BR-09.** Ship three versioned synthetic presets with different activity mix, session/idle patterns and timing parameters. Verify selection changes the frozen run configuration, seeded sampling is reproducible within the specified algorithm, and each sampled delay is persisted once. Log model latency, planned due time, actual dispatch and timing overrun. Delayed inference must never trigger rapid catch-up input. Report typing mode actually used; bulk insertion does not prove keyboard realism. Compare observed distributions against configured synthetic distributions without claiming that either represents humans.

### AC-10 — Unattended training and human calibration

**M2–M4; BR-04, BR-09, BR-11.** Run a bounded search/calibration job in resettable virtual fixtures: collect transitions, update navigation-policy/configuration parameters, evaluate a fixed holdout and publish or reject a versioned candidate. Complete three seeded jobs without manual rescue; include failed episodes and budget exhaustion. Demonstrate that a failed candidate cannot replace the active policy and a running campaign cannot change underneath the operator. This is not base-model fine-tuning; sponsor agreement on the training interpretation remains required.

For later realism evidence, collect a small consented benchmark using dedicated synthetic accounts: initially approximately 8–12 participants, two or three short sessions each. Capture task/timing events needed for calibration, not continuous personal-phone surveillance. Separate participants between calibration and holdout. Compare activity transitions, session lengths, reading/typing pauses, corrections and idle time, with raw counts and uncertainty. Set persona-specific tolerances after the pilot, before held-out testing. Synthetic traces cannot certify human realism; label this a limited development benchmark.

### AC-11 — Dual-platform capacity and endurance

**M1/M3; BR-01, BR-09.** Minimum build gate: one Simulator runs for 30 minutes without a harness crash, retaining complete action/outcome records. Competition target: three active virtual DUTs total, including at least one iOS and one Android, for 30 minutes on a documented host. Measure RAM/CPU, observation/driver/provider p50/p95 latency, timing misses and per-device fairness. Count peer simulators and receiver services separately in resource accounting. Probe capacity before admitting the run. If unavailable, publish the largest measured configuration and keep the three-DUT gate open. A two-hour soak is an additional competition goal, not an initial build prerequisite.

### AC-12 — Messaging, SMS and voice evidence

**M3–M4; BR-06–08.** Maintain a per-platform matrix for fixture messaging, any agreed named messaging app, virtual SMS/call behaviour and physical carrier paths. Probe Android outgoing/incoming telephony on the selected image; injected incoming events remain labelled simulation. iOS Simulator fixtures remain fixture evidence. For physical carrier tests, use dedicated provisioned devices, SIMs/accounts and peers; require recipient evidence for SMS and remote connection plus termination for calls. The everyday iPhone is not the default unattended endpoint. Record test counts, transport, app/OS versions and unsupported cells. Natural-language conversation is unnecessary. Mixed-platform evidence needs explicit sponsor acceptance.

### AC-13 — VPN exit verification

**M3–M4; BR-10.** Select two approved exits in separate campaign runs. Make a device-originated request to a controlled route observer and compare expected/observed egress. Record DNS/IPv6 coverage, reconnect behaviour, affected applications and controller/model traffic routing. A host IP check, VPN icon or proxy-only result cannot establish the requested device VPN path. Do not assume independent VPN isolation per Simulator or route ordinary carrier SMS/voice through the tunnel. Unprepared routes remain unsupported. Use an agreed internal observer topology if external observation is disallowed.

### AC-14 — Explainability and report integrity

**M1–M4; BR-02, BR-05.** Export configuration hashes, app/OS/model versions, observations, proposals, candidates, reason codes, validation decisions, planned/actual timing, execution statuses and oracle references. Include permissions, interventions, exclusions, evidence categories and every verdict count. Provide a factual action explanation from these records; do not request hidden chain-of-thought. Verify artifact hashes and referential integrity, generate a report after an interrupted run, and demonstrate read-only timeline replay. No missing receipt or model assertion may be rewritten as a pass.

### AC-15 — Installation and operator usability

**M4; BR-03.** Evaluate first-time administrative bootstrap separately from ordinary use. Inventory Xcode/runtime downloads, licences, permissions, provisioning and hardware signing; measure elapsed time and assistance. A prepared-host trial cannot prove effortless installation. Proposed operator gate: four of five unfamiliar evaluators select a preset, start, pause/stop and export a report within 15 minutes without terminal commands or developer help on the prepared host. Record all observed difficulties. Signing dependencies remain explicit; simulator operation does not resolve physical onboarding.

### AC-16 — Deployment and backend replacement

**M2–M4; BR-11.** Document which components run locally and which requests leave the host. Use synthetic content for cloud development; verify credential handling and configured trace export. Run the same fixture contract with rules/replay and the selected cloud adapter without changes to device execution or oracle logic. Test timeout, cancellation, budget exhaustion and stale-response discard. This establishes replaceability, not local-model quality. An offline acceptance claim additionally requires a real local inference adapter and observed absence of unauthorized model/telemetry egress; obtain sponsor agreement on required connectivity.

### AC-17 — Dedicated hardware and efficiency extension

**M4; desirable physical/efficient-model evidence.** Once dedicated hardware is prepared, repeat fixture and relevant network/carrier scenarios with their correct evidence categories. Record signing/device configuration, runner overhead, inference cost, latency and battery/thermal observations where available. Compare candidate providers on the same frozen dataset and task gates before claiming efficiency. No simulator performance result establishes physical battery or RF behaviour. Missing hardware blocks only the dependent tests and remains visible in the competition package.

### AC-18 — Reproducible handover

**M4; BR-02–03.** Deliver source, pinned dependencies, build instructions, fixture data, configuration examples, operator guidance, known limitations and the completed requirement matrix. Another engineer must reproduce one fixture journey from the declared prepared-host starting point, verify its independent receipt and regenerate the report. List credentials/hardware/sponsor decisions still required. Record actual evidence locations and failed/open gates. Documents describing future work do not count as executable delivery.

## 4. Demonstration script and sign-off

Use a prepared, frozen campaign and disclose its synthetic data and evidence categories before starting. First show readiness, supported capabilities and open dependencies. Run the single iOS Safari/message journey and open the receiver receipt. Select a different persona and show the changed timing/activity configuration. Introduce one known DUT fault, then a separate harness/environment interruption, and inspect their different verdicts. Demonstrate stop during a delayed action and explain any in-flight uncertainty.

For M3, add the Android counterpart and show the measured three-DUT campaign if capacity permits. Show VPN and telephony only for supported, independently evidenced scenarios; identify fixture/simulation substitutions plainly. Finish with the evidence report, exclusions, measured denominators, source package and unattended-training artifact. A prerecorded endurance report can complement the live demonstration but must be labelled recorded.

Engineering sign-off confirms which proposed gates passed. Sponsor sign-off resolves Simulator interpretation, training interpretation, messaging-app scope, acceptable carrier/virtual evidence and cloud/on-premises constraints. Until those decisions and required evidence exist, describe the result as a demonstrator with stated gaps, not full compliance or certification of normal human behaviour.

# Mobile behaviour testing demonstrator specification

Version 0.1 • 3 October 2026 • Design for implementation, not a claim of an existing working product

This document specifies a system that uses existing mobile UI automation to operate test devices according to selectable behavioural personas, then produces evidence of what happened. It is written for an AI coding agent and the human developing and reviewing its work. The first implementation must work on an iOS Simulator on the user's Mac. The competition demonstrator must include both iOS and Android. The controlling program runs on the Mac or a laboratory host; no foundation model needs to run on the phone.

All numerical targets, component choices, example personas and implementation schedules below are proposed engineering decisions. They are not HMGCC acceptance criteria or measured results. Source facts and remaining decisions appear in [Sources and decisions](SOURCES_AND_DECISIONS.md). The detailed interfaces in [Contracts](CONTRACTS.md) and tests in [Acceptance plan](ACCEPTANCE_PLAN.md) are part of this specification.

## 1 Confirmed decisions and unresolved dependencies

| Topic | Decision | Consequence |
|---|---|---|
| First platform | iPhone first, using iOS Simulator initially | Xcode and Appium XCUITest are the first device integration |
| Competition platforms | iOS and Android | Add a separate UiAutomator2 adapter and Android fixtures; execute acceptance on both |
| Physical-device prerequisites | Dedicated test handset and developer signing must be provisioned separately | No initial dependence on real-device automation or personal accounts |
| Inference | Cloud APIs for development, replaceable backend | First real provider is OpenAI; local execution is a separately validated adapter |
| Deliverable now | Markdown specification and implementation backlog | This package does not install tools, deploy software or interact with a phone |
| Prototype language | Python control service; TypeScript dashboard | Native fixture apps use SwiftUI and Kotlin |
| Agent orchestration | OpenAI Agents SDK for the OpenAI policy backend | Durable scheduling and action authorization remain in application code |
| Initial autonomy | One bounded proposed action per decision | No model gets unrestricted shell, Appium or network administration access |
| Optional model | Jev, evaluated after the baseline | It is a typed decision service, not the vision/generation backend |
| Initial environments | Synthetic data and owned fixture services | No dependency on personal SMS, iMessage, WhatsApp or Apple Account data |

The current Mac reports Apple Silicon and macOS 26.6.2. Its active developer directory is `/Library/Developer/CommandLineTools`. This does not establish whether full Xcode is installed elsewhere. Memory capacity, Xcode version, Simulator runtimes, signing and device capacity remain unverified. The implementation preflight must discover these rather than assume them.

Sponsor decisions remain necessary for: permitted cloud inference and trace handling; acceptance of Apple's Simulator as the required virtual environment; exact messaging apps and OS modifications; telephony transport evidence; permissions on target hardware; and the interpretation of autonomous training. These do not prevent fixture development, but they prevent claiming full competition compliance. Track them as explicit decision gates, not TODOs hidden in code.

## 2 Product outcome and boundaries

The operator selects devices, personas, scenarios and duration, presses Start, watches progress, intervenes if necessary, and exports a report. A run should answer four separate questions:

1. What did each simulated person try to do, and why was that action appropriate to the configured persona and current state?
2. What input actually reached the device, and at what time?
3. What independently observed result followed?
4. Is the evidence a device fault, an automation failure, an environmental problem, or insufficient to decide?

The first successful demonstration is intentionally narrow: one iOS Simulator reads a controlled page in Safari, navigates to a native Lab Messenger app, writes a short synthetic message at a configured pace, sends it to a fixture peer, and resumes browsing. The report contains real screen observations and a receiver acknowledgement. A second run suppresses an acknowledgement and reports the action as UNKNOWN while reconciling it; if independent evidence cannot resolve delivery, the result is INCONCLUSIVE, without automatically sending a duplicate message.

That first demonstration proves the UI-control loop, app switching, timing and evidence collection. It does not prove SMS, iMessage, cellular calls, human realism, fleet scale or compatibility with arbitrary apps.

The competition demonstrator adds Android, multiple personas, VPN exit selection, platform telephony scenarios with truthful evidence labels, bounded unattended policy calibration, physical-device evidence where available, and installation/operator evaluation. A hand-operated fixture backend is not an autonomous agent; a mocked adapter must be visibly identified everywhere.

Out of scope for this delivery: foundation-model training; jailbreaking/rooting; firmware flashing; bypassing device security; biometric/passcode circumvention; autonomous Apple-account setup; natural-language telephone conversation; hundreds of devices on one laptop; measuring real RF, battery or thermal behaviour in a simulator; and claims of exhaustive software correctness. Testing modified firmware is possible only when the sponsor supplies a supported, instrumentable target build and suitable hardware.

## 3 Operator journeys

### 3.1 First setup

The setup assistant checks the host toolchain and shows each dependency as Ready, Missing or Incompatible with a specific remedy. It distinguishes simulator prerequisites from physical-device signing. It creates a project-owned simulator, installs only project fixture apps, starts owned fixture services and executes a screenshot/tap/network smoke check.

Development may initially use documented terminal commands. A competition deliverable must provide a guided launcher and onboarding procedure; do not mark the no-technical-expertise requirement satisfied merely because an engineer prepared the machine. Measure initial installation separately from everyday operation.

### 3.2 Start a campaign

The operator sees available devices and capability badges, chooses a scenario pack, assigns one versioned persona to each device, chooses a duration and spending ceiling, and reviews preflight results. Unsupported mandatory capabilities disable Start for that campaign. Optional scenarios can be excluded explicitly, with exclusions included in the report.

The first screen offers useful defaults: one simulator, five-minute browsing-and-messaging campaign, synthetic content and the deterministic baseline. Enabling the cloud policy requires a configured provider and an explicit data-egress profile. API credentials never appear in browser storage or exported artifacts.

### 3.3 Observe and intervene

Each device card shows current app, last observation age, scenario step, pending action, persona, elapsed time, provider usage, evidence level and current verdict. The operator can pause a device, pause all, stop, or take manual control after the device lease is yielded. A global stop control remains available even when a model call or Appium command is slow.

The UI must distinguish a requested pause from a confirmed pause. It must show an in-flight send/call whose outcome is unknown. Resuming requires a new observation and precondition checks; the controller must not blindly continue an old queue.

### 3.4 Investigate and export

A failure opens a timeline linking the proposed action, scheduled time, actual dispatch, device result, external acknowledgement, screenshots and relevant logs. The operator can export an HTML report and a machine-readable evidence bundle. The report never describes an incomplete or skipped test as passed. Read-only replay of evidence is separate from rerunning actions on a device.

## 4 System architecture

```mermaid
flowchart TD
    UI[Local operator dashboard] --> API[Control API and durable coordinator]
    API --> DB[(SQLite and artifact directory)]
    API <--> P[Persona policy and model adapter]
    API --> V[Validate action and schedule human timing]
    V --> W[One worker per device]
    W --> A[Platform adapter]
    W --> O[Observed screen and candidates]
    O --> API
    A --> IOS[Appium XCUITest and WDA]
    A --> AND[Appium UiAutomator2 and ADB]
    IOS --> D1[iOS Simulator or paired iPhone]
    AND --> D2[Android emulator or test phone]
    D1 --> F[Owned fixture services and test peers]
    D2 --> F
    F --> OR[Independent outcome checks]
    OR --> API
```

### 4.1 Minimal deployment

Use one repository and one local control service. Use Python 3.12, FastAPI, Pydantic 2, SQLite in WAL mode, SQLAlchemy and Alembic. The coordinator is the only database writer; per-device subprocesses submit events over a bounded local RPC interface. This makes a blocked native driver call unable to freeze the dashboard or global stop gate. Do not add Redis, Kubernetes, a vector database or a distributed message bus for the initial three-device target.

Use a React/TypeScript/Vite dashboard, served by the local application after a production build. Use HTTP commands and server-sent events for progress. Bind the control API and Appium to loopback by default. The fixture data service may bind to an explicitly configured laboratory interface so phones can reach it; it has separate credentials and no administrative endpoints exposed to devices.

Xcode, Simulator, WDA and Appium run on the Mac. Do not put the iOS device-control stack inside a generic Linux container. Optional fixture services may be containerized later, but containers are not prerequisites for the first demo. Resolve and pin mutually compatible Appium, driver, Node, Xcode, runtime and client versions in the first feasibility task; never blindly install all components from floating `latest` tags.

### 4.2 Component ownership

| Component | Owns | Must not own |
|---|---|---|
| Coordinator | Per-run policy loop, model invocation, timing, run state, device leases, budgets, stop gate, durable events | Blocking driver execution |
| Device worker | Bounded serial observation/input operations and priority fences for one device | Model invocation, policy decisions, other devices, database writes, global permissions |
| Platform adapter | Capability discovery, screenshots/tree, bounded input, driver lifecycle | Persona goals or test verdicts |
| Policy backend | Proposed action among supplied possibilities | Direct device mutation, authoritative test outcomes |
| Persona engine | Goals, activity transitions, timing distributions, session memory | Network privileges or carrier claims |
| Outcome evaluator | Assertions using observations and external receipts | Choosing the next persona action |
| Environment controller | Fixture resets, fault schedules, configured VPN/network changes | Unannounced changes during realistic-use measurement |
| Report service | Evidence compilation and coverage accounting | Inventing missing telemetry |

Expose privileged environment operations only to the coordinator under an approved campaign configuration. Model output cannot add contacts, applications, hosts, VPN profiles or capabilities to its own allowlist.

### 4.3 Device and run lifecycle

A device is discovered, probed, leased to a run, prepared, exercised, drained, and released. A lease has a generation token. Commands with a stale generation are rejected. Only one worker may issue UI-mutating commands to a device at a time; native driver operations, screenshots and source-tree queries are serialized through that worker where required by Appium.

The coordinator persists an action as intended before dispatch. A crash during dispatch leaves the result UNKNOWN until observation or a peer receipt resolves it. This is particularly important for sends and calls. Durable journaling does not make UI actions exactly-once; the design must tolerate an unknown outcome without retrying a non-idempotent action.

On controller restart, close the dispatch gate and put previously active runs into recovery/PAUSING. Mark them PAUSED only after workers are fenced and in-flight effects are reconciled or explicitly left unresolved on a quarantined device. Do not resume actions automatically. Verify old worker termination, leases, device state and pending external effects. On device disconnection, preserve evidence and classify the interruption rather than repeatedly reconnecting and replaying the last action.

## 5 Platform integration and capability evidence

### 5.1 iOS first

Use Appium XCUITest backed by WebDriverAgent for screenshots, accessibility elements and UI gestures. The initial target is a fresh iOS Simulator with Safari and the project-owned Lab Messenger. Use stable accessibility identifiers in the fixture app; use observed labels, roles, visible bounds and limited screenshot interpretation for Safari.

Do not assume there is an Android-style system Back action on iOS. Back must resolve to a currently observed navigation control or an adapter-supported gesture in a known context. Platform-neutral actions need capability checks; they do not imply identical semantics.

Use native UI interaction for measured realistic journeys. A Safari DOM helper can diagnose or support separately labelled functional tests, but do not mix DOM shortcuts with claims about ordinary touch/keyboard behaviour. Opening an app directly may be a setup convenience; a persona journey that measures launcher/app-switcher use must execute that visible path instead.

The hardware phase needs a trusted iPhone, Developer Mode/UI Automation as applicable, signed WDA and signed fixture apps. The implementation must detect missing signing without repeatedly attempting installation. A paid developer membership must not be assumed. Personal Team limitations and renewal need a clear onboarding explanation. Apple's restrictions are not removable by adding an LLM.

Before using the everyday iPhone, inventory relevant test settings, explain proposed changes and restrict the campaign to installed fixture apps and test endpoints. Appium can alter keyboard preferences; this must be recorded and restoration verified. If restoration cannot be established, defer the everyday-phone run. Do not launch the user's Messages, Phone or personal Safari history in the initial hardware smoke test. Build a small project-owned WKWebView Lab Browser for that profile, restricted to test origins; simulator campaigns continue to use Safari. A dedicated test iPhone and receiving endpoint are dependencies for unattended carrier scenarios.

### 5.2 Android competition adapter

Implement the same domain contracts through Appium UiAutomator2 and ADB. Use a fresh AVD with a pinned image and a Kotlin Lab Messenger counterpart. Keep platform-only navigation actions explicit. Record the selected serial, OS image, Appium session, helper version and screenshot geometry.

Early Android work must verify outgoing/incoming SMS and call-state behaviour for the selected emulator image. Console injection of incoming SMS or an incoming call is environment simulation, not proof that the agent sent a message or placed an outgoing call. If emulator-to-emulator transport works, capture destination evidence and label it as OS simulation. Otherwise, leave the outgoing emulator feature unsupported and exercise it on dedicated physical hardware.

### 5.3 Evidence levels

Every scenario declares its required evidence level and every result states the level actually obtained:

| Level | Meaning | Example |
|---|---|---|
| `fixture` | Owned test-app or backend behaviour | A native Lab Messenger sends a real HTTP/WebSocket message to the owned server |
| `os_simulation` | OS UI or emulator event with simulated services | Android receives an injected SMS; supported virtual telephony interaction |
| `physical_ip` | Assertion about physical-phone IP connectivity | A device-originated probe verifies the selected VPN exit |
| `physical_carrier` | Physical phone plus independently observed carrier path | Dedicated SMS peer receives a sent SMS; a test call connects at the remote endpoint |

These are categories, not a universal quality ranking. Record device kind separately: Lab Messenger on a physical phone still provides `fixture` messaging semantics. Split a journey's VPN assertion into a separate `physical_ip` subscenario. Passing a fixture scenario cannot satisfy a scenario requiring physical carrier evidence. A rendered fake Messages screen must never be presented as native SMS support. Apple Simulator results are labelled Simulator; obtain sponsor confirmation about the virtual-environment requirement.

### 5.4 Capabilities as measured facts

The device profile records `supported`, `unsupported` or `unverified` for observation, taps, gestures, typing methods, app switching, background execution, notifications, native SMS, outgoing calls, incoming calls, VPN route control and telemetry. Record the probing date, platform/runtime versions, known settings and evidence artifact. No positive capability is inferred merely because an API method exists.

Arbitrary third-party messaging apps are not initially supported. Build an adapter for each selected app/version/account setup and validate its navigation and delivery oracle. Authentication and CAPTCHA are provisioning dependencies; they are not tasks for the autonomous test agent to bypass.

## 6 Observation and execution loop

At each decision boundary:

1. Check coordinator permission, device lease, run state and resource budgets.
2. Observe the foreground application, screen image, accessibility tree, orientation, keyboard presence and relevant public UI state. Timestamp the observation.
3. Normalize the visible tree into bounded candidate targets. Discard off-screen or stale elements, preserve accessibility labels as untrusted data, and assign observation-scoped candidate IDs.
4. Combine the current observation with the current persona goal and bounded session history. Ask the policy for one proposed action, or use the explicit deterministic baseline.
5. Validate schema, candidate membership, permitted destination/app, action budget and scenario preconditions. Reject invalid proposals with a structured error.
6. Compute a human due time using the persona engine. Wait cancellably. Cloud latency must not be interpreted as deliberate human hesitation.
7. Reobserve immediately before dispatch. Rebind the candidate only if its semantic identity, foreground context and safety preconditions still match. Otherwise replan. The dispatch observation must be at most two seconds old; keep the original decision observation for audit.
8. Journal and execute one bounded action through the adapter. Capture its exact status, start and finish times, then observe the result.
9. Run independent assertions, update session memory and advance the scenario only when supported by evidence.

The two-second freshness value is a proposed default to tune in the feasibility spike. A slow cloud response should trigger fresh validation, not an infinite cycle that requires every full model response within two seconds. Changed destinations or send controls always invalidate the old proposal.

Coordinate taps are deferred beyond the first slice and rejected unless an explicit later capability probe enables them. When enabled, bind them to the exact screenshot geometry and screen state; require a fresh visual check. Do not reuse raw coordinates across orientation, screen size or app changes. A successful Appium HTTP response is evidence of command execution, not completion of the intended user task.

Execution types distinguish navigation from external effects. `activate` is not automatically harmless: tapping Send, Call or Confirm is classified from the current scenario and target context as a non-idempotent commit. The policy cannot downgrade this classification.

## 7 Model integration

### 7.1 OpenAI backend

Use a bounded Agents SDK invocation to produce the domain `ProposedAction`. The coordinator owns the durable outer loop, provider invocation, timing, authorization and journaling; device workers execute bounded typed observation/input requests. Initially provide the model with the already captured observation and no device-executing tools. If read-only tools are added, restrict them to the current observation and bounded history. Do not let an inner agent loop issue unrecorded UI actions.

Set the model explicitly in configuration. `gpt-6-luna` is a documented candidate to evaluate, not a guaranteed performance choice. Provide a separately configured stronger fallback only if the evaluation shows it is needed. Record requested and returned model identifiers, prompt/schema versions, latency, token usage and fallback reason. Do not invent a snapshot identifier when the API does not expose one.

Limit request size, screenshots, history and output. Initial proposed limits: one screenshot, up to 100 visible candidates, the last ten action summaries, 20-second provider timeout, one schema-repair attempt and a campaign-wide spending ceiling. Atomically reserve a conservative per-request cost before dispatch, including retries, against a versioned configured rate card and token cap. Reconcile actual usage; retain the reservation when timeout leaves usage unknown. Do not start another request when unreserved budget is exhausted. Surface estimated versus confirmed cost and billing uncertainty. Keep full logs locally while sending only the bounded model context. Provider transport retry must not trigger device-action retry.

Model explanations are short decision reasons tied to observable state and persona configuration. Do not request or store hidden chain-of-thought. The reason is descriptive evidence of the proposal, not proof that the action is correct.

### 7.2 Jev backend

Integrate Jev through its own client behind the policy interface. It receives normalized text state and enumerated choices; it does not receive raw screenshots and is not set as a drop-in Agents SDK chat model. Use a separate vision/structure extraction step when necessary and include its cost and error rate in evaluation.

Keep candidate counts within the documented service limit, including wait/stop options. Jev's confidence or option probabilities describe its decision uncertainty; do not automatically interpret them as frequencies of human behaviour. The persona engine owns behavioural sampling. Content generation uses a versioned synthetic corpus or the generative backend.

Add Jev only after measuring the OpenAI and rules baselines on the same scenarios. Compare end-to-end completion, invalid proposals, recovery rate, p50/p95 latency, cost and changes in timing fidelity. Low inference latency alone is not acceptance. Public local deployment availability is unverified; the design must not rely on installing Jev weights on a phone.

### 7.3 Local and replay providers

Define provider capabilities for text, vision, schema handling, cancellation and usage accounting. A future local service can implement the same interface. Until an actual local model passes the same tests, the UI must call this a planned adapter, not offline AI support.

A rules backend provides repeatable navigation and a replay backend supports deterministic logic tests with saved observations. They keep development possible without keys. They are clearly labelled baselines and cannot be counted as evidence of model-driven adaptation. Recorded-action replay must abort on diverging preconditions; it is not guaranteed to reproduce external systems or model outputs exactly.

## 8 Persona behaviour and timing

A persona is a versioned data object with activity preferences, transitions, goals, timing distributions, interruption handling and navigation skill parameters. Session memory stores current task, reading position, last conversation, pending notifications, completed goals, selected contact IDs and time budget. It contains test data only.

Start with three explicitly synthetic profiles:

| Persona | Initial behaviour hypothesis | Demonstrable difference |
|---|---|---|
| Careful reader | Longer reading dwell, fewer switches, usually finishes a paragraph before replying | Greater dwell and lower switching rate |
| Frequent messenger | Short browsing visits, frequent short replies, responsive to notifications | More messaging transitions and shorter reply delay |
| Task-focused user | Completes one goal before switching, fewer revisits | Higher task persistence and fewer abandonment events |

These profiles are not trained or validated human models at creation. Use them to establish functionality, then fit timing and transition parameters to a consented human reference dataset. Keep calibration and held-out evaluation traces separate. Report participant count, tasks, uncertainty and known population limitations. Do not use demographic stereotypes as a substitute for measured behaviour.

Use a semi-Markov activity model: activity transitions have probabilities, and dwell times depend on both activity and context. Reading time can depend on visible text length; typing depends on message length and configured keyboard method; interruption delay depends on current activity. Use bounded log-normal/gamma-style distributions where suitable and define clipping explicitly. Example numbers in configuration are synthetic defaults.

Maintain independent seeded random streams for activity selection, timing, content selection and fault scheduling. Log the algorithm/version as well as the seed. Preserve real and scheduled monotonic timestamps, provider delay and dispatch lateness. Do not issue rapid catch-up taps when inference is slow. Record timing degradation and continue or pause according to configured limits.

Typing modes are `field_set` for functional setup, `paced_text` for timed character/text events, and `keyboard_touch` for actual on-screen keyboard taps where supported. Reports state the chosen mode. Paced text injection is not proof that the physical keyboard, autocorrect or predictive text paths were exercised.

Keep realistic-use campaigns separate from directed edge-condition campaigns. A persona's normal action distribution should not be silently distorted to maximize coverage. Intentional abnormal conditions are labelled and separately reported.

## 9 Fixture environment and scenarios

### 9.1 Controlled services

The shared fixture backend provides deterministic web articles/forms, test conversations, unique message identifiers, receiver acknowledgements and fault controls. SwiftUI and Kotlin Lab Messenger apps display the same backend data through native controls and expose stable accessibility identifiers. The sender's normal UI must exercise the same network path that is being tested.

Use a receiver service or second fixture app as the peer. Distinguish server acceptance, recipient delivery and recipient display. An acknowledgement generated by the sender is not independent delivery evidence. A scripted peer is permitted and labelled; it need not consume another full simulator for every functional test.

The fixture admin interface is separate from device traffic. Only the environment controller can inject delay, drop an acknowledgement, change a fixture response, crash the test app or trigger a controlled interruption. Fault activation writes ground-truth records unavailable to the acting policy. The evaluator can compare these records after classification to score detection.

Fixture traffic on a phone cannot use the Mac's `localhost`. Configure a laboratory hostname/address reachable by the target and use test TLS where possible. Scope any iOS App Transport Security development exception to the fixture target and remove it for the packaged mode; no blanket arbitrary-load exception. Local-network permissions are provisioned and recorded. The model/provider connection remains on the host.

### 9.2 Required scenario packs

| Pack | Behaviour | Evidence and limitation |
|---|---|---|
| Browse and return | Read, scroll, follow link, switch apps, resume | UI observations plus controlled web server request evidence |
| Native fixture messaging | Compose/send, receive reply, revisit conversation | Backend receipt and independent recipient acknowledgement |
| Interrupt and resume | Notification or controlled interruption while browsing | App/OS-specific delivery recorded; a fixture banner is not an OS notification |
| Poor network | Delay, loss or disconnection through a supported fixture/network controller | Exact injected layer and observed recovery; server delay is not RF simulation |
| Native SMS | Send/receive using supported OS app and dedicated endpoint | Capability-gated; simulated and carrier evidence distinguished |
| Voice call | Initiate, observe connection, terminate | Remote connection evidence for real calls; no conversation generation |
| VPN exit | Select approved exit A/B and make device-originated request | External observer reports expected exit and reachability |
| Fault detection | Crash, UI no-progress, missing delivery, service error, route mismatch | Independent evidence and classification |
| Long session | Repeat permitted activities with bounded resources | Event continuity, usage, pacing and memory statistics |

Push notifications on iOS require a separate provisioning and delivery decision. Do not assume background WebSocket execution is unrestricted. The early fixture demo can foreground/poll and switch apps on the scheduled persona event. Add APNs or supported simulator notification injection only as an explicit later capability, with its transport labelled.

## 10 Telephony and VPN feasibility gates

Within the initial feasibility work, document whether the chosen iOS Simulator runtime supports the relevant system apps and events. Do not spend the project trying to make a simulated dialler prove a carrier connection. For iOS carrier evidence use a dedicated signed test device, explicitly configured test accounts/SIM and receiving peer; confirm that the target OS permits the desired UI workflow through WDA.

Both-platform coverage means each platform has its own result matrix. Android emulator support does not make iOS SMS compliant. If the sponsor accepts a mixed demonstration, record that decision and still disclose the per-platform limits.

VPN control belongs to the environment layer. For the demonstrator prefer existing configured VPN clients/profiles or a dedicated laboratory gateway; do not build a new VPN implementation. Campaign-wide selection of two exits is the default proposed scope. Per-device simultaneous unique exits are an extension until required.

An iOS Simulator commonly shares host networking. Do not promise isolated VPN routing per Simulator. The first VPN proof should use a dedicated physical test device or an explicitly validated isolated test-host route. Keep host model/control traffic separate where feasible. Changing the user's entire Mac route is not an invisible setup operation.

Verify the device-originated request from a remote controlled observer, not by checking the host's public IP or a green VPN icon. Record expected exit, observed source, DNS/IPv6 scope and the covered application routes. A proxy-only test must be labelled proxy, not VPN. Ordinary cellular SMS and calls are not assumed to traverse the IP VPN. If the sponsor's on-premises interpretation forbids the remote observer, agree an internal exit-observer topology and state what it proves.

## 11 Outcome evaluation and reporting

Use explicit assertions and external evidence before language-model judgement. Assertions include expected visible state, receiver receipt, route observation, app crash records, scenario deadline and measured no-progress. An evaluator may use model assistance for ambiguous visual evidence, but its output is advisory until supported or reviewed.

`PASS`, `DUT_FAILURE`, `HARNESS_FAILURE`, `ENVIRONMENT_FAILURE`, `INCONCLUSIVE` and `UNSUPPORTED` are separate verdicts. A model failing to locate a button is normally a harness/policy failure. A fixture server intentionally unavailable is an environmental condition unless the DUT mishandles the specified recovery behaviour. Timeout alone does not establish a product bug.

The report contains configuration hashes, OS/app/model versions, tested scenarios, exclusions, trial counts, evidence categories, pass/failure rates with denominators, defect timelines, pacing statistics, provider costs, interventions and limitations. Include a coverage matrix of defined scenarios and conditions; never report percentage of all possible phone behaviours.

Store artifacts in run-specific directories with a manifest and hashes. Store local wall-clock UTC timestamps for correlation and monotonic timestamps for duration. Pin app builds and fixture data versions. Use structured event records rather than parsing prose to reconstruct outcomes. Limit artifact retention with an operator-visible policy; never delete original evidence while generating a report.

## 12 Autonomy, data and operational safeguards

The operator configures permitted app identifiers, fixture domains, test contacts/numbers, run duration, maximum actions, per-provider budgets and available environment operations. Unknown destinations are rejected by deterministic code. Incoming page/message text is untrusted content and cannot modify these controls. Include a fixture page containing adversarial instructions and verify that it cannot change the campaign's permissions.

Use cloud development mode only with synthetic fixtures by default. The everyday-iPhone smoke profile uses RulesProvider and local-only observations, regardless of the project cloud setting: a personal notification can overlay an allowlisted fixture app. On an unexpected overlay, stop and discard content captures from export; retain only a redacted diagnostic. Do not send that phone's screenshots or accessibility tree to a provider or automatically export them. Cloud device testing starts on synthetic simulators or a provisioned dedicated test handset. Local AI mode requires a tested local inference adapter and no telemetry/model egress; turning off the UI's cloud toggle is insufficient evidence. Configure SDK tracing/export explicitly; default to local application events and no automatic external trace export.

Persist the stop gate immediately and distinguish request receipt from confirmed worker fencing. Target confirmed fencing under one second on the measured local host. After confirmed fencing, workers may not begin new UI input. A delayed fence remains visibly pending; do not announce that all devices are stopped merely because the database gate closed. Already-dispatched events cannot be undone, and driver cancellation may take longer. Treat forceful worker termination as a harness interruption with possible unknown outcomes. Releasing a held touch and other input cleanup is best-effort, separately recorded and not permission to execute further scenario steps.

Credentials are injected at runtime from environment or an OS secret store, never stored in persona JSON, git, browser storage, logs or reports. Appium administrative ports are not exposed to the LAN. Use typed argument arrays for subprocess invocations; never interpolate model strings into shell commands.

For hardware testing, preserve existing data and settings. No factory reset, firmware change, deletion of apps or personal-account automation is part of the default workflow. Simulator resets are permitted only for project-created, explicitly identified test instances. Include artifact redaction and a known-secret canary check in acceptance.

## 13 Unattended calibration and training interpretation

Implement a bounded offline job that explores approved fixture states, collects transitions and failures, tunes navigation-policy parameters or action selection thresholds, and evaluates a new version against a fixed holdout. Exploration occurs in resettable virtual devices with synthetic data, maximum episode/action/spend budgets, and an independent stop mechanism.

The output is a versioned policy/persona configuration with a training manifest, data provenance, evaluation results and promotion decision. Do not modify a running campaign's policy. A failed candidate remains unpromoted and the previous policy stays active. Holdout evaluation is not used as the optimization signal.

This is policy calibration, not foundation-model fine-tuning. Unsupervised operation of the job does not establish unsupervised machine learning or human realism. The sponsor must confirm that this addresses its training requirement. A profile can be distributed as preconfigured or previously calibrated only when its provenance supports that label.

## 14 Performance, scale and deployment targets

Start with one virtual DUT. The competition target is three active virtual DUTs in total, including at least one iOS and one Android instance, for 30 minutes on a documented host. This is a proposed test target, not a capacity promise. Peer simulators, if needed, consume additional resources and must be included in resource accounting. Run a capacity probe before admitting a fleet campaign.

Use one outstanding decision request per device and a global provider concurrency/rate limiter. Enforce per-device fairness. Slow provider calls must not block other devices or control commands. A two-hour soak is a later gate on the reference host; larger farms require multiple hosts and are not a deliverable of the first build.

Record p50/p95 observation, model, driver and end-to-end latency. Surface timing misses instead of hiding them behind averages. Use scenario-specific deadlines, configurable provider ceilings and bounded backoff. Pauses and input waits use monotonic cancellable scheduling, not blocking sleeps on the API event loop.

Provide `doctor`, `start`, `stop`, `report` and `replay` CLI commands, then package the same functions behind a local launcher. These names are proposed interfaces, not commands currently installed. Export a support bundle that excludes secrets. Explain full-Xcode/runtime downloads, host permissions and signing as prerequisites; do not silently install large toolchains or accept licences.

## 15 Delivery sequence and release criteria

Build in vertical slices. [Implementation backlog](IMPLEMENTATION_BACKLOG.md) defines tasks and dependencies; [Agent start](AGENT_START.md) gives the initial coding prompt.

1. Prove iOS Simulator control and expose feasibility blockers for telephony/VPN/signing.
2. Complete one deterministic browse/message journey with independent evidence and stop control.
3. Add model proposals, personas, timing, dashboard and fault classification.
4. Add the Android adapter, equivalent fixtures and a mixed-platform campaign.
5. Add capability-gated physical-device, telephony and VPN demonstrations, calibration, package onboarding and sponsor-specific targets.

Never move a task to Done solely because unit tests pass against a mocked device. Driver work needs real simulator/device evidence; model adaptation needs a real provider run; carrier claims need a receiving endpoint. Where hardware, credentials or sponsor decisions are unavailable, keep the dependent acceptance item open and continue independent work.

The intended differentiator is a measured behavioural testing system with reproducible evidence. The first coding task is a functioning observation/action/evidence loop, not a decorative fleet dashboard.

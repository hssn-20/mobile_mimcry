# Sources and design decisions

Research snapshot: 3 October 2026. External documentation can change. Recheck version-sensitive setup during implementation and record the actual installed versions. The specifications are original engineering proposals informed by these sources; citations do not make their proposed performance thresholds supplier or sponsor guarantees.

## 1 Requirements and authoritative sources

| Source | What it establishes | Design consequence |
|---|---|---|
| [HMGCC authored challenge brief](https://www.plexal.com/wp-content/uploads/2026/09/Challenge-Form-Mobile-Mimicry-using-AI-v0.6.pdf) | Twelve-week TRL 5 demonstrator; £60,000 excluding VAT; virtual testing, selectable personas, communications, VPN exits, source/report, usability and autonomy requirements; on-premises testing without supplied training data | See the concise BR traceability table in the acceptance plan; cloud and platform interpretation remain open |
| [Apple XCUIAutomation](https://developer.apple.com/documentation/xcuiautomation) and [installed-app initialization](https://developer.apple.com/documentation/xcuiautomation/xcuiapplication/init%28bundleidentifier%3A%29) | UI testing and access to an installed app by bundle identifier | Feasible test harness, not universal permission to control every protected workflow |
| [Apple Simulator explanation](https://developer.apple.com/videos/play/wwdc2019/418/) | Simulator's execution model differs from a hardware emulator | Label the environment accurately and confirm sponsor acceptance |
| [XCUITest system requirements](https://appium.github.io/appium-xcuitest-driver/latest/getting-started/system-requirements/) | Host, driver and Xcode compatibility requirements | Resolve a released compatible stack and pin it after a smoke test |
| [XCUITest device preparation](https://appium.github.io/appium-xcuitest-driver/latest/getting-started/device-setup/) | WDA provisioning, device trust/settings and automatic keyboard preference changes | Guided onboarding, measured capability and restoration checks |
| [WDA provisioning](https://appium.github.io/appium-xcuitest-driver/latest/getting-started/provisioning-profile/) and [Apple account limits](https://developer.apple.com/help/account/basics/about-your-developer-account) | Signing choices and Personal Team constraints | Do not assume paid membership, unlimited installations or permanent profiles |
| [XCUITest parallel testing](https://appium.github.io/appium-xcuitest-driver/latest/guides/parallel-tests/) | Per-session identifiers, ports and build-data isolation | Isolated device worker configuration |
| [Apple MessageUI](https://developer.apple.com/documentation/messageui/mfmessagecomposeviewcontroller) | Message composition facilities and capability checks | Composer success is not a carrier-delivery oracle |
| [Android Emulator](https://developer.android.com/studio/run/emulator), [ADB](https://developer.android.com/tools/adb), [UI Automator](https://developer.android.com/training/testing/other-components/ui-automator) | Virtual devices, host/device connection and cross-app UI testing | Separate Android implementation behind the common contracts |
| [Appium UiAutomator2](https://github.com/appium/appium-uiautomator2-driver) | Android driver operation and version requirements | Pin a compatible driver/image, probe device capabilities |
| [Android emulator console](https://developer.android.com/studio/run/emulator-console) | Injected telephony/network events, including incoming SMS/call simulation | Do not describe event injection as outgoing carrier operation |
| [Android emulator networking](https://developer.android.com/studio/run/emulator-networking) | Version-dependent virtual networking capabilities | Verify selected runtime instead of assuming historical networking behaviour |
| [OpenAI Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk) and [models/providers](https://developers.openai.com/api/docs/guides/agents/models) | Application-hosted agent orchestration and explicit provider/model configuration | Use bounded policy invocation inside the application's durable loop |
| [OpenAI GPT-6 Luna](https://developers.openai.com/api/docs/models/gpt-6-luna) | Documented candidate with image input and structured/function outputs | Benchmark it; no claim of tested suitability yet |
| [OpenAI Agents API](https://developers.openai.com/api/docs/guides/agents-api/overview) | Managed agent runtime and its data-control constraints | Not required by the initial design; distinguish local execution from hosted inference |
| [TypeSafe models](https://docs.typesafe.ai/models) and [integration explanation](https://docs.typesafe.ai/introduction/coding-agents) | Text/JSON decisions; not a screenshot or free-text generation model | Jev requires a separate adapter and grounded candidate map |
| [TypeSafe API](https://docs.typesafe.ai/api), [Choice](https://docs.typesafe.ai/primitives/choice), [limitations](https://docs.typesafe.ai/model-jaggedness/jev-1.13) | Typed choice interface, candidate limits and semantic failure modes | Validate decisions independently; keep human activity probabilities separate |

No publicly documented OpenAI Decisions API was found in the official documentation searches for this design. There is no dependency on its release. No public on-phone/local Jev deployment was verified. These are research limits, not claims about private roadmaps or private enterprise agreements.

## 2 Confirmed user choices

| ID | Choice |
|---|---|
| D-01 | iPhone-first development |
| D-02 | Both iOS and Android in the competition demonstrator |
| D-03 | Cloud APIs during development; replaceable inference backend |
| D-04 | macOS development host; physical-device testing requires separate provisioning and developer signing |
| D-05 | Detailed Markdown specification and backlog saved in this workspace |

## 3 Proposed engineering decisions

| ID | Decision | Reason and revisit trigger |
|---|---|---|
| D-06 | Simulator first; everyday phone optional fixture-only smoke | Allows development without signing or personal data; revisit when dedicated devices are ready |
| D-07 | Python coordinator and per-device worker subprocesses | Keep control responsive during native-driver stalls; revisit for multi-host fleets |
| D-08 | SQLite single writer and local artifacts | Adequate first scale, simple recovery; revisit after measured contention or multi-host requirement |
| D-09 | SwiftUI and Kotlin fixture clients, shared protocol | Real native UI and observable IP messaging; expand to named target apps only with agreed test accounts |
| D-10 | Three total virtual DUTs as the first mixed-platform capacity target | Bounded demonstrator goal; confirm host capacity before committing |
| D-11 | OpenAI baseline before Jev comparison | Establish whether model routing improves end-to-end outcomes before adding complexity |
| D-12 | Existing VPN profiles/gateway, campaign-wide exit selection | Focus on behavioural testing; revisit if simultaneous unique per-device exits are required |
| D-13 | Separate persona calibration and navigation-policy training | Do not confuse human realism with task completion or fine-tuning |
| D-14 | No cloud capture from everyday iPhone | App allowlisting cannot exclude personal notification overlays |

## 4 Decisions still required and safe defaults

| ID | Decision owner and unresolved issue | Default while unresolved | Blocks |
|---|---|---|---|
| O-01 | Sponsor: permitted model/trace egress and retention | Synthetic development cloud profile only | Production/on-premises acceptance |
| O-02 | Sponsor: Simulator and externally controlled agent accepted | Explicitly labelled virtual surrogate; add Android emulator independently | Full iOS requirement mapping |
| O-03 | Sponsor: exact OS versions, apps, modifications and device count | One verified iOS runtime and one Android image; fixtures | General app/hardware claims |
| O-04 | Sponsor: acceptable SMS/call evidence on each platform | Require separate carrier proof for carrier claims | Communications compliance |
| O-05 | Project owner: dedicated handsets, SIM/test endpoints and signing | No unattended carrier activity on everyday phone | Physical carrier tests |
| O-06 | Sponsor: unattended policy calibration meets training intent | Implement bounded job and disclose interpretation | Training compliance |
| O-07 | Sponsor/network owner: VPN topology and allowed exits | No host-wide route modification; use configured test profile later | VPN acceptance |
| O-08 | Project owner: human reference cohort/data licence | Synthetic personas labelled uncalibrated | Human-realism claims |
| O-09 | Sponsor: fresh-machine installation boundaries | Measure initial provisioning and daily use separately | Nontechnical-installation claim |
| O-10 | Project owner: budget, team and reference host capacity | One Simulator first; capacity probe before scale | Schedule/capacity commitment |

These are specification dependencies, not requests to pause all development. The fixture-based core can proceed. Capture resolved answers in a dated decision record and update only the dependent requirements and tests.

## 5 Research and verification limitations

No application code, SDK call, Simulator session, physical-phone action, signing workflow or VPN route has been executed for this document. Host inspection was read-only and did not establish full Xcode readiness or available memory. API access and model availability for the user's account remain untested. No test pass or technology-readiness certification is implied by the existence of this design package.

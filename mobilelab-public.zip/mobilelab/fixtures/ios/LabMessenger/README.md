# Lab Messenger (fixture) — iOS

Project-owned SwiftUI test app for the mobilelab demonstrator (backlog T06, FR-04).
It is a plainly labelled **synthetic fixture**, not a look-alike of any real
messenger. Its messaging results always carry the `fixture` evidence label; it
never demonstrates SMS, iMessage or carrier capability.

- Bundle id: `org.mobilelab.fixtures.LabMessenger`, display name "Lab Messenger"
- iOS 17+, iPhone, Simulator first (signing-free)

## Layout

| Path | Contents |
|---|---|
| `Package.swift`, `Sources/LabMessengerCore/` | All non-UI logic (Swift package `LabMessengerCore`, iOS 17 / macOS 14) |
| `Tests/LabMessengerCoreTests/` | swift-testing unit tests (mock transport only) |
| `App/` | SwiftUI app: `LabMessengerApp`, `ConversationListView`, `MessageView`, `Composer`, `ErrorBanner`, `Info.plist` |
| `project.yml` | XcodeGen spec (app target + local package dependency) |
| `gen_xcodeproj.py` | Stdlib generator of the same project when XcodeGen is absent |
| `build_sim.sh` | Generate project and build for one Simulator UDID |
| `run_tests.sh` | `swift test` with the Command Line Tools search paths for Testing.framework |
| `typecheck_app.sh` | Build the core and typecheck `App/*.swift` against the macOS SDK |

## Configuration (launch arguments only)

Pass as Appium `processArguments` (or the same names as environment variables;
arguments win):

```
-MLFixtureBaseURL http://127.0.0.1:8781 -MLFixtureToken <sender token> -MLRunId <run uuid>
```

- The base URL must be plain `http`/`https` with no credentials, query or fragment.
- Its host must be `127.0.0.1`, `localhost`, or listed in Info.plist
  `MLAllowedFixtureHosts`. Otherwise the app shows a visible `app.error`
  configuration error and refuses to send.
- `127.0.0.1` works for the **Simulator only** because it shares the Mac's
  network stack. A physical phone needs the lab Mac's reachable host (add it to
  `MLAllowedFixtureHosts`, and use HTTPS because ATS applies).
- The token is the per-run **sender** token. The app never receives the
  fixture admin secret.
- Drafts and the outbox are stored per run in
  `Application Support/LabMessenger/runs/<run_id>/` (`drafts.json`, `outbox.json`).

ATS: `NSExceptionDomains` allows cleartext HTTP for `localhost` and `127.0.0.1`
only, with no global arbitrary-loads exception. ATS exception domains are
documented for domain names; the `127.0.0.1` IP-literal entry was observed to
allow cleartext on the iOS 27.0 Simulator. If it is ever blocked, use
`http://localhost:8781`.

## Accessibility identifiers (shared UI contract)

| Identifier | Element | Label / value |
|---|---|---|
| `conversation.list` | conversation List | |
| `conversation.row.<conversation_id>` | row | label = conversation title |
| `conversation.title` | header text in message view | conversation title |
| `message.list` | message List | |
| `message.row.<client_message_id>` | message body text (outbound and inbound peer messages) | label = body |
| `message.status.<client_message_id>` | status text (outbound only) | value ∈ `pending sending accepted delivered displayed failed unknown` |
| `composer.text` | TextField | |
| `composer.send` | Send button | disabled when the composer is empty/whitespace or >2000 chars, or config is invalid |
| `composer.draft_id` | small static text | value = current draft `client_message_id` (lowercase UUID) |
| `app.error` | error banner text | the message |

Inbound peer rows use the server message's `client_message_id`. All ids are
lowercase. `composer.draft_id` is **deliberately artificial** test-correlation
metadata. Third-party apps expose nothing equivalent.

## Behaviour

- **Draft identity:** the `client_message_id` is minted when a conversation's
  draft is created, which happens when the conversation opens and before Send.
  It is persisted with the draft text, so it stays the same across restarts.
  If the app crashed after queuing a send but before minting the next draft,
  the stale id is detected on open (it is already in the outbox) and a fresh
  draft is minted; an id is never reused for different text.
- **Body limit:** 1..2000 Unicode scalars (code points), the same count the
  server's validator uses.
- **Send:** tapping Send moves the draft into the persistent outbox, retires its
  id, mints the next draft id and clears the composer. All of this happens
  before the first network call, so a second tap cannot reuse an id. The row
  then shows `sending`, and the message is POSTed to `/fixture/v1/messages`
  through the app's normal `URLSession`.
- **Retries:** at most 3 attempts with 0.5 s and 1 s backoff. Every attempt
  reuses the same `client_message_id` and `sequence`. The app retries after a
  timeout, connection loss, unreachable host, 5xx, or a 2xx with a malformed
  receipt.
  - 409 gives `failed` and a visible "409 CLIENT_MESSAGE_ID_CONFLICT" error.
  - Any other 4xx gives `failed` and is never retried.
  - If retries run out after an attempt that may have reached the server, the
    status is `unknown`, not `failed`. The app shows an error saying the message
    was not resent automatically.
  - If every attempt failed with an unreachable host, the status is `failed`.
  - A request blocked on the device (ATS, TLS/certificate failure, bad or
    unsupported URL) never reached the server: `failed` at once, not retried.
- **Restart:** on launch the conversation list loads first; then outbox entries
  left `pending`/`sending` are resent (shown as `sending`) with the same id. If an earlier attempt was stored, the server returns the
  original receipt.
- **Polling:** in the foreground, the open conversation is fetched in full every
  ~2 s, following `next_cursor`. Statuses then update from the server
  (`accepted` → `delivered` → `displayed`). An `unknown` message is resolved
  when the server lists the same id with the same body, and the `app.error`
  banner for that message is cleared at the same time, so the banner never
  contradicts `message.status.<id>`. The app never invents delivered/displayed.
- **No send path without the UI:** there is no URL scheme, deep link, debug
  endpoint or launch argument that sends. The only path is the `composer.send`
  button.

## Build and verification status (honest)

Host: macOS 26.6.2 arm64, Xcode 27.0 (27A266a) at `/Applications/Xcode.app`
used via `DEVELOPER_DIR` (xcode-select still points at Command Line Tools and is
never changed). XcodeGen is not installed.

| Check | Status |
|---|---|
| `LabMessengerCore` unit tests: `./run_tests.sh` (mock transport, not a device) | 40 tests pass |
| Project generation without XcodeGen: `python3 gen_xcodeproj.py` (stdlib; local package reference to `LabMessengerCore`) | done |
| iOS Simulator build: `./build_sim.sh <udid>` (iphonesimulator SDK 27.0, signing-free) | **BUILD SUCCEEDED** on 2026-10-03 |
| Install + launch on project Simulator `mobilelab-iphone-01` (iPhone 17, iOS 27.0) with launch args; app fetched `GET /fixture/v1/conversations` (200) from the fixture server over cleartext `http://127.0.0.1` | done (`uv run python -m mobilelab.sim.bringup`, evidence in `artifacts/bringup/<ts>/`) |
| Accessibility tree via Appium/WDA, real send through `composer.send` | not done here (next stage) |

`./build_sim.sh <udid>` uses `DEVELOPER_DIR` if set, else `/Applications/Xcode.app`
when present; uses XcodeGen if on PATH, otherwise `gen_xcodeproj.py`. It writes
`LabMessenger.xcodeproj` (gitignored) and DerivedData to `build/DerivedData`, then
prints `build/DerivedData/Build/Products/Debug-iphonesimulator/LabMessenger.app`.
The ATS `127.0.0.1` exception works on the iOS 27.0 Simulator (observed above).

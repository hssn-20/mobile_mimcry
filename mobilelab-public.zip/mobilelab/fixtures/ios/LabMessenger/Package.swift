// swift-tools-version:6.0
// LabMessengerCore: all non-UI logic of the Lab Messenger fixture app.
// Buildable and testable with the Command Line Tools toolchain (`swift test`).
import PackageDescription

let package = Package(
    name: "LabMessengerCore",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [
        .library(name: "LabMessengerCore", targets: ["LabMessengerCore"]),
    ],
    targets: [
        .target(name: "LabMessengerCore", path: "Sources/LabMessengerCore"),
        .testTarget(
            name: "LabMessengerCoreTests",
            dependencies: ["LabMessengerCore"],
            path: "Tests/LabMessengerCoreTests"
        ),
    ],
    swiftLanguageModes: [.v6]
)

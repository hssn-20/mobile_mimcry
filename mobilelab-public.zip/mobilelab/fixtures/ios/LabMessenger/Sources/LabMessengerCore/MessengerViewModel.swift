import Foundation
import Observation

/// One row in the message list. `id` is the client_message_id (lowercase) and
/// is used for the `message.row.<id>` / `message.status.<id>` identifiers.
public struct MessageRow: Sendable, Equatable, Identifiable {
    public enum Direction: Sendable, Equatable { case outbound, inbound }
    public var id: String
    public var body: String
    public var direction: Direction
    /// Only outbound rows carry a status.
    public var status: DisplayStatus?
}

/// UI state and actions for the Lab Messenger fixture. The only way to send
/// is `send()`, which the Composer's Send button calls.
@MainActor
@Observable
public final class MessengerViewModel {
    public static let pollInterval: Duration = .seconds(2)
    public static let maxBodyLength = 2000

    public private(set) var conversations: [Conversation] = []
    public private(set) var selectedConversationID: String?
    /// Current draft client_message_id (exposed via `composer.draft_id`).
    public private(set) var draftID: String?
    public private(set) var configError: String?
    public private(set) var sendError: String?
    public private(set) var syncError: String?

    public var composerText: String = "" {
        didSet { persistComposerText() }
    }

    /// Text for the `app.error` banner, if any.
    public var errorMessage: String? { configError ?? sendError ?? syncError }

    public var canSend: Bool {
        guard configError == nil, outbox != nil, draftID != nil else { return false }
        let trimmed = composerText.trimmingCharacters(in: .whitespacesAndNewlines)
        // Count Unicode scalars (code points), as the server's Pydantic
        // max_length does, not grapheme clusters.
        return !trimmed.isEmpty && composerText.unicodeScalars.count <= Self.maxBodyLength
    }

    public var selectedConversation: Conversation? {
        conversations.first { $0.conversationID == selectedConversationID }
    }

    @ObservationIgnored private let client: FixtureAPIClient?
    @ObservationIgnored private let drafts: DraftStore?
    @ObservationIgnored private let outbox: Outbox?
    private var serverMessages: [String: [Message]] = [:]
    @ObservationIgnored private var suppressDraftPersist = false
    /// The outbox entry `sendError` describes (nil for storage errors), so the
    /// banner can be cleared once that entry is resolved by reconciliation.
    @ObservationIgnored private var sendErrorClientMessageID: String?

    /// - Parameters:
    ///   - configResult: result of `FixtureConfig.load`. On failure the app
    ///     shows a config error and refuses to send.
    ///   - storageRoot: injectable root for run-scoped files (nil = Application Support).
    ///   - makeTransport: builds the network transport (URLSessionTransport in the app).
    public init(
        configResult: Result<FixtureConfig, FixtureConfigError>,
        storageRoot: URL? = nil,
        makeTransport: (FixtureConfig) -> any FixtureTransport,
        retryPolicy: RetryPolicy = RetryPolicy(),
        sleep: @escaping Sleeper = taskSleeper
    ) {
        switch configResult {
        case .failure(let error):
            configError = error.description
            client = nil
            drafts = nil
            outbox = nil
        case .success(let config):
            let client = FixtureAPIClient(transport: makeTransport(config))
            self.client = client
            do {
                let directory = try LabMessengerStorage.runDirectory(runID: config.runID, root: storageRoot)
                let draftStore = try DraftStore(directory: directory, runID: config.runID)
                let outboxStore = try Outbox(directory: directory, client: client, policy: retryPolicy, sleep: sleep)
                drafts = draftStore
                outbox = outboxStore
            } catch {
                configError = "Storage error: \(error.localizedDescription). Sending is disabled."
                drafts = nil
                outbox = nil
            }
        }
    }

    /// App launch: load conversations first (so `conversation.list` is never
    /// held empty behind slow retries), then resume interrupted sends with
    /// their original client_message_ids. Resends show as `sending` meanwhile.
    public func start() async {
        await loadConversations()
        if let outbox {
            for id in outbox.interruptedEntryIDs() {
                await deliver(id)
            }
        }
    }

    public func loadConversations() async {
        guard let client else { return }
        do {
            conversations = try await client.listConversations()
            syncError = nil
        } catch {
            syncError = error.description
        }
    }

    /// Select a conversation; creates/loads its persistent draft.
    public func open(conversationID: String) async {
        selectedConversationID = conversationID
        loadDraft()
        await pollOnce()
    }

    public func close() {
        selectedConversationID = nil
        draftID = nil
        setComposerTextWithoutPersist("")
    }

    /// Send the current draft. Called only from the Composer's Send button.
    public func send() async {
        guard canSend, let drafts, let outbox, let conversationID = selectedConversationID else { return }
        let entryID: String
        do {
            var draft = try drafts.draft(for: conversationID)
            if outbox.entry(draft.clientMessageID) != nil {
                // Persisted draft identity was already handed to the outbox
                // (crash between enqueue and draft rotation): never reuse it.
                draft = try drafts.replaceAfterSend(conversationID: conversationID)
            }
            draft.body = composerText
            let entry = try outbox.enqueue(draft)
            entryID = entry.clientMessageID
            // Retire the sent identity and mint the next draft before any await,
            // so a second tap can never reuse this draft.
            let next = try drafts.replaceAfterSend(conversationID: conversationID)
            draftID = next.clientMessageID
            setComposerTextWithoutPersist("")
        } catch {
            setSendError("Storage error: \(error.localizedDescription)", for: nil)
            return
        }
        setSendError(nil, for: nil)
        await deliver(entryID)
    }

    /// One foreground poll of the open conversation.
    public func pollOnce() async {
        guard let client, let conversationID = selectedConversationID else { return }
        do {
            let messages = try await client.listAllMessages(conversationID: conversationID)
            serverMessages[conversationID] = messages
            outbox?.reconcile(with: messages)
            clearResolvedSendError()
            syncError = nil
        } catch {
            syncError = error.description
        }
    }

    /// Foreground polling loop; ends when the calling task is cancelled
    /// (SwiftUI `.task` cancels it when the view disappears).
    public func runForegroundPolling(interval: Duration = MessengerViewModel.pollInterval) async {
        while !Task.isCancelled {
            try? await Task.sleep(for: interval)
            if Task.isCancelled { break }
            await pollOnce()
        }
    }

    public func dismissError() {
        setSendError(nil, for: nil)
    }

    // MARK: - Private

    private func deliver(_ clientMessageID: String) async {
        guard let outbox else { return }
        clearResolvedSendError()
        let result = await outbox.deliver(clientMessageID)
        if let result {
            let id = result.clientMessageID
            switch result.state {
            case .conflict:
                setSendError("Send failed: message id conflict (409 CLIENT_MESSAGE_ID_CONFLICT).", for: id)
            case .failed:
                setSendError("Send failed: \(result.lastError ?? "request rejected").", for: id)
            case .unknown:
                setSendError("Send outcome unknown after \(result.attempts) attempts (\(result.lastError ?? "transport error")). Not resent automatically.", for: id)
            case .pending, .sending, .accepted:
                break
            }
        }
        clearResolvedSendError()
    }

    private func setSendError(_ message: String?, for clientMessageID: String?) {
        sendError = message
        sendErrorClientMessageID = message == nil ? nil : clientMessageID
    }

    /// Clear a send error whose outbox entry is no longer failed/unknown/conflict
    /// (e.g. a poll showed the server stored it), so `app.error` never
    /// contradicts `message.status.<id>`.
    private func clearResolvedSendError() {
        guard let id = sendErrorClientMessageID, let state = outbox?.entry(id)?.state else { return }
        switch state {
        case .unknown, .failed, .conflict:
            break
        case .pending, .sending, .accepted:
            setSendError(nil, for: nil)
        }
    }

    private func loadDraft() {
        guard let drafts, let conversationID = selectedConversationID else { return }
        do {
            var draft = try drafts.draft(for: conversationID)
            if outbox?.entry(draft.clientMessageID) != nil {
                // Crash between outbox enqueue and draft rotation: the persisted
                // draft id was already sent. Mint a fresh draft.
                draft = try drafts.replaceAfterSend(conversationID: conversationID)
            }
            draftID = draft.clientMessageID
            setComposerTextWithoutPersist(draft.body)
        } catch {
            setSendError("Storage error: \(error.localizedDescription)", for: nil)
        }
    }

    private func setComposerTextWithoutPersist(_ text: String) {
        suppressDraftPersist = true
        composerText = text
        suppressDraftPersist = false
    }

    private func persistComposerText() {
        guard !suppressDraftPersist, let drafts, let conversationID = selectedConversationID else { return }
        do {
            let draft = try drafts.updateBody(composerText, conversationID: conversationID)
            draftID = draft.clientMessageID
        } catch {
            setSendError("Storage error: \(error.localizedDescription)", for: nil)
        }
    }

    /// Rows for the open conversation: server messages in sequence order,
    /// then local outbox entries the server has not (yet) shown.
    public var rows: [MessageRow] {
        guard let conversationID = selectedConversationID else { return [] }
        let server = serverMessages[conversationID] ?? []
        let outboxEntries = (outbox?.entries ?? []).filter { $0.conversationID == conversationID }
        let ownSenders = outbox?.ownSenderIDs ?? []
        var byID: [String: OutboxEntry] = [:]
        for entry in outboxEntries { byID[entry.clientMessageID] = entry }

        var result: [MessageRow] = []
        var seen: Set<String> = []
        for message in server {
            let id = message.clientMessageID.lowercased()
            seen.insert(id)
            if let entry = byID[id] {
                result.append(MessageRow(id: id, body: entry.body, direction: .outbound, status: entry.displayStatus))
            } else if ownSenders.contains(message.senderID) {
                result.append(MessageRow(id: id, body: message.body, direction: .outbound, status: DisplayStatus(message.status)))
            } else {
                result.append(MessageRow(id: id, body: message.body, direction: .inbound, status: nil))
            }
        }
        for entry in outboxEntries.sorted(by: { $0.createdAt < $1.createdAt }) where !seen.contains(entry.clientMessageID) {
            result.append(MessageRow(id: entry.clientMessageID, body: entry.body, direction: .outbound, status: entry.displayStatus))
        }
        return result
    }
}

import Foundation

/// Wire models for the shared fixture protocol (`/fixture/v1`, schema_version 1).
/// Field names are mapped explicitly to the snake_case wire names.
/// Identifiers are carried as lowercase strings so that the value shown in
/// accessibility metadata is byte-identical to what the server and oracle use.

public let fixtureSchemaVersion = 1

/// Server-side message/receipt state. The server never manufactures
/// delivered/displayed itself; those come from receiver acknowledgements.
public enum ServerMessageStatus: String, Codable, Sendable, Equatable {
    case accepted
    case delivered
    case displayed
}

public struct Conversation: Codable, Sendable, Equatable, Identifiable {
    public var conversationID: String
    public var title: String
    public var contactID: String
    public var participants: [String]

    public var id: String { conversationID }

    public init(conversationID: String, title: String, contactID: String, participants: [String]) {
        self.conversationID = conversationID
        self.title = title
        self.contactID = contactID
        self.participants = participants
    }

    enum CodingKeys: String, CodingKey {
        case conversationID = "conversation_id"
        case title
        case contactID = "contact_id"
        case participants
    }
}

public struct ConversationsResponse: Codable, Sendable, Equatable {
    public var schemaVersion: Int
    public var conversations: [Conversation]

    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version"
        case conversations
    }
}

public struct Message: Codable, Sendable, Equatable {
    public var messageID: String
    public var runID: String
    public var conversationID: String
    public var clientMessageID: String
    public var senderID: String
    public var sequence: Int
    public var body: String
    public var serverAcceptedAt: Date
    public var receiverDeliveredAt: Date?
    public var receiverDisplayedAt: Date?
    public var status: ServerMessageStatus

    enum CodingKeys: String, CodingKey {
        case messageID = "message_id"
        case runID = "run_id"
        case conversationID = "conversation_id"
        case clientMessageID = "client_message_id"
        case senderID = "sender_id"
        case sequence
        case body
        case serverAcceptedAt = "server_accepted_at"
        case receiverDeliveredAt = "receiver_delivered_at"
        case receiverDisplayedAt = "receiver_displayed_at"
        case status
    }
}

public struct MessagesPage: Codable, Sendable, Equatable {
    public var schemaVersion: Int
    public var messages: [Message]
    public var nextCursor: String?

    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version"
        case messages
        case nextCursor = "next_cursor"
    }
}

/// Body of `POST /fixture/v1/messages`. Exactly these six fields; the server
/// rejects extra fields with 422.
public struct SendMessageRequest: Codable, Sendable, Equatable {
    public var schemaVersion: Int
    public var runID: String
    public var conversationID: String
    public var clientMessageID: String
    public var sequence: Int
    public var body: String

    public init(runID: String, conversationID: String, clientMessageID: String, sequence: Int, body: String) {
        self.schemaVersion = fixtureSchemaVersion
        self.runID = runID
        self.conversationID = conversationID
        self.clientMessageID = clientMessageID
        self.sequence = sequence
        self.body = body
    }

    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version"
        case runID = "run_id"
        case conversationID = "conversation_id"
        case clientMessageID = "client_message_id"
        case sequence
        case body
    }
}

public struct Receipt: Codable, Sendable, Equatable {
    public var schemaVersion: Int
    public var messageID: String
    public var runID: String
    public var conversationID: String
    public var clientMessageID: String
    public var senderID: String
    public var serverAcceptedAt: Date
    public var receiverDeliveredAt: Date?
    public var receiverDisplayedAt: Date?
    public var receiverType: String?
    public var status: ServerMessageStatus
    public var correlationEvidenceIDs: [String]

    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version"
        case messageID = "message_id"
        case runID = "run_id"
        case conversationID = "conversation_id"
        case clientMessageID = "client_message_id"
        case senderID = "sender_id"
        case serverAcceptedAt = "server_accepted_at"
        case receiverDeliveredAt = "receiver_delivered_at"
        case receiverDisplayedAt = "receiver_displayed_at"
        case receiverType = "receiver_type"
        case status
        case correlationEvidenceIDs = "correlation_evidence_ids"
    }
}

/// `{"error": "<CODE>"}` bodies (e.g. CLIENT_MESSAGE_ID_CONFLICT, TOKEN_INVALID).
public struct FixtureErrorBody: Codable, Sendable, Equatable {
    public var error: String
}

/// JSON coders using ISO 8601 dates. Decoding accepts `Z` or numeric offsets,
/// with or without fractional seconds (Python emits microseconds).
public enum FixtureJSON {
    public static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let raw = try container.decode(String.self)
            if let date = parseDate(raw) { return date }
            throw DecodingError.dataCorruptedError(
                in: container, debugDescription: "Invalid ISO 8601 date: \(raw)")
        }
        return decoder
    }

    public static func encoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        encoder.dateEncodingStrategy = .custom { date, encoder in
            var container = encoder.singleValueContainer()
            try container.encode(formatDate(date))
        }
        return encoder
    }

    public static func parseDate(_ raw: String) -> Date? {
        if let date = try? Date.ISO8601FormatStyle(includingFractionalSeconds: true).parse(raw) {
            return date
        }
        return try? Date.ISO8601FormatStyle().parse(raw)
    }

    /// UTC with millisecond precision and a `Z` suffix.
    public static func formatDate(_ date: Date) -> String {
        date.formatted(Date.ISO8601FormatStyle(includingFractionalSeconds: true, timeZone: .gmt))
    }
}

/// Lowercase UUID string, the canonical client-side identifier form.
public func newLowercaseUUID() -> String {
    UUID().uuidString.lowercased()
}

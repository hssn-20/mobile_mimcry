import Foundation
import Observation

/// Values exposed as the accessibilityValue of `message.status.<client_message_id>`.
public enum DisplayStatus: String, Sendable, Equatable, CaseIterable {
    case pending, sending, accepted, delivered, displayed, failed, unknown

    init(_ server: ServerMessageStatus) {
        switch server {
        case .accepted: self = .accepted
        case .delivered: self = .delivered
        case .displayed: self = .displayed
        }
    }
}

public enum OutboxState: String, Codable, Sendable, Equatable {
    /// Waiting to be (re)sent, e.g. after an app restart.
    case pending
    /// An attempt is in flight (persisted so a crash mid-send resumes).
    case sending
    /// Server receipt obtained.
    case accepted
    /// 409 CLIENT_MESSAGE_ID_CONFLICT.
    case conflict
    /// Non-retryable 4xx, or retries exhausted without ever reaching the server.
    case failed
    /// Retries exhausted after attempts that may have reached the server.
    case unknown
}

public struct OutboxEntry: Codable, Sendable, Equatable {
    public var clientMessageID: String
    public var runID: String
    public var conversationID: String
    public var sequence: Int
    public var body: String
    public var createdAt: Date
    public var state: OutboxState
    public var attempts: Int
    public var lastError: String?
    public var receipt: Receipt?
    /// Latest server-side status seen (receipt or conversation poll).
    public var serverStatus: ServerMessageStatus?

    public var displayStatus: DisplayStatus {
        switch state {
        case .pending: .pending
        case .sending: .sending
        case .accepted: DisplayStatus(serverStatus ?? .accepted)
        case .conflict, .failed: .failed
        case .unknown: .unknown
        }
    }

    var request: SendMessageRequest {
        SendMessageRequest(runID: runID, conversationID: conversationID,
                           clientMessageID: clientMessageID, sequence: sequence, body: body)
    }

    enum CodingKeys: String, CodingKey {
        case clientMessageID = "client_message_id"
        case runID = "run_id"
        case conversationID = "conversation_id"
        case sequence, body
        case createdAt = "created_at"
        case state, attempts
        case lastError = "last_error"
        case receipt
        case serverStatus = "server_status"
    }
}

public enum OutboxError: Error, Sendable, Equatable, LocalizedError {
    /// The id is already in the outbox with a different payload.
    case clientMessageIDAlreadyUsed(String)

    public var errorDescription: String? {
        switch self {
        case .clientMessageIDAlreadyUsed(let id): "client_message_id \(id) was already used for a different message"
        }
    }
}

public struct RetryPolicy: Sendable, Equatable {
    public var maxAttempts: Int
    public var initialBackoff: Duration
    public var multiplier: Int

    public init(maxAttempts: Int = 3, initialBackoff: Duration = .milliseconds(500), multiplier: Int = 2) {
        precondition(maxAttempts >= 1)
        self.maxAttempts = maxAttempts
        self.initialBackoff = initialBackoff
        self.multiplier = multiplier
    }

    func backoff(afterAttempt attempt: Int) -> Duration {
        var delay = initialBackoff
        for _ in 1..<max(attempt, 1) { delay = delay * multiplier }
        return delay
    }
}

public typealias Sleeper = @Sendable (Duration) async -> Void

public let taskSleeper: Sleeper = { duration in try? await Task.sleep(for: duration) }

/// Persistent outbox. Every attempt for an entry reuses the entry's
/// client_message_id. Retries happen only for transport failures, 5xx and
/// malformed 2xx; 4xx are never retried; 409 becomes `.conflict`.
@MainActor
@Observable
public final class Outbox {
    public private(set) var entries: [OutboxEntry]
    @ObservationIgnored private let file: JSONFile<[OutboxEntry]>
    @ObservationIgnored private let client: FixtureAPIClient
    @ObservationIgnored private let policy: RetryPolicy
    @ObservationIgnored private let sleep: Sleeper
    @ObservationIgnored private let now: () -> Date
    @ObservationIgnored private var inFlight: Set<String> = []

    public init(directory: URL, client: FixtureAPIClient, policy: RetryPolicy = RetryPolicy(),
                sleep: @escaping Sleeper = taskSleeper, now: @escaping () -> Date = Date.init) throws {
        self.file = JSONFile(url: directory.appendingPathComponent("outbox.json"))
        self.client = client
        self.policy = policy
        self.sleep = sleep
        self.now = now
        self.entries = try file.load() ?? []
    }

    public func entry(_ clientMessageID: String) -> OutboxEntry? {
        entries.first { $0.clientMessageID == clientMessageID }
    }

    /// Sender ids learned from our own receipts (used to tell own messages from peer messages).
    public var ownSenderIDs: Set<String> {
        Set(entries.compactMap { $0.receipt?.senderID })
    }

    /// Move a draft into the outbox (state `.pending`). Idempotent per id for
    /// the same payload; reusing an id with a different body or conversation
    /// throws instead of silently dropping the new text.
    @discardableResult
    public func enqueue(_ draft: Draft) throws -> OutboxEntry {
        if let existing = entry(draft.clientMessageID) {
            guard existing.body == draft.body, existing.conversationID == draft.conversationID else {
                throw OutboxError.clientMessageIDAlreadyUsed(draft.clientMessageID)
            }
            return existing
        }
        let entry = OutboxEntry(
            clientMessageID: draft.clientMessageID, runID: draft.runID, conversationID: draft.conversationID,
            sequence: draft.sequence, body: draft.body, createdAt: now(), state: .pending, attempts: 0,
            lastError: nil, receipt: nil, serverStatus: nil)
        entries.append(entry)
        try persist()
        return entry
    }

    /// Entries interrupted by an app restart/crash (`pending` or `sending`).
    /// They are re-sent with the same client_message_id; the server returns
    /// the original receipt if the earlier attempt was stored.
    public func interruptedEntryIDs() -> [String] {
        entries.filter { $0.state == .pending || $0.state == .sending }.map(\.clientMessageID)
    }

    /// Deliver one entry with bounded retries. Returns the final entry.
    @discardableResult
    public func deliver(_ clientMessageID: String) async -> OutboxEntry? {
        guard let initial = entry(clientMessageID) else { return nil }
        guard initial.state == .pending || initial.state == .sending else { return initial }
        guard !inFlight.contains(clientMessageID) else { return initial }
        inFlight.insert(clientMessageID)
        defer { inFlight.remove(clientMessageID) }

        var mayHaveReachedServer = initial.state == .sending || initial.attempts > 0
        for attempt in 1...policy.maxAttempts {
            update(clientMessageID) { $0.state = .sending; $0.attempts += 1 }
            let result = await client.postMessage(initial.request)
            switch result {
            case .accepted(let receipt, _):
                update(clientMessageID) {
                    $0.state = .accepted
                    $0.receipt = receipt
                    $0.serverStatus = receipt.status
                    $0.lastError = nil
                }
                return entry(clientMessageID)
            case .conflict:
                update(clientMessageID) { $0.state = .conflict; $0.lastError = "CLIENT_MESSAGE_ID_CONFLICT" }
                return entry(clientMessageID)
            case .notSent(let reason):
                update(clientMessageID) { $0.state = .failed; $0.lastError = "request not sent: \(reason)" }
                return entry(clientMessageID)
            case .rejected(let status, let code):
                update(clientMessageID) { $0.state = .failed; $0.lastError = "HTTP \(status)\(code.map { " \($0)" } ?? "")" }
                return entry(clientMessageID)
            case .retryable(let reason, let reached):
                mayHaveReachedServer = mayHaveReachedServer || reached
                update(clientMessageID) { $0.lastError = reason }
                if attempt < policy.maxAttempts {
                    await sleep(policy.backoff(afterAttempt: attempt))
                }
            }
        }
        update(clientMessageID) { $0.state = mayHaveReachedServer ? .unknown : .failed }
        return entry(clientMessageID)
    }

    /// Apply server-side state from a conversation poll. Resolves `unknown`
    /// (or interrupted) entries when the server shows the same identity with
    /// the same payload, and updates delivered/displayed status.
    public func reconcile(with messages: [Message]) {
        var changed = false
        for message in messages {
            guard let index = entries.firstIndex(where: { $0.clientMessageID == message.clientMessageID.lowercased() })
            else { continue }
            var entry = entries[index]
            guard entry.body == message.body, entry.conversationID == message.conversationID else { continue }
            switch entry.state {
            case .unknown, .pending, .failed:
                entry.state = .accepted
                entry.lastError = nil
            case .accepted, .sending, .conflict:
                break
            }
            if entry.state == .accepted || entry.state == .sending { entry.serverStatus = message.status }
            if entry != entries[index] {
                entries[index] = entry
                changed = true
            }
        }
        if changed { try? persist() }
    }

    private func update(_ clientMessageID: String, _ mutate: (inout OutboxEntry) -> Void) {
        guard let index = entries.firstIndex(where: { $0.clientMessageID == clientMessageID }) else { return }
        mutate(&entries[index])
        try? persist()
    }

    private func persist() throws {
        try file.save(entries)
    }
}

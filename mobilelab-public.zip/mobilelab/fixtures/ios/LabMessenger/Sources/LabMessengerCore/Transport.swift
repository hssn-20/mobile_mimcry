import Foundation

public struct HTTPResponseData: Sendable, Equatable {
    public var statusCode: Int
    public var headers: [String: String]
    public var body: Data

    public init(statusCode: Int, headers: [String: String] = [:], body: Data) {
        self.statusCode = statusCode
        self.headers = headers
        self.body = body
    }
}

/// Transport-level failures (no HTTP status was received).
public enum TransportError: Error, Sendable, Equatable {
    /// Request may have reached the server (it may have been stored).
    case timeout
    /// Connection dropped mid-request; the request may have been stored.
    case connectionLost
    /// Host could not be reached at all; the request did not reach the server.
    case unreachable
    /// The request was never sent: blocked locally (ATS, TLS/certificate
    /// failure, bad or unsupported URL). A configuration problem, not a
    /// transient one: not retried, and the request provably did not reach
    /// the server.
    case notSent(String)
    case other(String)
}

/// Minimal HTTP abstraction so send/poll logic can be tested with a scripted
/// fake. The production implementation is `URLSessionTransport`.
public protocol FixtureTransport: Sendable {
    /// `path` is relative to the configured base URL, e.g. `/fixture/v1/messages`.
    func perform(method: String, path: String, query: [URLQueryItem], body: Data?) async throws(TransportError) -> HTTPResponseData
}

/// Real network transport: the app's normal URLSession path. Adds the sender
/// bearer token; nothing else (no admin credentials ever).
public final class URLSessionTransport: FixtureTransport {
    private let baseURL: URL
    private let token: String
    private let session: URLSession

    public init(baseURL: URL, token: String, requestTimeout: TimeInterval = 10) {
        self.baseURL = baseURL
        self.token = token
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = requestTimeout
        configuration.timeoutIntervalForResource = requestTimeout * 2
        configuration.waitsForConnectivity = false
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        self.session = URLSession(configuration: configuration)
    }

    public func perform(method: String, path: String, query: [URLQueryItem], body: Data?) async throws(TransportError) -> HTTPResponseData {
        guard var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false) else {
            throw .notSent("invalid base URL")
        }
        let basePath = components.path.hasSuffix("/") ? String(components.path.dropLast()) : components.path
        components.path = basePath + path
        components.queryItems = query.isEmpty ? nil : query
        guard let url = components.url else { throw .notSent("invalid request URL") }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.httpBody = body
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch let error as URLError {
            throw Self.map(error)
        } catch {
            throw .other(String(describing: error))
        }
        guard let http = response as? HTTPURLResponse else { throw .other("non-HTTP response") }
        var headers: [String: String] = [:]
        for (key, value) in http.allHeaderFields {
            if let key = key as? String, let value = value as? String { headers[key.lowercased()] = value }
        }
        return HTTPResponseData(statusCode: http.statusCode, headers: headers, body: data)
    }

    static func map(_ error: URLError) -> TransportError {
        switch error.code {
        case .timedOut:
            return .timeout
        case .notConnectedToInternet, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed:
            return .unreachable
        case .networkConnectionLost, .badServerResponse, .zeroByteResource:
            return .connectionLost
        case .appTransportSecurityRequiresSecureConnection:
            return .notSent("blocked by App Transport Security (URLError \(error.code.rawValue))")
        case .secureConnectionFailed, .serverCertificateHasBadDate, .serverCertificateUntrusted,
             .serverCertificateHasUnknownRoot, .serverCertificateNotYetValid,
             .clientCertificateRejected, .clientCertificateRequired:
            return .notSent("TLS/certificate failure (URLError \(error.code.rawValue))")
        case .badURL, .unsupportedURL:
            return .notSent("invalid or unsupported URL (URLError \(error.code.rawValue))")
        default:
            return .other("URLError \(error.code.rawValue)")
        }
    }
}

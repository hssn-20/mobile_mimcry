import Foundation

/// Run configuration supplied ONLY through launch arguments
/// (`-MLFixtureBaseURL <url> -MLFixtureToken <sender token> -MLRunId <uuid>`)
/// or the equivalent environment variables. The base URL host must be in the
/// allowlist (127.0.0.1, localhost, plus Info.plist `MLAllowedFixtureHosts`).
/// The app never receives the fixture admin secret.
public struct FixtureConfig: Sendable, Equatable {
    public static let baseURLKey = "MLFixtureBaseURL"
    public static let tokenKey = "MLFixtureToken"
    public static let runIDKey = "MLRunId"
    public static let infoPlistAllowedHostsKey = "MLAllowedFixtureHosts"
    public static let builtInAllowedHosts: Set<String> = ["127.0.0.1", "localhost"]

    public let baseURL: URL
    public let token: String
    /// Lowercase UUID string.
    public let runID: String

    public init(baseURL: URL, token: String, runID: String) {
        self.baseURL = baseURL
        self.token = token
        self.runID = runID
    }

    /// Parse and validate configuration. Launch arguments take precedence
    /// over environment variables.
    public static func load(
        arguments: [String],
        environment: [String: String],
        extraAllowedHosts: [String]
    ) -> Result<FixtureConfig, FixtureConfigError> {
        let values = argumentValues(arguments)
        func value(_ key: String) -> String? {
            let raw = values[key] ?? environment[key]
            guard let trimmed = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !trimmed.isEmpty else {
                return nil
            }
            return trimmed
        }

        guard let rawURL = value(baseURLKey) else { return .failure(.missing(baseURLKey)) }
        guard let token = value(tokenKey) else { return .failure(.missing(tokenKey)) }
        guard let rawRunID = value(runIDKey) else { return .failure(.missing(runIDKey)) }

        guard let components = URLComponents(string: rawURL),
              let scheme = components.scheme?.lowercased(), scheme == "http" || scheme == "https",
              let host = components.host?.lowercased(), !host.isEmpty,
              components.user == nil, components.password == nil,
              components.query == nil, components.fragment == nil,
              let url = components.url
        else {
            return .failure(.invalidBaseURL(rawURL))
        }
        let allowed = builtInAllowedHosts.union(
            extraAllowedHosts.map { $0.trimmingCharacters(in: .whitespaces).lowercased() }.filter { !$0.isEmpty })
        guard allowed.contains(host) else {
            return .failure(.hostNotAllowed(host))
        }
        guard let runUUID = UUID(uuidString: rawRunID) else {
            return .failure(.invalidRunID(rawRunID))
        }
        return .success(FixtureConfig(baseURL: url, token: token, runID: runUUID.uuidString.lowercased()))
    }

    /// Collect `-Key value` pairs (the NSArgumentDomain convention used by
    /// Appium `processArguments`).
    static func argumentValues(_ arguments: [String]) -> [String: String] {
        var result: [String: String] = [:]
        let keys: Set<String> = [baseURLKey, tokenKey, runIDKey]
        var index = 0
        while index < arguments.count {
            let arg = arguments[index]
            if arg.hasPrefix("-"), keys.contains(String(arg.dropFirst())), index + 1 < arguments.count {
                result[String(arg.dropFirst())] = arguments[index + 1]
                index += 2
            } else {
                index += 1
            }
        }
        return result
    }
}

public enum FixtureConfigError: Error, Sendable, Equatable, CustomStringConvertible {
    case missing(String)
    case invalidBaseURL(String)
    case hostNotAllowed(String)
    case invalidRunID(String)

    public var description: String {
        switch self {
        case .missing(let key): "Configuration error: missing \(key) launch argument."
        case .invalidBaseURL: "Configuration error: fixture base URL is not a plain http(s) URL."
        case .hostNotAllowed(let host): "Configuration error: fixture host \(host) is not allowlisted. Sending is disabled."
        case .invalidRunID: "Configuration error: MLRunId is not a UUID."
        }
    }
}

import Foundation

/// Where per-run state lives. Default: Application Support/LabMessenger/runs/<run_id>.
/// Tests inject a temporary directory.
public enum LabMessengerStorage {
    public static func runDirectory(runID: String, root: URL? = nil) throws -> URL {
        let base: URL
        if let root {
            base = root
        } else {
            base = try FileManager.default.url(
                for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true
            ).appendingPathComponent("LabMessenger", isDirectory: true)
        }
        let directory = base.appendingPathComponent("runs", isDirectory: true)
            .appendingPathComponent(runID, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }
}

/// Small atomic JSON file persistence.
struct JSONFile<Value: Codable> {
    let url: URL

    func load() throws -> Value? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        let data = try Data(contentsOf: url)
        return try FixtureJSON.decoder().decode(Value.self, from: data)
    }

    func save(_ value: Value) throws {
        let data = try FixtureJSON.encoder().encode(value)
        try data.write(to: url, options: [.atomic])
    }
}

/// A composer draft. `clientMessageID` is minted when the draft is created,
/// before Send, and persisted so it is stable across app restarts.
public struct Draft: Codable, Sendable, Equatable {
    public var clientMessageID: String
    public var runID: String
    public var conversationID: String
    /// Client-side sequence number sent with the message (stable across retries).
    public var sequence: Int
    public var body: String
    public var createdAt: Date

    enum CodingKeys: String, CodingKey {
        case clientMessageID = "client_message_id"
        case runID = "run_id"
        case conversationID = "conversation_id"
        case sequence
        case body
        case createdAt = "created_at"
    }
}

/// File-backed store of one draft per conversation for a single run.
public final class DraftStore {
    struct State: Codable {
        var nextSequence: Int
        var drafts: [String: Draft]

        enum CodingKeys: String, CodingKey {
            case nextSequence = "next_sequence"
            case drafts
        }
    }

    public let runID: String
    private let file: JSONFile<State>
    private let now: () -> Date
    private var state: State

    public init(directory: URL, runID: String, now: @escaping () -> Date = Date.init) throws {
        self.runID = runID
        self.file = JSONFile(url: directory.appendingPathComponent("drafts.json"))
        self.now = now
        self.state = try file.load() ?? State(nextSequence: 1, drafts: [:])
    }

    /// The current draft for a conversation, creating (and persisting) one with
    /// a fresh client_message_id if none exists.
    public func draft(for conversationID: String) throws -> Draft {
        if let existing = state.drafts[conversationID] { return existing }
        return try mint(for: conversationID, body: "")
    }

    @discardableResult
    public func updateBody(_ body: String, conversationID: String) throws -> Draft {
        var draft = try draft(for: conversationID)
        guard draft.body != body else { return draft }
        draft.body = body
        state.drafts[conversationID] = draft
        try file.save(state)
        return draft
    }

    /// Called once the current draft has been handed to the outbox: the old
    /// identity is retired and a new draft with a new client_message_id begins.
    @discardableResult
    public func replaceAfterSend(conversationID: String) throws -> Draft {
        try mint(for: conversationID, body: "")
    }

    private func mint(for conversationID: String, body: String) throws -> Draft {
        let draft = Draft(
            clientMessageID: newLowercaseUUID(),
            runID: runID,
            conversationID: conversationID,
            sequence: state.nextSequence,
            body: body,
            createdAt: now()
        )
        state.nextSequence += 1
        state.drafts[conversationID] = draft
        try file.save(state)
        return draft
    }
}

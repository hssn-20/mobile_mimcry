import Foundation

/// Failure of a non-send API call (listing conversations / messages).
public enum FixtureAPIError: Error, Sendable, Equatable, CustomStringConvertible {
    case transport(TransportError)
    case http(status: Int, code: String?)
    case decoding(String)

    public var description: String {
        switch self {
        case .transport(.timeout): "Fixture server timed out."
        case .transport(.unreachable): "Fixture server unreachable."
        case .transport(.connectionLost): "Connection to fixture server lost."
        case .transport(.notSent(let detail)): "Request not sent: \(detail)."
        case .transport(.other(let detail)): "Network error: \(detail)"
        case .http(let status, let code): "Fixture server error \(status)\(code.map { " \($0)" } ?? "")."
        case .decoding: "Malformed fixture server response."
        }
    }
}

/// Classified outcome of a single `POST /fixture/v1/messages` attempt.
public enum SendAttemptResult: Sendable, Equatable {
    /// 201 (first accept) or 200 (duplicate, original receipt returned).
    case accepted(Receipt, duplicate: Bool)
    /// Retry with the SAME client_message_id. `mayHaveReachedServer` is false
    /// only when the request provably never left the device / reached the host.
    case retryable(reason: String, mayHaveReachedServer: Bool)
    /// 409 CLIENT_MESSAGE_ID_CONFLICT: same identity, different payload.
    case conflict
    /// Any other 4xx: never retried.
    case rejected(status: Int, code: String?)
    /// The request was blocked on the device (ATS, TLS, bad URL) and never
    /// reached the server: never retried, final state `failed`.
    case notSent(reason: String)
}

public struct FixtureAPIClient: Sendable {
    public let transport: any FixtureTransport

    public init(transport: any FixtureTransport) {
        self.transport = transport
    }

    public func listConversations() async throws(FixtureAPIError) -> [Conversation] {
        let response = try await get("/fixture/v1/conversations", query: [])
        return try decode(ConversationsResponse.self, response).conversations
    }

    /// Fetch the whole conversation (following `next_cursor`). A full refetch
    /// is used on each poll because statuses of already-seen messages change
    /// (accepted -> delivered) and the sender role cannot read receipts.
    public func listAllMessages(conversationID: String, pageLimit: Int = 100, maxPages: Int = 50) async throws(FixtureAPIError) -> [Message] {
        var all: [Message] = []
        var cursor: String?
        for _ in 0..<maxPages {
            var query = [URLQueryItem(name: "limit", value: String(pageLimit))]
            if let cursor { query.append(URLQueryItem(name: "after", value: cursor)) }
            let encodedID = conversationID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? conversationID
            let response = try await get("/fixture/v1/conversations/\(encodedID)/messages", query: query)
            let page = try decode(MessagesPage.self, response)
            all.append(contentsOf: page.messages)
            guard let next = page.nextCursor, next != cursor, !page.messages.isEmpty else { break }
            cursor = next
        }
        return all.sorted { $0.sequence < $1.sequence }
    }

    public func postMessage(_ request: SendMessageRequest) async -> SendAttemptResult {
        let body: Data
        do {
            body = try FixtureJSON.encoder().encode(request)
        } catch {
            return .rejected(status: 0, code: "CLIENT_ENCODING_FAILED")
        }
        let response: HTTPResponseData
        do {
            response = try await transport.perform(method: "POST", path: "/fixture/v1/messages", query: [], body: body)
        } catch {
            switch error {
            case .unreachable: return .retryable(reason: "unreachable", mayHaveReachedServer: false)
            case .notSent(let detail): return .notSent(reason: detail)
            case .timeout: return .retryable(reason: "timeout", mayHaveReachedServer: true)
            case .connectionLost: return .retryable(reason: "connection lost", mayHaveReachedServer: true)
            case .other(let detail): return .retryable(reason: detail, mayHaveReachedServer: true)
            }
        }
        switch response.statusCode {
        case 200, 201:
            guard let receipt = try? FixtureJSON.decoder().decode(Receipt.self, from: response.body),
                  receipt.clientMessageID.lowercased() == request.clientMessageID.lowercased()
            else {
                // The server may have stored it; retrying the same id is safe.
                return .retryable(reason: "malformed receipt", mayHaveReachedServer: true)
            }
            let duplicate = response.statusCode == 200 || response.headers["fixture-duplicate"]?.lowercased() == "true"
            return .accepted(receipt, duplicate: duplicate)
        case 409:
            return .conflict
        case 400..<500:
            return .rejected(status: response.statusCode, code: errorCode(response.body))
        case 500..<600:
            return .retryable(reason: "HTTP \(response.statusCode)", mayHaveReachedServer: true)
        default:
            return .retryable(reason: "unexpected HTTP \(response.statusCode)", mayHaveReachedServer: true)
        }
    }

    private func get(_ path: String, query: [URLQueryItem]) async throws(FixtureAPIError) -> HTTPResponseData {
        let response: HTTPResponseData
        do {
            response = try await transport.perform(method: "GET", path: path, query: query, body: nil)
        } catch {
            throw .transport(error)
        }
        guard (200..<300).contains(response.statusCode) else {
            throw .http(status: response.statusCode, code: errorCode(response.body))
        }
        return response
    }

    private func decode<T: Decodable>(_ type: T.Type, _ response: HTTPResponseData) throws(FixtureAPIError) -> T {
        do {
            return try FixtureJSON.decoder().decode(type, from: response.body)
        } catch {
            throw .decoding(String(describing: error))
        }
    }

    private func errorCode(_ body: Data) -> String? {
        (try? JSONDecoder().decode(FixtureErrorBody.self, from: body))?.error
    }
}

import LabMessengerCore
import SwiftUI

struct ConversationListView: View {
    @Bindable var viewModel: MessengerViewModel

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ErrorBanner(message: viewModel.errorMessage)
                List(viewModel.conversations) { conversation in
                    NavigationLink(value: conversation.conversationID) {
                        Text(conversation.title)
                    }
                    .accessibilityIdentifier("conversation.row.\(conversation.conversationID)")
                    .accessibilityLabel(conversation.title)
                }
                .accessibilityIdentifier("conversation.list")
                Text("Synthetic test fixture. Not a real messaging service.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .padding(6)
            }
            .navigationTitle("Lab Messenger (fixture)")
            .navigationDestination(for: String.self) { conversationID in
                MessageView(viewModel: viewModel, conversationID: conversationID)
            }
        }
    }
}

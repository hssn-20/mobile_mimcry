import LabMessengerCore
import SwiftUI

struct MessageView: View {
    @Bindable var viewModel: MessengerViewModel
    let conversationID: String

    private var title: String {
        viewModel.conversations.first { $0.conversationID == conversationID }?.title ?? conversationID
    }

    var body: some View {
        VStack(spacing: 0) {
            ErrorBanner(message: viewModel.errorMessage)
            Text(title)
                .font(.headline)
                .padding(8)
                .accessibilityIdentifier("conversation.title")
                .accessibilityAddTraits(.isHeader)
            ScrollViewReader { proxy in
                List(viewModel.rows) { row in
                    MessageRowView(row: row, peerName: title)
                        .id(row.id)
                }
                .listStyle(.plain)
                .accessibilityIdentifier("message.list")
                .onChange(of: viewModel.rows.last?.id) { _, last in
                    if let last { proxy.scrollTo(last, anchor: .bottom) }
                }
            }
            Divider()
            Composer(viewModel: viewModel)
        }
        .navigationTitle("Lab Messenger (fixture)")
        #if os(iOS)
        .navigationBarTitleDisplayMode(.inline)
        #endif
        .task(id: conversationID) {
            // Foreground polling (~2 s). SwiftUI cancels this task when the
            // view disappears.
            await viewModel.open(conversationID: conversationID)
            await viewModel.runForegroundPolling()
        }
    }
}

/// Plain, deliberately un-styled row: not a look-alike of any real messenger.
struct MessageRowView: View {
    let row: MessageRow
    let peerName: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(row.direction == .outbound ? "You (test sender)" : peerName)
                .font(.caption)
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)
            Text(row.body)
                .accessibilityIdentifier("message.row.\(row.id)")
                .accessibilityLabel(row.body)
            if let status = row.status {
                Text("Status: \(status.rawValue)")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .accessibilityIdentifier("message.status.\(row.id)")
                    .accessibilityLabel("Status")
                    .accessibilityValue(status.rawValue)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

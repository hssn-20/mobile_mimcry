import LabMessengerCore
import SwiftUI

struct Composer: View {
    @Bindable var viewModel: MessengerViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                TextField("Message", text: $viewModel.composerText)
                    .textFieldStyle(.roundedBorder)
                    .accessibilityIdentifier("composer.text")
                Button("Send") {
                    Task { await viewModel.send() }
                }
                .disabled(!viewModel.canSend)
                .accessibilityIdentifier("composer.send")
            }
            // Deliberately artificial test-correlation metadata: the draft's
            // client_message_id, minted before Send. Third-party apps do not
            // expose anything like this.
            Text("Draft id: \(viewModel.draftID ?? "none")")
                .font(.system(size: 9, design: .monospaced))
                .foregroundStyle(.secondary)
                .accessibilityIdentifier("composer.draft_id")
                .accessibilityLabel("Draft id")
                .accessibilityValue(viewModel.draftID ?? "")
        }
        .padding(8)
    }
}

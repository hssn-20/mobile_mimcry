import LabMessengerCore
import SwiftUI

/// Lab Messenger (fixture): a synthetic, project-owned test app. It talks only
/// to the mobilelab fixture server configured via launch arguments. There is
/// deliberately NO URL scheme, deep link or debug endpoint: the only way to
/// send is the Composer's Send button.
@main
struct LabMessengerApp: App {
    @State private var viewModel: MessengerViewModel = LabMessengerApp.makeViewModel()

    var body: some Scene {
        WindowGroup {
            ConversationListView(viewModel: viewModel)
                .task { await viewModel.start() }
        }
    }

    @MainActor
    private static func makeViewModel() -> MessengerViewModel {
        let process = ProcessInfo.processInfo
        let plistHosts = Bundle.main.object(forInfoDictionaryKey: FixtureConfig.infoPlistAllowedHostsKey) as? [String] ?? []
        let result = FixtureConfig.load(
            arguments: process.arguments,
            environment: process.environment,
            extraAllowedHosts: plistHosts
        )
        return MessengerViewModel(configResult: result) { config in
            URLSessionTransport(baseURL: config.baseURL, token: config.token)
        }
    }
}

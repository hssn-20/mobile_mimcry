import SwiftUI

/// Visible error text (`app.error`): config errors, send failures (409, 4xx,
/// unknown outcome) and sync errors.
struct ErrorBanner: View {
    let message: String?

    var body: some View {
        if let message {
            Text(message)
                .font(.footnote)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(10)
                .background(Color.red.opacity(0.85))
                .accessibilityIdentifier("app.error")
                .accessibilityLabel(message)
        }
    }
}

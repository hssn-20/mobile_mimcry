import Foundation
import Testing
@testable import LabMessengerCore

@MainActor
@Suite("MessengerViewModel (mock transport)")
struct ViewModelTests {
    let messagesPath = "/fixture/v1/conversations/\(Samples.conversationID)/messages"

    func makeTransport(posts: [ScriptedReply] = []) -> MockTransport {
        let transport = MockTransport(posts: posts, gets: ["/fixture/v1/conversations": .http(200, Samples.conversationsJSON)])
        transport.setGet(messagesPath, .http(200, Samples.page([
            Samples.messageJSON(clientMessageID: Samples.peerClientMessageID, sequence: 1,
                                body: "Did you get a chance to read the article?", senderID: Samples.receiverID),
        ])))
        return transport
    }

    func makeViewModel(root: URL, transport: MockTransport, policy: RetryPolicy = RetryPolicy()) -> MessengerViewModel {
        MessengerViewModel(configResult: .success(Samples.config()), storageRoot: root,
                           makeTransport: { _ in transport }, retryPolicy: policy, sleep: noSleep)
    }

    @Test func loadsConversationsAndShowsInboundPeerMessage() async throws {
        let vm = makeViewModel(root: try temporaryDirectory(), transport: makeTransport())
        await vm.start()
        #expect(vm.conversations.map(\.conversationID) == [Samples.conversationID])
        await vm.open(conversationID: Samples.conversationID)
        #expect(vm.selectedConversation?.title == "Alex (test peer)")
        #expect(vm.rows == [MessageRow(id: Samples.peerClientMessageID, body: "Did you get a chance to read the article?",
                                       direction: .inbound, status: nil)])
        #expect(vm.errorMessage == nil)
    }

    @Test func draftIDStableBeforeSendAndAcrossRestartThenNewAfterSend() async throws {
        let root = try temporaryDirectory()
        let vm = makeViewModel(root: root, transport: makeTransport())
        await vm.open(conversationID: Samples.conversationID)
        let draftID = try #require(vm.draftID)
        #expect(!vm.canSend)  // empty composer
        vm.composerText = "I have finished reading the article."
        #expect(vm.draftID == draftID)
        #expect(vm.canSend)

        // Simulated app restart: new view model over the same storage.
        let transport = makeTransport()
        let restarted = makeViewModel(root: root, transport: transport)
        await restarted.open(conversationID: Samples.conversationID)
        #expect(restarted.draftID == draftID)
        #expect(restarted.composerText == "I have finished reading the article.")

        await restarted.send()
        let sent = transport.posts.compactMap(\.sendRequest)
        #expect(sent.map(\.clientMessageID) == [draftID])
        #expect(sent.first?.runID == Samples.runID)
        #expect(restarted.rows.last == MessageRow(id: draftID, body: "I have finished reading the article.",
                                                  direction: .outbound, status: .accepted))
        let newDraftID = try #require(restarted.draftID)
        #expect(newDraftID != draftID)
        #expect(restarted.composerText.isEmpty)
        #expect(!restarted.canSend)
    }

    @Test func conflictShowsVisibleErrorAndFailedStatus() async throws {
        let transport = makeTransport(posts: [.http(409, "{\"error\":\"CLIENT_MESSAGE_ID_CONFLICT\"}")])
        let vm = makeViewModel(root: try temporaryDirectory(), transport: transport)
        await vm.open(conversationID: Samples.conversationID)
        let draftID = try #require(vm.draftID)
        vm.composerText = "hello"
        await vm.send()
        #expect(vm.errorMessage?.contains("409") == true)
        #expect(vm.rows.first { $0.id == draftID }?.status == .failed)
        #expect(transport.posts.count == 1)
    }

    @Test func pollUpdatesStatusToDelivered() async throws {
        let transport = makeTransport()
        let vm = makeViewModel(root: try temporaryDirectory(), transport: transport)
        await vm.open(conversationID: Samples.conversationID)
        let draftID = try #require(vm.draftID)
        vm.composerText = "hi"
        await vm.send()
        #expect(vm.rows.first { $0.id == draftID }?.status == .accepted)

        transport.setGet(messagesPath, .http(200, Samples.page([
            Samples.messageJSON(clientMessageID: Samples.peerClientMessageID, sequence: 1, body: "peer", senderID: Samples.receiverID),
            Samples.messageJSON(clientMessageID: draftID, sequence: 2, body: "hi", senderID: Samples.senderID,
                                status: "delivered", delivered: "2026-10-03T12:00:02Z"),
        ])))
        await vm.pollOnce()
        #expect(vm.rows.map(\.id) == [Samples.peerClientMessageID, draftID])
        #expect(vm.rows.last?.status == .delivered)
    }

    @Test func pollFollowsCursorPagination() async throws {
        let transport = makeTransport()
        transport.setGet(messagesPath, .http(200, Samples.page([
            Samples.messageJSON(clientMessageID: Samples.peerClientMessageID, sequence: 1, body: "peer", senderID: Samples.receiverID),
        ], next: "c1")))
        let client = FixtureAPIClient(transport: transport)
        // Second page uses the same path; mock returns the same page, so the
        // client must stop when the cursor does not advance.
        let messages = try await client.listAllMessages(conversationID: Samples.conversationID)
        #expect(messages.count == 2)
        #expect(transport.requests.last?.query.contains(URLQueryItem(name: "after", value: "c1")) == true)
    }

    @Test func configErrorIsVisibleAndSendingRefused() async throws {
        let transport = makeTransport()
        let result = FixtureConfig.load(
            arguments: ["-MLFixtureBaseURL", "https://evil.example", "-MLFixtureToken", "t", "-MLRunId", Samples.runID],
            environment: [:], extraAllowedHosts: [])
        let vm = MessengerViewModel(configResult: result, storageRoot: try temporaryDirectory(),
                                    makeTransport: { _ in transport }, sleep: noSleep)
        await vm.start()
        await vm.open(conversationID: Samples.conversationID)
        vm.composerText = "hello"
        #expect(!vm.canSend)
        await vm.send()
        #expect(vm.errorMessage?.contains("not allowlisted") == true)
        #expect(transport.requests.isEmpty)
    }

    @Test func interruptedSendIsResumedOnStartWithSameID() async throws {
        let root = try temporaryDirectory()
        let directory = try LabMessengerStorage.runDirectory(runID: Samples.runID, root: root)
        let draft = Draft(clientMessageID: newLowercaseUUID(), runID: Samples.runID, conversationID: Samples.conversationID,
                          sequence: 1, body: "queued", createdAt: Date())
        let seed = try Outbox(directory: directory, client: FixtureAPIClient(transport: MockTransport()), sleep: noSleep)
        try seed.enqueue(draft)

        let transport = makeTransport()
        let vm = makeViewModel(root: root, transport: transport)
        await vm.start()
        #expect(transport.posts.compactMap(\.sendRequest?.clientMessageID) == [draft.clientMessageID])
    }

    @Test func unknownSendErrorClearsOnceAPollShowsTheMessage() async throws {
        let transport = makeTransport(posts: [.fail(.timeout), .fail(.timeout), .fail(.timeout)])
        let vm = makeViewModel(root: try temporaryDirectory(), transport: transport)
        await vm.open(conversationID: Samples.conversationID)
        let draftID = try #require(vm.draftID)
        vm.composerText = "hi"
        await vm.send()
        #expect(vm.rows.last?.status == .unknown)
        #expect(vm.errorMessage?.contains("unknown") == true)

        // Server actually stored it (e.g. accepted_response_dropped); a poll shows it.
        transport.setGet(messagesPath, .http(200, Samples.page([
            Samples.messageJSON(clientMessageID: Samples.peerClientMessageID, sequence: 1, body: "peer", senderID: Samples.receiverID),
            Samples.messageJSON(clientMessageID: draftID, sequence: 2, body: "hi", senderID: Samples.senderID),
        ])))
        await vm.pollOnce()
        #expect(vm.rows.last == MessageRow(id: draftID, body: "hi", direction: .outbound, status: .accepted))
        #expect(vm.errorMessage == nil)
    }

    @Test func unresolvedSendErrorSurvivesUnrelatedPoll() async throws {
        let transport = makeTransport(posts: [.http(409, "{\"error\":\"CLIENT_MESSAGE_ID_CONFLICT\"}")])
        let vm = makeViewModel(root: try temporaryDirectory(), transport: transport)
        await vm.open(conversationID: Samples.conversationID)
        vm.composerText = "hello"
        await vm.send()
        await vm.pollOnce()
        #expect(vm.errorMessage?.contains("409") == true)
    }

    @Test func startLoadsConversationsBeforeResumingInterruptedSends() async throws {
        let root = try temporaryDirectory()
        let directory = try LabMessengerStorage.runDirectory(runID: Samples.runID, root: root)
        let draft = Draft(clientMessageID: newLowercaseUUID(), runID: Samples.runID, conversationID: Samples.conversationID,
                          sequence: 1, body: "queued", createdAt: Date())
        let seed = try Outbox(directory: directory, client: FixtureAPIClient(transport: MockTransport()), sleep: noSleep)
        try seed.enqueue(draft)

        let transport = makeTransport(posts: [.fail(.timeout), .fail(.timeout), .fail(.timeout)])
        let vm = makeViewModel(root: root, transport: transport)
        await vm.start()
        #expect(transport.requests.first?.path == "/fixture/v1/conversations")
        #expect(transport.posts.count == 3)
        #expect(vm.conversations.map(\.conversationID) == [Samples.conversationID])
    }

    @Test func crashBetweenEnqueueAndDraftRotationMintsFreshDraft() async throws {
        let root = try temporaryDirectory()
        let directory = try LabMessengerStorage.runDirectory(runID: Samples.runID, root: root)
        // State left by a crash: drafts.json still holds the id already in outbox.json.
        let store = try DraftStore(directory: directory, runID: Samples.runID)
        let stale = try store.updateBody("already sent", conversationID: Samples.conversationID)
        let seed = try Outbox(directory: directory, client: FixtureAPIClient(transport: MockTransport()), sleep: noSleep)
        try seed.enqueue(stale)

        let transport = makeTransport()
        let vm = makeViewModel(root: root, transport: transport)
        await vm.start()
        await vm.open(conversationID: Samples.conversationID)
        let fresh = try #require(vm.draftID)
        #expect(fresh != stale.clientMessageID)
        #expect(vm.composerText.isEmpty)

        vm.composerText = "new text"
        await vm.send()
        let sentIDs = transport.posts.compactMap(\.sendRequest?.clientMessageID)
        #expect(sentIDs == [stale.clientMessageID, fresh])
        #expect(transport.posts.last?.sendRequest?.body == "new text")
        #expect(vm.errorMessage == nil)
    }

    @Test func bodyLimitCountsUnicodeScalarsLikeTheServer() async throws {
        let vm = makeViewModel(root: try temporaryDirectory(), transport: makeTransport())
        await vm.open(conversationID: Samples.conversationID)
        let flag = "\u{1F1EC}\u{1F1E7}"  // one grapheme, two scalars
        vm.composerText = String(repeating: flag, count: 1000)
        #expect(vm.canSend)  // 2000 scalars
        vm.composerText = String(repeating: flag, count: 1001)
        #expect(vm.composerText.count == 1001)
        #expect(!vm.canSend)  // 2002 scalars: server would 422
    }
}

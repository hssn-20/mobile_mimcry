import Foundation
@testable import LabMessengerCore

// Test doubles. These are MOCK transports (no network, no device): they only
// exercise client logic and are never evidence of Simulator/device behaviour.

enum Samples {
    static let runID = "458de165-ab49-467e-8f19-e80d574e97cb"
    static let conversationID = "fixture-conversation-01"
    static let senderID = "fixture-sender-01"
    static let receiverID = "fixture-receiver-01"

    static func receiptJSON(clientMessageID: String, status: String = "accepted", delivered: String? = nil) -> String {
        """
        {"schema_version":1,"message_id":"0f8fad5b-d9cb-469f-a165-70867728950e","run_id":"\(runID)",
         "conversation_id":"\(conversationID)","client_message_id":"\(clientMessageID)",
         "sender_id":"\(senderID)","server_accepted_at":"2026-10-03T12:00:00.123456Z",
         "receiver_delivered_at":\(delivered.map { "\"\($0)\"" } ?? "null"),"receiver_displayed_at":null,
         "receiver_type":\(delivered == nil ? "null" : "\"scripted_receiver\""),"status":"\(status)",
         "correlation_evidence_ids":[]}
        """
    }

    static func messageJSON(clientMessageID: String, sequence: Int, body: String, senderID: String,
                            status: String = "accepted", delivered: String? = nil) -> String {
        """
        {"message_id":"\(UUID().uuidString.lowercased())","run_id":"\(runID)","conversation_id":"\(conversationID)",
         "client_message_id":"\(clientMessageID)","sender_id":"\(senderID)","sequence":\(sequence),
         "body":"\(body)","server_accepted_at":"2026-10-03T12:00:00Z",
         "receiver_delivered_at":\(delivered.map { "\"\($0)\"" } ?? "null"),"receiver_displayed_at":null,
         "status":"\(status)"}
        """
    }

    static let peerClientMessageID = "6a2f41a3-c54c-4fe3-a1b2-3c4d5e6f7a8b"

    static let conversationsJSON = """
    {"schema_version":1,"conversations":[{"conversation_id":"\(conversationID)","title":"Alex (test peer)",
     "contact_id":"fixture-contact-01","participants":["\(senderID)","\(receiverID)"]}]}
    """

    static func page(_ messages: [String], next: String? = nil) -> String {
        "{\"schema_version\":1,\"messages\":[\(messages.joined(separator: ","))],\"next_cursor\":\(next.map { "\"\($0)\"" } ?? "null")}"
    }

    static func config() -> FixtureConfig {
        FixtureConfig(baseURL: URL(string: "http://127.0.0.1:8781")!, token: "sender-token", runID: runID)
    }
}

struct RecordedRequest: Sendable {
    var method: String
    var path: String
    var query: [URLQueryItem]
    var body: Data?

    var sendRequest: SendMessageRequest? {
        body.flatMap { try? FixtureJSON.decoder().decode(SendMessageRequest.self, from: $0) }
    }
}

enum ScriptedReply: Sendable {
    case http(Int, String, [String: String] = [:])
    case fail(TransportError)
}

/// Mock transport: POST replies are consumed from a queue (falls back to a
/// receipt echoing the request); GET replies come from a closure-free table.
final class MockTransport: FixtureTransport, @unchecked Sendable {
    private let lock = NSLock()
    private var postQueue: [ScriptedReply]
    private var getReplies: [String: ScriptedReply]
    private(set) var requestsStorage: [RecordedRequest] = []

    init(posts: [ScriptedReply] = [], gets: [String: ScriptedReply] = [:]) {
        self.postQueue = posts
        self.getReplies = gets
    }

    var requests: [RecordedRequest] { lock.withLock { requestsStorage } }
    var posts: [RecordedRequest] { requests.filter { $0.method == "POST" } }

    func setGet(_ path: String, _ reply: ScriptedReply) {
        lock.withLock { getReplies[path] = reply }
    }

    func perform(method: String, path: String, query: [URLQueryItem], body: Data?) async throws(TransportError) -> HTTPResponseData {
        let reply: ScriptedReply = lock.withLock {
            requestsStorage.append(RecordedRequest(method: method, path: path, query: query, body: body))
            if method == "POST" {
                if !postQueue.isEmpty { return postQueue.removeFirst() }
                let request = try? FixtureJSON.decoder().decode(SendMessageRequest.self, from: body ?? Data())
                return .http(201, Samples.receiptJSON(clientMessageID: request?.clientMessageID ?? "missing"))
            }
            return getReplies[path] ?? .http(404, "{\"error\":\"NOT_FOUND\"}")
        }
        switch reply {
        case .http(let status, let text, let headers):
            return HTTPResponseData(statusCode: status, headers: headers, body: Data(text.utf8))
        case .fail(let error):
            throw error
        }
    }
}

let noSleep: Sleeper = { _ in }

func temporaryDirectory() throws -> URL {
    let url = FileManager.default.temporaryDirectory
        .appendingPathComponent("LabMessengerCoreTests-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
}

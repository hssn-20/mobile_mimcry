import Foundation
import Testing
@testable import LabMessengerCore

@Suite("Draft store")
struct DraftStoreTests {
    @Test func draftIDIsStableBeforeSendAndAcrossRestart() throws {
        let dir = try temporaryDirectory()
        let store = try DraftStore(directory: dir, runID: Samples.runID)
        let first = try store.draft(for: Samples.conversationID)
        try store.updateBody("Hello", conversationID: Samples.conversationID)
        #expect(try store.draft(for: Samples.conversationID).clientMessageID == first.clientMessageID)

        let restarted = try DraftStore(directory: dir, runID: Samples.runID)
        let reloaded = try restarted.draft(for: Samples.conversationID)
        #expect(reloaded.clientMessageID == first.clientMessageID)
        #expect(reloaded.body == "Hello")
        #expect(reloaded.sequence == first.sequence)
    }

    @Test func replaceAfterSendMintsNewIDAndSequence() throws {
        let store = try DraftStore(directory: try temporaryDirectory(), runID: Samples.runID)
        let first = try store.draft(for: Samples.conversationID)
        let next = try store.replaceAfterSend(conversationID: Samples.conversationID)
        #expect(next.clientMessageID != first.clientMessageID)
        #expect(next.sequence == first.sequence + 1)
        #expect(next.body.isEmpty)
    }
}

@MainActor
@Suite("Outbox retries")
struct OutboxTests {
    func makeDraft(body: String = "I have finished reading the article.") -> Draft {
        Draft(clientMessageID: newLowercaseUUID(), runID: Samples.runID, conversationID: Samples.conversationID,
              sequence: 1, body: body, createdAt: Date())
    }

    @Test func retriesReuseTheSameClientMessageID() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [
            .fail(.timeout),
            .http(503, "{\"error\":\"UNAVAILABLE\"}"),
            .http(201, Samples.receiptJSON(clientMessageID: draft.clientMessageID)),
        ])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport),
                                policy: RetryPolicy(maxAttempts: 3), sleep: noSleep)
        try outbox.enqueue(draft)
        let result = await outbox.deliver(draft.clientMessageID)
        #expect(result?.state == .accepted)
        #expect(result?.displayStatus == .accepted)
        #expect(result?.attempts == 3)
        let sent = transport.posts.compactMap(\.sendRequest)
        #expect(sent.count == 3)
        #expect(Set(sent.map(\.clientMessageID)) == [draft.clientMessageID])
        #expect(Set(sent.map(\.sequence)) == [1])
    }

    @Test func droppedResponseThenDuplicateReturnsOriginalReceipt() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [
            .fail(.connectionLost),
            .http(200, Samples.receiptJSON(clientMessageID: draft.clientMessageID), ["fixture-duplicate": "true"]),
        ])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport), sleep: noSleep)
        try outbox.enqueue(draft)
        #expect(await outbox.deliver(draft.clientMessageID)?.state == .accepted)
        #expect(transport.posts.count == 2)
    }

    @Test func conflictIsTerminalAndNotRetried() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.http(409, "{\"error\":\"CLIENT_MESSAGE_ID_CONFLICT\"}")])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport), sleep: noSleep)
        try outbox.enqueue(draft)
        let result = await outbox.deliver(draft.clientMessageID)
        #expect(result?.state == .conflict)
        #expect(result?.displayStatus == .failed)
        #expect(transport.posts.count == 1)
    }

    @Test func otherClientErrorsAreNotRetried() async throws {
        for status in [401, 403, 422] {
            let draft = makeDraft()
            let transport = MockTransport(posts: [.http(status, "{\"error\":\"TOKEN_INVALID\"}")])
            let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport), sleep: noSleep)
            try outbox.enqueue(draft)
            let result = await outbox.deliver(draft.clientMessageID)
            #expect(result?.state == .failed)
            #expect(transport.posts.count == 1)
        }
    }

    @Test func exhaustedRetriesAfterPossibleReceiptAreUnknownNotFailed() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.fail(.timeout), .fail(.timeout), .fail(.timeout), .http(201, "{}")])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport),
                                policy: RetryPolicy(maxAttempts: 3), sleep: noSleep)
        try outbox.enqueue(draft)
        let result = await outbox.deliver(draft.clientMessageID)
        #expect(result?.state == .unknown)
        #expect(result?.displayStatus == .unknown)
        #expect(transport.posts.count == 3)
    }

    @Test func exhaustedRetriesWhenHostUnreachableAreFailed() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.fail(.unreachable), .fail(.unreachable)])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport),
                                policy: RetryPolicy(maxAttempts: 2), sleep: noSleep)
        try outbox.enqueue(draft)
        #expect(await outbox.deliver(draft.clientMessageID)?.state == .failed)
    }

    @Test func requestBlockedOnDeviceIsFailedWithoutRetry() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.fail(.notSent("blocked by App Transport Security")), .http(201, "{}")])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport),
                                policy: RetryPolicy(maxAttempts: 3), sleep: noSleep)
        try outbox.enqueue(draft)
        let result = await outbox.deliver(draft.clientMessageID)
        #expect(result?.state == .failed)
        #expect(result?.displayStatus == .failed)
        #expect(result?.lastError?.contains("App Transport Security") == true)
        #expect(transport.posts.count == 1)
    }

    @Test func urlErrorsThatNeverLeaveTheDeviceMapToNotSent() {
        let notSent: [URLError.Code] = [
            .appTransportSecurityRequiresSecureConnection, .secureConnectionFailed, .serverCertificateUntrusted,
            .serverCertificateHasBadDate, .serverCertificateHasUnknownRoot, .serverCertificateNotYetValid,
            .clientCertificateRejected, .clientCertificateRequired, .badURL, .unsupportedURL,
        ]
        for code in notSent {
            guard case .notSent = URLSessionTransport.map(URLError(code)) else {
                Issue.record("URLError \(code.rawValue) should map to notSent")
                continue
            }
        }
        #expect(URLSessionTransport.map(URLError(.timedOut)) == .timeout)
        #expect(URLSessionTransport.map(URLError(.cannotConnectToHost)) == .unreachable)
        #expect(URLSessionTransport.map(URLError(.networkConnectionLost)) == .connectionLost)
    }

    @Test func enqueueRejectsReusedIDWithDifferentBody() throws {
        let draft = makeDraft(body: "first")
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: MockTransport()), sleep: noSleep)
        try outbox.enqueue(draft)
        #expect(try outbox.enqueue(draft).body == "first")  // identical payload: idempotent
        var edited = draft
        edited.body = "second"
        #expect(throws: OutboxError.clientMessageIDAlreadyUsed(draft.clientMessageID)) { try outbox.enqueue(edited) }
        #expect(outbox.entries.count == 1)
    }

    @Test func malformedSuccessBodyIsRetriedWithSameID() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.http(201, "{not json"), .http(201, Samples.receiptJSON(clientMessageID: draft.clientMessageID))])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport), sleep: noSleep)
        try outbox.enqueue(draft)
        #expect(await outbox.deliver(draft.clientMessageID)?.state == .accepted)
        #expect(Set(transport.posts.compactMap(\.sendRequest?.clientMessageID)) == [draft.clientMessageID])
    }

    @Test func pendingEntrySurvivesRestartAndResendsSameID() async throws {
        let dir = try temporaryDirectory()
        let draft = makeDraft()
        do {
            let outbox = try Outbox(directory: dir, client: FixtureAPIClient(transport: MockTransport()), sleep: noSleep)
            try outbox.enqueue(draft)  // "crash" before delivery
        }
        let transport = MockTransport()
        let restarted = try Outbox(directory: dir, client: FixtureAPIClient(transport: transport), sleep: noSleep)
        #expect(restarted.interruptedEntryIDs() == [draft.clientMessageID])
        #expect(await restarted.deliver(draft.clientMessageID)?.state == .accepted)
        #expect(transport.posts.compactMap(\.sendRequest?.clientMessageID) == [draft.clientMessageID])
        #expect(transport.posts.first?.sendRequest?.body == draft.body)
    }

    @Test func reconcileResolvesUnknownAndTracksDelivery() async throws {
        let draft = makeDraft()
        let transport = MockTransport(posts: [.fail(.timeout)])
        let outbox = try Outbox(directory: try temporaryDirectory(), client: FixtureAPIClient(transport: transport),
                                policy: RetryPolicy(maxAttempts: 1), sleep: noSleep)
        try outbox.enqueue(draft)
        #expect(await outbox.deliver(draft.clientMessageID)?.state == .unknown)

        let page = try FixtureJSON.decoder().decode(MessagesPage.self, from: Data(Samples.page([
            Samples.messageJSON(clientMessageID: draft.clientMessageID, sequence: 2, body: draft.body,
                                senderID: Samples.senderID, status: "delivered", delivered: "2026-10-03T12:00:02Z"),
        ]).utf8))
        outbox.reconcile(with: page.messages)
        #expect(outbox.entry(draft.clientMessageID)?.displayStatus == .delivered)
    }

    @Test func reconcileIgnoresSameIDWithDifferentBody() async throws {
        let draft = makeDraft()
        let outbox = try Outbox(directory: try temporaryDirectory(),
                                client: FixtureAPIClient(transport: MockTransport(posts: [.fail(.timeout)])),
                                policy: RetryPolicy(maxAttempts: 1), sleep: noSleep)
        try outbox.enqueue(draft)
        await outbox.deliver(draft.clientMessageID)
        let page = try FixtureJSON.decoder().decode(MessagesPage.self, from: Data(Samples.page([
            Samples.messageJSON(clientMessageID: draft.clientMessageID, sequence: 2, body: "other", senderID: Samples.senderID),
        ]).utf8))
        outbox.reconcile(with: page.messages)
        #expect(outbox.entry(draft.clientMessageID)?.state == .unknown)
    }

    @Test func backoffGrowsGeometrically() {
        let policy = RetryPolicy(maxAttempts: 3, initialBackoff: .milliseconds(500), multiplier: 2)
        #expect(policy.backoff(afterAttempt: 1) == .milliseconds(500))
        #expect(policy.backoff(afterAttempt: 2) == .milliseconds(1000))
    }
}

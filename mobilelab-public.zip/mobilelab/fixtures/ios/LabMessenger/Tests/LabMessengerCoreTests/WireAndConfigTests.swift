import Foundation
import Testing
@testable import LabMessengerCore

@Suite("Wire protocol JSON")
struct WireProtocolTests {
    @Test func decodesReceiptWithMicrosecondsAndNulls() throws {
        let id = "359683ab-58fe-491d-a2f1-3c66ba7a8ec4"
        let receipt = try FixtureJSON.decoder().decode(Receipt.self, from: Data(Samples.receiptJSON(clientMessageID: id).utf8))
        #expect(receipt.clientMessageID == id)
        #expect(receipt.status == .accepted)
        #expect(receipt.receiverDeliveredAt == nil)
        #expect(receipt.receiverType == nil)
        #expect(receipt.correlationEvidenceIDs.isEmpty)
        let expected = try #require(FixtureJSON.parseDate("2026-10-03T12:00:00.123Z"))
        #expect(abs(receipt.serverAcceptedAt.timeIntervalSince(expected)) < 0.001)
    }

    @Test func decodesDeliveredReceiptWithOffsetDate() throws {
        let json = Samples.receiptJSON(clientMessageID: "359683ab-58fe-491d-a2f1-3c66ba7a8ec4",
                                       status: "delivered", delivered: "2026-10-03T13:00:01+01:00")
        let receipt = try FixtureJSON.decoder().decode(Receipt.self, from: Data(json.utf8))
        #expect(receipt.status == .delivered)
        #expect(receipt.receiverType == "scripted_receiver")
        #expect(receipt.receiverDeliveredAt == FixtureJSON.parseDate("2026-10-03T12:00:01Z"))
    }

    @Test func decodesMessagesPageAndConversations() throws {
        let page = try FixtureJSON.decoder().decode(MessagesPage.self, from: Data(Samples.page([
            Samples.messageJSON(clientMessageID: Samples.peerClientMessageID, sequence: 1,
                                body: "Did you get a chance to read the article?", senderID: Samples.receiverID),
        ], next: "c1").utf8))
        #expect(page.messages.count == 1)
        #expect(page.messages[0].body == "Did you get a chance to read the article?")
        #expect(page.nextCursor == "c1")

        let conversations = try FixtureJSON.decoder().decode(ConversationsResponse.self, from: Data(Samples.conversationsJSON.utf8))
        #expect(conversations.conversations.first?.title == "Alex (test peer)")
        #expect(conversations.conversations.first?.contactID == "fixture-contact-01")
    }

    @Test func rejectsUnknownStatus() {
        let json = Samples.receiptJSON(clientMessageID: "359683ab-58fe-491d-a2f1-3c66ba7a8ec4", status: "read")
        #expect(throws: DecodingError.self) {
            try FixtureJSON.decoder().decode(Receipt.self, from: Data(json.utf8))
        }
    }

    @Test func encodesSendRequestWithExactlyTheSixWireFields() throws {
        let request = SendMessageRequest(runID: Samples.runID, conversationID: Samples.conversationID,
                                         clientMessageID: "359683ab-58fe-491d-a2f1-3c66ba7a8ec4", sequence: 1,
                                         body: "I have finished reading the article.")
        let object = try JSONSerialization.jsonObject(with: FixtureJSON.encoder().encode(request)) as? [String: Any]
        #expect(Set(object?.keys.map { $0 } ?? []) ==
                ["schema_version", "run_id", "conversation_id", "client_message_id", "sequence", "body"])
        #expect(object?["schema_version"] as? Int == 1)
        #expect(object?["client_message_id"] as? String == "359683ab-58fe-491d-a2f1-3c66ba7a8ec4")
    }

    @Test func generatedIdentifiersAreLowercaseUUIDs() {
        let id = newLowercaseUUID()
        #expect(id == id.lowercased())
        #expect(UUID(uuidString: id) != nil)
    }
}

@Suite("Fixture configuration")
struct FixtureConfigTests {
    let validArgs = ["LabMessenger", "-MLFixtureBaseURL", "http://127.0.0.1:8781", "-MLFixtureToken", "tok",
                     "-MLRunId", "458DE165-AB49-467E-8F19-E80D574E97CB"]

    @Test func acceptsLoopbackFromLaunchArguments() throws {
        let config = try FixtureConfig.load(arguments: validArgs, environment: [:], extraAllowedHosts: []).get()
        #expect(config.baseURL.host == "127.0.0.1")
        #expect(config.token == "tok")
        #expect(config.runID == Samples.runID)
    }

    @Test func rejectsNonAllowlistedHost() {
        var args = validArgs
        args[2] = "https://example.com"
        let result = FixtureConfig.load(arguments: args, environment: [:], extraAllowedHosts: [])
        #expect(result == .failure(.hostNotAllowed("example.com")))
    }

    @Test func acceptsInfoPlistAllowlistedHost() throws {
        var args = validArgs
        args[2] = "http://LabMac.local:8781"
        let config = try FixtureConfig.load(arguments: args, environment: [:], extraAllowedHosts: ["labmac.local"]).get()
        #expect(config.baseURL.host?.lowercased() == "labmac.local")
    }

    @Test func rejectsCredentialsQueryAndNonHTTPSchemes() {
        for url in ["http://user:pw@127.0.0.1:8781", "http://127.0.0.1:8781?x=1", "ftp://127.0.0.1", "file:///tmp"] {
            var args = validArgs
            args[2] = url
            #expect(FixtureConfig.load(arguments: args, environment: [:], extraAllowedHosts: []) == .failure(.invalidBaseURL(url)))
        }
    }

    @Test func requiresTokenAndUUIDRunID() {
        #expect(FixtureConfig.load(arguments: Array(validArgs[0...2]), environment: [:], extraAllowedHosts: [])
                == .failure(.missing("MLFixtureToken")))
        var args = validArgs
        args[6] = "not-a-uuid"
        #expect(FixtureConfig.load(arguments: args, environment: [:], extraAllowedHosts: []) == .failure(.invalidRunID("not-a-uuid")))
    }

    @Test func fallsBackToEnvironment() throws {
        let env = ["MLFixtureBaseURL": "http://localhost:8781", "MLFixtureToken": "t", "MLRunId": Samples.runID]
        let config = try FixtureConfig.load(arguments: ["LabMessenger"], environment: env, extraAllowedHosts: []).get()
        #expect(config.baseURL.host == "localhost")
    }
}

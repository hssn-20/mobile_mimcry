#!/usr/bin/env bash
# Best-effort check available WITHOUT Xcode: build LabMessengerCore and
# typecheck the SwiftUI app sources against the macOS SDK (iOS-only modifiers
# are behind #if os(iOS)). This is NOT an iOS build and proves nothing about
# runtime behaviour on a Simulator.
set -euo pipefail
cd "$(dirname "$0")"
swift build
swiftc -typecheck -swift-version 6 -target arm64-apple-macos14 \
  -sdk "$(xcrun --show-sdk-path)" -I .build/debug/Modules App/*.swift
plutil -lint App/Info.plist
echo "typecheck OK (macOS SDK only; iOS build not performed)"

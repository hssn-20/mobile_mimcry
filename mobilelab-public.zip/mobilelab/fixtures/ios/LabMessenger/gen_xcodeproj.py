#!/usr/bin/env python3
"""Generate LabMessenger.xcodeproj without XcodeGen (stdlib only).

    python3 gen_xcodeproj.py            # writes ./LabMessenger.xcodeproj

Equivalent to project.yml: one iOS application target compiling App/*.swift,
depending on the local Swift package product LabMessengerCore (Package.swift in
this directory), Info.plist App/Info.plist, iOS 17.0, simulator builds
signing-free. Object ids are deterministic so regeneration is stable. The
project is a build artifact (gitignored), never hand-edited.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = "LabMessenger"
BUNDLE_ID = "org.mobilelab.fixtures.LabMessenger"
DEPLOYMENT_TARGET = "17.0"
PACKAGE_PRODUCT = "LabMessengerCore"


def oid(*parts: str) -> str:
    return hashlib.sha256("/".join(parts).encode()).hexdigest()[:24].upper()


def q(value: str) -> str:
    """Quote a pbxproj string when it contains characters outside the bare set."""
    if value and all(c.isalnum() or c in "._/$" for c in value):
        return value
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def render(value: object, indent: int) -> str:
    pad = "\t" * indent
    if isinstance(value, dict):
        lines = ["{"]
        for key, item in value.items():
            lines.append(f"{pad}\t{q(key)} = {render(item, indent + 1)};")
        lines.append(f"{pad}}}")
        return "\n".join(lines)
    if isinstance(value, list):
        lines = ["("]
        for item in value:
            lines.append(f"{pad}\t{render(item, indent + 1)},")
        lines.append(f"{pad})")
        return "\n".join(lines)
    return q(str(value))


def build_objects(swift_files: list[str]) -> tuple[dict[str, dict[str, object]], str]:
    objs: dict[str, dict[str, object]] = {}

    project_id = oid("project")
    main_group = oid("group", "main")
    app_group = oid("group", "App")
    products_group = oid("group", "Products")
    product_ref = oid("product", PROJECT)
    plist_ref = oid("file", "App/Info.plist")
    sources_phase = oid("phase", "sources")
    frameworks_phase = oid("phase", "frameworks")
    resources_phase = oid("phase", "resources")
    target_id = oid("target", PROJECT)
    pkg_ref = oid("package", ".")
    pkg_dep = oid("package-product", PACKAGE_PRODUCT)
    pkg_build_file = oid("buildfile", PACKAGE_PRODUCT)

    file_refs: list[str] = []
    build_files: list[str] = []
    for name in swift_files:
        ref = oid("file", "App", name)
        bf = oid("buildfile", "App", name)
        objs[ref] = {
            "isa": "PBXFileReference",
            "lastKnownFileType": "sourcecode.swift",
            "path": name,
            "sourceTree": "<group>",
        }
        objs[bf] = {"isa": "PBXBuildFile", "fileRef": ref}
        file_refs.append(ref)
        build_files.append(bf)

    objs[plist_ref] = {
        "isa": "PBXFileReference",
        "lastKnownFileType": "text.plist.xml",
        "path": "Info.plist",
        "sourceTree": "<group>",
    }
    objs[product_ref] = {
        "isa": "PBXFileReference",
        "explicitFileType": "wrapper.application",
        "includeInIndex": "0",
        "path": f"{PROJECT}.app",
        "sourceTree": "BUILT_PRODUCTS_DIR",
    }
    objs[pkg_build_file] = {"isa": "PBXBuildFile", "productRef": pkg_dep}

    objs[app_group] = {"isa": "PBXGroup", "children": [*file_refs, plist_ref], "path": "App", "sourceTree": "<group>"}
    objs[products_group] = {"isa": "PBXGroup", "children": [product_ref], "name": "Products", "sourceTree": "<group>"}
    objs[main_group] = {"isa": "PBXGroup", "children": [app_group, products_group], "sourceTree": "<group>"}

    objs[sources_phase] = {
        "isa": "PBXSourcesBuildPhase",
        "buildActionMask": "2147483647",
        "files": build_files,
        "runOnlyForDeploymentPostprocessing": "0",
    }
    objs[frameworks_phase] = {
        "isa": "PBXFrameworksBuildPhase",
        "buildActionMask": "2147483647",
        "files": [pkg_build_file],
        "runOnlyForDeploymentPostprocessing": "0",
    }
    objs[resources_phase] = {
        "isa": "PBXResourcesBuildPhase",
        "buildActionMask": "2147483647",
        "files": [],
        "runOnlyForDeploymentPostprocessing": "0",
    }

    target_settings = {
        "PRODUCT_NAME": PROJECT,
        "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID,
        "INFOPLIST_FILE": "App/Info.plist",
        "GENERATE_INFOPLIST_FILE": "NO",
        "SWIFT_VERSION": "6.0",
        "TARGETED_DEVICE_FAMILY": "1",
        "SDKROOT": "iphoneos",
        "SUPPORTED_PLATFORMS": "iphonesimulator iphoneos",
        "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
        "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
        "CODE_SIGNING_ALLOWED[sdk=iphonesimulator*]": "NO",
        "CODE_SIGNING_REQUIRED[sdk=iphonesimulator*]": "NO",
        "CODE_SIGN_IDENTITY[sdk=iphonesimulator*]": "",
        "CODE_SIGN_STYLE": "Manual",
        "DEVELOPMENT_TEAM": "",
        "ENABLE_PREVIEWS": "NO",
    }
    project_common = {
        "ALWAYS_SEARCH_USER_PATHS": "NO",
        "CLANG_ENABLE_MODULES": "YES",
        "IPHONEOS_DEPLOYMENT_TARGET": DEPLOYMENT_TARGET,
        "SDKROOT": "iphoneos",
        "SWIFT_VERSION": "6.0",
    }
    config_ids: dict[str, list[str]] = {"project": [], "target": []}
    for config in ("Debug", "Release"):
        debug = config == "Debug"
        project_settings = {
            **project_common,
            "ONLY_ACTIVE_ARCH": "YES" if debug else "NO",
            "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if debug else "-O",
            "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG" if debug else "",
            "DEBUG_INFORMATION_FORMAT": "dwarf" if debug else "dwarf-with-dsym",
            "ENABLE_TESTABILITY": "YES" if debug else "NO",
        }
        for scope, settings in (("project", project_settings), ("target", target_settings)):
            cid = oid("config", scope, config)
            objs[cid] = {"isa": "XCBuildConfiguration", "buildSettings": dict(settings), "name": config}
            config_ids[scope].append(cid)
    project_cfg_list = oid("configlist", "project")
    target_cfg_list = oid("configlist", "target")
    for list_id, scope in ((project_cfg_list, "project"), (target_cfg_list, "target")):
        objs[list_id] = {
            "isa": "XCConfigurationList",
            "buildConfigurations": config_ids[scope],
            "defaultConfigurationIsVisible": "0",
            "defaultConfigurationName": "Debug",
        }

    objs[pkg_ref] = {"isa": "XCLocalSwiftPackageReference", "relativePath": "."}
    objs[pkg_dep] = {"isa": "XCSwiftPackageProductDependency", "package": pkg_ref, "productName": PACKAGE_PRODUCT}

    objs[target_id] = {
        "isa": "PBXNativeTarget",
        "buildConfigurationList": target_cfg_list,
        "buildPhases": [sources_phase, frameworks_phase, resources_phase],
        "buildRules": [],
        "dependencies": [],
        "name": PROJECT,
        "packageProductDependencies": [pkg_dep],
        "productName": PROJECT,
        "productReference": product_ref,
        "productType": "com.apple.product-type.application",
    }
    objs[project_id] = {
        "isa": "PBXProject",
        "attributes": {"BuildIndependentTargetsInParallel": "1", "LastUpgradeCheck": "1600"},
        "buildConfigurationList": project_cfg_list,
        "compatibilityVersion": "Xcode 14.0",
        "developmentRegion": "en",
        "hasScannedForEncodings": "0",
        "knownRegions": ["en", "Base"],
        "mainGroup": main_group,
        "packageReferences": [pkg_ref],
        "productRefGroup": products_group,
        "projectDirPath": "",
        "projectRoot": "",
        "targets": [target_id],
    }
    return objs, project_id


def pbxproj(swift_files: list[str]) -> str:
    objs, root = build_objects(swift_files)
    body = render({"archiveVersion": "1", "classes": {}, "objectVersion": "60", "objects": objs, "rootObject": root}, 0)
    return "// !$*UTF8*$!\n" + body + "\n"


def scheme(target_id: str) -> str:
    ref = (
        f'BuildableIdentifier = "primary" BlueprintIdentifier = "{target_id}" '
        f'BuildableName = "{PROJECT}.app" BlueprintName = "{PROJECT}" '
        f'ReferencedContainer = "container:{PROJECT}.xcodeproj"'
    )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion = "1600" version = "1.7">
   <BuildAction parallelizeBuildables = "YES" buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry buildForTesting = "NO" buildForRunning = "YES" buildForProfiling = "NO" buildForArchiving = "YES" buildForAnalyzing = "NO">
            <BuildableReference {ref}>
            </BuildableReference>
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <LaunchAction buildConfiguration = "Debug" launchStyle = "0" useCustomWorkingDirectory = "NO" debugDocumentVersioning = "YES" allowLocationSimulation = "NO">
      <BuildableProductRunnable runnableDebuggingMode = "0">
         <BuildableReference {ref}>
         </BuildableReference>
      </BuildableProductRunnable>
   </LaunchAction>
</Scheme>
"""


def generate(out_dir: Path = HERE) -> Path:
    swift_files = sorted(p.name for p in (HERE / "App").glob("*.swift"))
    if not swift_files:
        raise SystemExit("gen_xcodeproj.py: no App/*.swift sources found")
    proj = out_dir / f"{PROJECT}.xcodeproj"
    schemes = proj / "xcshareddata" / "xcschemes"
    schemes.mkdir(parents=True, exist_ok=True)
    (proj / "project.pbxproj").write_text(pbxproj(swift_files), encoding="utf-8")
    (schemes / f"{PROJECT}.xcscheme").write_text(scheme(oid("target", PROJECT)), encoding="utf-8")
    return proj


if __name__ == "__main__":
    print(generate())

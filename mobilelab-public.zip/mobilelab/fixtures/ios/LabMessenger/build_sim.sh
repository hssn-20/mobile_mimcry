#!/usr/bin/env bash
# Build the Lab Messenger fixture app for one iOS Simulator, signing-free.
#
#   ./build_sim.sh <simulator-udid>
#
# Requires full Xcode (xcodebuild + simctl). Xcode is taken from DEVELOPER_DIR
# when set, else /Applications/Xcode.app if present (xcode-select is never
# changed). Generates ./LabMessenger.xcodeproj (gitignored; SRCROOT == this
# directory so INFOPLIST_FILE=App/Info.plist resolves) with XcodeGen when it is
# on PATH, otherwise with the stdlib-only gen_xcodeproj.py. It
# builds into ./build/DerivedData and prints the .app path
# as the last line of stdout. Nothing outside this directory is modified; no
# signing, no xcode-select changes, no simulator is created or erased.
set -euo pipefail

die() { echo "build_sim.sh: $*" >&2; exit 1; }

[[ $# -eq 1 && -n "$1" ]] || die "usage: $0 <simulator-udid>"
UDID="$1"
HERE="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$HERE/build"
DERIVED="$BUILD_DIR/DerivedData"

if [[ -z "${DEVELOPER_DIR:-}" && -d /Applications/Xcode.app/Contents/Developer ]]; then
  export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi

if ! xcodebuild -version >/dev/null 2>&1; then
  die "full Xcode is required (xcodebuild unavailable; Command Line Tools alone cannot build iOS apps). Install Xcode or set DEVELOPER_DIR; this script never changes xcode-select."
fi
if ! xcrun simctl help >/dev/null 2>&1; then
  die "xcrun simctl is unavailable; full Xcode with an iOS Simulator runtime is required."
fi

if ! xcrun simctl list devices -j | grep -q "\"udid\" : \"$UDID\""; then
  die "simulator $UDID not found (see 'xcrun simctl list devices')."
fi

mkdir -p "$BUILD_DIR"
if command -v xcodegen >/dev/null 2>&1; then
  xcodegen generate --spec "$HERE/project.yml" --project "$HERE" >&2
else
  python3 "$HERE/gen_xcodeproj.py" >&2
fi

xcodebuild \
  -project "$HERE/LabMessenger.xcodeproj" \
  -scheme LabMessenger \
  -configuration Debug \
  -sdk iphonesimulator \
  -destination "id=$UDID" \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO \
  build >&2

APP="$DERIVED/Build/Products/Debug-iphonesimulator/LabMessenger.app"
[[ -d "$APP" ]] || die "build reported success but $APP is missing."
echo "$APP"

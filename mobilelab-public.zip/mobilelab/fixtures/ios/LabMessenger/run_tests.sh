#!/usr/bin/env bash
# Run LabMessengerCore unit tests (swift-testing) with the Command Line Tools
# toolchain. CLT ships Testing.framework outside the default search paths, so
# add them explicitly. With full Xcode, plain `swift test` also works.
set -euo pipefail
cd "$(dirname "$0")"
CLT=/Library/Developer/CommandLineTools/Library/Developer
EXTRA=()
if [[ -d "$CLT/Frameworks/Testing.framework" ]]; then
  EXTRA=(-Xswiftc -F -Xswiftc "$CLT/Frameworks"
         -Xlinker -F -Xlinker "$CLT/Frameworks"
         -Xlinker -rpath -Xlinker "$CLT/Frameworks"
         -Xlinker -rpath -Xlinker "$CLT/usr/lib")
fi
exec swift test ${EXTRA[@]+"${EXTRA[@]}"} "$@"

"""Keeping per-run secrets out of raw environment logs (``build/runs/<run_id>/``).

Two layers:

1. **As written** (Appium): the project-local Appium server gets ``--log-filters`` rules that mask
   the Lab Messenger launch-argument token and any bearer credential before a log line reaches
   ``appium.log``. The rules are *patterns*; the filter file never contains a secret value.
2. **At teardown** (every raw file): known per-run secrets (sender/receiver/oracle tokens, fixture
   admin secret) are replaced in place in every text file of the run's raw directory, and the
   fixture service's ``admin_secret`` file is removed once the service has stopped. This also
   covers ``worker.log``, ``fixture-service.log`` and ``request_log.json``.

``scrub_raw_dir`` returns counts only, never the secrets or their lengths.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

REDACTED = "[REDACTED]"

TOKEN_CHARS = r"[A-Za-z0-9_~.+/=-]"
NOT_MASKED = r"(?!REDACTED)"
APPIUM_LOG_FILTER_RULES: list[dict[str, str]] = [
    # Lab Messenger launch arguments: ["-MLFixtureToken", "<token>"] in capabilities/commands logs,
    # including JSON-escaped forms (\"-MLFixtureToken\",\"<token>\").
    {"pattern": r"(MLFixtureToken[\\\"',:=\s\]\[]{1,16})" + NOT_MASKED + TOKEN_CHARS + "{8,}", "flags": "g", "replacer": "$1" + REDACTED},
    # Any bearer credential.
    {"pattern": r"([Bb]earer\s+)" + NOT_MASKED + TOKEN_CHARS + "{8,}", "flags": "g", "replacer": "$1" + REDACTED},
    # Generic "token": "<value>" / token=<value> pairs.
    {
        "pattern": r"((?:token|secret|api_key|apiKey|authorization)[\\\"']*\s*[:=]\s*[\\\"']*)" + NOT_MASKED + TOKEN_CHARS + "{16,}",
        "flags": "gi",
        "replacer": "$1" + REDACTED,
    },
]
"""Appium ``--log-filters`` rules (JS ``String.replace`` with a RegExp; ``$1`` keeps the prefix)."""

_SKIP_SUFFIXES = (".sqlite", ".sqlite-wal", ".sqlite-shm", ".db", ".png", ".jpg", ".jpeg", ".xcresult")


def write_appium_log_filters(directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "appium-log-filters.json"
    path.write_text(json.dumps(APPIUM_LOG_FILTER_RULES, indent=2), encoding="utf-8")
    return path


def apply_filter_rules(text: str) -> str:
    """Python mirror of the Appium rules (unit tests; also applied again at teardown)."""
    for rule in APPIUM_LOG_FILTER_RULES:
        flags = re.IGNORECASE if "i" in rule["flags"] else 0
        text = re.sub(rule["pattern"], rule["replacer"].replace("$1", r"\1"), text, flags=flags)
    return text


def scrub_raw_dir(directory: Path, secrets: list[str], *, remove_admin_secret: bool = True) -> dict[str, Any]:
    """Replace known secrets (and pattern-matched tokens) in every text file under ``directory``."""
    secrets = [s for s in secrets if s]
    scrubbed: list[str] = []
    removed: list[str] = []
    had_known: list[str] = []
    if not directory.is_dir():
        return {"files_scrubbed": [], "files_removed": [], "files_checked": 0, "files_with_known_secrets_before_scrub": []}
    checked = 0
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = str(path.relative_to(directory))
        if remove_admin_secret and path.name == "admin_secret":
            had_known.append(rel)
            path.unlink()
            removed.append(rel)
            continue
        if path.name.endswith(_SKIP_SUFFIXES):
            continue
        try:
            data = path.read_bytes()
        except OSError:
            continue
        checked += 1
        if any(s.encode() in data for s in secrets):
            had_known.append(rel)
        if b"\x00" in data[:4096]:
            # Binary file: replace exact secret bytes only.
            new = data
            for s in secrets:
                new = new.replace(s.encode(), REDACTED.encode())
        else:
            text = data.decode("utf-8", errors="replace")
            for s in secrets:
                text = text.replace(s, REDACTED)
            text = apply_filter_rules(text)
            new = text.encode("utf-8")
        if new != data:
            tmp = path.with_name(path.name + ".redacting")
            tmp.write_bytes(new)
            os.replace(tmp, path)
            scrubbed.append(rel)
    return {
        "files_scrubbed": scrubbed,
        "files_removed": removed,
        "files_checked": checked,
        "files_with_known_secrets_before_scrub": had_known,
    }


__all__ = [
    "APPIUM_LOG_FILTER_RULES",
    "REDACTED",
    "apply_filter_rules",
    "scrub_raw_dir",
    "write_appium_log_filters",
]

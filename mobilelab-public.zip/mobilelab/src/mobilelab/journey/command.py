"""CLI: ``mobilelab run``, ``mobilelab report`` and ``mobilelab sim`` (registered in mobilelab.cli)."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from uuid import UUID

from mobilelab.journey.plan import VARIANTS
from mobilelab.journey.providers import PROVIDER_NAMES

Subparsers = argparse._SubParsersAction  # noqa: SLF001 - argparse has no public alias


def register(subparsers: Subparsers[argparse.ArgumentParser]) -> None:
    from mobilelab.journey.runner import DEFAULT_ARTIFACTS, DEFAULT_DB

    run = subparsers.add_parser(
        "run",
        help="Run a scenario end to end (fixture service, device worker, decision provider, oracle, report)",
        description="Run browse_then_reply on the project Simulator (default) or the labelled mock adapter.",
    )
    run.add_argument("scenario", choices=["browse_then_reply"])
    run.add_argument("--variant", choices=sorted(VARIANTS), default="default")
    run.add_argument("--adapter", choices=["ios", "mock"], default="ios",
                     help="ios = real project Simulator; mock = scripted fake, never device evidence")
    run.add_argument("--provider", choices=list(PROVIDER_NAMES), default="rules",
                     help="decision provider: rules (default, deterministic baseline); others resolve through "
                          "mobilelab.providers.registry:create_provider")
    run.add_argument("--max-duration-s", type=float, default=None,
                     help="override the scenario's loop duration budget (seconds; recorded in journey.json). "
                          "Model providers add inference latency to every step")
    run.add_argument("--seed", type=int, default=None, help="persona dwell seed (default: scenario seed)")
    run.add_argument("--dwell-mode", choices=["lognormal", "median"], default="lognormal")
    run.add_argument("--db", type=Path, default=DEFAULT_DB)
    run.add_argument("--artifacts", type=Path, default=DEFAULT_ARTIFACTS)
    run.add_argument("--app", type=Path, default=None, help="Lab Messenger .app (Simulator build)")
    run.add_argument("--reopen-gate", action="store_true",
                     help="operator override: reopen a gate closed by an emergency stop/operator and abandon "
                          "earlier unreconciled runs on this device as INCONCLUSIVE (their sends stay UNRESOLVED)")
    run.set_defaults(func=_run)

    report = subparsers.add_parser("report", help="(Re)generate and verify a run's report bundle")
    report.add_argument("run_id", type=UUID)
    report.add_argument("--db", type=Path, default=DEFAULT_DB)
    report.add_argument("--artifacts", type=Path, default=DEFAULT_ARTIFACTS)
    report.add_argument("--verify-only", action="store_true", help="only verify the existing bundle")
    report.set_defaults(func=_report)

    sim = subparsers.add_parser("sim", help="Project Simulator: ensure|boot|install|status|shutdown")
    sim.add_argument("sim_args", nargs=argparse.REMAINDER)
    sim.set_defaults(func=_sim)


def _run(args: argparse.Namespace) -> int:
    from mobilelab.journey.environment import IOSSimulatorEnvironment, MockDeviceEnvironment
    from mobilelab.journey.plan import load_plan
    from mobilelab.journey.providers import ProviderUnavailable, resolve_provider_factory
    from mobilelab.journey.runner import run_journey

    plan = load_plan(args.variant, seed=args.seed, dwell_mode=args.dwell_mode)
    factory = resolve_provider_factory(args.provider)
    if args.provider != "rules":
        try:
            import importlib

            importlib.import_module("mobilelab.providers.registry")
        except ModuleNotFoundError:
            print(f"[mobilelab run] provider {args.provider!r} unavailable: mobilelab.providers.registry is not installed",
                  file=sys.stderr)  # fmt: skip
            return 2
    env = IOSSimulatorEnvironment(app_path=args.app) if args.adapter == "ios" else MockDeviceEnvironment()
    limits = None
    if args.max_duration_s is not None:
        from mobilelab.journey.loop import LoopLimits

        if not 1 <= args.max_duration_s <= 1800:
            print("[mobilelab run] --max-duration-s must be within 1..1800", file=sys.stderr)
            return 2
        limits = LoopLimits(max_steps=plan.scenario.max_steps or 40, max_actions=plan.scenario.max_actions,
                            max_duration_s=args.max_duration_s)  # fmt: skip
    try:
        result = asyncio.run(
            run_journey(
                plan, env, db_path=args.db, artifacts_root=args.artifacts, reopen_gate=args.reopen_gate,
                provider_factory=factory, limits=limits,
                progress=lambda m: print(f"[mobilelab run] {m}", file=sys.stderr, flush=True),
            )
        )  # fmt: skip
    except ProviderUnavailable as exc:
        print(f"[mobilelab run] {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:  # the run was stopped, torn down and reported before this re-raise
        print("[mobilelab run] interrupted; run stopped and report written (see artifacts/runs/)", file=sys.stderr)
        return 130
    print(json.dumps(result.brief(), indent=2, default=str))
    return 0 if result.integrity_ok and result.status == "COMPLETED" else 1


def _report(args: argparse.Namespace) -> int:
    from mobilelab.reporting import default_report_dir, verify_report_integrity, write_report
    from mobilelab.store import Store

    directory = default_report_dir(args.artifacts, args.run_id)
    if not args.verify_only:
        store = Store.open(args.db)
        try:
            directory = write_report(store, args.run_id, args.artifacts).directory
        finally:
            store.close()
    result = verify_report_integrity(directory)
    print(json.dumps({"report_dir": str(directory), "ok": result.ok, "problems": result.problems,
                      "files_checked": result.files_checked}, indent=2))  # fmt: skip
    return 0 if result.ok else 1


def _sim(args: argparse.Namespace) -> int:
    from mobilelab.sim.__main__ import main

    return main(list(args.sim_args))

"""Run environments: the fixture service plus one device environment (real Simulator or mock).

The harness never mutates Lab Messenger state through the fixture API: it only resets the run
namespace and schedules declared faults through the admin listener, and reads receipts/messages.
Messages are created solely by the app (real Simulator: a tap on ``composer.send``).
"""

from __future__ import annotations

import hashlib
import subprocess
from contextlib import ExitStack
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol
from uuid import NAMESPACE_URL, UUID, uuid5

import httpx

from mobilelab.domain.devices import DeviceProfile
from mobilelab.domain.enums import DeviceKind, EvidenceSource, Platform
from mobilelab.fixtures.models import ConversationsResponse, Message, MessagesPage, ResetResponse

APPIUM_VERSION = "3.8.0"
XCUITEST_DRIVER_VERSION = "12.14.0"


@dataclass
class FixtureService:
    """The fixture data/admin service as a subprocess on ephemeral loopback ports (with receiver)."""

    out_dir: Path
    proc: subprocess.Popen[str] | None = None
    admin_url: str = ""
    admin_secret: str = ""
    ready: dict[str, Any] = field(default_factory=dict)

    def start(self) -> None:
        from mobilelab.sim.bringup import _start_service

        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.proc, self.ready = _start_service(self.out_dir / "fixture-state", self.out_dir / "fixture-service.log")
        self.admin_url = str(self.ready["admin_url"])
        self.admin_secret = Path(str(self.ready["admin_secret_file"])).read_text(encoding="utf-8").strip()

    def stop(self) -> int | None:
        from mobilelab.sim.bringup import _stop_service

        if self.proc is None:
            return None
        code = _stop_service(self.proc)
        self.proc = None
        return code


async def list_outbound_messages(reset: ResetResponse, conversation_id: str | None = None) -> list[Message]:
    """Read-only census with the run's sender identity: every message in every conversation of the
    run namespace (or only ``conversation_id``), so a message sent to another thread is counted too."""
    out: list[Message] = []
    async with httpx.AsyncClient(
        base_url=reset.data_base_url, headers={"Authorization": f"Bearer {reset.sender.token}"}, timeout=10.0
    ) as client:
        if conversation_id is None:
            resp = await client.get("/fixture/v1/conversations")
            resp.raise_for_status()
            ids = [c.conversation_id for c in ConversationsResponse.model_validate_json(resp.content).conversations]
        else:
            ids = [conversation_id]
        for conv in ids:
            after: str | None = None
            while True:
                params = {"limit": "100", **({"after": after} if after else {})}
                resp = await client.get(f"/fixture/v1/conversations/{conv}/messages", params=params)
                resp.raise_for_status()
                page = MessagesPage.model_validate_json(resp.content)
                out.extend(page.messages)
                if not page.next_cursor or not page.messages:
                    break
                after = page.next_cursor
    return out


class DeviceEnvironment(Protocol):
    adapter_name: str
    evidence_source: EvidenceSource
    device_kind: DeviceKind
    device_id: UUID

    def setup(self, out_dir: Path) -> None: ...

    def adapter_options(self, *, reset: ResetResponse, origins: list[str], probe_url: str) -> dict[str, Any]: ...

    def profile(self) -> DeviceProfile: ...

    def prepare_apps(self) -> None:
        """Setup between preflight and the run (never UI input through the automation path)."""

    def app_builds(self) -> dict[str, str]: ...

    def adapter_versions(self) -> dict[str, str]: ...

    def teardown(self) -> dict[str, Any]: ...


def FilteredAppiumServer(*, log_filters: Path, **kw: Any) -> Any:  # noqa: N802 - class factory
    """Project-local AppiumServer with ``--log-filters`` (secrets masked as log lines are written)."""
    from mobilelab.adapters.appium_server import AppiumServer

    class _Filtered(AppiumServer):  # type: ignore[misc, valid-type]
        def argv(self) -> list[str]:
            return [*super().argv(), "--log-filters", str(log_filters)]

    return _Filtered(**kw)


def _device_uuid(kind: str, serial: str) -> UUID:
    """Stable public device id derived from the adapter serial (the UDID itself stays adapter-only)."""
    return uuid5(NAMESPACE_URL, f"mobilelab:{kind}:{serial}")


class IOSSimulatorEnvironment:
    """The project-owned Simulator from configs/devices/ios_simulator.json, Appium on loopback."""

    adapter_name = "ios"
    evidence_source = EvidenceSource.DEVICE
    device_kind = DeviceKind.SIMULATOR

    def __init__(self, *, app_path: Path | None = None, record_path: Path | None = None) -> None:
        from mobilelab.sim.lifecycle import DEFAULT_APP_PATH, DEFAULT_RECORD_PATH, load_record
        from mobilelab.sim.simctl import Simctl, SimctlError

        self.app_path = app_path or DEFAULT_APP_PATH
        self.record = load_record(record_path or DEFAULT_RECORD_PATH)
        if self.record is None:
            raise SimctlError("no project Simulator record; run 'mobilelab sim ensure' first")
        self.simctl = Simctl()
        self.device_id = _device_uuid("ios-simulator", self.record.udid)
        self._stack = ExitStack()
        self.server: Any = None
        self.out_dir: Path | None = None

    def setup(self, out_dir: Path) -> None:
        from mobilelab.adapters.appium_server import free_loopback_port
        from mobilelab.journey.redaction import write_appium_log_filters
        from mobilelab.sim.adapter_check import device_lock
        from mobilelab.sim.lifecycle import REPO_ROOT, boot_device

        self.out_dir = out_dir
        self._stack.enter_context(device_lock(self.record.udid))
        boot_device(self.simctl, self.record)
        if not (self.app_path / "Info.plist").is_file():
            raise FileNotFoundError(f"Lab Messenger build not found at {self.app_path}; run build_sim.sh")
        self.simctl.install(self.record.udid, self.app_path)  # same build every run; data container kept
        self.server = FilteredAppiumServer(
            repo_root=REPO_ROOT, port=free_loopback_port(), log_path=out_dir / "appium.log",
            log_filters=write_appium_log_filters(out_dir),
        )  # fmt: skip
        self.server.start()

    def adapter_options(self, *, reset: ResetResponse, origins: list[str], probe_url: str) -> dict[str, Any]:
        from mobilelab.adapters.appium_server import free_loopback_port
        from mobilelab.sim.lifecycle import LAB_MESSENGER_BUNDLE_ID, REPO_ROOT, lab_messenger_launch_args

        return {
            "udid": self.record.udid,
            "device_name": self.record.name,
            "platform_version": self.record.runtime_version,
            "appium_url": self.server.url,
            "repo_root": str(REPO_ROOT),
            "wda_local_port": free_loopback_port(),
            "allowed_url_origins": origins,
            "app_launch_arguments": {
                LAB_MESSENGER_BUNDLE_ID: lab_messenger_launch_args(
                    reset.data_base_url, reset.sender.token, str(reset.run_id)
                )
            },
            "safari_probe_url": probe_url,
        }

    def profile(self) -> DeviceProfile:
        return DeviceProfile(
            device_id=self.device_id,
            platform=Platform.IOS,
            kind=DeviceKind.SIMULATOR,
            name=self.record.name,
            os_version=self.record.runtime_version,
            model=self.record.device_type_name,
            locale=self.record.locale,
            adapter_serial=self.record.udid,
            installed_fixture_builds=self.app_builds(),
            appium_version=APPIUM_VERSION,
            driver_versions={"xcuitest": XCUITEST_DRIVER_VERSION},
        )

    def prepare_apps(self) -> None:
        from mobilelab.sim.lifecycle import LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID

        # Cold start both apps so the journey's open_app applies this run's launch arguments.
        for bundle in (LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID):
            self.simctl.terminate(self.record.udid, bundle)

    def app_builds(self) -> dict[str, str]:
        from mobilelab.sim.lifecycle import LAB_MESSENGER_BUNDLE_ID

        exe = self.app_path / "LabMessenger"
        digest = hashlib.sha256(exe.read_bytes()).hexdigest() if exe.is_file() else "missing"
        return {LAB_MESSENGER_BUNDLE_ID: f"sha256:{digest}", "simulator_runtime": self.record.runtime_identifier}

    def adapter_versions(self) -> dict[str, str]:
        from mobilelab.adapters.ios import IOSXCUITestAdapter

        return {
            "ios": str(getattr(IOSXCUITestAdapter, "adapter_version", "unknown")),
            "appium": APPIUM_VERSION,
            "xcuitest": XCUITEST_DRIVER_VERSION,
        }

    def teardown(self) -> dict[str, Any]:
        from mobilelab.adapters.appium_server import find_wda_processes
        from mobilelab.sim.lifecycle import REPO_ROOT

        info: dict[str, Any] = {}
        try:
            if self.server is not None:
                self.server.stop()
                info["appium_running"] = self.server.running
            derived = (REPO_ROOT / "build" / "wda" / self.record.udid).resolve()  # IOSAdapterConfig default
            info["wda_processes_remaining"] = find_wda_processes(self.record.udid, derived)
            info["simulator_state"] = self.simctl.owned_device(self.record.udid).state
        finally:
            self._stack.close()
        return info


class MockDeviceEnvironment:
    """Scripted MOCK device (``evidence_source=mock``): exercises the harness, never device evidence."""

    adapter_name = "mock"
    evidence_source = EvidenceSource.MOCK
    device_kind = DeviceKind.SIMULATOR

    def __init__(self, *, conversations: dict[str, list[str]] | None = None, transport: bool = True) -> None:
        self.device_id = _device_uuid("mock", "mock-device-01")
        self.conversations = conversations or {"fixture-conversation-01": ["fixture-contact-01", "Alex (test peer)"]}
        self.transport = transport

    def setup(self, out_dir: Path) -> None:
        out_dir.mkdir(parents=True, exist_ok=True)

    def adapter_options(self, *, reset: ResetResponse, origins: list[str], probe_url: str) -> dict[str, Any]:
        opts: dict[str, Any] = {
            "fixture_base_url": reset.data_base_url,
            "foreground_app": "com.apple.springboard",
            "conversations": self.conversations,
        }
        if self.transport:
            opts["app_transport"] = {
                "base_url": reset.data_base_url,
                "token": reset.sender.token,
                "run_id": str(reset.run_id),
            }
        return opts

    def profile(self) -> DeviceProfile:
        return DeviceProfile(
            device_id=self.device_id,
            platform=Platform.IOS,
            kind=DeviceKind.SIMULATOR,
            name="mock-device-01",
            os_version="mock",
            model="MockAdapter (no device)",
        )

    def prepare_apps(self) -> None:
        return None

    def app_builds(self) -> dict[str, str]:
        return {"org.mobilelab.fixtures.LabMessenger": "mock"}

    def adapter_versions(self) -> dict[str, str]:
        from mobilelab.adapters.mock import MOCK_ADAPTER_VERSION

        return {"mock": MOCK_ADAPTER_VERSION}

    def teardown(self) -> dict[str, Any]:
        return {}

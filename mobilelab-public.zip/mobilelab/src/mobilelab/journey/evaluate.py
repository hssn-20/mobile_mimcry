"""Independent outcome evaluation for browse_then_reply (DEMONSTRATOR_SPEC §6 step 9, §11).

* The fixture receipt oracle decides delivery for each executed send, keyed by the
  ``client_message_id`` the coordinator read from ``composer.draft_id`` in the dispatch observation.
  That key is the action's correlation id by construction, so the draft-id and receipt-id equality
  checks are consistency checks, not independent evidence. The independent ties are (a) the census:
  the messages the app actually stored carry exactly the journaled ids, and (b) the app's own UI
  showing ``message.status.<id>`` for that id in an observation captured *after* the send.
* A stored oracle result never claims more than the run can: when the evidence is not from a device
  or the journey did not complete, a PASS/DUT_FAILURE receipt result is stored capped to INCONCLUSIVE
  (``NOT_DEVICE_EVIDENCE`` / ``JOURNEY_INCOMPLETE``) with the raw receipt verdict kept in ``observed``.
* Each potentially executed send is reconciled read-only against the fixture receipt
  (ACKNOWLEDGED/UNKNOWN -> VERIFIED/UNRESOLVED). Nothing is ever resent.
* A census of the sender's stored fixture messages in *every* conversation of the run namespace
  checks there is exactly one message per executed send (no duplicate, no unjournaled message).
* The run verdict is PASS only with device evidence, a completed and verified journey, consistent
  draft identity, a clean census, the sent message shown by the app after the send and a PASS
  receipt oracle (server accepted + scripted receiver delivered for that same client_message_id).
  Everything else is reported, never rounded up.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import select

from mobilelab.candidates.messenger import DRAFT_ID, message_statuses
from mobilelab.domain.base import utc_now
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus, EvidenceCategory, EvidenceSource, Verdict
from mobilelab.domain.observations import Observation
from mobilelab.domain.scenarios import OracleDefinition, OracleResult
from mobilelab.fixtures.models import Message
from mobilelab.oracles import FixtureMessageReceiptOracle, OracleWindow, reconcile_unknown_send
from mobilelab.oracles.polling import ReceiptSource
from mobilelab.oracles.receipt import ORACLE_KIND
from mobilelab.store import Store
from mobilelab.store.models import ObservationRow

EXECUTED_SEND_STATUSES = frozenset({ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED, ActionStatus.UNKNOWN})
MessageCensus = Callable[[], Awaitable[list[Message]]]


@dataclass
class SendCheck:
    action_id: UUID
    status_before: str
    client_message_id: str | None
    draft_id_in_dispatch_observation: str | None
    draft_identity_matches: bool
    oracle_result_id: UUID | None = None
    oracle_verdict: str | None = None
    oracle_reason: str | None = None
    receipt_client_message_id: str | None = None
    server_accepted_at: str | None = None
    receiver_delivered_at: str | None = None
    receiver_type: str | None = None
    receipt_verdict: str | None = None
    """The receipt oracle's own verdict before any evidence cap (``oracle_verdict`` is what was stored)."""
    reconciliation: dict[str, Any] | None = None
    status_after: str | None = None
    ui_statuses_seen: list[str] = field(default_factory=list)
    """``message.status.<id>`` values the app showed in observations captured after the send."""
    post_send_ui_row_seen: bool = False


@dataclass
class Evaluation:
    verdict: Verdict
    reason: str
    obtained_evidence: EvidenceCategory | None
    obtained_evidence_source: EvidenceSource
    sends: list[SendCheck]
    oracle_results: list[OracleResult]
    census: dict[str, Any]

    def as_json(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict.value,
            "reason": self.reason,
            "obtained_evidence": self.obtained_evidence.value if self.obtained_evidence else None,
            "obtained_evidence_source": self.obtained_evidence_source.value,
            "sends": [
                {k: (str(v) if isinstance(v, UUID) else v) for k, v in s.__dict__.items()} for s in self.sends
            ],
            "oracle_result_ids": [str(r.oracle_result_id) for r in self.oracle_results],
            "census": self.census,
        }


def decide_verdict(
    *,
    journey_completed: bool,
    journey_reason: str,
    oracle: OracleResult | None,
    evidence_source: EvidenceSource,
    identity_ok: bool,
    census_ok: bool,
    census_reason: str = "",
    ui_correlated: bool = True,
    journey_stop_class: str | None = None,
) -> tuple[Verdict, str]:
    """Pure verdict rule; see the module docstring. ``oracle`` is the uncapped receipt result.

    Without a send, the journey's stop class keeps provider causes apart from harness faults:
    ``provider_unavailable`` -> ENVIRONMENT_FAILURE (the model API could not be used),
    ``premature_completion`` -> INCONCLUSIVE (the model declared completion before the goal held)."""
    if not census_ok:
        return Verdict.HARNESS_FAILURE, f"fixture message census failed: {census_reason}"
    if not identity_ok:
        return Verdict.HARNESS_FAILURE, "send correlation id does not match composer.draft_id or the receipt"
    if oracle is None:
        if journey_stop_class == "provider_unavailable":
            return Verdict.ENVIRONMENT_FAILURE, f"model provider unavailable; no send was executed; journey: {journey_reason}"
        if journey_stop_class == "premature_completion":
            return Verdict.INCONCLUSIVE, f"model declared completion prematurely; no send was executed; journey: {journey_reason}"
        return Verdict.HARNESS_FAILURE, f"no send was executed; journey: {journey_reason}"
    if oracle.verdict in (Verdict.HARNESS_FAILURE, Verdict.ENVIRONMENT_FAILURE, Verdict.UNSUPPORTED):
        return oracle.verdict, f"receipt oracle {oracle.verdict.value}/{oracle.reason_code}"
    if evidence_source is not EvidenceSource.DEVICE:
        return Verdict.INCONCLUSIVE, (
            f"{evidence_source.value} adapter: not device evidence (receipt oracle {oracle.verdict.value}/"
            f"{oracle.reason_code})"
        )
    if not journey_completed:
        return Verdict.INCONCLUSIVE, (
            f"journey incomplete ({journey_reason}); receipt oracle {oracle.verdict.value}/{oracle.reason_code}"
        )
    if oracle.verdict is Verdict.PASS and not ui_correlated:
        return Verdict.INCONCLUSIVE, "receipt oracle PASS but the app never showed the sent message row after the send"
    if oracle.verdict is Verdict.PASS:
        return Verdict.PASS, "journey completed; receipt oracle PASS (server accepted, scripted receiver delivered)"
    return oracle.verdict, f"journey completed; receipt oracle {oracle.verdict.value}/{oracle.reason_code}"


def _not_executed_result(run_id: UUID, scenario_id: str, definition: OracleDefinition, evidence: list[str]) -> OracleResult:
    now = utc_now()
    return OracleResult(
        oracle_result_id=uuid4(),
        run_id=run_id,
        scenario_id=scenario_id,
        oracle_kind=ORACLE_KIND,
        verdict=Verdict.HARNESS_FAILURE,
        reason_code="SEND_NOT_EXECUTED",
        expected={"required_status": definition.required_status, "timeout_seconds": definition.timeout_seconds},
        observed={"detail": "no send_message action reached the device in this run"},
        evidence_ids=evidence,
        observation_window_start=now,
        observation_window_end=now,
        requirement_refs=["BR-07", "AC-02"],
    )


def cap_oracle_result(result: OracleResult, *, evidence_source: EvidenceSource, journey_completed: bool) -> OracleResult:
    """Store-side cap (see the module docstring): never a PASS/DUT_FAILURE the run cannot claim."""
    if result.verdict not in (Verdict.PASS, Verdict.DUT_FAILURE):
        return result
    device = evidence_source is EvidenceSource.DEVICE
    if device and journey_completed:
        return result
    code = "JOURNEY_INCOMPLETE" if device else "NOT_DEVICE_EVIDENCE"
    observed = {
        **result.observed,
        "uncapped_verdict": result.verdict.value,
        "uncapped_reason_code": result.reason_code,
        "evidence_source": evidence_source.value,
        "journey_completed": journey_completed,
    }
    data = result.model_dump(mode="json") | {
        "verdict": Verdict.INCONCLUSIVE.value,
        "reason_code": code,
        "observed": observed,
        "obtained_evidence": result.obtained_evidence.value if device and result.obtained_evidence else None,
    }
    return OracleResult.model_validate(data)


def _ui_statuses(store: Store, run_id: UUID, cmid: str, after: Any) -> list[str]:
    """Message status values Lab Messenger showed for this id in observations captured after the
    send was handed to the device (UI evidence, independent of the oracle)."""
    seen: list[str] = []
    with store.reader() as r:
        rows = r.session.scalars(
            select(ObservationRow).where(ObservationRow.run_id == str(run_id)).order_by(ObservationRow.created_at)
        )
        for row in rows:
            obs = Observation.model_validate({**row.body, "version": row.version})
            if after is None or obs.capture_started_at < after:
                continue
            value = message_statuses(obs).get(cmid)
            if value and (not seen or seen[-1] != value):
                seen.append(value)
    return seen


async def evaluate_run(
    store: Store,
    run_id: UUID,
    *,
    scenario_id: str,
    oracle_definitions: Sequence[OracleDefinition],
    receipts: ReceiptSource,
    census: MessageCensus,
    sender_id: str,
    evidence_source: EvidenceSource,
    journey_completed: bool,
    journey_reason: str,
    journey_stop_class: str | None = None,
    oracle: FixtureMessageReceiptOracle | None = None,
    reconcile_deadline_s: float = 5.0,
) -> Evaluation:
    definition = next((d for d in oracle_definitions if d.kind == ORACLE_KIND), None)
    if definition is None:
        raise ValueError(f"scenario declares no {ORACLE_KIND} oracle")
    oracle = oracle or FixtureMessageReceiptOracle(receipts)
    with store.reader() as r:
        actions: list[ActionRecord] = [a for a in r.list_actions(run_id=run_id) if a.kind is ActionKind.SEND_MESSAGE]
    executed = [a for a in actions if a.status in EXECUTED_SEND_STATUSES and a.correlation_id is not None]

    checks: list[SendCheck] = []
    results: list[OracleResult] = []  # uncapped: they decide the run verdict
    stored_results: list[OracleResult] = []  # what was persisted (capped)
    for action in executed:
        cmid = str(action.correlation_id)
        with store.reader() as r:
            dispatch_obs = r.get_observation(action.dispatch_observation_id) if action.dispatch_observation_id else None
        draft_el = next((e for e in dispatch_obs.ui_tree if e.identifier == DRAFT_ID), None) if dispatch_obs else None
        draft_value = draft_el.value.strip().lower() if draft_el and draft_el.value else None
        check = SendCheck(
            action_id=action.action_id,
            status_before=action.status.value,
            client_message_id=cmid,
            draft_id_in_dispatch_observation=draft_value,
            draft_identity_matches=draft_value == cmid,
        )
        window = OracleWindow(start=action.actual_dispatch_at) if action.actual_dispatch_at else None
        result = await oracle.evaluate(
            run_id,
            action.correlation_id,  # type: ignore[arg-type]
            definition,
            window,
            scenario_id=scenario_id,
            action_status=action.status,
            evidence_ids=[f"action:{action.action_id}", f"observation:{action.dispatch_observation_id}"],
        )
        stored = cap_oracle_result(result, evidence_source=evidence_source, journey_completed=journey_completed)
        with store.unit_of_work() as uow:
            uow.add_oracle_result(stored)
        results.append(result)
        stored_results.append(stored)
        receipt = result.observed.get("receipt") if isinstance(result.observed.get("receipt"), dict) else None
        check.oracle_result_id, check.oracle_verdict, check.oracle_reason = (
            stored.oracle_result_id, stored.verdict.value, stored.reason_code,
        )  # fmt: skip
        check.receipt_verdict = result.verdict.value
        if receipt:
            check.receipt_client_message_id = str(receipt.get("client_message_id"))  # type: ignore[union-attr]
            check.server_accepted_at = receipt.get("server_accepted_at")  # type: ignore[union-attr,assignment]
            check.receiver_delivered_at = receipt.get("receiver_delivered_at")  # type: ignore[union-attr,assignment]
            check.receiver_type = receipt.get("receiver_type")  # type: ignore[union-attr,assignment]

        rec = await reconcile_unknown_send(receipts, action, deadline_s=reconcile_deadline_s)
        with store.unit_of_work() as uow:
            for target in rec.transition_path:
                uow.transition_action(action.action_id, target)
        check.reconciliation = rec.model_dump(mode="json")
        check.status_after = rec.transition_path[-1].value if rec.transition_path else action.status.value
        check.ui_statuses_seen = _ui_statuses(store, run_id, cmid, action.actual_dispatch_at)
        check.post_send_ui_row_seen = bool(check.ui_statuses_seen)
        checks.append(check)

    if not executed:
        evidence = [f"action:{a.action_id}:{a.status.value}" for a in actions] or ["no-send-action-journaled"]
        result = _not_executed_result(run_id, scenario_id, definition, evidence)
        with store.unit_of_work() as uow:
            uow.add_oracle_result(result)
        results.append(result)
        stored_results.append(result)

    messages = [m for m in await census() if m.sender_id == sender_id]
    stored_ids = sorted(str(m.client_message_id) for m in messages)
    journal_ids = sorted(c.client_message_id for c in checks if c.client_message_id)
    census_ok = stored_ids == journal_ids and len(stored_ids) == len(set(stored_ids))
    census_info: dict[str, Any] = {
        "scope": "all conversations of the run namespace visible to the sender",
        "sender_id": sender_id,
        "stored_outbound_messages": len(messages),
        "stored_client_message_ids": stored_ids,
        "journaled_executed_send_ids": journal_ids,
        "send_actions_journaled": len(actions),
        "ok": census_ok,
    }
    identity_ok = all(
        c.draft_identity_matches and (c.receipt_client_message_id in (None, c.client_message_id)) for c in checks
    )
    primary = results[0] if len(results) == 1 else (max(results, key=_severity) if results else None)
    if not executed:
        primary = None
    verdict, reason = decide_verdict(
        journey_completed=journey_completed,
        journey_reason=journey_reason,
        journey_stop_class=journey_stop_class,
        oracle=primary,
        evidence_source=evidence_source,
        identity_ok=identity_ok,
        census_ok=census_ok,
        census_reason=f"stored {stored_ids} vs journaled {journal_ids}",
        ui_correlated=all(c.post_send_ui_row_seen for c in checks),
    )
    obtained = primary.obtained_evidence if primary is not None else None
    return Evaluation(verdict, reason, obtained, evidence_source, checks, stored_results, census_info)


_ORDER = [Verdict.PASS, Verdict.INCONCLUSIVE, Verdict.UNSUPPORTED, Verdict.ENVIRONMENT_FAILURE, Verdict.HARNESS_FAILURE, Verdict.DUT_FAILURE]


def _severity(result: OracleResult) -> int:
    """With several executed sends (never expected here) the worst oracle result decides."""
    return _ORDER.index(result.verdict)

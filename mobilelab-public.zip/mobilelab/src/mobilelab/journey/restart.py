"""Coordinator-restart experiment (ACCEPTANCE_PLAN AC-06): kill the coordinator right after the
send was dispatched, restart, reconcile by fixture receipt, never resend.

Process layout (all loopback, typed argv, no shell):

- **This process (the "restarted coordinator")** owns the fixture service and the run's fixture
  credentials (``admin.reset(run_id)``), so the receipt can be reconciled after the first
  coordinator is gone. Nothing is persisted to disk for that: the credentials stay in memory, and
  the child receives them through a 0600 file it deletes after reading.
- **The child coordinator** (``python -m mobilelab.journey.restart child --spec FILE``) runs an
  ordinary :class:`JourneyRun` on the real Simulator with that external fixture.
- The parent polls the run's journal (read-only) and sends ``SIGKILL`` to the child as soon as the
  ``send_message`` action is DISPATCHED/ACKNOWLEDGED (the tap returned; the receipt oracle has not
  run). It then cleans up the dead coordinator's orphans (Appium server, WebDriverAgent; the worker
  exits on stdin EOF), takes the single-coordinator lock, and runs ``RunController.recover()`` with
  a receipt reconciler. The run must end in recovery PAUSING -> PAUSED, the send VERIFIED by its
  receipt (``client_message_id``), with exactly one stored message and one fixture POST. The
  operator decision afterwards is explicit: the run is stopped (ABORTED, INCONCLUSIVE), not resumed.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from mobilelab.domain.base import utc_now
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus, RunStatus, Verdict
from mobilelab.secrets import child_env

SPEC_ENV_FLAG = "MOBILELAB_RESTART_CHILD"


@dataclass(frozen=True)
class _Unresolved:
    resolution: str = "UNRESOLVED"
    reason_code: str = "NO_INDEPENDENT_EVIDENCE_NON_COMMIT"


@dataclass
class RestartOutcome:
    run_id: UUID
    evidence: dict[str, Any] = field(default_factory=dict)
    report_dir: Path | None = None
    integrity_ok: bool | None = None


def _write_secret_file(data: dict[str, Any]) -> Path:
    tmpdir = Path(tempfile.mkdtemp(prefix="mobilelab-restart-"))
    path = tmpdir / "child.json"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    return path


# -- child -------------------------------------------------------------------------------------------


def _child(spec_path: Path) -> int:
    from mobilelab.fixtures.models import ResetResponse
    from mobilelab.journey.environment import IOSSimulatorEnvironment, MockDeviceEnvironment
    from mobilelab.journey.plan import load_plan
    from mobilelab.journey.runner import ExternalFixture, JourneyRun

    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    spec_path.unlink()
    spec_path.parent.rmdir()
    reset = ResetResponse.model_validate(spec["reset"])
    run = JourneyRun(
        load_plan(spec["variant"], seed=spec.get("seed"), dwell_mode=spec["dwell_mode"]),
        IOSSimulatorEnvironment() if spec.get("adapter", "ios") == "ios" else MockDeviceEnvironment(),
        db_path=Path(spec["db_path"]),
        artifacts_root=Path(spec["artifacts_root"]),
        work_dir=Path(spec["work_dir"]),
        run_id=UUID(spec["run_id"]),
        external_fixture=ExternalFixture(spec["admin_url"], spec["admin_secret"], reset),
        reopen_gate=bool(spec.get("reopen_gate", False)),
        progress=lambda m: print(f"[child coordinator] {m}", file=sys.stderr, flush=True),
    )
    result = asyncio.run(run.execute())
    print(json.dumps({"status": result.status, "verdict": result.verdict}), flush=True)
    return 0


# -- parent ------------------------------------------------------------------------------------------


def _send_action(db_path: Path, run_id: UUID) -> ActionRecord | None:
    from mobilelab.store import Store

    store = Store.open(db_path)
    try:
        with store.reader() as r:
            sends = [a for a in r.list_actions(run_id=run_id) if a.kind is ActionKind.SEND_MESSAGE]
    except Exception:  # run not created yet / schema busy
        return None
    finally:
        store.close()
    return sends[-1] if sends else None


def _kill_group(pid: int | None, sig: int = signal.SIGTERM, timeout_s: float = 15.0) -> str:
    if not pid:
        return "none"
    try:
        os.killpg(pid, sig)
    except ProcessLookupError:
        return "already gone"
    except PermissionError:
        return "permission denied"
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return "terminated"
        time.sleep(0.2)
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        return "terminated"
    return "killed"


def _pid_alive(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


async def run_restart_experiment(
    *,
    db_path: Path,
    artifacts_root: Path,
    work_dir: Path,
    variant: str = "default",
    seed: int | None = None,
    dwell_mode: str = "median",
    reopen_gate: bool = False,
    adapter: str = "ios",
    kill_on: tuple[ActionStatus, ...] = (ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED),
    child_timeout_s: float = 420.0,
) -> RestartOutcome:
    from mobilelab.adapters.appium_server import stop_wda_processes
    from mobilelab.candidates import generate_candidates, rebind
    from mobilelab.coordinator import RunController
    from mobilelab.fixtures.clients import FixtureAdminClient, FixtureOracleClient
    from mobilelab.journey.environment import FixtureService, list_outbound_messages
    from mobilelab.journey.plan import REPO_ROOT, load_plan
    from mobilelab.journey.redaction import scrub_raw_dir
    from mobilelab.oracles.reconcile import reconcile_unknown_send
    from mobilelab.reporting import verify_report_integrity, write_report
    from mobilelab.sim.lifecycle import DEFAULT_RECORD_PATH, load_record
    from mobilelab.store import Store
    from mobilelab.store.artifacts import ArtifactStore
    from mobilelab.store.lock import CoordinatorLock

    run_id = uuid4()
    work_dir.mkdir(parents=True, exist_ok=True)
    ev: dict[str, Any] = {"kind": "coordinator_restart_after_send_dispatch", "run_id": str(run_id), "adapter": adapter,
                          "started_at": utc_now().isoformat()}  # fmt: skip
    outcome = RestartOutcome(run_id=run_id, evidence=ev)
    fixture = FixtureService(work_dir / "parent-fixture")
    fixture.start()
    secrets = [fixture.admin_secret]
    try:
        async with FixtureAdminClient(fixture.admin_url, fixture.admin_secret) as admin:
            reset = await admin.reset(run_id)
        secrets += [reset.sender.token, reset.receiver.token, reset.oracle.token]
        spec = {
            "run_id": str(run_id), "variant": variant, "seed": seed, "dwell_mode": dwell_mode,
            "db_path": str(db_path), "artifacts_root": str(artifacts_root), "work_dir": str(work_dir),
            "admin_url": fixture.admin_url, "admin_secret": fixture.admin_secret,
            "reset": reset.model_dump(mode="json"), "reopen_gate": reopen_gate, "adapter": adapter,
        }  # fmt: skip
        spec_path = _write_secret_file(spec)
        log = (work_dir / "child-coordinator.log").open("wb")
        child = subprocess.Popen(  # noqa: S603 - fixed argv, no shell
            [sys.executable, "-m", "mobilelab.journey.restart", "child", "--spec", str(spec_path)],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log, cwd=REPO_ROOT, start_new_session=True,
            env=child_env(),  # the restart child uses no cloud provider; never inherit its key
        )  # fmt: skip
        log.close()
        ev["child_pid"] = child.pid
        killed_at = None
        seen: list[str] = []
        deadline = time.monotonic() + child_timeout_s
        while time.monotonic() < deadline and child.poll() is None:
            action = _send_action(db_path, run_id)
            if action is not None:
                if not seen or seen[-1] != action.status.value:
                    seen.append(action.status.value)
                if action.status in kill_on:
                    child.send_signal(signal.SIGKILL)
                    killed_at = utc_now()
                    ev["send_status_at_kill"] = action.status.value
                    ev["send_action_id"] = str(action.action_id)
                    ev["client_message_id"] = str(action.correlation_id)
                    break
            await asyncio.sleep(0.02)
        ev["send_status_sequence_seen_by_parent"] = seen
        if killed_at is None:
            if child.poll() is None:
                child.kill()
            child.wait(timeout=30)
            ev["error"] = f"send never reached {[s.value for s in kill_on]} (child exit {child.returncode})"
            return outcome
        child.wait(timeout=30)
        ev["killed_at"] = killed_at.isoformat()
        ev["child_exit_code"] = child.returncode

        # -- the dead coordinator's orphans ------------------------------------------------------
        procs: dict[str, Any] = {}
        pfile = work_dir / "processes.json"
        if pfile.is_file():
            procs = json.loads(pfile.read_text(encoding="utf-8"))
        ev["orphans"] = {"processes": procs}
        t_end = time.monotonic() + 15
        while _pid_alive(procs.get("worker_pid")) and time.monotonic() < t_end:
            await asyncio.sleep(0.2)
        ev["orphans"]["worker_exited_on_stdin_eof"] = not _pid_alive(procs.get("worker_pid"))
        if _pid_alive(procs.get("worker_pid")):
            ev["orphans"]["worker"] = _kill_group(procs.get("worker_pid"))
        ev["orphans"]["appium"] = _kill_group(procs.get("appium_pid"))
        record = load_record(DEFAULT_RECORD_PATH) if adapter == "ios" else None
        if record is not None:
            stopped = stop_wda_processes(record.udid, (REPO_ROOT / "build" / "wda" / record.udid).resolve())
            ev["orphans"]["wda_processes_stopped"] = len(stopped)

        # -- restart: a new coordinator on the same database ---------------------------------------
        lock = CoordinatorLock(db_path)
        lock.acquire()
        store = Store.open(db_path)
        try:
            with store.reader() as r:
                before = r.get_run(run_id)
                send_before = r.get_action(UUID(ev["send_action_id"]))
                gate_before = r.get_gate()
            ev["before_recovery"] = {"run_status": before.status.value, "send_status": send_before.status.value,
                                     "send_attempts": len(r_attempts(store, send_before.action_id)),
                                     "gate_open": gate_before.gate_open, "gate_reason": gate_before.reason}  # fmt: skip
            plan = load_plan(variant, seed=seed, dwell_mode=dwell_mode)
            scope = plan.scope(reset.data_base_url)
            reconciled_by: list[dict[str, Any]] = []
            async with FixtureOracleClient(reset.data_base_url, reset.oracle.token) as oracle:

                async def reconciler(action: ActionRecord) -> Any:
                    if action.run_id != run_id:
                        return None
                    if action.kind is ActionKind.SEND_MESSAGE and action.correlation_id is not None:
                        rec = await reconcile_unknown_send(oracle, action, deadline_s=15.0)
                        reconciled_by.append(rec.model_dump(mode="json"))
                        return rec
                    return _Unresolved()

                controller = RunController(
                    store, ArtifactStore(artifacts_root), scope, generate=generate_candidates, rebind=rebind,
                    provider=None, reconciler=reconciler, holder="coordinator:restarted",
                )  # fmt: skip
                t0 = time.monotonic()
                recovery = await controller.recover()
                ev["recovery_ms"] = round((time.monotonic() - t0) * 1000, 1)
            ev["recovery"] = recovery.model_dump(mode="json")
            ev["send_reconciliation"] = reconciled_by
            with store.reader() as r:
                after = r.get_run(run_id)
                send_after = r.get_action(UUID(ev["send_action_id"]))
                gate_after = r.get_gate()
                lease = r.get_active_lease(after.spec.device_id)
            every = await list_outbound_messages(reset)
            messages = [m for m in every if m.sender_id == reset.sender.sender_id]
            async with FixtureAdminClient(fixture.admin_url, fixture.admin_secret) as admin:
                entries = await admin.request_log(run_id, include_unscoped=True)
            (work_dir / "parent-request_log.json").write_text(
                json.dumps([e.model_dump(mode="json") for e in entries], indent=2), encoding="utf-8"
            )
            ev["after_recovery"] = {
                "run_status": after.status.value,
                "in_recovery": after.in_recovery,
                "send_status": send_after.status.value,
                "send_attempts": len(r_attempts(store, send_after.action_id)),
                "gate_open": gate_after.gate_open,
                "gate_reason": gate_after.reason,
                "active_lease": None if lease is None else {"kind": lease.kind.value, "holder": lease.holder},
                "stored_outbound_messages": len(messages),
                "stored_messages_all_senders": len(every),
                "stored_client_message_ids": [str(m.client_message_id) for m in messages],
                "fixture_message_posts": sum(1 for e in entries if e.method == "POST" and e.path == "/fixture/v1/messages"),
            }
            # -- explicit operator decision: stop, do not resume ------------------------------------
            decision = "stop: send reconciled by receipt; the interrupted journey is not resumed"
            if after.status is RunStatus.PAUSED:
                with store.unit_of_work() as uow:
                    uow.transition_run(run_id, RunStatus.STOPPING, reason=f"operator decision after restart: {decision}")
                    uow.transition_run(run_id, RunStatus.ABORTED, verdict=Verdict.INCONCLUSIVE,
                                       reason=f"operator decision after restart: {decision}")  # fmt: skip
                ev["operator_decision"] = decision
            else:
                ev["operator_decision"] = f"none: run is {after.status.value} (unreconciled), left for the operator"
            with store.reader() as r:
                ev["final_run_status"] = r.get_run(run_id).status.value
                ev["final_gate_open"] = r.get_gate().gate_open
            bundle = write_report(store, run_id, artifacts_root)
            integrity = verify_report_integrity(bundle.directory)
            outcome.report_dir, outcome.integrity_ok = bundle.directory, integrity.ok
            ev["report_dir"] = str(bundle.directory)
            ev["report_integrity_ok"] = integrity.ok
        finally:
            store.close()
            lock.release()
    finally:
        ev["fixture_service_exit"] = fixture.stop()
        try:
            ev["raw_log_redaction"] = scrub_raw_dir(work_dir, secrets)
        except Exception as exc:
            ev["raw_log_redaction"] = {"error": type(exc).__name__}
        ev["finished_at"] = utc_now().isoformat()
    return outcome


def r_attempts(store: Any, action_id: UUID) -> list[Any]:
    with store.reader() as r:
        return r.list_attempts(action_id)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mobilelab.journey.restart")
    sub = parser.add_subparsers(dest="cmd", required=True)
    child = sub.add_parser("child", help="internal: the coordinator that will be killed")
    child.add_argument("--spec", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.cmd == "child":
        return _child(args.spec)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

"""Frozen inputs of one browse_then_reply run: scenario variant, persona, provider config, scope.

The scenario file is hashed exactly as loaded (its ``${fixture_data_origin}`` placeholder unbound);
the origin is bound only when the per-run fixture namespace is reset and is recorded separately.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.personas import PersonaConfig
from mobilelab.domain.scenarios import ScenarioSpec
from mobilelab.fixtures.models import FaultLayer, FaultMatch, FaultMode, FaultRoute, FaultSpec
from mobilelab.personas.catalog import get_persona, persona_hash
from mobilelab.providers.script import BrowseThenReplyScript

REPO_ROOT = Path(__file__).resolve().parents[3]
SCENARIO_DIR = REPO_ROOT / "configs" / "scenarios"
VARIANTS: dict[str, str] = {
    "default": "browse_then_reply.yaml",
    "suppressed_ack": "browse_then_reply_suppressed_ack.yaml",
    "changed": "browse_then_reply_changed.yaml",
    "adversarial": "browse_adversarial.yaml",
}
PROVIDER_ID = "rules"
"""``mobilelab.reporting`` labels provider id ``rules`` as ``RulesProvider``."""


@dataclass(frozen=True)
class JourneyPlan:
    variant: str
    scenario_path: Path
    scenario: ScenarioSpec
    scenario_hash: str
    persona: PersonaConfig
    persona_hash: str
    seed: int
    dwell_mode: str
    provider_config: dict[str, Any]

    @property
    def provider_config_hash(self) -> str:
        return config_hash(self.provider_config)

    def scope(self, data_base_url: str) -> ScenarioScope:
        return ScenarioScope.from_scenario(self.scenario, fixture_data_base_url=data_base_url)

    def script(self, data_base_url: str) -> BrowseThenReplyScript:
        return BrowseThenReplyScript.from_scenario(self.scenario, fixture_data_base_url=data_base_url)

    def fault_specs(self) -> list[FaultSpec]:
        """Declared, controlled fixture faults (hidden from the acting provider)."""
        out: list[FaultSpec] = []
        for d in self.scenario.disturbances:
            params = d.params
            match = params.get("match") if isinstance(params.get("match"), dict) else {}
            out.append(
                FaultSpec(
                    fault_id=str(params.get("fault_id", d.kind)),
                    mode=FaultMode(d.kind),
                    layer=FaultLayer(d.layer or "fixture_server"),
                    match=FaultMatch(route=FaultRoute(str(match.get("route", "any")))),  # type: ignore[union-attr]
                )
            )
        return out


def load_plan(variant: str = "default", *, seed: int | None = None, dwell_mode: str = "lognormal") -> JourneyPlan:
    if variant not in VARIANTS:
        raise ValueError(f"unknown variant {variant!r}; choose from {sorted(VARIANTS)}")
    path = SCENARIO_DIR / VARIANTS[variant]
    scenario = ScenarioSpec.from_yaml(path.read_text(encoding="utf-8"))
    if scenario.persona_id is None or scenario.persona_version is None:
        raise ValueError("browse_then_reply scenarios must pin a persona")
    persona = get_persona(scenario.persona_id, scenario.persona_version)
    run_seed = seed if seed is not None else (scenario.seed or 0)
    provider_config: dict[str, Any] = {
        "label": "RulesProvider",
        "kind": "rules",
        "script": "browse_then_reply",
        "dwell_mode": dwell_mode,
        "dwell_category": "reading_dwell",
    }
    return JourneyPlan(
        variant=variant,
        scenario_path=path,
        scenario=scenario,
        scenario_hash=config_hash(scenario),
        persona=persona,
        persona_hash=persona_hash(persona),
        seed=run_seed,
        dwell_mode=dwell_mode,
        provider_config=provider_config,
    )

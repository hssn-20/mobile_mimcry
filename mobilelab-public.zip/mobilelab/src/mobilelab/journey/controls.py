"""Live control experiments on a journey run (ACCEPTANCE_PLAN AC-05, AC-06).

Each experiment is a ``LoopHook`` for :class:`~mobilelab.journey.runner.JourneyRun`: it runs next to
the decision loop and drives the *real* ``RunController`` controls. It measures, never decides:
every number comes from the store, the worker's own health counters or wall clocks, and the hook's
findings are written to ``run.journey["control_experiment"]`` (stored in ``journey.json``).

- :func:`pause_resume_hook`: pause during a long reading dwell executing on the device; PAUSED must
  be recorded only after that in-flight command settled. Optionally an operator takeover (operator
  lease) while paused, then resume via ``start`` (new lease epoch + control epoch, fresh observation).
- :func:`emergency_stop_hook`: emergency stop while a driver command is in flight (a long dwell
  wait, or a TEST-ONLY injected worker driver delay). Records ``gate_persisted_at`` and
  ``fence_acknowledged_at`` against the request time, then watches the worker's command counter for
  new UI commands after the confirmed fence, and finally stops the run (ABORTED).

The coordinator-restart experiment (kill after the send was dispatched) needs a separate process;
see :mod:`mobilelab.journey.restart`.
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime
from typing import TYPE_CHECKING, Any

from mobilelab.domain.base import utc_now
from mobilelab.domain.enums import ActionKind, ActionStatus, RunStatus

if TYPE_CHECKING:
    from mobilelab.journey.runner import JourneyRun, LoopHook

LONG_DWELL_MS = 4000
"""A wait at least this long is a persona reading dwell (precondition waits are 750 ms)."""


def _iso(t: datetime | None) -> str | None:
    return t.isoformat() if t else None


def _ms(a: datetime | None, b: datetime | None) -> float | None:
    if a is None or b is None:
        return None
    return round((b - a).total_seconds() * 1000, 1)


def executing_action(run: JourneyRun, kinds: set[ActionKind], *, min_wait_ms: int = 0) -> tuple[Any, Any] | None:
    """The run's action currently handed to the worker (PREPARED with an open attempt)."""
    store = run._store()  # noqa: SLF001 - the experiment belongs to the run
    with store.reader() as r:
        for action in r.list_actions(run_id=run.run_id, statuses=[ActionStatus.PREPARED]):
            if action.kind not in kinds:
                continue
            if action.kind is ActionKind.WAIT and getattr(action.payload, "duration_ms", 0) < min_wait_ms:
                continue
            open_attempts = [a for a in r.list_attempts(action.action_id) if a.result is None]
            if open_attempts:
                return action, open_attempts[-1]
    return None


async def wait_for_executing(
    run: JourneyRun, kinds: set[ActionKind], *, min_wait_ms: int = 0, timeout_s: float = 300.0
) -> tuple[Any, Any]:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        found = executing_action(run, kinds, min_wait_ms=min_wait_ms)
        if found is not None:
            return found
        with run._store().reader() as r:  # noqa: SLF001
            if r.get_run(run.run_id).status is not RunStatus.RUNNING:
                raise RuntimeError("run left RUNNING before the targeted command executed")
        await asyncio.sleep(0.05)
    raise TimeoutError(f"no {sorted(k.value for k in kinds)} command executed within {timeout_s} s")


def pause_resume_hook(
    *,
    pause_after_s: float = 1.5,
    hold_paused_s: float = 3.0,
    takeover: bool = True,
    operator: str = "operator:live-control-test",
) -> LoopHook:
    async def hook(run: JourneyRun) -> None:
        ev: dict[str, Any] = run.journey.setdefault("control_experiment", {"kind": "pause_resume"})
        controller = run.controller
        assert controller is not None
        action, attempt = await wait_for_executing(run, {ActionKind.WAIT}, min_wait_ms=LONG_DWELL_MS)
        dwell_ms = getattr(action.payload, "duration_ms", None)
        ev["target_action"] = {"action_id": str(action.action_id), "kind": action.kind.value,
                               "semantic_key": action.semantic_key, "dwell_ms": dwell_ms,
                               "attempt_id": str(attempt.attempt_id)}  # fmt: skip
        await asyncio.sleep(pause_after_s)
        with run._store().reader() as r:  # noqa: SLF001
            ev["epoch_before_pause"] = r.get_run(run.run_id).control_epoch
            lease = r.get_active_lease(run.env.device_id)
            ev["lease_before_pause"] = {"lease_id": str(lease.lease_id), "epoch": lease.epoch, "kind": lease.kind.value} if lease else None
        health_before = await controller.worker(run.run_id).health()
        ev["worker_in_flight_at_pause_request"] = {"state": health_before.in_flight_state,
                                                   "command_id": str(health_before.in_flight_command_id or ""),
                                                   "driver_busy": health_before.driver_busy}  # fmt: skip
        requested = utc_now()
        res = await controller.pause(run.run_id)
        returned = utc_now()
        with run._store().reader() as r:  # noqa: SLF001
            target = r.get_action(action.action_id)
            attempts = r.list_attempts(action.action_id)
            paused_run = r.get_run(run.run_id)
        settled_at = max((a.ended_at for a in attempts if a.ended_at), default=None)
        ev["pause"] = {
            "requested_at": _iso(requested),
            "returned_at": _iso(returned),
            "ok": res.ok,
            "run_status": res.run_status.value,
            "fence_confirmed": res.fence_confirmed,
            "fence_acknowledged_in_flight_state": res.fence.in_flight_state if res.fence else None,
            "in_flight_settled": res.in_flight_settled,
            "target_action_status_after": target.status.value,
            "target_attempt_ended_at": _iso(settled_at),
            "paused_recorded_at": _iso(paused_run.updated_at),
            "paused_after_in_flight_settled": bool(settled_at and paused_run.updated_at >= settled_at),
            "pause_request_to_paused_ms": _ms(requested, paused_run.updated_at),
            "control_epoch_after": paused_run.control_epoch,
            "detail": res.detail,
        }
        health_paused = await controller.worker(run.run_id).health()
        ev["worker_while_paused"] = {"gate_open": getattr(health_paused, "gate_open", None),
                                     "in_flight_state": health_paused.in_flight_state,
                                     "commands_started": health_paused.commands_started}  # fmt: skip
        if not res.ok:
            return
        if takeover:
            t = await controller.takeover(run.run_id, operator=operator)
            with run._store().reader() as r:  # noqa: SLF001
                lease = r.get_active_lease(run.env.device_id)
            ev["takeover"] = {"ok": t.ok, "detail": t.detail, "command_id": str(t.command_id),
                              "active_lease": {"kind": lease.kind.value, "epoch": lease.epoch,
                                               "holder": lease.holder} if lease else None}  # fmt: skip
        await asyncio.sleep(hold_paused_s)
        commands_during_hold = (await controller.worker(run.run_id).health()).commands_started - health_paused.commands_started
        ev["ui_commands_while_paused"] = commands_during_hold
        resumed_at = utc_now()
        binding = await controller.start(run.run_id)
        with run._store().reader() as r:  # noqa: SLF001
            lease = r.get_active_lease(run.env.device_id)
        ev["resume"] = {
            "at": _iso(resumed_at),
            "new_lease_id": str(binding.lease_id),
            "new_lease_epoch": binding.lease_epoch,
            "new_control_epoch": binding.control_epoch,
            "active_lease_kind": lease.kind.value if lease else None,
        }

    return hook


def emergency_stop_hook(
    *,
    target_kinds: set[ActionKind] | None = None,
    min_wait_ms: int = LONG_DWELL_MS,
    stop_after_s: float = 1.0,
    watch_s: float = 5.0,
    reason: str = "emergency stop: live control test",
) -> LoopHook:
    kinds = target_kinds or {ActionKind.WAIT}

    async def hook(run: JourneyRun) -> None:
        ev: dict[str, Any] = run.journey.setdefault("control_experiment", {"kind": "emergency_stop"})
        controller = run.controller
        assert controller is not None
        action, attempt = await wait_for_executing(run, kinds, min_wait_ms=min_wait_ms if ActionKind.WAIT in kinds else 0)
        ev["target_action"] = {"action_id": str(action.action_id), "kind": action.kind.value,
                               "semantic_key": action.semantic_key,
                               "dwell_ms": getattr(action.payload, "duration_ms", None),
                               "attempt_id": str(attempt.attempt_id)}  # fmt: skip
        await asyncio.sleep(stop_after_s)
        worker = controller.worker(run.run_id)
        before = await worker.health()
        ev["worker_before"] = {"in_flight_state": before.in_flight_state, "driver_busy": before.driver_busy,
                               "commands_started": before.commands_started,
                               "test_driver_delay": before.test_driver_delay}  # fmt: skip
        requested = utc_now()
        t0 = time.monotonic()
        result = await controller.emergency_stop(reason)
        returned_ms = (time.monotonic() - t0) * 1000
        after = await worker.health()
        ev["emergency_stop"] = {
            "requested_at": _iso(requested),
            "gate_persisted_at": _iso(result.gate_persisted_at),
            "fence_acknowledged_at": _iso(result.fence_acknowledged_at),
            "request_to_gate_persisted_ms": _ms(requested, result.gate_persisted_at),
            "request_to_fence_acknowledged_ms": _ms(requested, result.fence_acknowledged_at),
            "call_returned_ms": round(returned_ms, 1),
            "fully_fenced": result.fully_fenced,
            "target_under_1s": (_ms(requested, result.fence_acknowledged_at) or 1e9) < 1000,
            "devices": [d.model_dump(mode="json") for d in result.devices],
            "in_flight_at_fence": [d.in_flight_state for d in result.devices],
            "commands_started_at_fence": after.commands_started,
        }
        # Watch: no new UI command may start after the confirmed fence (the in-flight one may finish).
        deadline = time.monotonic() + watch_s
        samples: list[dict[str, Any]] = []
        settled_at: str | None = None
        while time.monotonic() < deadline or (after.in_flight_state != "none" and time.monotonic() < deadline + 60):
            after = await worker.health()
            samples.append({"t_ms": round((time.monotonic() - t0) * 1000), "in_flight": after.in_flight_state,
                            "commands_started": after.commands_started})  # fmt: skip
            if after.in_flight_state == "none" and settled_at is None:
                settled_at = utc_now().isoformat()
            await asyncio.sleep(0.25)
        ev["post_fence_watch"] = {
            "samples": samples[-40:],
            "in_flight_settled_at": settled_at,
            "new_ui_commands_after_fence": after.commands_started - ev["emergency_stop"]["commands_started_at_fence"],
            "last_command_started_at": _iso(after.last_command_started_at),
            "last_command_started_before_fence": bool(
                after.last_command_started_at is None
                or result.fence_acknowledged_at is None
                or after.last_command_started_at <= result.fence_acknowledged_at
            ),
        }
        with run._store().reader() as r:  # noqa: SLF001
            gate = r.get_gate()
            late = [
                str(a.attempt_id)
                for act in r.list_actions(run_id=run.run_id)
                for a in r.list_attempts(act.action_id)
                if a.started_at and result.fence_acknowledged_at and a.started_at > result.fence_acknowledged_at
                and a.status is not None and a.status.value != "REJECTED"
            ]
        ev["journal_attempts_started_after_fence"] = late
        ev["gate_after"] = {"open": gate.gate_open, "reason": gate.reason, "global_epoch": gate.global_epoch}
        stop = await controller.stop(run.run_id)
        ev["stop_after_emergency"] = {"ok": stop.ok, "run_status": stop.run_status.value, "detail": stop.detail}

    return hook


def pause_during_decision_hook(
    *,
    min_in_flight_s: float = 0.5,
    hold_paused_s: float = 1.0,
    timeout_s: float = 300.0,
) -> LoopHook:
    """Pause while a provider decision has been in flight for ``min_in_flight_s`` (a slow model call),
    then resume. Evidence: the in-flight decision is recorded ``cancelled`` (no result arrived) or
    ``discarded_stale`` (a late result arrived and was thrown away) for the old control
    epoch, no action is journaled from it, and post-resume decisions carry the new epoch."""

    async def hook(run: JourneyRun) -> None:
        ev: dict[str, Any] = run.journey.setdefault("control_experiment", {"kind": "pause_during_decision"})
        controller = run.controller
        assert controller is not None
        deadline = time.monotonic() + timeout_s
        while True:
            started = controller.decisions_in_flight.get(run.run_id)
            if started is not None and time.monotonic() - started >= min_in_flight_s:
                break
            with run._store().reader() as r:  # noqa: SLF001
                if r.get_run(run.run_id).status is not RunStatus.RUNNING:
                    raise RuntimeError("run left RUNNING before a slow decision was observed")
            if time.monotonic() > deadline:
                raise TimeoutError(f"no decision stayed in flight for {min_in_flight_s} s within {timeout_s} s")
            await asyncio.sleep(0.02)
        in_flight_for_ms = round((time.monotonic() - started) * 1000, 1)
        with run._store().reader() as r:  # noqa: SLF001
            before = r.get_run(run.run_id)
            n_actions_before = len(r.list_actions(run_id=run.run_id))
        requested = utc_now()
        res = await controller.pause(run.run_id)
        ev["pause"] = {
            "requested_at": _iso(requested),
            "decision_in_flight_for_ms_at_request": in_flight_for_ms,
            "decision_still_in_flight_after_pause": run.run_id in controller.decisions_in_flight,
            "ok": res.ok,
            "run_status": res.run_status.value,
            "fence_confirmed": res.fence_confirmed,
            "epoch_before": before.control_epoch,
            "detail": res.detail,
        }
        await asyncio.sleep(hold_paused_s)
        with run._store().reader() as r:  # noqa: SLF001
            from sqlalchemy import select

            from mobilelab.domain.decisions import DecisionRecord
            from mobilelab.store.models import DecisionRow

            rows = list(r.session.scalars(select(DecisionRow).where(DecisionRow.run_id == str(run.run_id))))
            decisions = [DecisionRecord.model_validate({**row.body, "version": row.version}) for row in rows]
            actions = r.list_actions(run_id=run.run_id)
        stale = [d for d in decisions if d.control_epoch == before.control_epoch and d.outcome in ("cancelled", "discarded_stale")]
        ev["discarded_decisions_old_epoch"] = [
            {"decision_id": str(d.decision_id), "control_epoch": d.control_epoch, "latency_ms": d.latency_ms,
             "outcome": d.outcome, "had_proposal": d.proposal is not None} for d in stale
        ]  # fmt: skip
        ev["actions_journaled_during_pause"] = len(actions) - n_actions_before
        if not res.ok:
            return
        binding = await controller.start(run.run_id)
        ev["resume"] = {"at": _iso(utc_now()), "new_control_epoch": binding.control_epoch,
                        "new_lease_epoch": binding.lease_epoch}  # fmt: skip

    return hook


def summarize_epochs(run: JourneyRun) -> dict[str, Any]:
    """Decisions grouped by control epoch (resume evidence: post-resume decisions use the new epoch
    and observations captured after the resume)."""
    from sqlalchemy import select

    from mobilelab.domain.decisions import DecisionRecord
    from mobilelab.store.models import DecisionRow

    store = run._store()  # noqa: SLF001
    out: dict[str, Any] = {}
    with store.reader() as r:
        rows = list(r.session.scalars(select(DecisionRow).where(DecisionRow.run_id == str(run.run_id))))
        for row in rows:
            d = DecisionRecord.model_validate({**row.body, "version": row.version})
            obs = r.get_observation(d.decision_observation_id)
            e = out.setdefault(str(d.control_epoch), {"decisions": 0, "first_observation_captured_at": None})
            e["decisions"] += 1
            ts = obs.capture_ended_at.isoformat()
            if e["first_observation_captured_at"] is None or ts < e["first_observation_captured_at"]:
                e["first_observation_captured_at"] = ts
    return out


__all__ = ["LONG_DWELL_MS", "emergency_stop_hook", "executing_action", "pause_during_decision_hook", "pause_resume_hook", "summarize_epochs", "wait_for_executing"]

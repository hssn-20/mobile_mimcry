"""The per-run decision loop (DEMONSTRATOR_SPEC §6 steps 1-8) over ``RunController.step``.

Each iteration: authority check + observe + provider decision + validation + fresh dispatch
observation + rebinding + one journaled command (all inside ``RunController.step``). This module
adds what the controller deliberately leaves to the caller: session history for the provider,
bounded retries when the provider cannot progress yet (e.g. an app still animating in), scenario
budgets, and the stop conditions: the provider's completion action acknowledged *and* a verification
observation showing its expected foreground app, or a non-idempotent commit whose outcome is UNKNOWN
(the run then goes straight to receipt reconciliation). Nothing here ever re-dispatches an action.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

from mobilelab.coordinator import OutcomeKind, RunController
from mobilelab.domain.actions import OpenApp
from mobilelab.domain.decisions import DecisionBudget, DecisionContext, HistoryEntry
from mobilelab.domain.enums import ActionKind, ActionStatus, RunStatus, SideEffectClass
from mobilelab.domain.observations import Observation

HISTORY_LIMIT = 10
"""``DecisionContext.session_history`` is bounded (CONTRACTS §5)."""
NO_PROGRESS = frozenset(
    {
        OutcomeKind.REJECTED,
        OutcomeKind.REPLAN,
        OutcomeKind.CANCELLED,
        OutcomeKind.DISCARDED,
        OutcomeKind.PROVIDER_ERROR,
        OutcomeKind.FAILED,
    }
)
FATAL_PROVIDER_ERRORS = frozenset(
    {"ProviderRequestRejected", "ProviderUnavailable", "SecretUnavailable", "BudgetExceeded", "LedgerError"}
)
"""Provider errors that retrying cannot fix (auth/request rejected, no key, spend cap): stop at once."""


@dataclass(frozen=True)
class EndCondition:
    """Harness-defined scenario end condition (CONTRACTS §5: a model cannot complete a run).

    A provider's ``completion`` flag is only a request to evaluate this condition: the journey is
    complete only when a ``send_message`` was executed and acknowledged (when ``require_send``) and a
    verification observation shows ``final_app_id`` in the foreground."""

    final_app_id: str | None = None
    require_send: bool = True
    max_premature_hints: int = 3
    """Completion hints before the condition holds are recorded; after this many the loop stops
    (INCONCLUSIVE: the model declared completion prematurely)."""


@dataclass(frozen=True)
class LoopLimits:
    max_steps: int = 40
    max_actions: int = 40
    max_duration_s: float = 120.0
    max_consecutive_no_progress: int = 12
    retry_delay_s: float = 0.75
    verify_timeout_s: float = 10.0
    settle_s: float = 1.5


@dataclass
class StepRecord:
    n: int
    outcome: str
    reason: str
    started_at_s: float
    duration_ms: float
    stage: str | None = None
    action_id: UUID | None = None
    decision_id: UUID | None = None
    status: str | None = None
    error_code: str | None = None

    def as_json(self) -> dict[str, Any]:
        return {
            "n": self.n,
            "outcome": self.outcome,
            "reason": self.reason[:500],
            "stage": self.stage,
            "started_at_s": round(self.started_at_s, 3),
            "duration_ms": round(self.duration_ms, 1),
            "action_id": str(self.action_id) if self.action_id else None,
            "decision_id": str(self.decision_id) if self.decision_id else None,
            "status": self.status,
            "error_code": self.error_code,
        }


@dataclass
class LoopResult:
    completed: bool
    stop_reason: str
    steps: list[StepRecord] = field(default_factory=list)
    completion_action_id: UUID | None = None
    verification_observation_id: UUID | None = None
    verification_foreground_app: str | None = None
    elapsed_s: float = 0.0
    control_stop: str | None = None
    """Set when the loop stopped because a control took the run out of RUNNING or closed the gate."""
    premature_completion_hints: list[dict[str, Any]] = field(default_factory=list)
    """Completion hints the harness end condition did not confirm (the loop kept stepping)."""
    stop_class: str | None = None
    """Why the journey stopped without completing, when the cause is known: ``provider_unavailable``
    (a provider error retrying cannot fix) or ``premature_completion`` (the model kept declaring
    completion before the harness end condition held). Used for the verdict class."""

    def as_json(self) -> dict[str, Any]:
        return {
            "completed": self.completed,
            "stop_reason": self.stop_reason,
            "elapsed_s": round(self.elapsed_s, 2),
            "completion_action_id": str(self.completion_action_id) if self.completion_action_id else None,
            "verification_observation_id": str(self.verification_observation_id)
            if self.verification_observation_id
            else None,
            "verification_foreground_app": self.verification_foreground_app,
            "control_stop": self.control_stop,
            "stop_class": self.stop_class,
            "premature_completion_hints": self.premature_completion_hints,
            "steps": [s.as_json() for s in self.steps],
        }


def history(controller: RunController, run_id: UUID) -> list[HistoryEntry]:
    """Latest journaled actions with their *current* status (the provider derives progress from it)."""
    with controller.store.reader() as r:
        actions = r.list_actions(run_id=run_id)
        recent = actions[-(HISTORY_LIMIT + 1):]
        summaries = _scroll_effects(r, recent)
    return [
        HistoryEntry(at=a.created_at, kind=a.kind, semantic_key=a.semantic_key, status=a.status,
                     summary=summaries.get(a.action_id, ""))
        for a in actions[-HISTORY_LIMIT:]
    ]  # fmt: skip


def screen_fingerprint(observation: Observation) -> tuple[Any, ...]:
    """Visible text and geometry of an observation; equal before/after a scroll means it had no effect."""
    return tuple(
        (e.role, e.label, e.value, None if e.bounds is None else e.bounds.model_dump_json())
        for e in observation.ui_tree
        if e.visible
    )


def _scroll_effects(reader: Any, actions: list[Any]) -> dict[UUID, str]:
    """Harness-derived (trusted) note per acknowledged scroll: did the screen change? Compares the
    scroll's dispatch observation with the next action's decision observation (one step of lag: the
    latest scroll has no "after" observation yet). Lets a model provider recognise the end of a page."""
    out: dict[UUID, str] = {}
    for prev, nxt in zip(actions, actions[1:], strict=False):
        if prev.kind is not ActionKind.SCROLL or prev.status.value != "ACKNOWLEDGED" or prev.dispatch_observation_id is None:
            continue
        try:
            before = reader.get_observation(prev.dispatch_observation_id)
            after = reader.get_observation(nxt.decision_observation_id)
        except Exception:  # noqa: BLE001 - history notes are best effort
            continue
        if before.foreground_app != after.foreground_app:
            continue
        if screen_fingerprint(before) == screen_fingerprint(after):
            out[prev.action_id] = "harness: screen unchanged after this scroll (end of scrollable content reached)"
        else:
            out[prev.action_id] = "harness: screen content moved after this scroll"
    return out


async def run_loop(
    controller: RunController,
    run_id: UUID,
    context: DecisionContext,
    budget: DecisionBudget,
    *,
    limits: LoopLimits = LoopLimits(),
    stage: Callable[[], str] | None = None,
    clock: Callable[[], float] = time.monotonic,
    end_condition: EndCondition | None = None,
) -> LoopResult:
    """Step until the completion action is acknowledged and verified, or a budget/no-progress stop.

    With ``end_condition`` (always given by ``JourneyRun``) a completion hint only triggers the
    harness check; without it (unit tests of the bare loop) the hint plus the action's own effect
    (open_app: that app in front) is the check."""
    t0 = clock()
    result = LoopResult(completed=False, stop_reason="")
    no_progress = 0
    actions = 0
    for n in range(1, limits.max_steps + 1):
        elapsed = clock() - t0
        if elapsed > limits.max_duration_s:
            result.stop_reason = f"scenario duration budget exceeded ({limits.max_duration_s:.0f} s)"
            break
        if actions >= limits.max_actions:
            result.stop_reason = f"scenario action budget exhausted ({limits.max_actions})"
            break
        halted = control_halt(controller, run_id)
        if halted is not None:
            result.control_stop = halted
            result.stop_reason = f"{halted}; no further steps"
            break
        ctx = context.model_copy(
            update={"session_history": history(controller, run_id), "scenario_stage": (stage() if stage else "journey")[:200]}
        )
        s0 = clock()
        outcome = await controller.step(run_id, ctx, budget)
        record = StepRecord(
            n=n,
            outcome=outcome.kind.value,
            reason=outcome.reason,
            started_at_s=s0 - t0,
            duration_ms=(clock() - s0) * 1000,
            stage=stage() if stage else None,  # after decide: the stage the proposal belongs to
            action_id=outcome.action_id,
            decision_id=outcome.decision_id,
            status=outcome.status.value if outcome.status else None,
            error_code=outcome.error_code.value if outcome.error_code else None,
        )
        result.steps.append(record)
        if outcome.action_id is not None:
            actions += 1
        if outcome.kind is OutcomeKind.STUCK:
            result.stop_reason = f"no progress: repeated semantic rebinding failures ({outcome.reason})"
            break
        if outcome.kind is OutcomeKind.PROVIDER_ERROR and outcome.error_class in FATAL_PROVIDER_ERRORS:
            result.stop_class = "provider_unavailable"
            result.stop_reason = f"provider unavailable ({outcome.error_class}): {outcome.reason}"
            break
        if outcome.kind in NO_PROGRESS:
            no_progress += 1
            if no_progress > limits.max_consecutive_no_progress:
                result.stop_reason = f"no progress after {no_progress} consecutive attempts: {outcome.reason}"
                break
            await asyncio.sleep(limits.retry_delay_s)
            continue
        no_progress = 0
        if outcome.kind is OutcomeKind.UNKNOWN and outcome.action_id and _is_commit(controller, outcome.action_id):
            result.stop_reason = f"commit outcome UNKNOWN ({outcome.reason}); stopped for receipt reconciliation"
            break
        if outcome.kind is OutcomeKind.ACKNOWLEDGED and outcome.decision_id is not None and outcome.action_id:
            if _is_completion(controller, outcome.decision_id):
                if end_condition is not None:
                    unmet = _end_condition_unmet(controller, run_id, end_condition)
                    verified = None
                    if unmet is None:
                        verified = await _verify_completion(controller, run_id, outcome.action_id, limits, clock,
                                                            expected_app=end_condition.final_app_id)  # fmt: skip
                        if verified is None:
                            unmet = f"{end_condition.final_app_id} not observed in the foreground"
                    if verified is None:
                        result.premature_completion_hints.append(
                            {"step": n, "action_id": str(outcome.action_id), "unmet": unmet})
                        if len(result.premature_completion_hints) >= end_condition.max_premature_hints:
                            result.stop_class = "premature_completion"
                            result.stop_reason = (f"model declared completion prematurely "
                                                  f"{len(result.premature_completion_hints)} times ({unmet})")  # fmt: skip
                            break
                        continue
                    result.completion_action_id = outcome.action_id
                    result.verification_observation_id = verified.observation_id
                    result.verification_foreground_app = verified.foreground_app
                    result.completed = True
                    result.stop_reason = "harness end condition met (send executed, final app observed) after a completion hint"
                    break
                result.completion_action_id = outcome.action_id
                verified = await _verify_completion(controller, run_id, outcome.action_id, limits, clock)
                if verified is not None:
                    result.verification_observation_id = verified.observation_id
                    result.verification_foreground_app = verified.foreground_app
                    result.completed = True
                    result.stop_reason = "completion action acknowledged and verified by observation"
                else:
                    result.stop_reason = "completion action acknowledged but its effect was not observed"
                break
    else:
        result.stop_reason = f"scenario step budget exhausted ({limits.max_steps})"
    result.elapsed_s = clock() - t0
    return result


def control_halt(controller: RunController, run_id: UUID) -> str | None:
    """Why the loop must not take another step (a pause/stop moved the run out of RUNNING, or an
    emergency stop closed the global gate), else None."""
    with controller.store.reader() as r:
        status = r.get_run(run_id).status
        gate = r.get_gate()
    if status is not RunStatus.RUNNING:
        return f"run left RUNNING (status {status.value})"
    if not gate.gate_open:
        return f"global gate closed ({gate.reason})"
    return None


def _is_commit(controller: RunController, action_id: UUID) -> bool:
    with controller.store.reader() as r:
        return r.get_action(action_id).side_effect_class is SideEffectClass.NON_IDEMPOTENT_COMMIT


def _end_condition_unmet(controller: RunController, run_id: UUID, cond: EndCondition) -> str | None:
    """None when the harness preconditions hold (before the foreground check), else why not."""
    if not cond.require_send:
        return None
    with controller.store.reader() as r:
        actions = r.list_actions(run_id=run_id)
    sent = [a for a in actions if a.kind is ActionKind.SEND_MESSAGE
            and a.status in (ActionStatus.ACKNOWLEDGED, ActionStatus.VERIFIED)]  # fmt: skip
    return None if sent else "no send_message has been executed and acknowledged"


def _is_completion(controller: RunController, decision_id: UUID) -> bool:
    with controller.store.reader() as r:
        decision = r.get_decision(decision_id)
    return decision.proposal is not None and decision.proposal.completion


async def _verify_completion(
    controller: RunController,
    run_id: UUID,
    action_id: UUID,
    limits: LoopLimits,
    clock: Callable[[], float],
    *,
    expected_app: str | None = None,
) -> Observation | None:
    """Observe until the completion action's effect is visible (open_app: that app in front; with
    ``expected_app``: that app in front)."""
    with controller.store.reader() as r:
        action = r.get_action(action_id)
    is_open = action.kind is ActionKind.OPEN_APP and isinstance(action.payload, OpenApp)
    expected = expected_app or (action.payload.app_id if is_open else None)  # type: ignore[union-attr]
    binding = controller.binding(run_id)
    worker = controller.worker(run_id)
    # Only an open_app needs time to take effect; any other completion action is checked once.
    deadline = clock() + (limits.verify_timeout_s if is_open else 0.0)
    while True:
        obs = await controller.engine.capture(worker, binding, "oracle")
        if expected is None or obs.foreground_app == expected:
            # The tree reports the new app before the switch animation ends: confirm after settling
            # so the verification screenshot shows the settled app (observed on the iOS 27 Simulator).
            await asyncio.sleep(limits.settle_s)
            settled = await controller.engine.capture(worker, binding, "oracle")
            if expected is None or settled.foreground_app == expected:
                return settled
        if clock() >= deadline:
            return None
        await asyncio.sleep(0.5)

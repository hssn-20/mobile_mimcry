"""End-to-end browse_then_reply run: fixture service, device worker, decision-provider loop, oracle, report.

Lifecycle: CREATED -> PREFLIGHT -> READY -> RUNNING -> COMPLETED (verdict + obtained evidence via
``transition_run``), or FAILED/ABORTED on preflight or harness failures. Raw environment logs (Appium,
worker, fixture service, request log) stay under ``work_dir``; the run's artifact set gets copies
with the per-run fixture credentials redacted, plus ``capability_report.json`` and ``journey.json``.
A verified report bundle is written for every run that reached the store, including failed and
interrupted ones (Ctrl-C / task cancellation: the run is stopped through the controller, every
process is torn down and the report is written before the interruption is re-raised).

Gate admission (CONTRACTS §7, §11): the run only reopens the global dispatch gate when start-up
recovery left no unreconciled run on this device and the gate was not closed by an emergency stop
or another operator action; otherwise the run fails with ENVIRONMENT_FAILURE unless the operator
passes ``reopen_gate=True``. The gate is closed again when the run finishes.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from mobilelab.candidates import generate_candidates, rebind
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.coordinator import RunController
from mobilelab.coordinator.types import RecoveryReport
from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import GateState
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionStatus, CapabilityStatus, ConfigKind, Platform, RunStatus, Verdict
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.runs import Run, RunSpec
from mobilelab.domain.transitions import POTENTIALLY_EXECUTED
from mobilelab.fixtures.clients import FixtureAdminClient, FixtureOracleClient
from mobilelab.fixtures.models import ResetResponse
from mobilelab.journey.environment import DeviceEnvironment, FixtureService, list_outbound_messages
from mobilelab.journey.evaluate import evaluate_run
from mobilelab.journey.loop import EndCondition, LoopLimits, LoopResult, run_loop
from mobilelab.journey.plan import REPO_ROOT, JourneyPlan
from mobilelab.journey.providers import (
    ProviderBuild,
    ProviderFactory,
    decision_budget,
    frozen_provider_config,
    model_goal,
    persona_dwell_policy,
    provider_stage,
    provider_usage,
    rules_factory,
)
from mobilelab.journey.redaction import scrub_raw_dir
from mobilelab.personas.sampling import PersonaSampler
from mobilelab.fixtures.layouts import layout_for_setup
from mobilelab.providers.script import BrowseThenReplyScript
from mobilelab.reporting import verify_report_integrity, write_report
from mobilelab.store import Store
from mobilelab.store.artifacts import ArtifactStore
from mobilelab.store.lock import CoordinatorLock
from mobilelab.workers import WorkerConfig, WorkerHandle

log = logging.getLogger(__name__)

DEFAULT_DB = REPO_ROOT / "artifacts" / "mobilelab.db"
DEFAULT_ARTIFACTS = REPO_ROOT / "artifacts"
COMMAND_MAX_DURATION_MS = 45_000
"""Covers the longest persona dwell (35 s) executed as one device wait; taps finish far sooner."""
DECISION_TIMEOUT_MS = 10_000
HOOK_GRACE_S = 180.0
EVIDENCE_FILES = ("appium.log", "worker.log", "fixture-service.log", "request_log.json")
_PRE_DISPATCH = (ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED, ActionStatus.PREPARED)
RUN_FINISHED_GATE_REASON = "mobilelab run finished"
BENIGN_GATE_REASONS = ("initial migration", "coordinator restart", RUN_FINISHED_GATE_REASON)
"""Closed-gate reasons a new run may reopen; anything else (emergency stop, operator) needs an override."""


@dataclass
class JourneyRunResult:
    run_id: UUID
    status: str
    verdict: str | None
    reason: str
    report_dir: Path | None
    integrity_ok: bool | None
    journey: dict[str, Any] = field(default_factory=dict)

    def brief(self) -> dict[str, Any]:
        j = self.journey
        loop = j.get("loop") or {}
        return {
            "run_id": str(self.run_id),
            "status": self.status,
            "verdict": self.verdict,
            "reason": self.reason,
            "evidence_source": j.get("evidence_source"),
            "journey_completed": loop.get("completed"),
            "stop_reason": loop.get("stop_reason"),
            "elapsed_s": loop.get("elapsed_s"),
            "sends": [
                {k: s.get(k) for k in ("client_message_id", "oracle_verdict", "oracle_reason", "status_after")}
                for s in (j.get("evaluation") or {}).get("sends", [])
            ],
            "census": (j.get("evaluation") or {}).get("census"),
            "report_dir": str(self.report_dir) if self.report_dir else None,
            "report_integrity_ok": self.integrity_ok,
        }


def redact(text: str, secrets: list[str]) -> str:
    for s in secrets:
        if s:
            text = text.replace(s, "[REDACTED]")
    return text


@dataclass(frozen=True)
class ExternalFixture:
    """A fixture service owned by the caller (restart-recovery experiments): the run neither starts,
    resets nor stops it; ``reset`` must be for this run's id."""

    admin_url: str
    admin_secret: str
    reset: ResetResponse


LoopHook = Callable[["JourneyRun"], Awaitable[None]]
"""Runs concurrently with the decision loop (live control experiments: pause/resume, emergency
stop). It receives the run and may call the controller; the loop stops on its own once the run
leaves RUNNING or the global gate closes."""


async def _no_reconciler(_action: ActionRecord) -> None:
    """Start-up recovery of *earlier* runs: their fixture namespaces no longer exist, so nothing can be
    verified. Returning None keeps them in recovery PAUSING (uncertainty preserved, nothing resent)."""
    return None


def gate_admission_problems(
    gate_before: GateState, recovery: RecoveryReport, run_devices: dict[UUID, UUID], device_id: UUID
) -> list[str]:
    """Why this run may not reopen the global gate (empty list: it may).

    ``gate_before`` is the gate as persisted *before* start-up recovery; ``run_devices`` maps each
    recovered run to its device."""
    problems: list[str] = []
    if not gate_before.gate_open and not (gate_before.reason or "").startswith(BENIGN_GATE_REASONS):
        problems.append(f"global gate was closed by: {gate_before.reason!r}")
    for run_id in recovery.recovered_run_ids:
        if run_id not in recovery.paused_run_ids and run_devices.get(run_id) == device_id:
            problems.append(f"run {run_id} on this device is still unreconciled after restart recovery")
    return problems


class JourneyRun:
    """One run. ``execute()`` never raises for run failures: they become run status + verdict."""

    def __init__(
        self,
        plan: JourneyPlan,
        env: DeviceEnvironment,
        *,
        db_path: Path = DEFAULT_DB,
        artifacts_root: Path = DEFAULT_ARTIFACTS,
        work_dir: Path | None = None,
        limits: LoopLimits | None = None,
        progress: Callable[[str], None] = lambda _msg: None,
        reopen_gate: bool = False,
        provider_factory: ProviderFactory | None = None,
        provider_options: dict[str, Any] | None = None,
        run_id: UUID | None = None,
        external_fixture: ExternalFixture | None = None,
        loop_hook: LoopHook | None = None,
        worker_config_overrides: dict[str, Any] | None = None,
    ) -> None:
        self.plan, self.env, self.progress = plan, env, progress
        self.reopen_gate = reopen_gate
        self.gate_problems: list[str] = []
        self.run_id = run_id or uuid4()
        self.provider_factory: ProviderFactory = provider_factory or rules_factory
        self.provider_options = dict(provider_options or {})
        self.provider: Any = None
        self.script: BrowseThenReplyScript | None = None
        self.sampler: PersonaSampler | None = None
        self.external_fixture = external_fixture
        if external_fixture is not None and external_fixture.reset.run_id != self.run_id:
            raise ValueError("external fixture reset belongs to another run id")
        self.loop_hook = loop_hook
        self.worker_config_overrides = dict(worker_config_overrides or {})
        self.loop_resumes: list[dict[str, Any]] = []
        self.db_path, self.artifacts_root = db_path, artifacts_root
        self.work = work_dir or REPO_ROOT / "build" / "runs" / str(self.run_id)
        self.limits = limits
        self.store: Store | None = None
        self.artifacts = ArtifactStore(artifacts_root)
        self.fixture = FixtureService(self.work)
        self.worker: WorkerHandle | None = None
        self.controller: RunController | None = None
        self.reset: ResetResponse | None = None
        self.secrets: list[str] = []
        self.run_created = False
        self.status, self.verdict, self.reason = "NOT_CREATED", None, ""
        self.journey: dict[str, Any] = {
            "run_id": str(self.run_id),
            "scenario_id": plan.scenario.scenario_id,
            "variant": plan.variant,
            "adapter": env.adapter_name,
            "evidence_source": env.evidence_source.value,
            "evidence_note": "real iOS Simulator via Appium/WebDriverAgent"
            if env.evidence_source.value == "device"
            else "MOCK adapter: harness logic only, never device evidence",
            "provider": None,
            "seed": plan.seed,
            "dwell_mode": plan.dwell_mode,
        }

    async def execute(self) -> JourneyRunResult:
        self.work.mkdir(parents=True, exist_ok=True)
        lock = CoordinatorLock(self.db_path)
        lock.acquire()
        t0 = time.monotonic()
        self.journey["started_at"] = utc_now().isoformat()
        interrupted: BaseException | None = None
        try:
            self.store = Store.open(self.db_path)
            try:
                await self._run()
            except Exception as exc:
                self.reason = f"harness error: {type(exc).__name__}: {exc}"[:2000]
                self.journey["error"] = self.reason
                log.exception("journey run %s failed", self.run_id)
                if self.run_created:
                    await self._fail_run()
            except (asyncio.CancelledError, KeyboardInterrupt) as exc:
                interrupted = exc
                task = asyncio.current_task()
                if task is not None:
                    task.uncancel()  # the cleanup below must run to completion; re-raised afterwards
                self.reason = f"interrupted ({type(exc).__name__}) before the run finished"
                self.journey["interrupted"] = True
                self.journey["error"] = self.reason
                log.warning("journey run %s interrupted; stopping and tearing down", self.run_id)
                if self.run_created:
                    await self._abort_interrupted()
            self.journey["wall_s"] = round(time.monotonic() - t0, 1)
            result = await self._finish()
            if interrupted is not None:
                raise interrupted
            return result
        finally:
            if self.store is not None:
                self.store.close()
            lock.release()

    # -- the run -----------------------------------------------------------------------------------

    async def _run(self) -> None:
        plan, env, store = self.plan, self.env, self._store()
        if self.external_fixture is not None:
            self.progress("using the caller's fixture service")
            ext = self.external_fixture
            self.fixture.admin_url, self.fixture.admin_secret = ext.admin_url, ext.admin_secret
            self.secrets.append(ext.admin_secret)
            reset = self.reset = ext.reset
            self.secrets += [reset.sender.token, reset.receiver.token, reset.oracle.token]
        else:
            self.progress("starting fixture service")
            self.fixture.start()
            self.secrets.append(self.fixture.admin_secret)
            async with FixtureAdminClient(self.fixture.admin_url, self.fixture.admin_secret) as admin:
                reset = self.reset = await admin.reset(self.run_id, layout=layout_for_setup(plan.scenario.fixture_setup))
                self.secrets += [reset.sender.token, reset.receiver.token, reset.oracle.token]
        faults = plan.fault_specs()
        if faults:
            async with FixtureAdminClient(self.fixture.admin_url, self.fixture.admin_secret) as admin:
                schedule = await admin.set_faults(self.run_id, faults)
            self.journey["fixture_faults"] = [f.model_dump(mode="json") for f in schedule.faults]
        self.journey["fixture"] = {"data_base_url": reset.data_base_url, "receiver_id": reset.receiver.receiver_id}
        scope, script = plan.scope(reset.data_base_url), plan.script(reset.data_base_url)
        self._build_provider(scope, script)

        self.progress(f"setting up the {env.adapter_name} device environment")
        env.setup(self.work)
        controller = self.controller = RunController(
            store, self.artifacts, scope, generate=generate_candidates, rebind=rebind,
            provider=None, reconciler=_no_reconciler, command_max_duration_ms=COMMAND_MAX_DURATION_MS,
        )  # fmt: skip
        with store.reader() as r:
            gate_before = r.get_gate()
        recovery = await controller.recover()
        self.journey["startup_recovery"] = recovery.model_dump(mode="json")
        self._create_run(scope)
        if not await self._admit(gate_before, recovery):
            return

        self.progress("spawning the device worker")
        opts = env.adapter_options(
            reset=reset, origins=list(scope.allowed_url_origins),
            probe_url=f"{scope.allowed_url_origins[0]}/fixture/v1/articles/{script.start_article}",
        )  # fmt: skip
        self.worker = await WorkerHandle.spawn(
            env.adapter_name,
            WorkerConfig(device_id=env.device_id, adapter_options=opts, **self.worker_config_overrides),
            stderr=self.work / "worker.log",
        )
        self._write_processes()
        if not await self._preflight():
            return
        env.prepare_apps()
        await self._journey(controller, scope, script)

    def _store(self) -> Store:
        assert self.store is not None
        return self.store

    def _create_run(self, scope: ScenarioScope) -> None:
        plan, env = self.plan, self.env
        profile = env.profile()
        info = self.provider.provider_info
        provider_config = {
            **plan.provider_config,
            "label": info.name,
            "kind": info.kind,
            "provider_version": info.version,
            "deployment": info.deployment,
            "supports_images": info.supports_images,
            "observation_modality": "text" if not info.supports_images else "text+image",
            **frozen_provider_config(self.provider),
            "fixture_data_origin": scope.allowed_url_origins[0],
        }
        spec = RunSpec(
            scenario_id=plan.scenario.scenario_id,
            scenario_version=plan.scenario.version,
            scenario_hash=plan.scenario_hash,
            persona_id=plan.persona.persona_id,
            persona_version=plan.persona.version,
            persona_hash=plan.persona_hash,
            provider_id=info.kind,
            provider_config=provider_config,
            provider_config_hash=config_hash(provider_config),
            model_identifier=info.model,
            app_builds=env.app_builds(),
            adapter_versions=env.adapter_versions(),
            seed=plan.seed,
            device_id=env.device_id,
            platform=Platform.IOS,
            device_kind=env.device_kind,
            device_profile_hash=config_hash(profile.model_dump(mode="json", exclude={"created_at", "version"})),
            planned_evidence=plan.scenario.platform_evidence,
            policy_limits={
                "max_dispatch_observation_age_ms": 2000,
                "command_max_duration_ms": COMMAND_MAX_DURATION_MS,
                "decision_timeout_ms": self._decision_budget().timeout_ms,
                "decision_max_input_tokens": self._decision_budget().max_input_tokens,
                "decision_max_output_tokens": self._decision_budget().max_output_tokens,
                "decision_max_cost_usd": self._decision_budget().max_cost_usd,
                "max_steps": plan.scenario.max_steps or 40,
                "max_actions": plan.scenario.max_actions,
                "max_duration_seconds": plan.scenario.max_duration_seconds,
                "text_max_length": scope.text_policy.max_length,
                "max_wait_ms": scope.max_wait_ms,
                "preflight": "non_strict: unsupported required capabilities block; unverified ones are recorded",
            },
        )
        with self._store().unit_of_work() as uow:
            uow.upsert_device_profile(profile)
            uow.add_config_revision(ConfigKind.SCENARIO, plan.scenario.scenario_id, plan.scenario)
            uow.add_config_revision(ConfigKind.PERSONA, plan.persona.persona_id, plan.persona)
            uow.add_config_revision(ConfigKind.PROVIDER, info.kind, provider_config)
            uow.add_run(Run(run_id=self.run_id, spec=spec))
            uow.transition_run(self.run_id, RunStatus.PREFLIGHT, reason="device preflight")
        self.run_created = True

    async def _admit(self, gate_before: GateState, recovery: RecoveryReport) -> bool:
        """Gate admission before any device work (see the module docstring)."""
        store = self._store()
        with store.reader() as r:
            devices = {rid: r.get_run(rid).spec.device_id for rid in recovery.recovered_run_ids}
        problems = self.gate_problems = gate_admission_problems(gate_before, recovery, devices, self.env.device_id)
        self.journey["gate_admission"] = {
            "gate_before": gate_before.model_dump(mode="json"),
            "problems": problems,
            "operator_reopen_gate": self.reopen_gate,
        }
        if not problems:
            return True
        if self.reopen_gate:
            self.journey["gate_admission"]["abandoned_runs"] = self._abandon_unreconciled(recovery, devices)
            return True
        self.reason = "gate kept closed: " + "; ".join(problems) + " (rerun with --reopen-gate after checking)"
        with store.unit_of_work() as uow:
            uow.transition_run(self.run_id, RunStatus.FAILED, reason=self.reason[:2000], verdict=Verdict.ENVIRONMENT_FAILURE)
        self.status, self.verdict = RunStatus.FAILED.value, Verdict.ENVIRONMENT_FAILURE.value
        return False

    def _abandon_unreconciled(self, recovery: RecoveryReport, devices: dict[UUID, UUID]) -> list[str]:
        """Operator override: earlier unreconciled runs on this device end ABORTED/INCONCLUSIVE and
        their potentially executed actions become UNRESOLVED (uncertainty recorded, nothing resent)."""
        abandoned: list[str] = []
        reason = f"abandoned by operator --reopen-gate before run {self.run_id}; potentially executed actions UNRESOLVED"
        for run_id in recovery.recovered_run_ids:
            if run_id in recovery.paused_run_ids or devices.get(run_id) != self.env.device_id:
                continue
            with self._store().unit_of_work() as uow:
                for action in uow.list_actions(run_id=run_id, statuses=POTENTIALLY_EXECUTED):
                    if action.status is not ActionStatus.UNKNOWN:
                        uow.transition_action(action.action_id, ActionStatus.UNKNOWN)
                    uow.transition_action(action.action_id, ActionStatus.UNRESOLVED)
                if uow.get_run(run_id).status is not RunStatus.STOPPING:
                    uow.transition_run(run_id, RunStatus.STOPPING, reason=reason)
                uow.transition_run(run_id, RunStatus.ABORTED, reason=reason, verdict=Verdict.INCONCLUSIVE)
            abandoned.append(str(run_id))
        return abandoned

    async def _preflight(self) -> bool:
        assert self.worker is not None
        self.progress("preflight (the first session may build WebDriverAgent)")
        t0 = time.monotonic()
        report = await self.worker.preflight(self.env.profile())
        self.journey["preflight_s"] = round(time.monotonic() - t0, 1)
        with self._store().unit_of_work() as uow:
            uow.add_capability_report(report)
        self._store_json("capability_report.json", report.model_dump(mode="json"))
        caps = {r.key.value: r.status.value for r in report.records}
        required = [c.value for c in self.plan.scenario.required_capabilities]
        blocked = [c for c in required if caps.get(c) in (None, CapabilityStatus.UNSUPPORTED.value)]
        self.journey["preflight"] = {
            "capabilities": caps,
            "required": required,
            "blocked": blocked,
            "unverified_required": [c for c in required if caps.get(c) == CapabilityStatus.UNVERIFIED.value],
        }
        with self._store().unit_of_work() as uow:
            if blocked:
                self.reason = f"preflight: required capabilities unavailable: {blocked}"
                uow.transition_run(self.run_id, RunStatus.FAILED, reason=self.reason, verdict=Verdict.UNSUPPORTED)
                self.status, self.verdict = RunStatus.FAILED.value, Verdict.UNSUPPORTED.value
                return False
            uow.transition_run(self.run_id, RunStatus.READY, reason="preflight passed")
            who = "operator override (--reopen-gate)" if self.gate_problems else "mobilelab run"
            uow.open_gate(f"{who}: {self.plan.scenario.scenario_id} ({self.run_id})")
        return True

    def _build_provider(self, scope: ScenarioScope, script: BrowseThenReplyScript) -> None:
        plan, env = self.plan, self.env
        self.script = script
        self.sampler = PersonaSampler(plan.persona, run_seed=plan.seed, device_id=env.device_id, mode=plan.dwell_mode)  # type: ignore[arg-type]
        build = ProviderBuild(
            name=getattr(self.provider_factory, "__name__", "provider"),
            run_id=self.run_id,
            script=script,
            scope=scope,
            sampler=self.sampler,
            scenario=plan.scenario,
            persona=plan.persona,
            options={"epoch_probe": self._epoch_probe, **self.provider_options},
        )
        provider = self.provider = self.provider_factory(build)
        info = provider.provider_info
        self.journey["provider"] = info.name
        self.journey["provider_info"] = info.model_dump(mode="json")

    def _epoch_probe(self) -> int:
        """Current persisted control epoch of this run (providers discard late results with it)."""
        with self._store().reader() as r:
            return r.get_run(self.run_id).control_epoch

    def _decision_budget(self) -> DecisionBudget:
        # RulesProvider spends nothing; its token/cost fields are inert lower bounds.
        default = DecisionBudget(timeout_ms=DECISION_TIMEOUT_MS, max_input_tokens=1, max_output_tokens=1, max_cost_usd=0)
        return decision_budget(self.provider, default)

    def _goal(self) -> str:
        """RulesProvider follows its script; a model provider gets the trusted scenario briefing."""
        plan = self.plan
        if self.provider is None or self.provider.provider_info.kind == "rules" or self.script is None:
            return plan.scenario.goal
        return model_goal(plan.scenario, self.script, self.run_id)

    def _context(self, scope: ScenarioScope, control_epoch: int) -> DecisionContext:
        plan = self.plan
        return DecisionContext(
            run_id=self.run_id,
            persona=plan.persona,
            scenario_id=plan.scenario.scenario_id,
            scenario_version=plan.scenario.version,
            scenario_stage=provider_stage(self.provider),
            goal=self._goal(),
            authorized_app_ids=list(scope.allowed_app_ids),
            authorized_contact_ids=list(scope.allowed_contact_ids),
            authorized_url_origins=list(scope.allowed_url_origins),
            control_epoch=control_epoch,
        )

    async def _journey(self, controller: RunController, scope: ScenarioScope, script: BrowseThenReplyScript) -> None:
        plan, env = self.plan, self.env
        assert self.worker is not None and self.reset is not None
        reset = self.reset
        provider = self.provider
        controller.provider = provider
        controller.dwell_policy = persona_dwell_policy(provider, self.sampler)
        controller.attach_worker(self.worker)
        binding = await controller.start(self.run_id)
        budget = self._decision_budget()
        limits = self.limits or LoopLimits(
            max_steps=plan.scenario.max_steps or 40,
            max_actions=plan.scenario.max_actions,
            max_duration_s=float(plan.scenario.max_duration_seconds),
        )
        self.journey["loop_limits"] = {**limits.__dict__, "source": "override" if self.limits else "scenario"}
        self.progress("running the decision loop")
        hook_task = asyncio.ensure_future(self.loop_hook(self)) if self.loop_hook is not None else None
        try:
            loop = await self._drive(controller, scope, binding.control_epoch, budget, limits, hook_task)
        finally:
            if hook_task is not None:
                # Let the hook finish its measurements (it may still be watching the fence or
                # stopping the run); cancel it only if it overstays.
                with contextlib.suppress(Exception, asyncio.CancelledError):
                    await asyncio.wait({hook_task}, timeout=HOOK_GRACE_S)
                if not hook_task.done():
                    hook_task.cancel()
                    self.journey["loop_hook_error"] = f"loop hook still running {HOOK_GRACE_S:.0f} s after the loop; cancelled"
                with contextlib.suppress(asyncio.CancelledError):
                    exc = await asyncio.gather(hook_task, return_exceptions=True)
                    if exc and isinstance(exc[0], BaseException) and not isinstance(exc[0], asyncio.CancelledError):
                        self.journey["loop_hook_error"] = f"{type(exc[0]).__name__}: {exc[0]}"[:1000]
        self.journey["loop"] = loop.as_json()
        if self.loop_resumes:
            self.journey["loop_resumes"] = self.loop_resumes
        self.journey["provider_outcomes"] = getattr(provider, "outcomes", None)
        self.journey["dwell_draws"] = [d.model_dump(mode="json") for d in self.sampler.draws] if self.sampler else []

        self.progress("evaluating the receipt oracle and reconciling the send")
        async with FixtureOracleClient(reset.data_base_url, reset.oracle.token) as oracle_client:
            evaluation = await evaluate_run(
                self._store(),
                self.run_id,
                scenario_id=plan.scenario.scenario_id,
                oracle_definitions=plan.scenario.oracles,
                receipts=oracle_client,
                census=lambda: list_outbound_messages(reset),  # whole run namespace, all conversations
                sender_id=reset.sender.sender_id,
                evidence_source=env.evidence_source,
                journey_completed=loop.completed,
                journey_reason=loop.stop_reason,
                journey_stop_class=loop.stop_class,
            )
        self.journey["evaluation"] = evaluation.as_json()
        with self._store().reader() as r:
            current = r.get_run(self.run_id)
        if current.status is not RunStatus.RUNNING:
            # A control (stop / emergency stop) ended or held the run; its state is the outcome.
            self.status = current.status.value
            self.verdict = current.verdict.value if current.verdict else None
            self.reason = f"run left RUNNING under control ({current.status.value}): {current.status_reason or ''}"[:2000]
            return
        run = await controller.complete(
            self.run_id,
            verdict=evaluation.verdict,
            reason=evaluation.reason,
            obtained_evidence=evaluation.obtained_evidence,
            obtained_evidence_source=evaluation.obtained_evidence_source,
            # An unusable model provider is an environment failure: the run FAILED, it did not complete.
            failed=evaluation.verdict is Verdict.ENVIRONMENT_FAILURE and loop.stop_class == "provider_unavailable",
        )
        self.status, self.verdict, self.reason = run.status.value, run.verdict.value if run.verdict else None, evaluation.reason

    def _end_condition(self) -> EndCondition:
        """Harness end condition for browse_then_reply: the reply was sent and Safari is back in front."""
        assert self.script is not None
        return EndCondition(final_app_id=self.script.safari_app_id, require_send=True)

    async def _drive(
        self,
        controller: RunController,
        scope: ScenarioScope,
        control_epoch: int,
        budget: DecisionBudget,
        limits: LoopLimits,
        hook_task: asyncio.Future[None] | None,
    ) -> LoopResult:
        """Run the loop; when a control paused the run, wait for the hook's resume (``start`` again:
        new lease epoch + control epoch, fresh observation) and continue with the remaining budget."""
        provider = self.provider
        merged: LoopResult | None = None
        t0 = time.monotonic()
        while True:
            remaining = LoopLimits(**{**limits.__dict__, "max_duration_s": max(1.0, limits.max_duration_s - (time.monotonic() - t0))})
            context = self._context(scope, control_epoch)
            loop = await run_loop(controller, self.run_id, context, budget, limits=remaining,
                                  stage=lambda: provider_stage(provider), end_condition=self._end_condition())  # fmt: skip
            merged = loop if merged is None else _merge_loops(merged, loop)
            if loop.completed or hook_task is None or not (loop.control_stop or "").startswith("run left RUNNING"):
                return merged
            # Paused by the control hook: wait for it to resume (start) or to finish without resuming.
            resumed = await self._await_resume(controller, hook_task)
            if resumed is None:
                return merged
            control_epoch = resumed.control_epoch
            self.loop_resumes.append({"at": utc_now().isoformat(), "lease_epoch": resumed.lease_epoch,
                                      "control_epoch": resumed.control_epoch, "lease_id": str(resumed.lease_id)})  # fmt: skip

    async def _await_resume(self, controller: RunController, hook_task: asyncio.Future[None]) -> Any:
        while True:
            with self._store().reader() as r:
                status = r.get_run(self.run_id).status
            if status is RunStatus.RUNNING:
                return controller.binding(self.run_id)
            if hook_task.done() or status not in (RunStatus.PAUSING, RunStatus.PAUSED):
                return None
            await asyncio.sleep(0.1)

    async def _fail_run(self) -> None:
        store = self._store()
        with store.reader() as r:
            run = r.get_run(self.run_id)
        try:
            if run.status is RunStatus.RUNNING and self.controller is not None:
                run = await self.controller.complete(
                    self.run_id, verdict=Verdict.HARNESS_FAILURE, reason=self.reason, failed=True
                )
            elif run.status is RunStatus.PREFLIGHT:
                with store.unit_of_work() as uow:
                    run = uow.transition_run(self.run_id, RunStatus.FAILED, reason=self.reason, verdict=Verdict.HARNESS_FAILURE)
            elif run.status not in (RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.ABORTED):
                with store.unit_of_work() as uow:
                    if run.status is not RunStatus.CREATED and run.status is not RunStatus.STOPPING:
                        uow.transition_run(self.run_id, RunStatus.STOPPING, reason=self.reason)
                    run = uow.transition_run(self.run_id, RunStatus.ABORTED, reason=self.reason, verdict=Verdict.HARNESS_FAILURE)
        except Exception:  # keep the original error; the report shows the run's actual state
            log.exception("could not record the harness failure for run %s", self.run_id)
        self.status, self.verdict = run.status.value, run.verdict.value if run.verdict else None

    async def _abort_interrupted(self) -> None:
        """Interrupted run: stop through the controller (fence + settle + lease release, journaled),
        else record ABORTED with the uncertainty. Never resends; sends stay as journaled."""
        store = self._store()
        with store.reader() as r:
            run = r.get_run(self.run_id)
        try:
            self._settle_interrupted_actions()
            if run.status is RunStatus.RUNNING and self.controller is not None:
                res = await self.controller.stop(self.run_id)
                self.journey["interrupt_stop"] = res.model_dump(mode="json")
                with store.reader() as r:
                    run = r.get_run(self.run_id)
            if run.status not in (RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.ABORTED):
                quarantined = run.spec.device_id in (self.controller.quarantined if self.controller else set())
                reason = self.reason + ("; stop not confirmed, device quarantined" if quarantined else "")
                with store.unit_of_work() as uow:
                    if run.status not in (RunStatus.CREATED, RunStatus.STOPPING):
                        uow.transition_run(self.run_id, RunStatus.STOPPING, reason=reason)
                    run = uow.transition_run(
                        self.run_id, RunStatus.ABORTED, reason=reason[:2000],
                        verdict=Verdict.HARNESS_FAILURE if quarantined else None,
                    )  # fmt: skip
                    lease = uow.get_active_lease(run.spec.device_id)
                    if lease is not None and lease.run_id == self.run_id:
                        uow.release_lease(lease.lease_id, reason="run interrupted")
        except Exception:  # keep the interruption; the report shows the run's actual state
            log.exception("could not record the interruption of run %s", self.run_id)
        with store.reader() as r:
            run = r.get_run(self.run_id)
        self.status, self.verdict = run.status.value, run.verdict.value if run.verdict else None

    def _settle_interrupted_actions(self) -> None:
        """The interrupted step may have left its action mid-journal: never-sent actions are
        CANCELLED; a PREPARED action whose command may have reached the worker becomes UNKNOWN."""
        with self._store().unit_of_work() as uow:
            for action in uow.list_actions(run_id=self.run_id, statuses=_PRE_DISPATCH):
                sent = action.status is ActionStatus.PREPARED and any(
                    a.result is None for a in uow.list_attempts(action.action_id)
                )
                if sent:
                    uow.transition_action(action.action_id, ActionStatus.DISPATCHED)
                    uow.transition_action(action.action_id, ActionStatus.UNKNOWN)
                else:
                    uow.transition_action(action.action_id, ActionStatus.CANCELLED)

    # -- teardown, evidence, report ----------------------------------------------------------------

    async def _teardown(self) -> dict[str, Any]:
        info: dict[str, Any] = {}
        if self.worker is not None:
            try:
                closed = await self.worker.close(timeout_s=30.0)
                info["worker_closed"], info["worker_close_detail"] = closed.closed, closed.detail
            except Exception as exc:
                info["worker_close_error"] = f"{type(exc).__name__}: {exc}"[:500]
        try:
            info |= self.env.teardown()
        except Exception as exc:
            info["env_teardown_error"] = f"{type(exc).__name__}: {exc}"[:500]
        if self.reset is not None and (self.fixture.proc is not None or self.external_fixture is not None):
            try:
                async with FixtureAdminClient(self.fixture.admin_url, self.fixture.admin_secret) as admin:
                    entries = await admin.request_log(self.run_id, include_unscoped=True)
                    ground = await admin.ground_truth(self.run_id)
                self.journey["fixture_requests"] = {
                    "total": len(entries),
                    "message_posts": sum(1 for e in entries if e.method == "POST" and e.path == "/fixture/v1/messages"),
                    "acknowledgement_posts": sum(1 for e in entries if e.method == "POST" and e.path.endswith("/acknowledgements")),
                }
                self.journey["fault_ground_truth"] = [g.model_dump(mode="json") for g in ground]
                (self.work / "request_log.json").write_text(
                    json.dumps([e.model_dump(mode="json") for e in entries], indent=2), encoding="utf-8"
                )
            except Exception as exc:
                info["request_log_error"] = f"{type(exc).__name__}: {exc}"[:500]
        info["fixture_service_exit"] = self.fixture.stop()
        return info

    def _close_gate(self) -> None:
        with self._store().unit_of_work() as uow:
            if uow.get_gate().gate_open:
                uow.close_gate(f"{RUN_FINISHED_GATE_REASON} ({self.run_id})")

    async def _finish(self) -> JourneyRunResult:
        self.journey["teardown"] = await self._teardown()
        await self._close_provider()
        try:
            self.journey["raw_log_redaction"] = scrub_raw_dir(self.work, self.secrets)
        except Exception as exc:
            self.journey["raw_log_redaction"] = {"error": f"{type(exc).__name__}"}
        if self.store is not None:
            try:
                self._close_gate()
            except Exception as exc:
                self.journey["teardown"]["gate_close_error"] = f"{type(exc).__name__}: {exc}"[:500]
        self.journey["finished_at"] = utc_now().isoformat()
        self.journey["raw_environment_dir"] = str(self.work)
        self.journey |= {"status": self.status, "verdict": self.verdict, "reason": self.reason}
        if not self.run_created:
            self._write_local_journey()
            return JourneyRunResult(self.run_id, self.status, self.verdict, self.reason, None, None, self.journey)
        for name in EVIDENCE_FILES:
            path = self.work / name
            if path.is_file():
                text = redact(path.read_text(encoding="utf-8", errors="replace"), self.secrets)
                ctype = "application/json" if name.endswith(".json") else "text/plain"
                self._store_bytes(name, text.encode(), ctype)
        if self.journey.get("provider_usage") is not None:
            self._store_json("provider_usage.json", json.loads(redact(json.dumps(self.journey["provider_usage"], default=str), self.secrets)))
        meta = self._store_json("journey.json", json.loads(redact(json.dumps(self.journey, default=str), self.secrets)))
        store = self._store()
        with store.reader() as r:
            run = r.get_run(self.run_id)
        bundle = write_report(store, self.run_id, self.artifacts_root)
        integrity = verify_report_integrity(bundle.directory)
        self.journey["journey_artifact_id"] = str(meta.artifact_id)
        self.journey["report_integrity"] = {
            "ok": integrity.ok, "problems": list(integrity.problems), "files_checked": integrity.files_checked,
        }  # fmt: skip
        self._write_local_journey()
        return JourneyRunResult(
            self.run_id, run.status.value, run.verdict.value if run.verdict else None,
            run.status_reason or self.reason, bundle.directory, integrity.ok, self.journey,
        )  # fmt: skip

    async def _close_provider(self) -> None:
        if self.provider is None:
            return
        try:
            usage = provider_usage(self.provider, self.run_id)
        except Exception as exc:
            usage = {"error": f"usage snapshot failed: {type(exc).__name__}"}
        info = self.provider.provider_info
        self.journey["provider_usage"] = {
            "provider_kind": info.kind,
            "provider_label": info.name,
            "model_identifier": info.model,
            "deployment": info.deployment,
            "supports_images": info.supports_images,
            **(usage if usage is not None else {"usage_reported": False, "note": "provider spends nothing / reports no usage"}),
        }
        closer = getattr(self.provider, "aclose", None)
        if callable(closer):
            try:
                await closer()
            except Exception as exc:
                self.journey["provider_close_error"] = f"{type(exc).__name__}"

    def _write_processes(self) -> None:
        """PIDs of the processes this coordinator started (diagnostics; restart experiments use it to
        clean up after a deliberately killed coordinator)."""
        import os

        server = getattr(self.env, "server", None)
        proc = getattr(server, "_proc", None)
        info = {
            "coordinator_pid": os.getpid(),
            "worker_pid": self.worker.pid if self.worker is not None else None,
            "appium_pid": proc.pid if proc is not None else None,
            "fixture_pid": self.fixture.proc.pid if self.fixture.proc is not None else None,
        }
        (self.work / "processes.json").write_text(json.dumps(info), encoding="utf-8")

    def _write_local_journey(self) -> None:
        text = redact(json.dumps(self.journey, indent=2, default=str), self.secrets)
        (self.work / "journey.json").write_text(text, encoding="utf-8")

    def _store_bytes(self, name: str, data: bytes, content_type: str) -> ArtifactMetadata:
        meta = self.artifacts.write_bytes(
            data, filename=name, content_type=content_type, evidence_source=self.env.evidence_source, run_id=self.run_id
        )
        with self._store().unit_of_work() as uow:
            uow.add_artifact(meta)
        return meta

    def _store_json(self, name: str, data: Any) -> ArtifactMetadata:
        return self._store_bytes(name, json.dumps(data, indent=2, default=str).encode(), "application/json")


def _merge_loops(a: LoopResult, b: LoopResult) -> LoopResult:
    offset = len(a.steps)
    for st in b.steps:
        st.n += offset
    return LoopResult(
        completed=b.completed,
        stop_reason=b.stop_reason,
        steps=[*a.steps, *b.steps],
        completion_action_id=b.completion_action_id,
        verification_observation_id=b.verification_observation_id,
        verification_foreground_app=b.verification_foreground_app,
        elapsed_s=a.elapsed_s + b.elapsed_s,
        control_stop=b.control_stop,
        premature_completion_hints=[*a.premature_completion_hints, *b.premature_completion_hints],
        stop_class=b.stop_class,
    )


async def run_journey(plan: JourneyPlan, env: DeviceEnvironment, **kw: Any) -> JourneyRunResult:
    return await JourneyRun(plan, env, **kw).execute()

"""Load the versioned persona catalogue from configs/personas/*.json (each file a PersonaCatalog)."""

from __future__ import annotations

import json
from pathlib import Path

from mobilelab.domain.errors import NotFound
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.personas import PersonaCatalog, PersonaConfig

DEFAULT_PERSONA_DIR = Path(__file__).resolve().parents[3] / "configs" / "personas"


def load_persona_file(path: Path) -> PersonaCatalog:
    return PersonaCatalog.model_validate(json.loads(path.read_text(encoding="utf-8")))


def load_persona_catalog(directory: Path = DEFAULT_PERSONA_DIR) -> dict[tuple[str, int], PersonaCatalog]:
    """``(persona_id, version)`` -> the file it came from. Duplicate revisions across files are rejected."""
    out: dict[tuple[str, int], PersonaCatalog] = {}
    for path in sorted(directory.glob("*.json")):
        catalog = load_persona_file(path)
        for persona in catalog.personas:
            key = (persona.persona_id, persona.version)
            if key in out:
                raise ValueError(f"duplicate persona revision {key} in {path.name}")
            out[key] = catalog
    return out


def get_persona(persona_id: str, version: int, directory: Path = DEFAULT_PERSONA_DIR) -> PersonaConfig:
    catalog = load_persona_catalog(directory).get((persona_id, version))
    if catalog is None:
        raise NotFound(f"persona {persona_id} v{version} not found", details={"directory": str(directory)})
    return next(p for p in catalog.personas if (p.persona_id, p.version) == (persona_id, version))


def persona_hash(persona: PersonaConfig) -> str:
    """Content hash frozen into a run (CONTRACTS §2)."""
    return config_hash(persona)

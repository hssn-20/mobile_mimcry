"""Seeded, independent persona random streams and recorded dwell draws (CONTRACTS §8).

Each (stream, category) pair gets its own ``random.Random`` seeded from SHA-256 of the run seed,
device ID, stream name and category, so draws in one category never shift another. Every draw is
recorded with its index so it can be persisted once and replayed. The full semi-Markov scheduler is
backlog T09; M1 exposes only ``sample_dwell``.
"""

from __future__ import annotations

import hashlib
import math
import random
from typing import Literal
from uuid import UUID

from pydantic import Field

from mobilelab.domain.base import FrozenModel
from mobilelab.domain.personas import DurationDistribution, PersonaConfig, RandomStream

DwellCategory = Literal["reading_dwell", "reply_delay"]
DwellMode = Literal["median", "lognormal"]


def derive_stream_seed(run_seed: int, device_id: UUID, stream: RandomStream, category: str) -> int:
    material = f"mobilelab/v1|{run_seed}|{device_id}|{stream}|{category}".encode()
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "big")


class DwellDraw(FrozenModel):
    persona_id: str
    persona_version: int = Field(ge=1)
    stream: RandomStream
    category: DwellCategory
    draw_index: int = Field(ge=0)
    mode: DwellMode
    sampled_ms: int = Field(ge=0)
    unclamped_ms: float = Field(ge=0)
    clamped: bool
    """True when the log-normal draw hit min/max (endpoint mass must be recorded)."""


class PersonaSampler:
    """Per-run, per-device sampler. Not thread-safe; owned by the coordinator's run loop."""

    def __init__(self, persona: PersonaConfig, *, run_seed: int, device_id: UUID, mode: DwellMode = "median") -> None:
        self.persona = persona
        self.run_seed = run_seed
        self.device_id = device_id
        self.mode: DwellMode = mode
        self._streams: dict[tuple[RandomStream, str], random.Random] = {}
        self._indices: dict[tuple[RandomStream, str], int] = {}
        self.draws: list[DwellDraw] = []

    def stream(self, stream: RandomStream, category: str) -> random.Random:
        key = (stream, category)
        if key not in self._streams:
            self._streams[key] = random.Random(derive_stream_seed(self.run_seed, self.device_id, stream, category))
        return self._streams[key]

    def _next_index(self, stream: RandomStream, category: str) -> int:
        idx = self._indices.get((stream, category), 0)
        self._indices[(stream, category)] = idx + 1
        return idx

    def sample_dwell(self, category: DwellCategory) -> DwellDraw:
        dist: DurationDistribution = getattr(self.persona, category)
        index = self._next_index("timing", category)
        if self.mode == "median":
            seconds = dist.median_seconds
        else:
            # Always consume exactly one variate per draw so indices stay aligned with the stream.
            z = self.stream("timing", category).gauss(0.0, 1.0)
            seconds = math.exp(math.log(dist.median_seconds) + dist.sigma_log * z)
        bounded = min(max(seconds, dist.min_seconds), dist.max_seconds)
        draw = DwellDraw(
            persona_id=self.persona.persona_id,
            persona_version=self.persona.version,
            stream="timing",
            category=category,
            draw_index=index,
            mode=self.mode,
            sampled_ms=round(bounded * 1000),
            unclamped_ms=seconds * 1000,
            clamped=bounded != seconds,
        )
        self.draws.append(draw)
        return draw

"""Bounded, typed IPC between the coordinator and one device-worker subprocess (CONTRACTS §1, §3).

Wire format: a 4-byte big-endian length prefix followed by one UTF-8 JSON document (a pydantic
envelope). Frames larger than ``MAX_FRAME_BYTES`` are a protocol error, never truncated. The worker
handles ``fence``/``health``/``close``/``authorize`` on a priority control lane that never waits
behind ``observe``/``execute`` driver operations.
"""

from __future__ import annotations

import asyncio
import base64
import struct
from dataclasses import dataclass
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import Field, TypeAdapter

from mobilelab.domain.base import StrictModel, UtcDatetime
from mobilelab.domain.devices import CapabilityReport, CloseResult, DeviceHealth, DeviceProfile, FenceResult
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.enums import EvidenceSource
from mobilelab.domain.errors import ErrorEnvelope, MobilelabError
from mobilelab.domain.observations import Observation, ObserveRequest

PROTOCOL_VERSION = 1
MAX_FRAME_BYTES = 32 * 1024 * 1024
"""Upper bound for one frame (a base64 screenshot plus tree fits comfortably)."""
_HEADER = struct.Struct(">I")


class ProtocolError(MobilelabError):
    """Malformed or oversized frame; the connection is unusable afterwards."""


# -- artifacts ------------------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ArtifactBlob:
    """Bytes captured by an adapter (e.g. a screenshot) handed back to the coordinator for storage.

    The worker never writes the database or the artifact store: the coordinator persists the blob
    with ``ArtifactStore.write_bytes(artifact_id=...)`` and commits its metadata.
    """

    artifact_id: UUID
    filename: str
    content_type: str
    data: bytes
    evidence_source: EvidenceSource


class ArtifactWire(StrictModel):
    artifact_id: UUID
    filename: str = Field(min_length=1, max_length=128)
    content_type: str = Field(min_length=1, max_length=128)
    evidence_source: EvidenceSource
    data_b64: str

    @classmethod
    def from_blob(cls, blob: ArtifactBlob) -> ArtifactWire:
        return cls(
            artifact_id=blob.artifact_id,
            filename=blob.filename,
            content_type=blob.content_type,
            evidence_source=blob.evidence_source,
            data_b64=base64.b64encode(blob.data).decode("ascii"),
        )

    def to_blob(self) -> ArtifactBlob:
        return ArtifactBlob(
            artifact_id=self.artifact_id,
            filename=self.filename,
            content_type=self.content_type,
            data=base64.b64decode(self.data_b64, validate=True),
            evidence_source=self.evidence_source,
        )


# -- worker status --------------------------------------------------------------------------------

InFlightState = Literal["none", "executing", "unknown"]


class WorkerHealth(StrictModel):
    """Worker-level status plus the adapter's own health report (None if it did not answer)."""

    device_id: UUID
    pid: int
    evidence_source: EvidenceSource
    gate_open: bool
    lease_id: UUID | None = None
    lease_epoch: int | None = None
    control_epoch: int | None = None
    fenced_through_epoch: int | None = None
    driver_busy: bool
    in_flight_command_id: UUID | None = None
    in_flight_state: InFlightState = "none"
    commands_started: int = Field(default=0, ge=0)
    """UI commands this worker has handed to the adapter (after its authority checks passed)."""
    last_command_started_at: UtcDatetime | None = None
    observations_started: int = Field(default=0, ge=0)
    test_driver_delay: dict[str, Any] | None = None
    """TEST-ONLY injected driver latency, when configured (never set by ``mobilelab run``)."""
    device: DeviceHealth | None = None
    detail: str = Field(default="", max_length=2000)


class AuthorizeAck(StrictModel):
    device_id: UUID
    lease_id: UUID
    lease_epoch: int
    control_epoch: int
    authorized_at: UtcDatetime


# -- requests -------------------------------------------------------------------------------------


class AuthorizeOp(StrictModel):
    op: Literal["authorize"] = "authorize"
    lease_id: UUID
    lease_epoch: int = Field(ge=1)
    control_epoch: int = Field(ge=0)


class ObserveOp(StrictModel):
    op: Literal["observe"] = "observe"
    request: ObserveRequest


class ExecuteOp(StrictModel):
    op: Literal["execute"] = "execute"
    command: DispatchCommand


class FenceOp(StrictModel):
    op: Literal["fence"] = "fence"
    control_epoch: int = Field(ge=0)


class HealthOp(StrictModel):
    op: Literal["health"] = "health"


class CloseOp(StrictModel):
    op: Literal["close"] = "close"


class PreflightOp(StrictModel):
    """Capability probe on the driver lane. Only allowed while no automation authority is installed."""

    op: Literal["preflight"] = "preflight"
    profile: DeviceProfile
    timeout_ms: int = Field(default=900_000, ge=1_000, le=1_800_000)
    """The first preflight also creates the driver session (WebDriverAgent build can take minutes)."""


RequestBody = Annotated[
    AuthorizeOp | ObserveOp | ExecuteOp | FenceOp | HealthOp | CloseOp | PreflightOp, Field(discriminator="op")
]
CONTROL_OPS = frozenset({"authorize", "fence", "health", "close"})
"""Priority lane: handled immediately, never queued behind a driver operation."""


class Request(StrictModel):
    msg_id: int = Field(ge=1)
    body: RequestBody


# -- responses ------------------------------------------------------------------------------------


class HelloResult(StrictModel):
    op: Literal["hello"] = "hello"
    protocol_version: int
    device_id: UUID
    pid: int
    adapter: str
    evidence_source: EvidenceSource


class AuthorizeResult(StrictModel):
    op: Literal["authorize"] = "authorize"
    ack: AuthorizeAck


class ObserveResult(StrictModel):
    op: Literal["observe"] = "observe"
    observation: Observation
    artifacts: list[ArtifactWire] = Field(default_factory=list)


class ExecuteResultBody(StrictModel):
    op: Literal["execute"] = "execute"
    result: ExecutionResult


class FenceResultBody(StrictModel):
    op: Literal["fence"] = "fence"
    result: FenceResult


class HealthResultBody(StrictModel):
    op: Literal["health"] = "health"
    result: WorkerHealth


class CloseResultBody(StrictModel):
    op: Literal["close"] = "close"
    result: CloseResult


class PreflightResultBody(StrictModel):
    op: Literal["preflight"] = "preflight"
    report: CapabilityReport


ResultBody = Annotated[
    HelloResult
    | AuthorizeResult
    | ObserveResult
    | ExecuteResultBody
    | FenceResultBody
    | HealthResultBody
    | CloseResultBody
    | PreflightResultBody,
    Field(discriminator="op"),
]


class Response(StrictModel):
    msg_id: int = Field(ge=0)
    """0 is the unsolicited hello frame sent once at worker start-up."""
    result: ResultBody | None = None
    error: ErrorEnvelope | None = None


REQUEST_ADAPTER: TypeAdapter[Request] = TypeAdapter(Request)
RESPONSE_ADAPTER: TypeAdapter[Response] = TypeAdapter(Response)


# -- framing --------------------------------------------------------------------------------------


def encode_frame(message: Request | Response, *, max_bytes: int = MAX_FRAME_BYTES) -> bytes:
    data = message.model_dump_json().encode("utf-8")
    if len(data) > max_bytes:
        raise ProtocolError("frame exceeds maximum size", details={"size": len(data), "max": max_bytes})
    return _HEADER.pack(len(data)) + data


async def read_frame(reader: asyncio.StreamReader, *, max_bytes: int = MAX_FRAME_BYTES) -> bytes | None:
    """Read one frame payload; ``None`` on clean EOF before a header."""
    try:
        header = await reader.readexactly(_HEADER.size)
    except asyncio.IncompleteReadError as err:
        if not err.partial:
            return None
        raise ProtocolError("truncated frame header") from err
    (size,) = _HEADER.unpack(header)
    if size > max_bytes:
        raise ProtocolError("incoming frame exceeds maximum size", details={"size": size, "max": max_bytes})
    try:
        return await reader.readexactly(size)
    except asyncio.IncompleteReadError as err:
        raise ProtocolError("truncated frame body") from err


def error_envelope(err: BaseException) -> ErrorEnvelope:
    if isinstance(err, MobilelabError):
        return err.to_envelope()
    return ErrorEnvelope(code=MobilelabError.code, message=f"{type(err).__name__}: {err}"[:2000])

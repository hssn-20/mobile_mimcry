"""Device-worker core: authority checks, one driver operation at a time, priority fencing.

``WorkerCore`` is transport-independent. The subprocess entry point (``workers.entry``) wraps it
with framed stdin/stdout IPC; tests may drive it in-process. Adapter coroutines run on a dedicated
driver thread with its own event loop, so even an adapter that blocks its thread cannot delay the
control lane (fence/health/close/authorize), which runs on the worker's main loop.

Authority (checked on the worker immediately before any adapter call, no await in between):
current lease id and lease epoch, the control epoch it was authorized for and not fenced, the
coordinator-pushed dispatch gate, and observation freshness measured on *this* process's monotonic
clock from the stamp the worker recorded when it captured the dispatch observation.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import os
import threading
import time
from collections import OrderedDict
from collections.abc import Awaitable, Callable, Coroutine
from typing import Any, TypeVar
from uuid import UUID

from mobilelab.adapters.base import DeviceAdapter
from mobilelab.domain.base import utc_now
from mobilelab.domain.devices import CapabilityReport, CloseResult, DeviceHealth, DeviceProfile, FenceResult
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.enums import EvidenceSource, ExecutionStatus
from mobilelab.domain.errors import (
    DispatchGateClosed,
    ErrorCode,
    ErrorEnvelope,
    MobilelabError,
    StaleEpoch,
    StaleLease,
    StaleObservation,
)
from mobilelab.domain.observations import Observation, ObserveRequest
from mobilelab.workers.errors import WorkerBusy, WorkerTimeout, WorkerUnavailable
from mobilelab.workers.protocol import ArtifactBlob, AuthorizeAck, InFlightState, WorkerHealth

log = logging.getLogger(__name__)
T = TypeVar("T")

DEFAULT_MAX_WAITING_DRIVER_OPS = 4
DEFAULT_OBSERVATION_CACHE = 64
DEFAULT_OBSERVE_TIMEOUT_MS = 30_000
DEFAULT_CONTROL_CALL_TIMEOUT_MS = 1_000


class DriverThread:
    """A dedicated thread + event loop for adapter coroutines (off the control loop)."""

    def __init__(self, name: str) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run, name=name, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def submit(
        self, coro: Coroutine[Any, Any, T]
    ) -> tuple[concurrent.futures.Future[T], concurrent.futures.Future[None]]:
        """Schedule ``coro``; returns (result future, future set only when the coroutine has exited)."""
        finished: concurrent.futures.Future[None] = concurrent.futures.Future()

        async def wrapper() -> T:
            try:
                return await coro
            finally:
                finished.set_result(None)

        return asyncio.run_coroutine_threadsafe(wrapper(), self._loop), finished

    def stop(self, timeout_s: float = 1.0) -> None:
        if self._loop.is_closed():
            return
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout_s)
        if not self._thread.is_alive():
            self._loop.close()


class _DriverTimeout(Exception):
    pass


class ArtifactCollector:
    """``ArtifactSink`` handed to the adapter: ``(artifact_id, filename, content_type, data)``.

    Adapters call it on the driver thread while capturing; the worker drains it after each
    observation and returns the bytes to the coordinator, which alone persists artifacts.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._items: list[tuple[UUID, str, str, bytes]] = []

    def __call__(self, artifact_id: UUID, filename: str, content_type: str, data: bytes) -> None:
        with self._lock:
            self._items.append((artifact_id, filename, content_type, bytes(data)))

    def drain(self) -> list[tuple[UUID, str, str, bytes]]:
        with self._lock:
            items, self._items = self._items, []
        return items


class WorkerCore:
    """Serializes driver operations for exactly one device and enforces dispatch authority."""

    def __init__(
        self,
        device_id: UUID,
        adapter: DeviceAdapter,
        *,
        adapter_name: str = "custom",
        max_waiting_driver_ops: int = DEFAULT_MAX_WAITING_DRIVER_OPS,
        observation_cache_size: int = DEFAULT_OBSERVATION_CACHE,
        observe_timeout_ms: int = DEFAULT_OBSERVE_TIMEOUT_MS,
        control_call_timeout_ms: int = DEFAULT_CONTROL_CALL_TIMEOUT_MS,
        clock_ns: Callable[[], int] = time.monotonic_ns,
        artifact_collector: ArtifactCollector | None = None,
        test_driver_delay: dict[str, Any] | None = None,
    ) -> None:
        self.device_id = device_id
        self.adapter = adapter
        self.adapter_name = adapter_name
        self.evidence_source: EvidenceSource = getattr(adapter, "evidence_source", EvidenceSource.DEVICE)
        self._max_waiting = max_waiting_driver_ops
        self._cache_size = observation_cache_size
        self._observe_timeout_s = observe_timeout_ms / 1000
        self._control_timeout_s = control_call_timeout_ms / 1000
        self._clock_ns = clock_ns
        self._collector = artifact_collector
        self._driver = DriverThread(f"mobilelab-driver-{device_id}")
        self._driver_lock = asyncio.Lock()
        self._waiting = 0
        self._background: set[asyncio.Task[Any]] = set()
        self._test_delay = dict(test_driver_delay) if test_driver_delay else None
        self._test_delay_used = 0
        self.commands_started = 0
        self.last_command_started_at: Any = None
        self.observations_started = 0

        self._lease_id: UUID | None = None
        self._lease_epoch: int | None = None
        self._control_epoch: int | None = None
        self._fenced_through: int | None = None
        self._gate_open = False
        self._closed = False

        self._in_flight_command: UUID | None = None
        self._in_flight_state: InFlightState = "none"
        self._obs_stamps: OrderedDict[UUID, int] = OrderedDict()
        self._artifacts: OrderedDict[UUID, list[ArtifactBlob]] = OrderedDict()

    @property
    def control_epoch(self) -> int | None:
        return self._control_epoch

    # -- control lane ------------------------------------------------------------------------------

    async def authorize(self, lease_id: UUID, lease_epoch: int, control_epoch: int) -> AuthorizeAck:
        """Install the coordinator's current lease/control epoch and open this worker's gate."""
        if self._closed:
            raise WorkerUnavailable("worker is closed")
        if self._fenced_through is not None and control_epoch <= self._fenced_through:
            raise StaleEpoch(
                "control epoch was already fenced", details={"control_epoch": control_epoch, "fenced_through": self._fenced_through}
            )
        if self._lease_epoch is not None:
            if lease_epoch < self._lease_epoch:
                raise StaleEpoch("lease epoch older than the current lease", details={"lease_epoch": lease_epoch})
            if lease_epoch == self._lease_epoch and lease_id != self._lease_id:
                raise StaleLease("different lease with the same epoch")
        self._lease_id, self._lease_epoch, self._control_epoch = lease_id, lease_epoch, control_epoch
        self._obs_stamps.clear()  # observations from a previous authority are never dispatchable
        self._gate_open = True
        return AuthorizeAck(
            device_id=self.device_id,
            lease_id=lease_id,
            lease_epoch=lease_epoch,
            control_epoch=control_epoch,
            authorized_at=utc_now(),
        )

    async def fence(self, control_epoch: int) -> FenceResult:
        """Close the gate synchronously, then acknowledge. Never waits for the driver.

        After this returns no new driver operation starts until a later ``authorize`` with a greater
        control epoch. The one in-flight command (if any) may still complete; it is reported here.
        """
        self._gate_open = False
        self._fenced_through = max(control_epoch, self._fenced_through or 0)
        self._obs_stamps.clear()
        result = FenceResult(
            device_id=self.device_id,
            control_epoch=control_epoch,
            fenced=True,
            acknowledged_at=utc_now(),
            in_flight_command_id=self._in_flight_command,
            in_flight_state=self._in_flight_state,
        )
        if not self._closed:
            self._spawn(self._best_effort(self.adapter.fence(control_epoch), "adapter fence"))
        return result

    async def health(self) -> WorkerHealth:
        device: DeviceHealth | None = None
        detail = ""
        if not self._closed:
            try:
                device = await self._side_call(self.adapter.health(), self._control_timeout_s)
            except Exception as err:  # health must always answer
                detail = f"adapter health unavailable: {type(err).__name__}: {err}"[:2000]
        return WorkerHealth(
            device_id=self.device_id,
            pid=os.getpid(),
            evidence_source=self.evidence_source,
            gate_open=self._gate_open,
            lease_id=self._lease_id,
            lease_epoch=self._lease_epoch,
            control_epoch=self._control_epoch,
            fenced_through_epoch=self._fenced_through,
            driver_busy=self._driver_lock.locked(),
            in_flight_command_id=self._in_flight_command,
            in_flight_state=self._in_flight_state,
            commands_started=self.commands_started,
            last_command_started_at=self.last_command_started_at,
            observations_started=self.observations_started,
            test_driver_delay=self._test_delay,
            device=device,
            detail=detail,
        )

    async def close(self) -> CloseResult:
        self._gate_open = False
        if self._closed:
            return CloseResult(device_id=self.device_id, closed=True, detail="already closed")
        self._closed = True
        detail = ""
        closed = True
        try:
            res = await self._side_call(self.adapter.close(), max(self._control_timeout_s, 5.0))
            closed, detail = res.closed, res.detail
        except Exception as err:
            closed, detail = False, f"adapter close failed: {type(err).__name__}: {err}"[:2000]
        if not self._driver_lock.locked():
            self._driver.stop()
        else:
            detail = (detail + "; driver operation still running at close").strip("; ")
        return CloseResult(device_id=self.device_id, closed=closed, detail=detail)

    # -- driver lane -------------------------------------------------------------------------------

    def _authority_error(
        self, *, device_id: UUID, lease_id: UUID, lease_epoch: int, control_epoch: int | None
    ) -> MobilelabError | None:
        if self._closed or not self._gate_open:
            return DispatchGateClosed("worker dispatch gate is closed (fenced or not authorized)")
        if device_id != self.device_id:
            return StaleLease("command addressed to a different device", details={"device_id": str(device_id)})
        if lease_id != self._lease_id:
            return StaleLease("lease is not this worker's current lease", details={"lease_id": str(lease_id)})
        if lease_epoch != self._lease_epoch:
            return StaleEpoch("stale lease epoch", details={"lease_epoch": lease_epoch, "current": self._lease_epoch})
        if control_epoch is not None and (
            control_epoch != self._control_epoch
            or (self._fenced_through is not None and control_epoch <= self._fenced_through)
        ):
            return StaleEpoch(
                "stale control epoch", details={"control_epoch": control_epoch, "current": self._control_epoch}
            )
        return None

    async def observe(self, request: ObserveRequest) -> Observation:
        def check() -> None:
            err = self._authority_error(
                device_id=request.device_id,
                lease_id=request.lease_id,
                lease_epoch=request.lease_epoch,
                control_epoch=None,
            )
            if err is not None:
                raise err

        check()
        await self._acquire_driver()
        try:
            check()  # authority may have changed while waiting for the driver
        except BaseException:
            self._driver_lock.release()
            raise
        t0 = self._clock_ns()
        self.observations_started += 1

        async def capture() -> tuple[Observation, list[ArtifactBlob]]:
            if self._collector is not None:
                self._collector.drain()  # leftovers of an abandoned capture never attach here
            obs = await self.adapter.observe(request)
            take = getattr(self.adapter, "take_artifacts", None)
            blobs: list[ArtifactBlob] = list(take(obs.observation_id)) if callable(take) else []
            if self._collector is not None:
                blobs += [
                    ArtifactBlob(aid, name, ctype, data, self.evidence_source)
                    for aid, name, ctype, data in self._collector.drain()
                ]
            return obs, blobs

        try:
            obs, blobs = await self._drive(capture(), self._observe_timeout_s)
        except _DriverTimeout:
            raise WorkerTimeout("observation exceeded its deadline", details={"timeout_s": self._observe_timeout_s}) from None
        t1 = self._clock_ns()
        if obs.device_id != self.device_id:
            raise StaleObservation("adapter returned an observation for another device")
        obs.check_capture_consistency(request.max_capture_span_ms)
        # The worker's own monotonic stamp: the adapter's capture time if it is plausible for this
        # call, otherwise the (older, conservative) call start.
        stamp = obs.worker_monotonic_capture_ns if t0 <= obs.worker_monotonic_capture_ns <= t1 else t0
        obs = obs.model_copy(update={"worker_monotonic_capture_ns": stamp})
        if self._gate_open:
            self._remember(self._obs_stamps, obs.observation_id, stamp)
        if blobs:
            self._remember(self._artifacts, obs.observation_id, blobs)
        return obs

    def take_artifacts(self, observation_id: UUID) -> list[ArtifactBlob]:
        return self._artifacts.pop(observation_id, [])

    async def preflight(self, profile: DeviceProfile, *, timeout_s: float = 900.0) -> CapabilityReport:
        """Run the adapter's capability probe on the driver lane.

        Preflight drives the UI itself (app launches, navigation), so it is refused once automation
        authority is installed (``authorize``) or after a fence: it belongs to run PREFLIGHT, before
        any lease-bound dispatch. Probe artifacts captured by the adapter are discarded here."""
        if self._closed:
            raise WorkerUnavailable("worker is closed")
        if self._gate_open or self._fenced_through is not None:
            raise DispatchGateClosed("preflight is only allowed before automation is authorized")
        if profile.device_id != self.device_id:
            raise StaleLease("preflight profile is for a different device", details={"device_id": str(profile.device_id)})
        await self._acquire_driver()
        try:
            report = await self._drive(self.adapter.preflight(profile), timeout_s)
        except _DriverTimeout:
            raise WorkerTimeout("preflight exceeded its deadline", details={"timeout_s": timeout_s}) from None
        finally:
            if self._collector is not None:
                self._collector.drain()
        return report

    async def execute(self, command: DispatchCommand) -> ExecutionResult:
        if self._waiting >= self._max_waiting:
            return self._rejected(command, ErrorCode.LEASE_CONFLICT, "device busy: driver queue is full")
        await self._acquire_driver()
        # Everything from here to the adapter call runs without an await: a fence handled on this
        # loop either happened before (and is seen here) or happens after the command started.
        err = self._authority_error(
            device_id=command.device_id,
            lease_id=command.lease_id,
            lease_epoch=command.lease_epoch,
            control_epoch=command.control_epoch,
        ) or self._freshness_error(command)
        if err is not None:
            self._driver_lock.release()
            return self._rejected(command, err.code, err.message, err.to_envelope())
        self._in_flight_command, self._in_flight_state = command.command_id, "executing"
        started = utc_now()
        t0 = self._clock_ns()
        self.commands_started += 1
        self.last_command_started_at = started
        delay = self._take_test_delay(command)
        try:
            result = await self._drive(self._delayed(command, delay) if delay else self.adapter.execute(command),
                                       command.max_duration_ms / 1000)
        except _DriverTimeout:
            return self._unknown(command, started, t0, "driver command exceeded max_duration_ms; outcome unknown")
        except Exception as exc:
            env = ErrorEnvelope(code=ErrorCode.INTERNAL_ERROR, message=f"{type(exc).__name__}: {exc}"[:2000])
            return self._unknown(command, started, t0, "driver raised after the command started", env)
        finally:
            if self._in_flight_state == "executing":
                self._in_flight_command, self._in_flight_state = None, "none"
        if result.command_id != command.command_id or result.action_id != command.action_id:
            return self._unknown(command, started, t0, "adapter returned a result for a different command")
        if delay:
            label = f" [TEST-ONLY injected driver delay {delay['delay_ms']} ms {delay['position']} the adapter call]"
            result = result.model_copy(update={"detail": ((result.detail or "") + label)[:4000]})
        return result

    def _take_test_delay(self, command: DispatchCommand) -> dict[str, Any] | None:
        """TEST-ONLY latency injection (``WorkerConfig.test_driver_delay``); None in normal runs."""
        cfg = self._test_delay
        if not cfg or self._test_delay_used >= int(cfg.get("max_commands", 1)):
            return None
        if str(command.payload.kind) not in {str(k) for k in cfg.get("kinds", [])}:
            return None
        self._test_delay_used += 1
        return cfg

    async def _delayed(self, command: DispatchCommand, cfg: dict[str, Any]) -> ExecutionResult:
        """Runs on the driver thread: the driver lane stays busy (in-flight ``executing``)."""
        if cfg.get("position") == "before":
            await asyncio.sleep(cfg["delay_ms"] / 1000)
            return await self.adapter.execute(command)
        result = await self.adapter.execute(command)
        await asyncio.sleep(cfg["delay_ms"] / 1000)
        return result

    def _freshness_error(self, command: DispatchCommand) -> MobilelabError | None:
        stamp = self._obs_stamps.get(command.dispatch_observation_id)
        if stamp is None:
            return StaleObservation(
                "dispatch observation unknown to this worker (not captured here or invalidated by a fence)",
                details={"observation_id": str(command.dispatch_observation_id)},
            )
        age_ms = (self._clock_ns() - stamp) / 1_000_000
        if age_ms < 0 or age_ms > command.max_observation_age_ms:
            return StaleObservation(
                "dispatch observation too old on the worker's monotonic clock",
                details={"age_ms": round(age_ms, 3), "max_age_ms": command.max_observation_age_ms},
            )
        return None

    def _rejected(
        self, command: DispatchCommand, code: ErrorCode, message: str, env: ErrorEnvelope | None = None
    ) -> ExecutionResult:
        return ExecutionResult(
            command_id=command.command_id,
            action_id=command.action_id,
            device_id=self.device_id,
            status=ExecutionStatus.REJECTED,
            evidence_source=self.evidence_source,
            rejection_code=code,
            error=env or ErrorEnvelope(code=code, message=message),
            detail=f"rejected before any adapter call: {message}"[:4000],
        )

    def _unknown(
        self,
        command: DispatchCommand,
        started: Any,
        t0: int,
        detail: str,
        env: ErrorEnvelope | None = None,
    ) -> ExecutionResult:
        return ExecutionResult(
            command_id=command.command_id,
            action_id=command.action_id,
            device_id=self.device_id,
            status=ExecutionStatus.UNKNOWN,
            evidence_source=self.evidence_source,
            started_at=started,
            ended_at=utc_now(),
            duration_ms=(self._clock_ns() - t0) / 1_000_000,
            error=env,
            detail=f"{detail}; not retried"[:4000],
        )

    # -- driver plumbing ---------------------------------------------------------------------------

    async def _acquire_driver(self) -> None:
        if self._waiting >= self._max_waiting:
            raise WorkerBusy("driver queue is full", details={"max_waiting": self._max_waiting})
        self._waiting += 1
        try:
            await self._driver_lock.acquire()
        finally:
            self._waiting -= 1

    async def _drive(self, coro: Coroutine[Any, Any, T], timeout_s: float) -> T:
        """Run ``coro`` on the driver thread. Caller holds the driver lock; this always releases it,
        immediately on completion or only once the driver coroutine has really exited."""
        result_cf, finished_cf = self._driver.submit(coro)
        fut = asyncio.wrap_future(result_cf)
        try:
            done, _ = await asyncio.wait({fut}, timeout=timeout_s)
        except asyncio.CancelledError:
            self._release_when_finished(result_cf, finished_cf)
            raise
        if not done:
            self._release_when_finished(result_cf, finished_cf)
            raise _DriverTimeout()
        self._driver_lock.release()
        return fut.result()

    def _release_when_finished(
        self, result_cf: concurrent.futures.Future[Any], finished_cf: concurrent.futures.Future[None]
    ) -> None:
        if self._in_flight_state == "executing":
            self._in_flight_state = "unknown"
        result_cf.cancel()  # best effort; cancellation does not undo a UI action

        async def wait_and_release() -> None:
            try:
                await asyncio.wrap_future(finished_cf)
            finally:
                self._in_flight_command, self._in_flight_state = None, "none"
                self._driver_lock.release()

        self._spawn(wait_and_release())

    async def _side_call(self, coro: Coroutine[Any, Any, T], timeout_s: float) -> T:
        """Adapter call outside the driver lock (health/close), bounded by ``timeout_s``."""
        result_cf, _ = self._driver.submit(coro)
        try:
            return await asyncio.wait_for(asyncio.wrap_future(result_cf), timeout_s)
        except TimeoutError:
            raise WorkerTimeout("adapter control call timed out", details={"timeout_s": timeout_s}) from None

    async def _best_effort(self, coro: Coroutine[Any, Any, Any], what: str) -> None:
        try:
            await self._side_call(coro, self._control_timeout_s)
        except Exception as err:
            log.warning("%s failed (best effort): %s", what, err)

    def _spawn(self, aw: Awaitable[Any]) -> None:
        task = asyncio.ensure_future(aw)
        self._background.add(task)
        task.add_done_callback(self._background.discard)

    def _remember[V](self, cache: OrderedDict[UUID, V], key: UUID, value: V) -> None:
        cache[key] = value
        cache.move_to_end(key)
        while len(cache) > self._cache_size:
            cache.popitem(last=False)

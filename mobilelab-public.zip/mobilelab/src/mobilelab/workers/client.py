"""Coordinator-side worker clients.

``WorkerClient`` is the interface the coordinator codes against. ``WorkerHandle`` implements it
over a subprocess (``python -m mobilelab.workers.entry``) with framed stdin/stdout IPC, a bounded
number of outstanding requests and per-call deadlines. ``WorkerCore`` (in-process) satisfies the same
protocol, which unit tests use with the mock adapter.

A deadline expiring on this side never means the operation did not happen: callers map an
``execute`` timeout to ``UNKNOWN`` and never retry it.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import IO, Protocol, TypeVar, runtime_checkable
from uuid import UUID

from pydantic import BaseModel, ValidationError

from mobilelab.domain.devices import CapabilityReport, CloseResult, DeviceProfile, FenceResult
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.enums import EvidenceSource
from mobilelab.domain.observations import Observation, ObserveRequest
from mobilelab.workers.entry import WorkerConfig
from mobilelab.workers.errors import WorkerBusy, WorkerTimeout, WorkerUnavailable, error_from_envelope
from mobilelab.workers.protocol import (
    CONTROL_OPS,
    RESPONSE_ADAPTER,
    ArtifactBlob,
    AuthorizeAck,
    AuthorizeOp,
    AuthorizeResult,
    CloseOp,
    CloseResultBody,
    ExecuteOp,
    ExecuteResultBody,
    FenceOp,
    FenceResultBody,
    HealthOp,
    HealthResultBody,
    HelloResult,
    ObserveOp,
    ObserveResult,
    PreflightOp,
    PreflightResultBody,
    ProtocolError,
    Request,
    RequestBody,
    Response,
    WorkerHealth,
    encode_frame,
    read_frame,
)
from mobilelab.secrets import child_env

log = logging.getLogger(__name__)
R = TypeVar("R", bound=BaseModel)

DEFAULT_FENCE_TIMEOUT_S = 1.0
EXECUTE_GRACE_S = 2.0


@runtime_checkable
class WorkerClient(Protocol):
    device_id: UUID
    evidence_source: EvidenceSource

    async def authorize(self, lease_id: UUID, lease_epoch: int, control_epoch: int) -> AuthorizeAck: ...

    async def observe(self, request: ObserveRequest) -> Observation: ...

    def take_artifacts(self, observation_id: UUID) -> list[ArtifactBlob]: ...

    async def execute(self, command: DispatchCommand) -> ExecutionResult: ...

    async def fence(self, control_epoch: int) -> FenceResult: ...

    async def health(self) -> WorkerHealth: ...

    async def close(self) -> CloseResult: ...


class WorkerHandle:
    """One device-worker subprocess. Driver ops run in the worker; fences use its priority lane."""

    def __init__(
        self,
        proc: asyncio.subprocess.Process,
        hello: HelloResult,
        *,
        max_outstanding: int,
        max_frame_bytes: int,
        observe_timeout_s: float,
    ) -> None:
        assert proc.stdin is not None and proc.stdout is not None
        self._proc = proc
        self._stdin = proc.stdin
        self._stdout = proc.stdout
        self.device_id: UUID = hello.device_id
        self.evidence_source: EvidenceSource = hello.evidence_source
        self.adapter = hello.adapter
        self._max_outstanding = max_outstanding
        self._max_frame = max_frame_bytes
        self._observe_timeout_s = observe_timeout_s
        self._next_id = 1
        self._pending: dict[int, asyncio.Future[Response]] = {}
        self._write_lock = asyncio.Lock()
        self._artifacts: dict[UUID, list[ArtifactBlob]] = {}
        self._dead: str | None = None
        self._reader_task = asyncio.ensure_future(self._read_loop())

    # -- lifecycle ---------------------------------------------------------------------------------

    @classmethod
    async def spawn(
        cls,
        adapter: str,
        config: WorkerConfig,
        *,
        stderr: Path | None = None,
        python: str = sys.executable,
        startup_timeout_s: float = 20.0,
        max_outstanding: int = 8,
    ) -> WorkerHandle:
        """Start ``python -m mobilelab.workers.entry`` (typed argv, no shell) and wait for its hello.

        The configuration is passed as a 0600 temporary file (removed once the worker is up) so
        adapter options such as fixture tokens do not appear in the process list.
        """
        tmpdir = Path(tempfile.mkdtemp(prefix="mobilelab-worker-"))
        cfg_path = tmpdir / "worker.json"
        fd = os.open(cfg_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(config.model_dump_json())
        err_fh: IO[bytes] | None = open(stderr, "ab") if stderr is not None else None  # noqa: SIM115
        try:
            proc = await asyncio.create_subprocess_exec(
                python,
                "-m",
                "mobilelab.workers.entry",
                "--adapter",
                adapter,
                "--config",
                str(cfg_path),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=err_fh if err_fh is not None else asyncio.subprocess.DEVNULL,
                # A terminal Ctrl-C reaches only the coordinator, which then fences and closes the
                # worker in order; the worker also exits on stdin EOF if the coordinator dies.
                start_new_session=True,
                env=child_env(),  # never inherit provider credentials (OPENAI_API_KEY)
            )
        finally:
            if err_fh is not None:
                err_fh.close()
        try:
            assert proc.stdout is not None
            raw = await asyncio.wait_for(read_frame(proc.stdout, max_bytes=config.max_frame_bytes), startup_timeout_s)
            if raw is None:
                raise WorkerUnavailable("worker exited before its hello frame", details={"returncode": proc.returncode})
            hello = RESPONSE_ADAPTER.validate_json(raw)
            if not isinstance(hello.result, HelloResult) or hello.msg_id != 0:
                raise ProtocolError("first worker frame was not a hello")
            if hello.result.device_id != config.device_id:
                raise ProtocolError("worker reported a different device id")
        except BaseException:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            await proc.wait()
            raise
        finally:
            cfg_path.unlink(missing_ok=True)
            tmpdir.rmdir()
        return cls(
            proc,
            hello.result,
            max_outstanding=max_outstanding,
            max_frame_bytes=config.max_frame_bytes,
            observe_timeout_s=config.observe_timeout_ms / 1000 + 5.0,
        )

    @property
    def pid(self) -> int:
        return self._proc.pid

    @property
    def returncode(self) -> int | None:
        return self._proc.returncode

    @property
    def alive(self) -> bool:
        return self._dead is None and self._proc.returncode is None

    async def kill(self) -> int:
        """Forceful termination: a harness interruption; in-flight outcomes stay UNKNOWN."""
        with contextlib.suppress(ProcessLookupError):
            self._proc.kill()
        return await self._proc.wait()

    # -- transport ---------------------------------------------------------------------------------

    async def _read_loop(self) -> None:
        reason = "worker closed its output"
        try:
            while True:
                raw = await read_frame(self._stdout, max_bytes=self._max_frame)
                if raw is None:
                    break
                try:
                    resp = RESPONSE_ADAPTER.validate_json(raw)
                except ValidationError as err:
                    reason = f"invalid frame from worker: {err}"[:500]
                    break
                fut = self._pending.pop(resp.msg_id, None)
                if fut is not None and not fut.done():
                    fut.set_result(resp)
                elif resp.error is not None:
                    log.warning("worker error without pending request: %s", resp.error.message)
        except ProtocolError as err:
            reason = f"protocol error: {err}"
        except Exception as err:  # pragma: no cover - defensive
            reason = f"reader failed: {type(err).__name__}: {err}"
        self._dead = reason
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(WorkerUnavailable(reason))
        self._pending.clear()

    async def _call(self, body: RequestBody, expected: type[R], timeout_s: float) -> R:
        if self._dead is not None:
            raise WorkerUnavailable(f"worker unavailable: {self._dead}")
        # Control-lane ops (fence/health/close/authorize) are never refused for capacity.
        if body.op not in CONTROL_OPS and len(self._pending) >= self._max_outstanding:
            raise WorkerBusy("too many outstanding worker requests", details={"max": self._max_outstanding})
        msg_id = self._next_id
        self._next_id += 1
        fut: asyncio.Future[Response] = asyncio.get_running_loop().create_future()
        self._pending[msg_id] = fut
        try:
            frame = encode_frame(Request(msg_id=msg_id, body=body), max_bytes=self._max_frame)
            async with self._write_lock:
                self._stdin.write(frame)
                await self._stdin.drain()
        except (ConnectionError, ProtocolError) as err:
            self._pending.pop(msg_id, None)
            if isinstance(err, ProtocolError):
                raise
            raise WorkerUnavailable(f"could not write to worker: {err}") from err
        try:
            resp = await asyncio.wait_for(fut, timeout_s)
        except TimeoutError:
            self._pending.pop(msg_id, None)
            raise WorkerTimeout(
                f"no {body.op} reply from worker within {timeout_s:.3f}s", details={"op": body.op, "timeout_s": timeout_s}
            ) from None
        if resp.error is not None:
            raise error_from_envelope(resp.error)
        if not isinstance(resp.result, expected):
            raise ProtocolError(f"unexpected reply type for {body.op}")
        return resp.result

    # -- operations --------------------------------------------------------------------------------

    async def authorize(self, lease_id: UUID, lease_epoch: int, control_epoch: int) -> AuthorizeAck:
        body = AuthorizeOp(lease_id=lease_id, lease_epoch=lease_epoch, control_epoch=control_epoch)
        return (await self._call(body, AuthorizeResult, 5.0)).ack

    async def observe(self, request: ObserveRequest) -> Observation:
        res = await self._call(ObserveOp(request=request), ObserveResult, self._observe_timeout_s)
        if res.artifacts:
            self._artifacts[res.observation.observation_id] = [a.to_blob() for a in res.artifacts]
        return res.observation

    def take_artifacts(self, observation_id: UUID) -> list[ArtifactBlob]:
        return self._artifacts.pop(observation_id, [])

    async def execute(self, command: DispatchCommand) -> ExecutionResult:
        timeout = command.max_duration_ms / 1000 + EXECUTE_GRACE_S
        return (await self._call(ExecuteOp(command=command), ExecuteResultBody, timeout)).result

    async def fence(self, control_epoch: int, *, timeout_s: float = DEFAULT_FENCE_TIMEOUT_S) -> FenceResult:
        return (await self._call(FenceOp(control_epoch=control_epoch), FenceResultBody, timeout_s)).result

    async def health(self, *, timeout_s: float = 5.0) -> WorkerHealth:
        return (await self._call(HealthOp(), HealthResultBody, timeout_s)).result

    async def preflight(self, profile: DeviceProfile, *, timeout_s: float = 900.0) -> CapabilityReport:
        """Adapter capability probe (driver lane; refused while automation authority is installed)."""
        body = PreflightOp(profile=profile, timeout_ms=int(timeout_s * 1000))
        return (await self._call(body, PreflightResultBody, timeout_s + EXECUTE_GRACE_S)).report

    async def close(self, *, timeout_s: float = 10.0) -> CloseResult:
        try:
            result = (await self._call(CloseOp(), CloseResultBody, timeout_s)).result
        except (WorkerTimeout, WorkerUnavailable):
            await self.kill()
            raise
        finally:
            with contextlib.suppress(ConnectionError):
                self._stdin.close()
        try:
            await asyncio.wait_for(self._proc.wait(), timeout_s)
        except TimeoutError:
            await self.kill()
        return result

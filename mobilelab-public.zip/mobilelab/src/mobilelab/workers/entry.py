"""Device-worker subprocess entry point.

    python -m mobilelab.workers.entry --adapter ios|mock --config <path-to-json | inline-json>

The configuration is a ``WorkerConfig`` JSON object. stdout carries only protocol frames: the
original stdout descriptor is reserved for IPC and fd 1 is redirected to stderr so stray prints
from drivers cannot corrupt the stream. The worker never opens the SQLite database.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any
from uuid import UUID

from typing import Literal

from pydantic import Field

from mobilelab.domain.base import StrictModel
from mobilelab.domain.enums import ActionKind
from mobilelab.workers.core import (
    DEFAULT_CONTROL_CALL_TIMEOUT_MS,
    ArtifactCollector,
    DEFAULT_MAX_WAITING_DRIVER_OPS,
    DEFAULT_OBSERVATION_CACHE,
    DEFAULT_OBSERVE_TIMEOUT_MS,
    WorkerCore,
)
from mobilelab.workers.protocol import MAX_FRAME_BYTES
from mobilelab.workers.registry import create_adapter
from mobilelab.workers.server import DEFAULT_MAX_CONCURRENT_REQUESTS, WorkerServer


class TestDriverDelay(StrictModel):
    """TEST-ONLY driver latency injected on the worker's driver lane (live emergency-stop tests).

    ``position="after"``: the adapter performs the command, then the driver lane stays busy for
    ``delay_ms`` before the result returns (a slow driver reply). ``"before"``: the lane is busy
    before the adapter call (a slow driver queue; the adapter's own fence check then still runs).
    Results of delayed commands carry ``[TEST-ONLY injected driver delay ...]`` in their detail."""

    __test__ = False  # not a pytest test class
    kinds: list[ActionKind] = Field(min_length=1)
    delay_ms: int = Field(ge=1, le=60_000)
    position: Literal["before", "after"] = "after"
    max_commands: int = Field(default=1, ge=1, le=100)


class WorkerConfig(StrictModel):
    device_id: UUID
    adapter_options: dict[str, Any] = Field(default_factory=dict)
    max_frame_bytes: int = Field(default=MAX_FRAME_BYTES, ge=1024, le=MAX_FRAME_BYTES)
    max_concurrent_requests: int = Field(default=DEFAULT_MAX_CONCURRENT_REQUESTS, ge=2, le=256)
    max_waiting_driver_ops: int = Field(default=DEFAULT_MAX_WAITING_DRIVER_OPS, ge=1, le=64)
    observation_cache_size: int = Field(default=DEFAULT_OBSERVATION_CACHE, ge=1, le=4096)
    observe_timeout_ms: int = Field(default=DEFAULT_OBSERVE_TIMEOUT_MS, ge=1, le=600_000)
    control_call_timeout_ms: int = Field(default=DEFAULT_CONTROL_CALL_TIMEOUT_MS, ge=1, le=60_000)
    test_driver_delay: TestDriverDelay | None = None
    """TEST-ONLY, labelled: injected driver latency for live control tests. Never set by ``mobilelab run``."""


def load_config(value: str) -> WorkerConfig:
    text = value if value.lstrip().startswith("{") else Path(value).read_text(encoding="utf-8")
    return WorkerConfig.model_validate(json.loads(text))


async def _stdio_streams(proto_out_fd: int) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader(limit=MAX_FRAME_BYTES + 8)
    await loop.connect_read_pipe(lambda: asyncio.StreamReaderProtocol(reader), os.fdopen(0, "rb", buffering=0))
    transport, protocol = await loop.connect_write_pipe(
        asyncio.streams.FlowControlMixin, os.fdopen(proto_out_fd, "wb", buffering=0)
    )
    writer = asyncio.StreamWriter(transport, protocol, None, loop)
    return reader, writer


async def run_worker(adapter_name: str, config: WorkerConfig, proto_out_fd: int) -> None:
    collector = ArtifactCollector()
    adapter = create_adapter(adapter_name, config.device_id, config.adapter_options, artifact_sink=collector)
    core = WorkerCore(
        config.device_id,
        adapter,
        adapter_name=adapter_name,
        max_waiting_driver_ops=config.max_waiting_driver_ops,
        observation_cache_size=config.observation_cache_size,
        observe_timeout_ms=config.observe_timeout_ms,
        control_call_timeout_ms=config.control_call_timeout_ms,
        artifact_collector=collector,
        test_driver_delay=config.test_driver_delay.model_dump(mode="json") if config.test_driver_delay else None,
    )
    reader, writer = await _stdio_streams(proto_out_fd)
    server = WorkerServer(
        core,
        reader,
        writer,
        max_frame_bytes=config.max_frame_bytes,
        max_concurrent_requests=config.max_concurrent_requests,
    )
    await server.serve()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="mobilelab.workers.entry")
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--config", required=True, help="WorkerConfig JSON file path or inline JSON object")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="worker %(levelname)s %(name)s: %(message)s")
    config = load_config(args.config)
    proto_out_fd = os.dup(1)
    os.dup2(2, 1)  # anything printed to stdout now lands on stderr, not in the frame stream
    sys.stdout = sys.stderr
    asyncio.run(run_worker(args.adapter, config, proto_out_fd))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

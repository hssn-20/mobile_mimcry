"""Worker-side framed IPC loop around ``WorkerCore`` (runs inside the worker subprocess).

Every request is handled in its own task so control-lane requests (fence/health/authorize/close)
are answered while a driver operation is still running. The number of concurrently handled
requests is bounded; excess requests get an immediate ``WorkerBusy`` error, never a silent queue.
If the coordinator's pipe closes, the worker fences itself and exits: an orphaned worker never
continues issuing UI input.
"""

from __future__ import annotations

import asyncio
import logging
import os

from pydantic import ValidationError

from mobilelab.workers.core import WorkerCore
from mobilelab.workers.errors import WorkerBusy
from mobilelab.workers.protocol import (
    CONTROL_OPS,
    MAX_FRAME_BYTES,
    PROTOCOL_VERSION,
    REQUEST_ADAPTER,
    ArtifactWire,
    AuthorizeOp,
    AuthorizeResult,
    CloseOp,
    CloseResultBody,
    ExecuteOp,
    ExecuteResultBody,
    FenceOp,
    FenceResultBody,
    HealthOp,
    HealthResultBody,
    HelloResult,
    ObserveOp,
    ObserveResult,
    PreflightOp,
    PreflightResultBody,
    ProtocolError,
    Request,
    Response,
    ResultBody,
    encode_frame,
    error_envelope,
    read_frame,
)

log = logging.getLogger(__name__)
DEFAULT_MAX_CONCURRENT_REQUESTS = 16


class WorkerServer:
    def __init__(
        self,
        core: WorkerCore,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        *,
        max_frame_bytes: int = MAX_FRAME_BYTES,
        max_concurrent_requests: int = DEFAULT_MAX_CONCURRENT_REQUESTS,
    ) -> None:
        self.core = core
        self._reader = reader
        self._writer = writer
        self._max_frame = max_frame_bytes
        self._max_concurrent = max_concurrent_requests
        self._write_lock = asyncio.Lock()
        self._tasks: set[asyncio.Task[None]] = set()
        self._closing = asyncio.Event()

    async def _send(self, response: Response) -> None:
        frame = encode_frame(response, max_bytes=self._max_frame)
        async with self._write_lock:
            self._writer.write(frame)
            await self._writer.drain()

    async def serve(self) -> None:
        await self._send(
            Response(
                msg_id=0,
                result=HelloResult(
                    protocol_version=PROTOCOL_VERSION,
                    device_id=self.core.device_id,
                    pid=os.getpid(),
                    adapter=self.core.adapter_name,
                    evidence_source=self.core.evidence_source,
                ),
            )
        )
        reading = asyncio.ensure_future(self._read_loop())
        closing = asyncio.ensure_future(self._closing.wait())
        await asyncio.wait({reading, closing}, return_when=asyncio.FIRST_COMPLETED)
        reading.cancel()
        closing.cancel()
        if not self._closing.is_set():  # coordinator went away: fence and close, never keep driving
            await self.core.fence(self.core.control_epoch or 0)
            await self.core.close()
        for task in list(self._tasks):
            if not task.done():
                task.cancel()

    async def _read_loop(self) -> None:
        while True:
            try:
                raw = await read_frame(self._reader, max_bytes=self._max_frame)
            except ProtocolError as err:
                log.error("protocol error from coordinator: %s", err)
                return
            if raw is None:
                return
            try:
                request = REQUEST_ADAPTER.validate_json(raw)
            except ValidationError as err:
                await self._send(Response(msg_id=0, error=error_envelope(ProtocolError(f"invalid request: {err}"[:1900]))))
                continue
            if request.body.op not in CONTROL_OPS and len(self._tasks) >= self._max_concurrent:
                await self._send(Response(msg_id=request.msg_id, error=WorkerBusy("too many outstanding requests").to_envelope()))
                continue
            task = asyncio.ensure_future(self._handle(request))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    async def _handle(self, request: Request) -> None:
        body = request.body
        try:
            result: ResultBody
            match body:
                case AuthorizeOp():
                    ack = await self.core.authorize(body.lease_id, body.lease_epoch, body.control_epoch)
                    result = AuthorizeResult(ack=ack)
                case ObserveOp():
                    obs = await self.core.observe(body.request)
                    blobs = self.core.take_artifacts(obs.observation_id)
                    result = ObserveResult(observation=obs, artifacts=[ArtifactWire.from_blob(b) for b in blobs])
                case ExecuteOp():
                    result = ExecuteResultBody(result=await self.core.execute(body.command))
                case FenceOp():
                    result = FenceResultBody(result=await self.core.fence(body.control_epoch))
                case HealthOp():
                    result = HealthResultBody(result=await self.core.health())
                case CloseOp():
                    result = CloseResultBody(result=await self.core.close())
                case PreflightOp():
                    report = await self.core.preflight(body.profile, timeout_s=body.timeout_ms / 1000)
                    result = PreflightResultBody(report=report)
            response = Response(msg_id=request.msg_id, result=result)
        except Exception as err:
            response = Response(msg_id=request.msg_id, error=error_envelope(err))
        try:
            await self._send(response)
        except (ConnectionError, ProtocolError) as err:
            log.error("could not deliver response %s: %s", request.msg_id, err)
        if isinstance(body, CloseOp):
            self._closing.set()

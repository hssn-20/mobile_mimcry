"""Worker ``--adapter`` name -> adapter class. Delegates to the shared ``mobilelab.adapters.registry``.

Adapters are built with ``create_adapter(name, config, artifact_sink=...)``; ``config`` is the JSON
object from ``WorkerConfig.adapter_options`` with the worker's ``device_id`` filled in.
"""

from mobilelab.adapters.registry import ADAPTERS, UnknownAdapter, adapter_class, create_adapter

__all__ = ["ADAPTERS", "UnknownAdapter", "adapter_class", "create_adapter"]

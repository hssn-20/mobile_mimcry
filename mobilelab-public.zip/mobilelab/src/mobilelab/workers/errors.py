"""Worker transport errors and reconstruction of typed domain errors from wire envelopes."""

from __future__ import annotations

from mobilelab.domain import errors as domain_errors
from mobilelab.domain.errors import ErrorCode, ErrorEnvelope, MobilelabError


class WorkerUnavailable(MobilelabError):
    """The worker process is gone or its pipe closed; outstanding commands have unknown outcomes."""

    http_status = 503


class WorkerTimeout(MobilelabError):
    """No reply within the caller's deadline. Not proof that the operation did not happen."""

    http_status = 504


class WorkerBusy(MobilelabError):
    """Bounded queue/outstanding-request limit reached; nothing was sent to the device."""

    http_status = 503
    retryable = True


def _code_map() -> dict[ErrorCode, type[MobilelabError]]:
    out: dict[ErrorCode, type[MobilelabError]] = {}
    for name in domain_errors.__all__:
        cls = getattr(domain_errors, name)
        if isinstance(cls, type) and issubclass(cls, MobilelabError) and cls is not MobilelabError:
            out.setdefault(cls.code, cls)
    return out


_BY_CODE = _code_map()


def error_from_envelope(envelope: ErrorEnvelope) -> MobilelabError:
    cls = _BY_CODE.get(envelope.code, MobilelabError)
    return cls(envelope.message, details=dict(envelope.details), current_state=envelope.current_state)

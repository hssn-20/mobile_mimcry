"""Run reports: JSON + self-contained HTML, artifact manifest and integrity verification."""

from mobilelab.reporting.build import build_run_report, provider_label
from mobilelab.reporting.bundle import (
    IntegrityResult,
    ReportBundle,
    default_report_dir,
    verify_report_integrity,
    write_report,
)
from mobilelab.reporting.html import render_html
from mobilelab.reporting.model import NOT_EVALUATED, RunReport

__all__ = [
    "NOT_EVALUATED",
    "IntegrityResult",
    "ReportBundle",
    "RunReport",
    "build_run_report",
    "default_report_dir",
    "provider_label",
    "render_html",
    "verify_report_integrity",
    "write_report",
]

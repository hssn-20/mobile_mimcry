"""Decision-latency and timing summary over recorded runs (read-only; T08 evidence).

Only decisions whose result was used (``accepted`` or ``rejected``: a full model answer arrived) count
toward decision-latency statistics. ``cancelled`` (no answer arrived: pause/stop/timeout cut the call
short), ``discarded_stale`` (a late answer was thrown away) and ``provider_error`` decisions are
reported separately with their own latencies, so a partial call is never pooled as a full decision.

``uv run python -m mobilelab.reporting.latency --db artifacts/mobilelab.db --out DIR RUN_ID...``
"""

from __future__ import annotations

import argparse
import json
import math
import sqlite3
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

FULL_DECISION_OUTCOMES = frozenset({"accepted", "rejected"})


def stats(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"n": 0}
    v = sorted(values)
    p90 = v[max(0, math.ceil(0.9 * len(v)) - 1)]  # nearest rank
    return {"n": len(v), "median": round(statistics.median(v), 1), "p90": round(p90, 1), "max": round(v[-1], 1)}


def _ts(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value.replace("Z", "+00:00")) if value else None


def run_summary(conn: sqlite3.Connection, run_id: str) -> dict[str, Any]:
    run = json.loads(conn.execute("SELECT body FROM runs WHERE run_id = ?", (run_id,)).fetchone()[0])
    decisions = [(o, lat, json.loads(b)) for o, lat, b in conn.execute(
        "SELECT outcome, latency_ms, body FROM decisions WHERE run_id = ? ORDER BY created_at", (run_id,))]  # fmt: skip
    full = [lat for o, lat, _ in decisions if o in FULL_DECISION_OUTCOMES and lat is not None]
    excluded = [
        {"outcome": o, "latency_ms": round(lat, 1) if lat is not None else None,
         "error_class": ((b.get("error") or {}).get("details") or {}).get("error_class")}
        for o, lat, b in decisions if o not in FULL_DECISION_OUTCOMES
    ]  # fmt: skip
    obs_end: dict[str, datetime | None] = {}
    o2d: list[float] = []
    status: Counter[str] = Counter()
    for (body,) in conn.execute("SELECT body FROM actions WHERE run_id = ?", (run_id,)):
        a = json.loads(body)
        status[a["status"]] += 1
        oid = a.get("decision_observation_id")
        if oid and oid not in obs_end:
            row = conn.execute("SELECT body FROM observations WHERE observation_id = ?", (oid,)).fetchone()
            obs_end[oid] = _ts(json.loads(row[0]).get("capture_ended_at")) if row else None
        end, disp = obs_end.get(oid), _ts(a.get("actual_dispatch_at"))
        if end and disp:
            o2d.append((disp - end).total_seconds() * 1000)
    provider = decisions[0][2].get("provider_id") if decisions else None
    return {
        "run": run_id,
        "status": run.get("status"),
        "verdict": run.get("verdict"),
        "provider": provider,
        "decision_outcomes": dict(Counter(o for o, _, _ in decisions)),
        "decision_latency_ms": stats(full),
        "excluded_from_latency": excluded,
        "observe_to_dispatch_ms": stats(o2d),
        "action_status": dict(status),
        "_full": full,
        "_o2d": o2d,
    }


def summarize(db: Path, run_ids: list[str]) -> dict[str, Any]:
    conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        runs = [run_summary(conn, r) for r in run_ids]
    finally:
        conn.close()
    pooled: dict[str, dict[str, Any]] = defaultdict(lambda: {"runs": [], "_full": [], "_o2d": [], "excluded": []})
    for r in runs:
        p = pooled[r["provider"] or "unknown"]
        p["runs"].append(r["run"])
        p["_full"] += r.pop("_full")
        p["_o2d"] += r.pop("_o2d")
        p["excluded"] += r["excluded_from_latency"]
    out = {k: {"runs": v["runs"], "decision_latency_ms": stats(v["_full"]), "observe_to_dispatch_ms": stats(v["_o2d"]),
               "excluded_from_latency": v["excluded"]} for k, v in pooled.items()}  # fmt: skip
    return {"rule": "decision latency counts accepted/rejected decisions only", "per_run": runs, "pooled": out}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--db", type=Path, required=True)
    ap.add_argument("--out", type=Path)
    ap.add_argument("run_ids", nargs="+")
    args = ap.parse_args(argv)
    summary = summarize(args.db, args.run_ids)
    text = json.dumps(summary, indent=1)
    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "latency_summary.json").write_text(text + "\n")
    print(json.dumps(summary["pooled"], indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())


__all__ = ["FULL_DECISION_OUTCOMES", "run_summary", "stats", "summarize"]

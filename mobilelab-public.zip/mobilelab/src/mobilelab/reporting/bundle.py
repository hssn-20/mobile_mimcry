"""Write a run report bundle (report.json, report.html, manifest.json) and verify its integrity.

Default layout: ``<artifacts_root>/runs/<run_id>/`` — the same directory that ``ArtifactStore``
uses for the run's evidence files, so artifact links are sibling paths. Report files are written
atomically and may be regenerated; original evidence is never modified or deleted.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any
from uuid import UUID

from pydantic import ValidationError

from mobilelab.domain.errors import ArtifactPathViolation
from mobilelab.store import ArtifactStore, Store
from mobilelab.reporting.build import build_run_report
from mobilelab.reporting.html import render_html
from mobilelab.reporting.model import NOT_EVALUATED, VERDICT_KEYS, RunReport

MANIFEST_SCHEMA_VERSION = 1
REPORT_JSON = "report.json"
REPORT_HTML = "report.html"
MANIFEST_JSON = "manifest.json"


@dataclass(frozen=True, slots=True)
class ReportBundle:
    directory: Path
    report: RunReport
    manifest: dict[str, Any]


@dataclass(frozen=True, slots=True)
class IntegrityResult:
    ok: bool
    problems: list[str]
    files_checked: int


def default_report_dir(artifacts_root: Path | str, run_id: UUID) -> Path:
    return Path(artifacts_root) / "runs" / str(run_id)


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _atomic_write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp-", suffix=".part")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _posix_rel(target: Path, start: Path) -> str:
    return PurePosixPath(*Path(os.path.relpath(target, start)).parts).as_posix()


def _href(target: Path, start: Path) -> str:
    """Relative link that can never be read as a URL scheme (e.g. a stored name like ``javascript:x``)."""
    rel = _posix_rel(target, start)
    return rel if rel.startswith("../") else f"./{rel}"


def write_report(
    store: Store, run_id: UUID, artifacts_root: Path | str, *, report_dir: Path | str | None = None
) -> ReportBundle:
    root = Path(artifacts_root).resolve()
    out = Path(report_dir).resolve() if report_dir is not None else default_report_dir(root, run_id).resolve()
    out.mkdir(parents=True, exist_ok=True)
    report = build_run_report(store, run_id, root)

    links: dict[UUID, str] = {
        ae.metadata.artifact_id: _href(root / ae.metadata.relative_path, out)
        for ae in report.artifacts
        if ae.check != "path_violation"
    }
    report_bytes = (report.model_dump_json(indent=2) + "\n").encode("utf-8")
    html_bytes = render_html(report, artifact_links=links).encode("utf-8")
    manifest: dict[str, Any] = {
        "manifest_schema_version": MANIFEST_SCHEMA_VERSION,
        "run_id": str(run_id),
        "generated_at": report.generated_at.isoformat(),
        "generator": report.generator,
        "provider_label": report.labels.provider_label,
        "provider_kind": report.labels.provider_kind,
        "model_identifier": report.labels.model_identifier,
        "evidence_category": report.labels.planned_evidence.value,
        "device_kind": report.labels.device_kind.value,
        "no_device": report.labels.no_device,
        "messaging_disclaimer": report.labels.messaging_disclaimer,
        "run_status": report.run.status.value,
        "interrupted": report.run.interrupted,
        "config_hashes": report.config_hashes,
        "versions": report.versions,
        "verdict_counts": report.verdict_counts.model_dump(mode="json"),
        "result_counts": report.result_counts.model_dump(mode="json"),
        "artifacts_root": _posix_rel(root, out),
        "report_files": [
            {"path": REPORT_JSON, "sha256": _sha256(report_bytes), "size_bytes": len(report_bytes)},
            {"path": REPORT_HTML, "sha256": _sha256(html_bytes), "size_bytes": len(html_bytes)},
        ],
        "artifacts": [
            {
                "artifact_id": str(ae.metadata.artifact_id),
                "relative_path": ae.metadata.relative_path,
                "sha256": ae.metadata.sha256,
                "size_bytes": ae.metadata.size_bytes,
                "content_type": ae.metadata.content_type,
                "evidence_source": ae.metadata.evidence_source.value,
                "check_at_report_time": ae.check,
            }
            for ae in report.artifacts
        ],
    }
    _atomic_write(out / REPORT_JSON, report_bytes)
    _atomic_write(out / REPORT_HTML, html_bytes)
    _atomic_write(out / MANIFEST_JSON, (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8"))
    return ReportBundle(directory=out, report=report, manifest=manifest)


# -- verification ---------------------------------------------------------------------------------


def _referential_problems(report: RunReport) -> list[str]:
    problems: list[str] = []
    run_id = report.run.run_id
    obs = {o.observation_id: o for o in report.observations}
    decisions = {d.decision_id: d for d in report.decisions}
    actions = {a.action.action_id: a for a in report.actions}
    attempts = {t.attempt_id for a in report.actions for t in a.attempts}
    oracle_ids = {o.oracle_result_id for o in report.oracle_results}
    artifact_ids = {ae.metadata.artifact_id for ae in report.artifacts}

    for d in report.decisions:
        if d.run_id != run_id:
            problems.append(f"decision {d.decision_id} belongs to run {d.run_id}")
        o = obs.get(d.decision_observation_id)
        if o is None:
            problems.append(f"decision {d.decision_id} references missing observation {d.decision_observation_id}")
        elif d.outcome == "accepted" and d.proposal is not None:
            if d.proposal.candidate_id not in {c.candidate_id for c in o.candidates}:
                problems.append(f"accepted decision {d.decision_id} selects a candidate not offered in its observation")
    for aid, a in actions.items():
        act = a.action
        if act.run_id != run_id:
            problems.append(f"action {aid} belongs to run {act.run_id}")
        if act.decision_id is not None and act.decision_id not in decisions:
            problems.append(f"action {aid} references missing decision {act.decision_id}")
        for label, ref in (("decision", act.decision_observation_id), ("dispatch", act.dispatch_observation_id)):
            if ref is not None and ref not in obs:
                problems.append(f"action {aid} references missing {label} observation {ref}")
        for t in a.attempts:
            if t.action_id != aid:
                problems.append(f"attempt {t.attempt_id} is listed under action {aid} but belongs to {t.action_id}")
    for o in report.observations:
        if o.screenshot_artifact_id is not None and o.screenshot_artifact_id not in artifact_ids:
            problems.append(f"observation {o.observation_id} references missing artifact {o.screenshot_artifact_id}")
    for r in report.oracle_results:
        if r.run_id != run_id:
            problems.append(f"oracle result {r.oracle_result_id} belongs to run {r.run_id}")
    for p in report.planned_oracles:
        if p.oracle_result_id is not None and p.oracle_result_id not in oracle_ids:
            problems.append(f"planned oracle {p.index} references missing result {p.oracle_result_id}")
        if p.effective_verdict != NOT_EVALUATED and p.oracle_result_id is None:
            problems.append(f"planned oracle {p.index} claims verdict {p.effective_verdict} without a result")
    refs: dict[str, set[Any]] = {
        "action": {str(x) for x in actions},
        "observation": {str(x) for x in obs},
        "decision": {str(x) for x in decisions},
        "oracle_result": {str(x) for x in oracle_ids},
        "attempt": {str(x) for x in attempts},
        "artifact": {str(x) for x in artifact_ids},
    }
    for t in report.timeline:
        if t.ref_type in refs and t.ref_id not in refs[t.ref_type]:
            problems.append(f"timeline entry {t.event_id} references missing {t.ref_type} {t.ref_id}")
    for counts in (report.verdict_counts, report.result_counts):
        if set(counts.counts) != set(VERDICT_KEYS) or sum(counts.counts.values()) != counts.denominator:
            problems.append(f"verdict counts ({counts.basis}) do not sum to the denominator")
    expected = [p.effective_verdict for p in report.planned_oracles]
    if report.verdict_counts.denominator != len(expected) or any(
        report.verdict_counts.counts.get(k, 0) != expected.count(k) for k in VERDICT_KEYS
    ):
        problems.append("planned verdict counts do not match the planned oracle verdicts")
    return problems


def verify_report_integrity(report_dir: Path | str) -> IntegrityResult:
    """Check file hashes (report files and evidence artifacts) and referential integrity."""
    base = Path(report_dir)
    problems: list[str] = []
    checked = 0
    try:
        manifest = json.loads((base / MANIFEST_JSON).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return IntegrityResult(False, [f"manifest unreadable: {type(exc).__name__}"], 0)

    for entry in manifest.get("report_files", []):
        name = str(entry.get("path", ""))
        if name not in (REPORT_JSON, REPORT_HTML):
            problems.append(f"unexpected report file entry {name!r}")
            continue
        try:
            data = (base / name).read_bytes()
        except OSError:
            problems.append(f"{name} missing")
            continue
        checked += 1
        if _sha256(data) != entry.get("sha256"):
            problems.append(f"{name} sha256 mismatch")
    if {e.get("path") for e in manifest.get("report_files", [])} != {REPORT_JSON, REPORT_HTML}:
        problems.append("manifest does not list both report files")

    try:
        report = RunReport.model_validate_json((base / REPORT_JSON).read_bytes())
    except (OSError, ValidationError) as exc:
        problems.append(f"report.json invalid: {type(exc).__name__}")
        return IntegrityResult(False, problems, checked)
    if str(report.run.run_id) != manifest.get("run_id"):
        problems.append("manifest run_id does not match report")

    by_id = {str(ae.metadata.artifact_id): ae.metadata for ae in report.artifacts}
    listed = {str(a.get("artifact_id")): a for a in manifest.get("artifacts", [])}
    if set(by_id) != set(listed):
        problems.append("manifest artifact list does not match the report's artifact list")
    root = base / str(manifest.get("artifacts_root", "."))
    astore = ArtifactStore(root) if root.is_dir() else None
    for aid, entry in listed.items():
        meta = by_id.get(aid)
        if meta is not None and (meta.sha256 != entry.get("sha256") or meta.relative_path != entry.get("relative_path")):
            problems.append(f"artifact {aid} metadata differs between report and manifest")
        if astore is None:
            problems.append(f"artifact {aid} missing (artifact root not found)")
            continue
        try:
            data = astore.resolve(str(entry.get("relative_path"))).read_bytes()
        except ArtifactPathViolation:
            problems.append(f"artifact {aid} path escapes the artifact root")
            continue
        except OSError:
            problems.append(f"artifact {aid} missing")
            continue
        checked += 1
        if _sha256(data) != entry.get("sha256"):
            problems.append(f"artifact {aid} sha256 mismatch")

    problems.extend(_referential_problems(report))
    return IntegrityResult(not problems, problems, checked)

"""Self-contained HTML rendering of a RunReport.

No scripts and no external assets (inline CSS only, light/dark via prefers-color-scheme). Every
value from the report is escaped: element labels, provider explanations and fixture text are
untrusted. Artifact links are relative paths computed by trusted code.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from html import escape
from typing import Any
from uuid import UUID

from mobilelab.reporting.model import NOT_EVALUATED, VERDICT_KEYS, RunReport, VerdictCounts

_CSS = """
:root{color-scheme:light dark;--bg:#f7f7f5;--fg:#1d1d1f;--muted:#5f6368;--card:#fff;--line:#d9d9d6;
--pass:#16794a;--fail:#b3261e;--warn:#8a5a00;--info:#2b5fb4;--code:#f0f0ec}
@media (prefers-color-scheme:dark){:root{--bg:#141416;--fg:#ececec;--muted:#a0a4ab;--card:#1d1e21;--line:#34363b;
--pass:#5cc58d;--fail:#ff8a80;--warn:#f0b54a;--info:#8ab4f8;--code:#26272b}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
main{max-width:1200px;margin:0 auto;padding:16px}h1{font-size:22px;margin:8px 0}h2{font-size:17px;margin:24px 0 8px}
section{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px 14px;margin:12px 0;overflow-x:auto}
table{border-collapse:collapse;width:100%}th,td{text-align:left;vertical-align:top;padding:4px 8px;border-bottom:1px solid var(--line)}
th{color:var(--muted);font-weight:600;white-space:nowrap}code,pre{font-family:ui-monospace,Menlo,monospace;font-size:12px}
pre{background:var(--code);padding:8px;border-radius:6px;white-space:pre-wrap;word-break:break-word;margin:4px 0}
.labels{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}.tag{border:1px solid var(--line);border-radius:999px;padding:2px 10px}
.banner{border-left:4px solid var(--warn);padding:8px 12px;background:var(--card);margin:12px 0}
.v-PASS{color:var(--pass);font-weight:600}.v-DUT_FAILURE,.v-HARNESS_FAILURE,.v-ENVIRONMENT_FAILURE{color:var(--fail);font-weight:600}
.v-INCONCLUSIVE,.v-NOT_EVALUATED,.v-UNSUPPORTED{color:var(--warn);font-weight:600}.muted{color:var(--muted)}
img.shot{max-width:180px;border:1px solid var(--line);border-radius:4px}
@media (max-width:640px){main{padding:16px}th,td{padding:4px}}
"""

_CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; script-src 'none'; base-uri 'none'; form-action 'none'"


def _e(value: Any) -> str:
    return escape("" if value is None else str(value), quote=True)


def _verdict(v: str | None) -> str:
    v = v or NOT_EVALUATED
    cls = v if v in VERDICT_KEYS else "NOT_EVALUATED"
    return f'<span class="v-{cls}">{_e(v)}</span>'


def _json(value: Any) -> str:
    return f"<pre>{_e(json.dumps(value, indent=2, sort_keys=True, default=str))}</pre>"


def _table(headers: Iterable[str], rows: Iterable[Iterable[str]]) -> str:
    head = "".join(f"<th>{_e(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body or '<tr><td class=muted>none</td></tr>'}</tbody></table>"


def _counts(c: VerdictCounts) -> str:
    rows = [[_verdict(k), _e(n), _e(f"{n}/{c.denominator}")] for k, n in c.counts.items()]
    return f"<p class=muted>{_e(c.basis)}; denominator {c.denominator}</p>" + _table(["Verdict", "Count", "Of"], rows)


def render_html(report: RunReport, *, artifact_links: Mapping[UUID, str] | None = None) -> str:
    links = artifact_links or {}
    r, lab = report.run, report.labels
    out: list[str] = []
    title = f"Run report {r.run_id}"
    out.append(f"<h1>{_e(title)}</h1>")
    tags = [
        f"Provider: {lab.provider_label}",
        f"Evidence category: {lab.planned_evidence.value}",
        f"Device kind: {lab.device_kind.value}" + (" (MOCK, no device)" if lab.no_device else ""),
        f"Platform: {lab.platform.value}",
    ]
    if lab.model_identifier:
        tags.append(f"Model: {lab.model_identifier}")
    if lab.provider_kind:
        tags.append(f"Provider kind: {lab.provider_kind}")
    out.append('<div class="labels">' + "".join(f'<span class="tag">{_e(t)}</span>' for t in tags) + "</div>")
    if lab.messaging_disclaimer:
        out.append(f'<div class="banner"><strong>{_e(lab.messaging_disclaimer)}.</strong></div>')
    if r.interrupted:
        out.append(
            f'<div class="banner">This run did not complete (status {_e(r.status.value)}). '
            "Planned checks without stored results are shown as NOT_EVALUATED, never as passed.</div>"
        )

    summary = [
        ("Status", _e(r.status.value) + (f" — {_e(r.status_reason)}" if r.status_reason else "")),
        ("Recorded run verdict", _verdict(r.recorded_verdict.value) if r.recorded_verdict else '<span class="muted">not recorded</span>'),
        ("Scenario", _e(f"{r.scenario_id} v{r.scenario_version}")),
        ("Persona", _e(f"{r.persona_id} v{r.persona_version}")),
        ("Seed", _e(r.seed)),
        ("Created / started / ended", _e(f"{r.created_at} / {r.started_at} / {r.ended_at}")),
        ("In recovery", _e(r.in_recovery)),
        ("Obtained evidence", _e(f"{lab.obtained_evidence} ({lab.obtained_evidence_source})")),
        ("Observation sources", _e(lab.observation_evidence_sources)),
        ("Generated", _e(report.generated_at)),
    ]
    out.append("<section><h2>Summary</h2>" + _table(["Field", "Value"], ([_e(k), v] for k, v in summary)) + "</section>")

    pu = report.provider_usage
    if pu is not None:
        def money(v: float | None) -> str:
            return "n/a" if v is None else f"${v:.6f}"

        rows = [
            ("Provider", _e(f"{pu.provider_label} (kind {pu.provider_kind}, {pu.deployment or 'local'})")),
            ("Model identifier", _e(pu.model_identifier or "none")),
            ("Observation modality", _e(pu.observation_modality or "text") + _e(f"; image support: {pu.supports_images}")),
            ("Usage reported", _e(pu.usage_reported)),
            ("Requests / input tokens / output tokens", _e(f"{pu.requests} / {pu.input_tokens} / {pu.output_tokens}")),
            ("Cost estimated / confirmed / unresolved",
             _e(f"{money(pu.estimated_cost_usd)} / {money(pu.confirmed_cost_usd)} / {money(pu.unresolved_cost_usd)}")),
            ("Source", _e(pu.source)),
        ]  # fmt: skip
        out.append("<section><h2>Decision provider and usage</h2>" + _table(["Field", "Value"], ([_e(k), v] for k, v in rows)) + "</section>")

    out.append("<section><h2>Verdict counts (planned oracles)</h2>" + _counts(report.verdict_counts))
    out.append(
        _table(
            ["#", "Oracle", "Required", "Timeout s", "Effective verdict", "Result"],
            (
                [_e(p.index), _e(p.kind), _e(p.required_status), _e(p.timeout_seconds), _verdict(p.effective_verdict), _e(p.oracle_result_id)]
                for p in report.planned_oracles
            ),
        )
        + "</section>"
    )
    out.append("<section><h2>All oracle results</h2>" + _counts(report.result_counts))
    for o in report.oracle_results:
        out.append(
            f"<h3>{_verdict(o.verdict.value)} {_e(o.reason_code)} <span class=muted>{_e(o.oracle_kind)} {_e(o.oracle_result_id)}</span></h3>"
            f"<p>Window {_e(o.observation_window_start)} → {_e(o.observation_window_end)}; "
            f"requirements {_e(', '.join(o.requirement_refs))}; evidence category {_e(o.obtained_evidence)}</p>"
            f"<p>Expected</p>{_json(o.expected)}<p>Observed</p>{_json(o.observed)}"
            f"<p>Evidence ids</p>{_json(o.evidence_ids)}"
        )
    out.append("</section>")

    out.append(
        "<section><h2>Timeline</h2>"
        + _table(
            ["Time (UTC)", "Event", "Kind", "Reference", "Summary"],
            ([_e(t.at), _e(t.event_id), _e(t.kind), _e(f"{t.ref_type}:{t.ref_id}" if t.ref_id else ""), _e(t.summary)] for t in report.timeline),
        )
        + "</section>"
    )

    rows = []
    for a in report.actions:
        act = a.action
        attempts = "<br>".join(
            _e(
                f"#{t.attempt_no} {t.status.value if t.status else 'pending'} "
                f"{t.started_at}→{t.ended_at}"
                + (f" {t.result.duration_ms:.0f} ms" if t.result and t.result.duration_ms is not None else "")
                + (f" typing={t.result.typing_mode_actual.value}" if t.result and t.result.typing_mode_actual else "")
                + (f" source={t.result.evidence_source.value}" if t.result else "")
                + (f" rejected={t.result.rejection_code}" if t.result and t.result.rejection_code else "")
            )
            for t in a.attempts
        )
        timing = _e(
            f"delay {act.sampled_delay_ms} ms; decision latency {act.decision_latency_ms} ms; "
            f"scheduled {act.scheduled_at}; dispatched {act.actual_dispatch_at}; overrun {act.timing_overrun_ms} ms"
        )
        payload = _json(act.payload.model_dump(mode="json")) if act.payload else '<span class="muted">not bound</span>'
        rows.append(
            [
                _e(act.action_id),
                _e(f"{act.kind.value} {act.semantic_key}"),
                _e(act.status.value),
                _e(a.validation),
                timing,
                attempts,
                payload + f"<p>{_e(a.explanation)}</p>",
            ]
        )
    out.append(
        "<section><h2>Actions (planned vs actual timing)</h2>"
        + _table(["Action", "Kind", "Status", "Validation", "Timing", "Attempts", "Payload and explanation"], rows)
        + "</section>"
    )

    out.append(
        "<section><h2>Decisions</h2>"
        + _table(
            ["Decision", "Time", "Provider", "Outcome", "Candidate", "Reason code", "Latency ms", "Explanation (untrusted)"],
            (
                [
                    _e(d.decision_id),
                    _e(d.created_at),
                    _e(d.provider_id + (f" / {d.model_identifier}" if d.model_identifier else "")),
                    _e(d.outcome + (f" ({d.error.code})" if d.error else "")),
                    _e(d.proposal.candidate_id if d.proposal else ""),
                    _e(d.proposal.reason_code if d.proposal else ""),
                    _e(d.latency_ms),
                    _e(d.proposal.explanation if d.proposal else ""),
                ]
                for d in report.decisions
            ),
        )
        + "</section>"
    )

    obs_rows = []
    for o in report.observations:
        shot = ""
        if o.screenshot_artifact_id is not None:
            href = links.get(o.screenshot_artifact_id)
            shot = (
                f'<a href="{_e(href)}"><img class="shot" alt="screenshot" src="{_e(href)}"></a>'
                if href
                else f'<span class="muted">screenshot {_e(o.screenshot_artifact_id)} unavailable</span>'
            )
        elements = "<br>".join(
            _e(f"{el.identifier or el.element_ref} [{el.role}] {el.label or ''}" + (f" = {el.value}" if el.value else ""))
            for el in o.elements
        )
        cands = "<br>".join(
            _e(f"{c.candidate_id} {c.kind.value} {c.semantic_key} ({c.side_effect_class.value})")
            + (_e(f" rebound from {c.rebound_from_candidate_id}") if c.rebound_from_candidate_id else "")
            for c in o.candidates
        )
        obs_rows.append(
            [
                _e(o.observation_id),
                _e(f"{o.capture_started_at} → {o.capture_ended_at}"),
                _e(f"{o.evidence_source.value}; {o.foreground_app}; {o.orientation.value}"),
                shot,
                elements,
                cands,
            ]
        )
    out.append(
        "<section><h2>Observations</h2>"
        + _table(["Observation", "Capture", "Source; app; orientation", "Screenshot", "Elements (untrusted text)", "Candidates"], obs_rows)
        + "</section>"
    )

    out.append(
        "<section><h2>Interventions</h2>"
        + _table(["Time", "Kind", "Detail", "Command"], ([_e(i.at), _e(i.kind), _e(i.detail), _e(i.command_id)] for i in report.interventions))
        + "</section>"
    )
    art_rows = []
    for ae in report.artifacts:
        m = ae.metadata
        href = links.get(m.artifact_id)
        name = f'<a href="{_e(href)}">{_e(m.relative_path)}</a>' if href else _e(m.relative_path)
        art_rows.append([_e(m.artifact_id), name, _e(m.content_type), _e(m.size_bytes), f"<code>{_e(m.sha256)}</code>", _e(m.evidence_source.value), _e(ae.check)])
    out.append(
        "<section><h2>Artifacts</h2>"
        + _table(["Artifact", "Path", "Type", "Bytes", "SHA-256", "Source", "Check"], art_rows)
        + "</section>"
    )
    out.append(
        "<section><h2>Configuration and versions</h2>"
        + _table(["Hash", "Value"], ([_e(k), f"<code>{_e(v)}</code>"] for k, v in report.config_hashes.items()))
        + _json(report.versions)
        + "<p>Policy limits</p>"
        + _json(report.policy_limits)
        + "</section>"
    )
    out.append(
        "<section><h2>Exclusions and limitations</h2><ul>"
        + "".join(f"<li>{_e(x)}</li>" for x in [*report.exclusions, *report.limitations])
        + "</ul></section>"
    )
    return (
        "<!doctype html><html lang=en><head><meta charset=utf-8>"
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<meta http-equiv="Content-Security-Policy" content="{_CSP}">'
        f"<title>{_e(f'Run report {str(r.run_id)[:8]}')}</title><style>{_CSS}</style></head>"
        f"<body><main>{''.join(out)}</main></body></html>\n"
    )

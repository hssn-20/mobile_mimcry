"""Machine-readable run report (CONTRACTS §9, §11; ACCEPTANCE AC-14).

The report is a read-only compilation of stored records. It never invents telemetry: a planned
oracle without a stored result is ``NOT_EVALUATED`` and is never counted as a pass.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import Field, JsonValue

from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.base import StrictModel, UtcDatetime
from mobilelab.domain.decisions import DecisionRecord
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord
from mobilelab.domain.enums import (
    ActionStatus,
    DeviceKind,
    EvidenceCategory,
    EvidenceSource,
    Orientation,
    Platform,
    RunStatus,
    Verdict,
)
from mobilelab.domain.observations import CandidateAction
from mobilelab.domain.scenarios import OracleResult

REPORT_SCHEMA_VERSION = 1
NOT_EVALUATED = "NOT_EVALUATED"
VERDICT_KEYS: tuple[str, ...] = (*(v.value for v in Verdict), NOT_EVALUATED)

ArtifactCheck = Literal["ok", "missing", "digest_mismatch", "path_violation"]


class RunSummary(StrictModel):
    run_id: UUID
    campaign_id: UUID | None
    status: RunStatus
    status_reason: str | None
    recorded_verdict: Verdict | None
    """The run-level verdict recorded by the coordinator (None if never recorded)."""
    interrupted: bool
    in_recovery: bool
    control_epoch: int
    scenario_id: str
    scenario_version: int
    persona_id: str
    persona_version: int
    seed: int
    created_at: UtcDatetime
    started_at: UtcDatetime | None
    ended_at: UtcDatetime | None


class ProviderUsage(StrictModel):
    """Decision-provider identity and spend for the run (CONTRACTS §11: estimated, confirmed and
    unresolved amounts are reported separately, never summed into one number)."""

    provider_kind: str
    provider_label: str
    model_identifier: str | None = None
    deployment: str | None = None
    supports_images: bool | None = None
    observation_modality: str | None = None
    usage_reported: bool = False
    """False when the provider reports no usage (RulesProvider/ReplayProvider spend nothing)."""
    requests: int | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    estimated_cost_usd: float | None = None
    confirmed_cost_usd: float | None = None
    unresolved_cost_usd: float | None = None
    source: str
    """Where these numbers came from (the run's ``provider_usage.json`` artifact or the run spec)."""
    detail: dict[str, JsonValue] = Field(default_factory=dict)
    """Further provider-reported accounting (rate card id/source, caps, ledger totals), as given."""


class ReportLabels(StrictModel):
    provider_label: str
    provider_id: str
    model_identifier: str | None
    provider_kind: str | None = None
    planned_evidence: EvidenceCategory
    obtained_evidence: EvidenceCategory | None
    obtained_evidence_source: EvidenceSource | None
    device_kind: DeviceKind
    platform: Platform
    messaging_disclaimer: str | None
    observation_evidence_sources: dict[str, int]
    """Count of observations by evidence_source (device/mock/replay)."""
    no_device: bool = False
    """True when no device or Simulator was involved (mock/replay only); ``device_kind`` is then only
    the profile the mock stood in for."""


class VerdictCounts(StrictModel):
    basis: str
    denominator: int = Field(ge=0)
    counts: dict[str, int]


class PlannedOracle(StrictModel):
    index: int = Field(ge=0)
    kind: str
    required_status: str | None
    timeout_seconds: float | None
    effective_verdict: str
    """Latest stored verdict for this oracle kind, or NOT_EVALUATED."""
    oracle_result_id: UUID | None


class ElementSummary(StrictModel):
    element_ref: str
    role: str
    identifier: str | None
    label: str | None
    """Untrusted on-screen text; rendered escaped."""
    value: str | None


class ObservationEntry(StrictModel):
    observation_id: UUID
    evidence_source: EvidenceSource
    capture_started_at: UtcDatetime
    capture_ended_at: UtcDatetime
    foreground_app: str | None
    orientation: Orientation
    keyboard_visible: bool
    screenshot_artifact_id: UUID | None
    element_count: int
    elements: list[ElementSummary]
    """Labelled/identified elements (capped); untrusted text."""
    candidates: list[CandidateAction]


class StatusChange(StrictModel):
    at: UtcDatetime
    event_id: int
    from_status: ActionStatus | None
    to_status: ActionStatus


class ActionEntry(StrictModel):
    action: ActionRecord
    attempts: list[AttemptRecord]
    status_history: list[StatusChange]
    validation: str
    """validated | rejected:<code> | cancelled | pending."""
    explanation: str
    """Factual summary assembled from stored records; not model reasoning."""


class TimelineEntry(StrictModel):
    at: UtcDatetime
    event_id: int | None
    kind: str
    ref_type: str | None
    ref_id: str | None
    summary: str


class Intervention(StrictModel):
    at: UtcDatetime
    kind: str
    detail: str
    command_id: UUID | None = None


class ArtifactEntry(StrictModel):
    metadata: ArtifactMetadata
    check: ArtifactCheck
    """Result of re-hashing the stored file at report time."""


class RunReport(StrictModel):
    report_schema_version: Literal[1] = REPORT_SCHEMA_VERSION
    generated_at: datetime
    generator: dict[str, str]
    run: RunSummary
    labels: ReportLabels
    config_hashes: dict[str, str | None]
    versions: dict[str, JsonValue]
    policy_limits: dict[str, JsonValue]
    planned_oracles: list[PlannedOracle]
    verdict_counts: VerdictCounts
    """Effective verdict per planned oracle; denominator = planned oracle count."""
    result_counts: VerdictCounts
    """Every stored oracle result, including superseded/reconciliation results."""
    oracle_results: list[OracleResult]
    observations: list[ObservationEntry]
    decisions: list[DecisionRecord]
    actions: list[ActionEntry]
    timeline: list[TimelineEntry]
    interventions: list[Intervention]
    artifacts: list[ArtifactEntry]
    exclusions: list[str]
    limitations: list[str]
    provider_usage: ProviderUsage | None = None

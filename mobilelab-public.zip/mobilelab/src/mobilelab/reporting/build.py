"""Compile a RunReport from the store (read-only unit of work) and the run artifact directory."""

from __future__ import annotations

import hashlib
import json
import platform as host_platform
from collections import Counter
from importlib import metadata
from pathlib import Path
from typing import Any, TypeVar
from uuid import UUID

from pydantic import BaseModel, ValidationError
from sqlalchemy import select

from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import ControlCommand
from mobilelab.domain.decisions import DecisionRecord
from mobilelab.domain.enums import (
    ActionStatus,
    CommandKind,
    ConfigKind,
    DeviceKind,
    EvidenceCategory,
    EvidenceSource,
    EventType,
    RunStatus,
)
from mobilelab.domain.errors import ArtifactPathViolation, NotFound
from mobilelab.domain.events import (
    ActionStatusChangedEvent,
    Event,
    RunStatusChangedEvent,
)
from mobilelab.domain.observations import Observation
from mobilelab.domain.runs import Run
from mobilelab.domain.scenarios import OracleResult, ScenarioSpec
from mobilelab.store import ArtifactStore, Store, UnitOfWork
from mobilelab.store.models import CommandRow, DecisionRow, ObservationRow
from mobilelab.reporting.model import (
    ProviderUsage,
    NOT_EVALUATED,
    VERDICT_KEYS,
    ActionEntry,
    ArtifactCheck,
    ArtifactEntry,
    ElementSummary,
    Intervention,
    ObservationEntry,
    PlannedOracle,
    ReportLabels,
    RunReport,
    RunSummary,
    StatusChange,
    TimelineEntry,
    VerdictCounts,
)

M = TypeVar("M", bound=BaseModel)

GENERATOR_NAME = "mobilelab.reporting"
PROVIDER_LABELS = {"rules": "RulesProvider", "replay": "ReplayProvider"}
MAX_ELEMENTS_PER_OBSERVATION = 60
INTERVENTION_RUN_STATUSES = frozenset({RunStatus.PAUSING, RunStatus.PAUSED, RunStatus.STOPPING, RunStatus.ABORTED})


def _package_version() -> str:
    try:
        return metadata.version("mobilelab")
    except metadata.PackageNotFoundError:
        return "unknown"


USAGE_ARTIFACT = "provider_usage.json"
_USAGE_NUMBERS = ("requests", "input_tokens", "output_tokens", "estimated_cost_usd", "confirmed_cost_usd", "unresolved_cost_usd")


def _num(v: Any, kind: type) -> Any:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    return kind(v)


def provider_usage_summary(
    spec: Any, label: str, artifacts: list[ArtifactMetadata], astore: ArtifactStore | None
) -> tuple[ProviderUsage, list[str]]:
    """Provider identity + usage from the run's ``provider_usage.json`` artifact, else the spec."""
    cfg = dict(spec.provider_config)
    problems: list[str] = []
    raw: dict[str, Any] = {}
    source = "run spec (no provider usage artifact)"
    meta = next((m for m in artifacts if m.relative_path.endswith("-" + USAGE_ARTIFACT)), None)
    if meta is not None and astore is not None:
        try:
            raw = json.loads(astore.read_bytes(meta).decode("utf-8"))
            source = f"artifact {meta.artifact_id} ({USAGE_ARTIFACT})"
        except Exception as exc:  # integrity failure is reported, numbers are not guessed
            problems.append(f"Provider usage artifact {meta.artifact_id} unreadable: {type(exc).__name__}.")
            raw = {}
    cost = raw.get("cost") if isinstance(raw.get("cost"), dict) else {}
    tokens = raw.get("tokens") if isinstance(raw.get("tokens"), dict) else {}
    nums: dict[str, Any] = {}
    for key in _USAGE_NUMBERS:
        kind = float if key.endswith("_usd") else int
        v = raw.get(key)
        if v is None and key.endswith("_cost_usd"):
            v = cost.get(key.removesuffix("_cost_usd"))
        if v is None and key.endswith("_tokens"):
            v = tokens.get(key.removesuffix("_tokens"))
        nums[key] = _num(v, kind)
    known = {"provider_kind", "provider_label", "model_identifier", "deployment", "supports_images",
             "observation_modality", "usage_reported", *_USAGE_NUMBERS}  # fmt: skip
    detail = {k: v for k, v in raw.items() if k not in known}
    reported = bool(raw.get("usage_reported", any(nums[k] is not None for k in _USAGE_NUMBERS)))
    usage = ProviderUsage(
        provider_kind=str(raw.get("provider_kind") or cfg.get("kind") or spec.provider_id),
        provider_label=label,
        model_identifier=spec.model_identifier or (raw.get("model_identifier") if isinstance(raw.get("model_identifier"), str) else None),
        deployment=str(raw.get("deployment") or cfg.get("deployment") or "") or None,
        supports_images=raw.get("supports_images", cfg.get("supports_images")) if isinstance(raw.get("supports_images", cfg.get("supports_images")), bool) else None,
        observation_modality=str(cfg.get("observation_modality") or raw.get("observation_modality") or "") or None,
        usage_reported=reported,
        source=source,
        detail=json.loads(json.dumps(detail, default=str)),
        **nums,
    )
    return usage, problems


def provider_label(provider_id: str, provider_config: dict[str, Any]) -> str:
    label = provider_config.get("label")
    if isinstance(label, str) and label:
        return label
    return PROVIDER_LABELS.get(provider_id, provider_id)


def _bodies(uow: UnitOfWork, row_type: Any, model: type[M], *where: Any) -> list[M]:
    rows = uow.session.scalars(select(row_type).where(*where).order_by(row_type.created_at))
    return [model.model_validate({**r.body, "version": r.version}) for r in rows]


def _all_events(uow: UnitOfWork, run_id: UUID) -> list[Event]:
    events: list[Event] = []
    after: int | None = None
    while True:
        page = uow.events_after(after, run_id=run_id, limit=500)
        events.extend(page)
        if len(page) < 500:
            return events
        after = page[-1].event_id


def _check_artifact(store: ArtifactStore, meta: ArtifactMetadata) -> ArtifactCheck:
    try:
        path = store.resolve(meta.relative_path)
    except ArtifactPathViolation:
        return "path_violation"
    if not path.is_file():
        return "missing"
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return "ok" if digest == meta.sha256 else "digest_mismatch"


def _counts(verdicts: list[str], basis: str) -> VerdictCounts:
    tally = Counter(verdicts)
    return VerdictCounts(basis=basis, denominator=len(verdicts), counts={k: tally.get(k, 0) for k in VERDICT_KEYS})


def _scenario(uow: UnitOfWork, run: Run, limitations: list[str]) -> tuple[ScenarioSpec | None, str | None]:
    try:
        rev = uow.get_config_revision(ConfigKind.SCENARIO, run.spec.scenario_id, run.spec.scenario_version)
    except NotFound:
        limitations.append(
            "Scenario manifest revision not found in the store: the planned oracle set is inferred from stored "
            "results and may be incomplete."
        )
        return None, None
    if rev.content_hash != run.spec.scenario_hash:
        limitations.append(
            "Stored scenario revision hash does not match the run's frozen scenario hash; planned oracles are "
            "inferred from stored results."
        )
        return None, rev.content_hash
    try:
        return ScenarioSpec.model_validate(rev.content), rev.content_hash
    except ValidationError:
        limitations.append("Stored scenario manifest failed validation; planned oracles inferred from results.")
        return None, rev.content_hash


def _planned(spec: ScenarioSpec | None, results: list[OracleResult]) -> list[PlannedOracle]:
    latest: dict[str, OracleResult] = {}
    for r in sorted(results, key=lambda r: r.created_at):
        latest[r.oracle_kind] = r
    if spec is not None:
        defs = [(d.kind, d.required_status, d.timeout_seconds) for d in spec.oracles]
    else:
        defs = [(kind, None, None) for kind in dict.fromkeys(r.oracle_kind for r in results)]
    planned: list[PlannedOracle] = []
    for i, (kind, status, timeout) in enumerate(defs):
        hit = latest.get(kind)
        planned.append(
            PlannedOracle(
                index=i,
                kind=kind,
                required_status=status,
                timeout_seconds=timeout,
                effective_verdict=hit.verdict.value if hit else NOT_EVALUATED,
                oracle_result_id=hit.oracle_result_id if hit else None,
            )
        )
    return planned


def _observation_entry(obs: Observation) -> ObservationEntry:
    elements = [
        ElementSummary(element_ref=e.element_ref, role=e.role, identifier=e.identifier, label=e.label, value=e.value)
        for e in obs.ui_tree
        if e.identifier or e.label
    ][:MAX_ELEMENTS_PER_OBSERVATION]
    return ObservationEntry(
        observation_id=obs.observation_id,
        evidence_source=obs.evidence_source,
        capture_started_at=obs.capture_started_at,
        capture_ended_at=obs.capture_ended_at,
        foreground_app=obs.foreground_app,
        orientation=obs.orientation,
        keyboard_visible=obs.keyboard_visible,
        screenshot_artifact_id=obs.screenshot_artifact_id,
        element_count=len(obs.ui_tree),
        elements=elements,
        candidates=obs.candidates,
    )


def _validation(history: list[StatusChange], action_reject: str | None) -> str:
    reached = {h.to_status for h in history}
    if ActionStatus.REJECTED in reached:
        return f"rejected:{action_reject or 'UNSPECIFIED'}"
    if ActionStatus.VALIDATED in reached:
        return "validated"
    if ActionStatus.CANCELLED in reached:
        return "cancelled"
    return "pending"


def _explain(entry: ActionEntry, decisions: dict[UUID, DecisionRecord], label: str) -> str:
    a = entry.action
    parts = [f"{a.kind.value} '{a.semantic_key}' ({a.side_effect_class.value})."]
    d = decisions.get(a.decision_id) if a.decision_id else None
    if d is not None and d.proposal is not None:
        parts.append(
            f"Proposed by {label} decision {d.decision_id} (reason code {d.proposal.reason_code}) from observation "
            f"{a.decision_observation_id}, candidate {a.original_candidate_id}."
        )
    elif a.decision_id is not None:
        parts.append(f"Decision {a.decision_id} is not in the store.")
    parts.append(f"Validation: {entry.validation}.")
    if a.dispatch_observation_id is not None:
        rebound = " (rebound)" if a.dispatch_candidate_id != a.original_candidate_id else ""
        parts.append(f"Dispatch observation {a.dispatch_observation_id}, candidate {a.dispatch_candidate_id}{rebound}.")
    if a.scheduled_at or a.actual_dispatch_at:
        parts.append(
            f"Planned delay {a.sampled_delay_ms} ms, scheduled {a.scheduled_at}, dispatched {a.actual_dispatch_at}, "
            f"overrun {a.timing_overrun_ms} ms."
        )
    if entry.attempts:
        parts.append(
            "Attempts: " + ", ".join(f"#{t.attempt_no} {t.status.value if t.status else 'no result'}" for t in entry.attempts) + "."
        )
    parts.append(f"Current status {a.status.value}.")
    return " ".join(parts)


def _event_entry(e: Event) -> TimelineEntry:
    p: Any = e.payload
    ref_type: str | None = None
    ref_id: str | None = None
    match e.type:
        case EventType.RUN_STATUS_CHANGED:
            summary = f"Run {p.from_status or '-'} -> {p.to_status}" + (" (recovery)" if p.recovery else "")
            if p.reason:
                summary += f": {p.reason}"
        case EventType.ACTION_STATUS_CHANGED:
            summary = f"Action {p.kind} {p.from_status or '-'} -> {p.to_status}"
            ref_type, ref_id = "action", str(e.action_id)
        case EventType.ATTEMPT_RECORDED:
            summary = f"Attempt #{p.attempt_no} result {p.status}"
            ref_type, ref_id = "attempt", str(p.attempt_id)
        case EventType.OBSERVATION_CAPTURED:
            summary = f"Observation ({p.evidence_source}) app={p.foreground_app} candidates={p.candidate_count}"
            ref_type, ref_id = "observation", str(p.observation_id)
        case EventType.ORACLE_RESULT:
            summary = f"Oracle {p.verdict} {p.reason_code}"
            ref_type, ref_id = "oracle_result", str(p.oracle_result_id)
        case EventType.COMMAND_UPDATED:
            summary = f"Command {p.kind} {p.status}"
            ref_type, ref_id = "command", str(p.command_id)
        case EventType.LEASE_ACQUIRED | EventType.LEASE_RELEASED:
            summary = f"Lease {p.kind} epoch {p.epoch} {p.status}"
        case EventType.ARTIFACT_CREATED:
            summary = f"Artifact {p.content_type}"
            ref_type, ref_id = "artifact", str(p.artifact_id)
        case _:
            summary = str(e.type)
    return TimelineEntry(at=e.timestamp, event_id=e.event_id, kind=str(e.type), ref_type=ref_type, ref_id=ref_id, summary=summary)


def build_run_report(store: Store, run_id: UUID, artifacts_root: Path | str) -> RunReport:
    """Read-only compilation; works for runs in any status, including interrupted ones."""
    limitations: list[str] = []
    with store.reader() as uow:
        run = uow.get_run(run_id)
        spec = run.spec
        scenario, scenario_rev_hash = _scenario(uow, run, limitations)
        observations = _bodies(uow, ObservationRow, Observation, ObservationRow.run_id == str(run_id))
        decisions = _bodies(uow, DecisionRow, DecisionRecord, DecisionRow.run_id == str(run_id))
        actions = uow.list_actions(run_id=run_id)
        attempts = {a.action_id: uow.list_attempts(a.action_id) for a in actions}
        results = uow.list_oracle_results(run_id)
        events = _all_events(uow, run_id)
        commands = _bodies(uow, CommandRow, ControlCommand, CommandRow.run_id == str(run_id))
        global_stops = _bodies(
            uow, CommandRow, ControlCommand, CommandRow.run_id.is_(None), CommandRow.kind == CommandKind.EMERGENCY_STOP.value
        )
        artifacts = uow.list_artifacts(run_id=run_id, limit=10_000)
        known = {m.artifact_id for m in artifacts}
        for obs in observations:
            aid = obs.screenshot_artifact_id
            if aid is not None and aid not in known:
                try:
                    artifacts.append(uow.get_artifact(aid))
                    known.add(aid)
                except NotFound:
                    limitations.append(f"Observation {obs.observation_id} references missing artifact {aid}.")
        try:
            device = uow.get_device_profile(spec.device_id)
        except NotFound:
            device = None

    label = provider_label(spec.provider_id, dict(spec.provider_config))
    run_end = run.ended_at or utc_now()
    global_stops = [c for c in global_stops if run.created_at <= c.created_at <= run_end]

    # -- actions ---------------------------------------------------------------------------------
    history: dict[UUID, list[StatusChange]] = {}
    for e in events:
        if isinstance(e, ActionStatusChangedEvent) and e.action_id is not None:
            history.setdefault(e.action_id, []).append(
                StatusChange(at=e.timestamp, event_id=e.event_id, from_status=e.payload.from_status, to_status=e.payload.to_status)
            )
    by_decision = {d.decision_id: d for d in decisions}
    action_entries: list[ActionEntry] = []
    for a in actions:
        h = history.get(a.action_id, [])
        entry = ActionEntry(
            action=a,
            attempts=attempts[a.action_id],
            status_history=h,
            validation=_validation(h, a.reject_code.value if a.reject_code else None),
            explanation="",
        )
        action_entries.append(entry.model_copy(update={"explanation": _explain(entry, by_decision, label)}))

    # -- timeline and interventions ---------------------------------------------------------------
    timeline = [_event_entry(e) for e in events]
    for d in decisions:
        cand = d.proposal.candidate_id if d.proposal else None
        timeline.append(
            TimelineEntry(
                at=d.created_at, event_id=None, kind="decision", ref_type="decision", ref_id=str(d.decision_id),
                summary=f"Decision {d.outcome} by {d.provider_id}"
                + (f" candidate={cand} reason={d.proposal.reason_code}" if d.proposal else "")
                + (f" error={d.error.code}" if d.error else ""),
            )  # fmt: skip
        )
    timeline.sort(key=lambda t: (t.at, t.event_id if t.event_id is not None else 1 << 62))

    interventions: list[Intervention] = [
        Intervention(at=c.created_at, kind=f"command:{c.kind.value}", detail=f"status {c.status.value}", command_id=c.command_id)
        for c in [*commands, *global_stops]
        if c.kind not in (CommandKind.PREFLIGHT, CommandKind.DISCOVER, CommandKind.START)
    ]
    for e in events:
        if isinstance(e, RunStatusChangedEvent) and (e.payload.to_status in INTERVENTION_RUN_STATUSES or e.payload.recovery):
            detail = f"{e.payload.from_status} -> {e.payload.to_status}" + (" (recovery)" if e.payload.recovery else "")
            interventions.append(Intervention(at=e.timestamp, kind="run_status", detail=detail + (f": {e.payload.reason}" if e.payload.reason else "")))
    interventions.sort(key=lambda i: i.at)

    # -- artifacts ---------------------------------------------------------------------------------
    root = Path(artifacts_root)
    astore = ArtifactStore(root) if root.is_dir() else None
    artifact_entries = [
        ArtifactEntry(metadata=m, check=_check_artifact(astore, m) if astore else "missing") for m in artifacts
    ]
    for ae in artifact_entries:
        if ae.check != "ok":
            limitations.append(f"Artifact {ae.metadata.artifact_id} integrity check at report time: {ae.check}.")

    # -- verdicts ----------------------------------------------------------------------------------
    planned = _planned(scenario, results)
    interrupted = run.status is not RunStatus.COMPLETED
    if interrupted:
        limitations.append(
            f"Run did not complete (status {run.status.value}). Oracles without stored results are reported as "
            "NOT_EVALUATED and never as PASS."
        )
    if any(p.effective_verdict == NOT_EVALUATED for p in planned):
        limitations.append("At least one planned oracle was not evaluated.")
    unresolved = [a.action_id for a in actions if a.status in (ActionStatus.UNKNOWN, ActionStatus.UNRESOLVED, ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED)]
    if unresolved:
        limitations.append(
            f"{len(unresolved)} action(s) have uncertain or unverified outcomes (DISPATCHED/ACKNOWLEDGED/UNKNOWN/UNRESOLVED); "
            "they were not retried automatically."
        )

    sources = Counter(o.evidence_source.value for o in observations)
    if sources.get("mock") or sources.get("replay"):
        limitations.append("Some observations are mock or replay data and are not device evidence.")
    no_device = run.obtained_evidence_source in (EvidenceSource.MOCK, EvidenceSource.REPLAY) or (
        bool(sources) and not sources.get(EvidenceSource.DEVICE.value)
    )
    if no_device:
        limitations.append(
            f"MOCK, no device: no Simulator, emulator or phone was involved; device_kind "
            f"'{spec.device_kind.value}' is only the profile the mock or replay stood in for."
        )
    disclaimer: str | None = None
    if spec.planned_evidence is EvidenceCategory.FIXTURE:
        if no_device:
            disclaimer = "MOCK, no device: fixture messages are not SMS"
        elif spec.device_kind is DeviceKind.SIMULATOR:
            disclaimer = "Simulator fixture messages are not SMS"
        else:
            disclaimer = "Fixture messages are not SMS"
        limitations.append(
            f"{disclaimer}: Lab Messenger exchanges IP messages with a scripted fixture receiver. This does not "
            "demonstrate operating-system SMS, iMessage or cellular capability."
        )
    if spec.device_kind is DeviceKind.SIMULATOR and not no_device:
        limitations.append("Results were obtained on an iOS/Android virtual device (Simulator/emulator), not a physical phone.")
    usage, usage_problems = provider_usage_summary(spec, label, artifacts, astore)
    limitations += usage_problems
    if spec.provider_id in PROVIDER_LABELS:
        limitations.append(f"Decisions came from the deterministic {label}; they do not demonstrate model-driven behaviour.")
    elif usage.deployment == "cloud":
        limitations.append(
            f"Decisions came from the cloud model {usage.model_identifier or 'unknown'} via {label}; the model chose only "
            "among supplied candidates and permitted parameters and never set a verdict."
        )
    typing = sorted(
        {t.result.typing_mode_actual.value for e in action_entries for t in e.attempts if t.result and t.result.typing_mode_actual}
    )
    if typing:
        limitations.append(f"Typing modes actually used: {', '.join(typing)}. Bulk or paced text injection is not keyboard realism.")

    now = utc_now()
    return RunReport(
        generated_at=now,
        generator={"name": GENERATOR_NAME, "mobilelab_version": _package_version(), "python": host_platform.python_version()},
        run=RunSummary(
            run_id=run.run_id, campaign_id=run.campaign_id, status=run.status, status_reason=run.status_reason,
            recorded_verdict=run.verdict, interrupted=interrupted, in_recovery=run.in_recovery,
            control_epoch=run.control_epoch, scenario_id=spec.scenario_id, scenario_version=spec.scenario_version,
            persona_id=spec.persona_id, persona_version=spec.persona_version, seed=spec.seed,
            created_at=run.created_at, started_at=run.started_at, ended_at=run.ended_at,
        ),  # fmt: skip
        labels=ReportLabels(
            provider_label=label, provider_id=spec.provider_id, model_identifier=spec.model_identifier,
            provider_kind=usage.provider_kind,
            planned_evidence=spec.planned_evidence, obtained_evidence=run.obtained_evidence,
            obtained_evidence_source=run.obtained_evidence_source, device_kind=spec.device_kind,
            platform=spec.platform, messaging_disclaimer=disclaimer, observation_evidence_sources=dict(sources),
            no_device=no_device,
        ),  # fmt: skip
        config_hashes={
            "run_spec": spec.spec_hash(),
            "scenario": spec.scenario_hash,
            "scenario_revision": scenario_rev_hash,
            "persona": spec.persona_hash,
            "provider_config": spec.provider_config_hash,
            "device_profile": spec.device_profile_hash,
            "capability_evidence": spec.capability_evidence_hash,
        },
        versions={
            "app_builds": dict(spec.app_builds),
            "adapter_versions": dict(spec.adapter_versions),
            "model_identifier": spec.model_identifier,
            "device_os_version": device.os_version if device else None,
            "device_model": device.model if device else None,
            "appium_version": device.appium_version if device else None,
            "driver_versions": dict(device.driver_versions) if device else {},
        },
        policy_limits=dict(spec.policy_limits),
        planned_oracles=planned,
        verdict_counts=_counts([p.effective_verdict for p in planned], "effective verdict per planned oracle"),
        result_counts=_counts([r.verdict.value for r in results], "all stored oracle results"),
        oracle_results=results,
        observations=[_observation_entry(o) for o in observations],
        decisions=decisions,
        actions=action_entries,
        timeline=timeline,
        interventions=interventions,
        artifacts=artifact_entries,
        exclusions=[],
        limitations=limitations,
        provider_usage=usage,
    )


__all__ = ["build_run_report", "provider_label"]

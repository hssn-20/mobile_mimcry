"""``python -m mobilelab.reporting <db> <run_id> <out_dir>`` / ``python -m mobilelab.reporting --verify <dir>``.

``out_dir`` is the artifacts root; the report is written to ``<out_dir>/runs/<run_id>/`` (next to
the run's evidence files). The database is opened without migrating and only read.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from uuid import UUID

from mobilelab.reporting.bundle import verify_report_integrity, write_report
from mobilelab.store import Store


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mobilelab.reporting", description=__doc__)
    parser.add_argument("--verify", metavar="REPORT_DIR", type=Path, help="verify an existing report directory")
    parser.add_argument("db", nargs="?", type=Path)
    parser.add_argument("run_id", nargs="?", type=UUID)
    parser.add_argument("out_dir", nargs="?", type=Path, help="artifacts root")
    args = parser.parse_args(argv)

    if args.verify is not None:
        result = verify_report_integrity(args.verify)
        print(f"integrity {'OK' if result.ok else 'FAILED'} ({result.files_checked} files hashed)")
        for problem in result.problems:
            print(f"- {problem}")
        return 0 if result.ok else 1
    if args.db is None or args.run_id is None or args.out_dir is None:
        parser.error("db, run_id and out_dir are required unless --verify is given")
    if not args.db.is_file():
        parser.error(f"database not found: {args.db}")
    store = Store.open(args.db, migrate=False)
    try:
        bundle = write_report(store, args.run_id, args.out_dir)
    finally:
        store.close()
    result = verify_report_integrity(bundle.directory)
    print(bundle.directory / "report.html")
    print(f"integrity {'OK' if result.ok else 'FAILED'} ({result.files_checked} files hashed)")
    for problem in result.problems:
        print(f"- {problem}")
    return 0 if result.ok else 1


if __name__ == "__main__":
    sys.exit(main())

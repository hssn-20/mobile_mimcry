"""Runtime secret lookup for cloud providers (T08).

The OpenAI API key is read only inside the mobilelab process: first from ``OPENAI_API_KEY``, otherwise
from the macOS Keychain generic password ``service=mobilelab-openai-api-key``, ``account=<current
user>`` via ``security find-generic-password ... -w`` run as a typed argv subprocess (no shell).

The value is wrapped in :class:`SecretValue`, whose ``repr``/``str``/``format`` never reveal it (nor its
length or a prefix). Error messages never include it, and the Keychain subprocess's stderr is not
propagated either.
"""

from __future__ import annotations

import getpass
import os
import shutil
import subprocess
from collections.abc import Callable, Mapping
from typing import Literal, NoReturn

from mobilelab.domain.errors import ProviderError

ENV_VAR = "OPENAI_API_KEY"
KEYCHAIN_SERVICE = "mobilelab-openai-api-key"
SECURITY_BIN = "/usr/bin/security"
KEYCHAIN_TIMEOUT_S = 10.0

SecretSource = Literal["env", "keychain"]

_MASK = "SecretValue(<redacted>)"


class SecretUnavailable(ProviderError):
    """No API key is available to this process. The message never contains secret material."""


class SecretValue:
    """Opaque secret holder. Only :meth:`reveal` returns the value; nothing else prints it."""

    __slots__ = ("__value", "source")

    def __init__(self, value: str, *, source: SecretSource) -> None:
        if not isinstance(value, str) or not value:
            raise SecretUnavailable("secret value is empty")
        self.__value = value
        self.source: SecretSource = source

    def reveal(self) -> str:
        return self.__value

    def __repr__(self) -> str:
        return _MASK

    __str__ = __repr__

    def __format__(self, spec: str) -> str:
        return _MASK

    def __eq__(self, other: object) -> bool:  # avoid leaking via comparison helpers in assertion output
        return NotImplemented

    __hash__ = None  # type: ignore[assignment]

    def __reduce__(self) -> NoReturn:
        raise TypeError("SecretValue cannot be pickled")

    def __getstate__(self) -> NoReturn:
        raise TypeError("SecretValue cannot be serialized")


Runner = Callable[..., subprocess.CompletedProcess[str]]


def _keychain_argv(account: str) -> list[str]:
    return [SECURITY_BIN, "find-generic-password", "-s", KEYCHAIN_SERVICE, "-a", account, "-w"]


def read_keychain_secret(
    *, account: str | None = None, runner: Runner = subprocess.run, security_bin: str | None = None
) -> SecretValue:
    """Read the key from the login Keychain via a typed argv (never a shell). Errors are redacted."""
    account = account or getpass.getuser()
    argv = _keychain_argv(account)
    if security_bin is not None:
        argv[0] = security_bin
    elif not os.path.exists(SECURITY_BIN) and shutil.which("security") is None:
        raise SecretUnavailable("macOS 'security' tool not available; set OPENAI_API_KEY for this process")
    try:
        proc = runner(argv, capture_output=True, text=True, timeout=KEYCHAIN_TIMEOUT_S, check=False)
    except subprocess.TimeoutExpired:
        raise SecretUnavailable("Keychain lookup timed out", details={"service": KEYCHAIN_SERVICE}) from None
    except OSError as exc:
        raise SecretUnavailable(
            "Keychain lookup could not run", details={"service": KEYCHAIN_SERVICE, "errno": exc.errno}
        ) from None
    if proc.returncode != 0:
        # stderr is deliberately dropped: it is not needed and must never carry secret material.
        raise SecretUnavailable(
            "Keychain item not found or access denied",
            details={"service": KEYCHAIN_SERVICE, "returncode": proc.returncode},
        )
    value = _normalize(proc.stdout or "")
    if not value:
        raise SecretUnavailable("Keychain item is empty", details={"service": KEYCHAIN_SERVICE})
    return SecretValue(value, source="keychain")


def _normalize(raw: str) -> str:
    """Drop surrounding whitespace and one pair of matching surrounding quotes (common paste artefacts)."""
    value = raw.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1].strip()
    return value


def key_shape_problems(secret: SecretValue) -> list[str]:
    """Non-revealing format diagnostics: returns fixed messages only, never any part of the value."""
    value = secret.reveal()
    problems: list[str] = []
    if not value.startswith("sk-"):
        problems.append("does not start with 'sk-'")
    if any(ch.isspace() for ch in value):
        problems.append("contains whitespace inside the key")
    if any(ch in "\"'`" for ch in value):
        problems.append("contains quote characters")
    if not value.isascii():
        problems.append("contains non-ASCII characters")
    if len(value) < 40:
        problems.append("is shorter than any current OpenAI API key format")
    return problems


def get_openai_api_key(
    *,
    environ: Mapping[str, str] | None = None,
    account: str | None = None,
    runner: Runner = subprocess.run,
    allow_keychain: bool = True,
) -> SecretValue:
    """Return the OpenAI key: env ``OPENAI_API_KEY`` first, else the macOS Keychain item."""
    env = os.environ if environ is None else environ
    value = env.get(ENV_VAR, "").strip()
    if value:
        return SecretValue(value, source="env")
    if not allow_keychain:
        raise SecretUnavailable(f"{ENV_VAR} is not set and Keychain lookup is disabled")
    return read_keychain_secret(account=account, runner=runner)


PROVIDER_CREDENTIAL_ENV_VARS = frozenset({
    ENV_VAR, "OPENAI_ADMIN_KEY", "AZURE_OPENAI_API_KEY", "ANTHROPIC_API_KEY",
})  # fmt: skip
"""Cloud-provider credentials that only the mobilelab coordinator process may hold."""


def child_env(base: Mapping[str, str] | None = None, **overrides: str) -> dict[str, str]:
    """Environment for a child process (Appium, worker, fixture service, restart child, tools).

    Copies ``base`` (default ``os.environ``) without provider credential variables, so the API key is
    never inherited by Appium/WDA/xcodebuild, the device worker or any other subprocess."""
    src = os.environ if base is None else base
    env = {k: v for k, v in src.items() if k not in PROVIDER_CREDENTIAL_ENV_VARS}
    env.update({k: v for k, v in overrides.items() if k not in PROVIDER_CREDENTIAL_ENV_VARS})
    return env


__all__ = [
    "ENV_VAR",
    "PROVIDER_CREDENTIAL_ENV_VARS",
    "child_env",
    "KEYCHAIN_SERVICE",
    "SecretUnavailable",
    "SecretValue",
    "get_openai_api_key",
    "key_shape_problems",
    "read_keychain_secret",
]


if __name__ == "__main__":  # `python -m mobilelab.secrets`: non-revealing key format check
    secret = get_openai_api_key()
    found = key_shape_problems(secret)
    print(f"source: {secret.source}")
    print("format: ok" if not found else "format problems: " + "; ".join(found))

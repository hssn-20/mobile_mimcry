"""Export JSON Schema for API-facing domain models and generate dashboard TypeScript types.

Single source of truth is the Pydantic models (CONTRACTS §2). Usage::

    uv run python -m mobilelab.schema_export          # write schemas/*.json and generated.ts
    uv run python -m mobilelab.schema_export --check  # exit 1 if generated files are stale
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, TypeAdapter
from pydantic.json_schema import models_json_schema

from mobilelab.domain.actions import ActionPayload
from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.control import ControlCommand, EmergencyStopResult, GateState
from mobilelab.domain.decisions import DecisionContext, DecisionRecord
from mobilelab.domain.devices import CapabilityReport, DeviceHealth, DeviceProfile, FenceResult
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, DispatchCommand, ExecutionResult
from mobilelab.domain.errors import ErrorEnvelope
from mobilelab.domain.events import Event
from mobilelab.domain.observations import Observation
from mobilelab.domain.personas import PersonaCatalog, PersonaConfig
from mobilelab.domain.proposals import ProposedAction
from mobilelab.domain.runs import Campaign, ConfigRevision, Lease, Run, RunSpec
from mobilelab.domain.scenarios import OracleResult, ScenarioSpec

REPO_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = Path("schemas")
TS_FILE = Path("apps/dashboard/src/types/generated.ts")

API_MODELS: tuple[type[BaseModel], ...] = (
    ActionRecord,
    ArtifactMetadata,
    AttemptRecord,
    Campaign,
    CapabilityReport,
    ConfigRevision,
    ControlCommand,
    DecisionContext,
    DecisionRecord,
    DeviceHealth,
    DeviceProfile,
    DispatchCommand,
    EmergencyStopResult,
    ErrorEnvelope,
    ExecutionResult,
    FenceResult,
    GateState,
    Lease,
    Observation,
    OracleResult,
    PersonaCatalog,
    PersonaConfig,
    ProposedAction,
    Run,
    RunSpec,
    ScenarioSpec,
)
UNIONS: dict[str, Any] = {"ActionPayload": ActionPayload, "Event": Event}


def _dump(obj: Any) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False) + "\n"


def build_json_schemas() -> dict[str, str]:
    """Map of file name -> JSON text (one self-contained schema per model/union)."""
    out: dict[str, str] = {}
    for model in API_MODELS:
        schema = model.model_json_schema(mode="validation")
        schema["$schema"] = "https://json-schema.org/draft/2020-12/schema"
        out[f"{model.__name__}.schema.json"] = _dump(schema)
    for name, tp in UNIONS.items():
        schema = TypeAdapter(tp).json_schema(mode="validation")
        schema["title"] = name
        schema["$schema"] = "https://json-schema.org/draft/2020-12/schema"
        out[f"{name}.schema.json"] = _dump(schema)
    return out


# -- JSON Schema -> TypeScript ------------------------------------------------------------------

_IDENT = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")


def _ref_name(ref: str) -> str:
    return ref.rsplit("/", 1)[-1]


def _lit(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def ts_type(schema: dict[str, Any]) -> str:
    if "$ref" in schema:
        return _ref_name(schema["$ref"])
    for key in ("anyOf", "oneOf"):
        if key in schema:
            parts: list[str] = []
            for s in schema[key]:
                t = ts_type(s)
                if t not in parts:
                    parts.append(t)
            return " | ".join(parts)
    if "const" in schema:
        return _lit(schema["const"])
    if "enum" in schema:
        return " | ".join(_lit(v) for v in schema["enum"])
    typ = schema.get("type")
    if isinstance(typ, list):
        return " | ".join(ts_type({**schema, "type": t}) for t in typ)
    match typ:
        case "string":
            return "string"
        case "integer" | "number":
            return "number"
        case "boolean":
            return "boolean"
        case "null":
            return "null"
        case "array":
            if "prefixItems" in schema:
                return "[" + ", ".join(ts_type(s) for s in schema["prefixItems"]) + "]"
            inner = ts_type(schema.get("items", {}))
            return f"({inner})[]" if "|" in inner else f"{inner}[]"
        case "object":
            if "properties" in schema:
                return _inline_object(schema)
            extra = schema.get("additionalProperties")
            if isinstance(extra, dict) and extra:
                return f"Record<string, {ts_type(extra)}>"
            return "Record<string, unknown>"
    return "unknown"


def _prop_key(name: str) -> str:
    return name if _IDENT.match(name) else _lit(name)


def _props(schema: dict[str, Any], indent: str) -> list[str]:
    required = set(schema.get("required", []))
    lines: list[str] = []
    for name, prop in schema.get("properties", {}).items():
        desc = prop.get("description")
        if desc:
            lines.append(f"{indent}/** {' '.join(desc.split())} */")
        opt = "" if name in required else "?"
        lines.append(f"{indent}{_prop_key(name)}{opt}: {ts_type(prop)};")
    return lines


def _inline_object(schema: dict[str, Any]) -> str:
    return "{ " + " ".join(_props(schema, "")) + " }"


def _emit_def(name: str, schema: dict[str, Any]) -> str:
    doc = schema.get("description")
    head = f"/** {' '.join(doc.split())} */\n" if doc else ""
    if schema.get("type") == "object" and "properties" in schema:
        body = "\n".join(_props(schema, "  "))
        return f"{head}export interface {name} {{\n{body}\n}}\n"
    return f"{head}export type {name} = {ts_type(schema)};\n"


def build_typescript() -> str:
    # Serialization mode: the dashboard reads server output, where defaulted fields are always present.
    _, top = models_json_schema([(m, "serialization") for m in API_MODELS], ref_template="#/$defs/{model}")
    defs: dict[str, Any] = dict(top.get("$defs", {}))
    for name, tp in UNIONS.items():
        schema = TypeAdapter(tp).json_schema(mode="serialization", ref_template="#/$defs/{model}")
        defs.update(schema.pop("$defs", {}))
        defs[name] = schema
    chunks = [
        "// GENERATED by `uv run python -m mobilelab.schema_export` from the Pydantic domain models.\n"
        "// Do not edit by hand. Shapes are server output (serialization mode); inbound JSON Schemas live in\n"
        "// schemas/*.schema.json. Timestamps are UTC ISO 8601 strings; UUIDs are strings.\n"
    ]
    chunks += [_emit_def(name, defs[name]) for name in sorted(defs)]
    text = "\n".join(chunks)
    # Pydantic inlines discriminated unions at each use site; refer to the named alias instead.
    for name in UNIONS:
        expansion = ts_type(defs[name])
        definition = f"export type {name} = {expansion};"
        text = text.replace(definition, "\0").replace(expansion, name).replace("\0", definition)
    return text


# -- entry point --------------------------------------------------------------------------------


def outputs() -> dict[Path, str]:
    files = {SCHEMA_DIR / name: text for name, text in build_json_schemas().items()}
    files[TS_FILE] = build_typescript()
    return files


def stale_files(root: Path = REPO_ROOT) -> list[Path]:
    stale = [p for p, text in outputs().items() if not (root / p).exists() or (root / p).read_text() != text]
    expected = {p.name for p in outputs() if p.parent == SCHEMA_DIR}
    if (root / SCHEMA_DIR).is_dir():
        stale += [SCHEMA_DIR / f.name for f in (root / SCHEMA_DIR).glob("*.schema.json") if f.name not in expected]
    return stale


def write_all(root: Path = REPO_ROOT) -> list[Path]:
    written: list[Path] = []
    expected = set()
    for rel, text in outputs().items():
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
        written.append(rel)
        expected.add(target.name)
    for orphan in (root / SCHEMA_DIR).glob("*.schema.json"):
        if orphan.name not in expected:
            orphan.unlink()
    return written


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0] if __doc__ else None)
    parser.add_argument("--check", action="store_true", help="fail if generated files are out of date")
    parser.add_argument("--root", type=Path, default=REPO_ROOT)
    args = parser.parse_args(argv)
    if args.check:
        stale = stale_files(args.root)
        for p in stale:
            print(f"stale: {p}", file=sys.stderr)
        return 1 if stale else 0
    for p in write_all(args.root):
        print(p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

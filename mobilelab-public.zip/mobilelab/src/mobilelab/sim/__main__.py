"""``python -m mobilelab.sim ensure|boot|install|status|shutdown``

Operates only on the project-owned Simulator recorded in
configs/devices/ios_simulator.json (created by ``ensure``). Prints JSON.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from mobilelab.sim.lifecycle import (
    DEFAULT_APP_PATH,
    DEFAULT_DEVICE_NAME,
    DEFAULT_RECORD_PATH,
    LAB_MESSENGER_BUNDLE_ID,
    boot_device,
    ensure_device,
    load_record,
)
from mobilelab.sim.runner import CommandTimeout
from mobilelab.sim.simctl import DEFAULT_DEVELOPER_DIR, SimctlError, Simctl


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mobilelab.sim")
    parser.add_argument("command", choices=["ensure", "boot", "install", "status", "shutdown"])
    parser.add_argument("--name", default=DEFAULT_DEVICE_NAME)
    parser.add_argument("--record", type=Path, default=DEFAULT_RECORD_PATH)
    parser.add_argument("--developer-dir", default=DEFAULT_DEVELOPER_DIR)
    parser.add_argument("--app", type=Path, default=DEFAULT_APP_PATH, help="for install")
    args = parser.parse_args(argv)

    simctl = Simctl(developer_dir=args.developer_dir)
    try:
        if args.command == "ensure":
            record = ensure_device(simctl, name=args.name, record_path=args.record)
            out: dict[str, object] = record.model_dump(mode="json")
        else:
            record = load_record(args.record)
            if record is None:
                raise SimctlError(f"no device record at {args.record}; run 'ensure' first")
            if args.command == "boot":
                device = boot_device(simctl, record)
                out = {"udid": device.udid, "state": device.state}
            elif args.command == "install":
                simctl.install(record.udid, args.app)
                out = {"udid": record.udid, "installed": str(args.app),
                       "bundle_id": LAB_MESSENGER_BUNDLE_ID}  # fmt: skip
            elif args.command == "status":
                device = simctl.owned_device(record.udid)
                out = {
                    "udid": device.udid,
                    "name": device.name,
                    "state": device.state,
                    "runtime": device.runtime_identifier,
                    "lab_messenger_installed": device.booted and simctl.is_installed(device.udid, LAB_MESSENGER_BUNDLE_ID),
                }
            else:
                simctl.shutdown(record.udid)
                out = {"udid": record.udid, "state": "Shutdown"}
    except (SimctlError, CommandTimeout) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Typed ``xcrun simctl`` wrapper restricted to project-owned Simulators.

Every device-addressed operation first resolves the UDID through
``simctl list devices`` and refuses unless the device name starts with
``mobilelab-``. Xcode is selected per process via ``DEVELOPER_DIR``; the
active developer directory (xcode-select) is never changed.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from mobilelab.sim.runner import CommandResult, CommandRunner, SubprocessRunner

DEFAULT_DEVELOPER_DIR = "/Applications/Xcode.app/Contents/Developer"
PROJECT_PREFIX = "mobilelab-"

LIST_TIMEOUT_S = 30.0
CREATE_TIMEOUT_S = 90.0
BOOT_TIMEOUT_S = 120.0
BOOTSTATUS_TIMEOUT_S = 300.0
INSTALL_TIMEOUT_S = 180.0
LAUNCH_TIMEOUT_S = 60.0
SHORT_TIMEOUT_S = 30.0
SHUTDOWN_TIMEOUT_S = 90.0


class SimctlError(RuntimeError):
    def __init__(self, message: str, result: CommandResult | None = None) -> None:
        detail = f": {result.stderr.strip() or result.stdout.strip()}" if result is not None else ""
        super().__init__(message + detail)
        self.result = result


class NotProjectOwnedError(SimctlError):
    """Raised before any command touches a Simulator not named ``mobilelab-*``."""


class DeviceNotFoundError(SimctlError):
    pass


@dataclass(frozen=True)
class DeviceType:
    identifier: str
    name: str
    product_family: str


@dataclass(frozen=True)
class Runtime:
    identifier: str
    name: str
    version: str
    platform: str
    is_available: bool
    device_types: tuple[DeviceType, ...]


@dataclass(frozen=True)
class SimDevice:
    udid: str
    name: str
    state: str
    runtime_identifier: str
    device_type_identifier: str
    is_available: bool

    @property
    def booted(self) -> bool:
        return self.state == "Booted"


def is_project_owned_name(name: str) -> bool:
    return name.startswith(PROJECT_PREFIX) and len(name) > len(PROJECT_PREFIX)


def require_project_name(name: str) -> None:
    if not is_project_owned_name(name):
        raise NotProjectOwnedError(f"refusing Simulator {name!r}: name must start with {PROJECT_PREFIX!r}")


class Simctl:
    def __init__(self, runner: CommandRunner | None = None, developer_dir: str = DEFAULT_DEVELOPER_DIR) -> None:
        self._runner = runner or SubprocessRunner()
        self._env = {"DEVELOPER_DIR": developer_dir}
        self.developer_dir = developer_dir

    # -- raw execution -------------------------------------------------
    def run(self, args: Sequence[str], *, timeout_s: float, check: bool = True) -> CommandResult:
        result = self._runner(["xcrun", "simctl", *args], timeout_s=timeout_s, env=self._env)
        if check and result.returncode != 0:
            raise SimctlError(f"simctl {args[0] if args else ''} failed (exit {result.returncode})", result)
        return result

    def _json(self, args: Sequence[str]) -> dict[str, object]:
        out = self.run(args, timeout_s=LIST_TIMEOUT_S).stdout
        try:
            data = json.loads(out)
        except json.JSONDecodeError as exc:
            raise SimctlError(f"simctl {' '.join(args)} returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise SimctlError(f"simctl {' '.join(args)} returned unexpected JSON")
        return data

    # -- discovery (read-only) ------------------------------------------
    def list_runtimes(self) -> list[Runtime]:
        runtimes = []
        for raw in self._json(["list", "runtimes", "-j"]).get("runtimes", []):  # type: ignore[union-attr]
            types = tuple(
                DeviceType(t["identifier"], t["name"], t.get("productFamily", ""))
                for t in raw.get("supportedDeviceTypes", [])
            )
            runtimes.append(
                Runtime(
                    identifier=raw["identifier"],
                    name=raw["name"],
                    version=raw["version"],
                    platform=raw.get("platform", ""),
                    is_available=bool(raw.get("isAvailable", False)),
                    device_types=types,
                )
            )
        return runtimes

    def list_device_types(self) -> list[DeviceType]:
        raw = self._json(["list", "devicetypes", "-j"]).get("devicetypes", [])
        return [DeviceType(t["identifier"], t["name"], t.get("productFamily", "")) for t in raw]  # type: ignore[union-attr]

    def list_devices(self) -> list[SimDevice]:
        raw = self._json(["list", "devices", "-j"]).get("devices", {})
        devices = []
        for runtime_id, entries in raw.items():  # type: ignore[union-attr]
            for d in entries:
                devices.append(
                    SimDevice(
                        udid=d["udid"],
                        name=d["name"],
                        state=d.get("state", "Unknown"),
                        runtime_identifier=runtime_id,
                        device_type_identifier=d.get("deviceTypeIdentifier", ""),
                        is_available=bool(d.get("isAvailable", False)),
                    )
                )
        return devices

    def find_device(self, udid: str) -> SimDevice | None:
        return next((d for d in self.list_devices() if d.udid == udid), None)

    def owned_device(self, udid: str) -> SimDevice:
        """Resolve ``udid`` and enforce the ``mobilelab-`` name guard."""
        device = self.find_device(udid)
        if device is None:
            raise DeviceNotFoundError(f"Simulator {udid} not found")
        require_project_name(device.name)
        return device

    # -- lifecycle (project-owned only) ---------------------------------
    def create(self, name: str, device_type_id: str, runtime_id: str) -> str:
        require_project_name(name)
        udid = self.run(["create", name, device_type_id, runtime_id], timeout_s=CREATE_TIMEOUT_S).stdout.strip()
        if not udid:
            raise SimctlError("simctl create returned no UDID")
        return udid

    def boot(self, udid: str) -> None:
        device = self.owned_device(udid)
        if not device.booted:
            self.run(["boot", udid], timeout_s=BOOT_TIMEOUT_S)

    def wait_booted(self, udid: str, timeout_s: float = BOOTSTATUS_TIMEOUT_S) -> None:
        self.owned_device(udid)
        self.run(["bootstatus", udid], timeout_s=timeout_s)

    def shutdown(self, udid: str) -> None:
        device = self.owned_device(udid)
        if device.state != "Shutdown":
            self.run(["shutdown", udid], timeout_s=SHUTDOWN_TIMEOUT_S)

    def write_global_default(self, udid: str, key: str, value_args: Sequence[str]) -> None:
        """``defaults write`` into the Simulator's global domain (booted device)."""
        self.owned_device(udid)
        self.run(
            ["spawn", udid, "defaults", "write", "Apple Global Domain", key, *value_args], timeout_s=SHORT_TIMEOUT_S
        )

    def pin_locale(self, udid: str, locale: str = "en_GB", language: str = "en") -> None:
        self.write_global_default(udid, "AppleLocale", ["-string", locale])
        self.write_global_default(udid, "AppleLanguages", ["-array", language])

    def status_bar_override(self, udid: str, time: str = "09:41") -> None:
        self.owned_device(udid)
        self.run(
            [
                "status_bar", udid, "override", "--time", time, "--batteryState", "charged",
                "--batteryLevel", "100", "--wifiBars", "3", "--cellularMode", "notSupported",
            ],
            timeout_s=SHORT_TIMEOUT_S,
        )  # fmt: skip

    def install(self, udid: str, app_path: Path) -> None:
        self.owned_device(udid)
        if not (app_path.is_dir() and app_path.suffix == ".app"):
            raise SimctlError(f"not an .app bundle: {app_path}")
        self.run(["install", udid, str(app_path)], timeout_s=INSTALL_TIMEOUT_S)

    def is_installed(self, udid: str, bundle_id: str) -> bool:
        self.owned_device(udid)
        return self.run(["get_app_container", udid, bundle_id, "app"], timeout_s=SHORT_TIMEOUT_S, check=False).returncode == 0

    def launch(self, udid: str, bundle_id: str, args: Sequence[str] = (), *, terminate_running: bool = True) -> int:
        """Launch an installed app; returns its pid. ``args`` are the app's process arguments."""
        self.owned_device(udid)
        argv = ["launch"]
        if terminate_running:
            argv.append("--terminate-running-process")
        argv += [udid, bundle_id, *args]
        out = self.run(argv, timeout_s=LAUNCH_TIMEOUT_S).stdout.strip()
        # Output: "<bundle id>: <pid>"
        try:
            return int(out.rsplit(":", 1)[1])
        except (IndexError, ValueError) as exc:
            raise SimctlError(f"unexpected simctl launch output: {out!r}") from exc

    def terminate(self, udid: str, bundle_id: str) -> bool:
        """Terminate an app; returns False when it was not running."""
        self.owned_device(udid)
        return self.run(["terminate", udid, bundle_id], timeout_s=SHORT_TIMEOUT_S, check=False).returncode == 0

    def screenshot(self, udid: str, path: Path) -> Path:
        self.owned_device(udid)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.run(["io", udid, "screenshot", "--type=png", str(path)], timeout_s=SHORT_TIMEOUT_S)
        return path

    def openurl(self, udid: str, url: str) -> None:
        """Setup convenience only (not an agent action path)."""
        if not url.startswith(("http://", "https://")):
            raise SimctlError(f"openurl allows only http(s) URLs: {url!r}")
        self.owned_device(udid)
        self.run(["openurl", udid, url], timeout_s=SHORT_TIMEOUT_S)

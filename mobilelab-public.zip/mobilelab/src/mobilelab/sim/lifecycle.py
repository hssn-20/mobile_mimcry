"""Project Simulator lifecycle: create-or-reuse, boot, pin locale, record UDID.

The device record (``configs/devices/ios_simulator.json``) identifies the
project-owned Simulator by UDID; the name guard still applies on every call.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from mobilelab.sim.simctl import (
    DeviceType,
    Runtime,
    SimctlError,
    Simctl,
    SimDevice,
    require_project_name,
)

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_RECORD_PATH = REPO_ROOT / "configs" / "devices" / "ios_simulator.json"
DEFAULT_DEVICE_NAME = "mobilelab-iphone-01"
PREFERRED_RUNTIME_VERSION = "27.0"
PREFERRED_DEVICE_TYPES: tuple[str, ...] = ("iPhone 17", "iPhone 17 Pro", "iPhone 16", "iPhone 16 Pro")
LAB_MESSENGER_BUNDLE_ID = "org.mobilelab.fixtures.LabMessenger"
SAFARI_BUNDLE_ID = "com.apple.mobilesafari"
DEFAULT_APP_PATH = (
    REPO_ROOT
    / "fixtures/ios/LabMessenger/build/DerivedData/Build/Products/Debug-iphonesimulator/LabMessenger.app"
)


class SimulatorRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: int = 1
    device_kind: str = "simulator"
    project_owned: bool = True
    name: str
    udid: str
    runtime_identifier: str
    runtime_version: str
    device_type_identifier: str
    device_type_name: str
    locale: str = "en_GB"
    language: str = "en"
    developer_dir: str
    recorded_at: datetime


def load_record(path: Path = DEFAULT_RECORD_PATH) -> SimulatorRecord | None:
    if not path.exists():
        return None
    return SimulatorRecord.model_validate_json(path.read_text(encoding="utf-8"))


def save_record(record: SimulatorRecord, path: Path = DEFAULT_RECORD_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record.model_dump(mode="json"), indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def select_runtime(runtimes: Sequence[Runtime], preferred_version: str = PREFERRED_RUNTIME_VERSION) -> Runtime:
    ios = [r for r in runtimes if r.platform == "iOS" and r.is_available]
    if not ios:
        raise SimctlError("no available iOS Simulator runtime")
    for r in ios:
        if r.version == preferred_version:
            return r
    return max(ios, key=lambda r: tuple(int(p) for p in r.version.split(".") if p.isdigit()))


def select_device_type(runtime: Runtime, preferred: Sequence[str] = PREFERRED_DEVICE_TYPES) -> DeviceType:
    iphones = [t for t in runtime.device_types if t.product_family == "iPhone"]
    if not iphones:
        raise SimctlError(f"runtime {runtime.name} supports no iPhone device type")
    by_name = {t.name: t for t in iphones}
    for name in preferred:
        if name in by_name:
            return by_name[name]
    return iphones[0]


def ensure_device(
    simctl: Simctl,
    *,
    name: str = DEFAULT_DEVICE_NAME,
    record_path: Path = DEFAULT_RECORD_PATH,
) -> SimulatorRecord:
    """Reuse the recorded/owned Simulator named ``name`` or create it; write the record."""
    require_project_name(name)
    runtimes = simctl.list_runtimes()
    devices = simctl.list_devices()
    existing: SimDevice | None = None
    record = load_record(record_path)
    if record is not None:
        existing = next((d for d in devices if d.udid == record.udid and d.name == name and d.is_available), None)
    if existing is None:
        existing = next((d for d in devices if d.name == name and d.is_available), None)

    if existing is not None:
        runtime = next((r for r in runtimes if r.identifier == existing.runtime_identifier), None)
        if runtime is None:
            raise SimctlError(f"runtime {existing.runtime_identifier} of {name} is not installed")
        dtype = next((t for t in runtime.device_types if t.identifier == existing.device_type_identifier), None)
        udid = existing.udid
        dtype_name = dtype.name if dtype else existing.device_type_identifier
        dtype_id = existing.device_type_identifier
    else:
        runtime = select_runtime(runtimes)
        chosen = select_device_type(runtime)
        udid = simctl.create(name, chosen.identifier, runtime.identifier)
        dtype_name, dtype_id = chosen.name, chosen.identifier

    new_record = SimulatorRecord(
        name=name,
        udid=udid,
        runtime_identifier=runtime.identifier,
        runtime_version=runtime.version,
        device_type_identifier=dtype_id,
        device_type_name=dtype_name,
        developer_dir=simctl.developer_dir,
        recorded_at=record.recorded_at if record is not None and record.udid == udid else datetime.now(UTC),
    )
    if new_record != record:
        save_record(new_record, record_path)
    return new_record


def boot_device(simctl: Simctl, record: SimulatorRecord, *, pin_locale: bool = True) -> SimDevice:
    """Boot (if needed), wait for bootstatus, pin locale/language; returns the device."""
    simctl.boot(record.udid)
    simctl.wait_booted(record.udid)
    if pin_locale:
        simctl.pin_locale(record.udid, record.locale, record.language)
    return simctl.owned_device(record.udid)


def lab_messenger_launch_args(base_url: str, sender_token: str, run_id: str) -> list[str]:
    return ["-MLFixtureBaseURL", base_url, "-MLFixtureToken", sender_token, "-MLRunId", run_id]

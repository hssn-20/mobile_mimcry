"""Real Simulator bring-up smoke check (setup evidence, not a scenario run).

    uv run python -m mobilelab.sim.bringup [--app PATH] [--out artifacts/bringup]

Starts the fixture service on ephemeral loopback ports, resets a fresh run
namespace, installs and launches Lab Messenger on the recorded project
Simulator with launch arguments, screenshots it, confirms from the fixture
request log that the app fetched conversations, opens article-01 in Safari
(simctl openurl, setup convenience only), screenshots, stops the service and
writes ``bringup.json``. The Simulator is left booted.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from mobilelab.fixtures.clients import FixtureAdminClient
from mobilelab.sim.lifecycle import (
    DEFAULT_APP_PATH,
    DEFAULT_RECORD_PATH,
    LAB_MESSENGER_BUNDLE_ID,
    REPO_ROOT,
    SAFARI_BUNDLE_ID,
    boot_device,
    lab_messenger_launch_args,
    load_record,
)
from mobilelab.sim.simctl import SimctlError, Simctl
from mobilelab.secrets import child_env

READY_TIMEOUT_S = 30.0
CONVERSATION_FETCH_TIMEOUT_S = 45.0
SAFARI_SETTLE_S = 8.0


def _start_service(state_dir: Path, log_path: Path) -> tuple[subprocess.Popen[str], dict[str, object]]:
    argv = [
        sys.executable, "-m", "mobilelab.fixtures.service",
        "--bind-host", "127.0.0.1", "--data-port", "0", "--admin-port", "0",
        "--state-dir", str(state_dir), "--with-receiver",
    ]  # fmt: skip
    with log_path.open("w", encoding="utf-8") as log:  # the child keeps its own copy of the fd
        proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=log, text=True, cwd=REPO_ROOT, start_new_session=True, env=child_env())  # noqa: S603
    assert proc.stdout is not None
    deadline = time.monotonic() + READY_TIMEOUT_S
    while time.monotonic() < deadline:
        line = proc.stdout.readline()
        if not line:
            break
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if record.get("event") == "fixture_ready":
            return proc, record
    proc.kill()
    proc.wait(timeout=5)
    proc.stdout.close()
    raise RuntimeError(f"fixture service did not become ready; see {log_path}")


def _stop_service(proc: subprocess.Popen[str]) -> int:
    try:
        if proc.poll() is None:
            proc.send_signal(signal.SIGTERM)
        try:
            return proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
            return proc.wait(timeout=5)
    finally:
        if proc.stdout is not None:
            proc.stdout.close()


async def _run(app: Path, out_root: Path, simctl: Simctl) -> dict[str, object]:
    record = load_record(DEFAULT_RECORD_PATH)
    if record is None:
        raise SimctlError("no device record; run 'python -m mobilelab.sim ensure' first")
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    out = out_root / stamp
    out.mkdir(parents=True, exist_ok=True)
    device = boot_device(simctl, record)
    result: dict[str, object] = {
        "evidence_source": "real_simulator",
        "device_kind": "simulator",
        "udid": device.udid,
        "device_name": device.name,
        "runtime": device.runtime_identifier,
        "app_path": str(app),
        "started_at": datetime.now(UTC).isoformat(),
    }
    proc, ready = _start_service(out / "fixture-state", out / "fixture-service.log")
    try:
        admin_url = str(ready["admin_url"])
        secret = Path(str(ready["admin_secret_file"])).read_text(encoding="utf-8").strip()
        if os.environ.get("MOBILELAB_FIXTURE_ADMIN_SECRET"):
            secret = os.environ["MOBILELAB_FIXTURE_ADMIN_SECRET"]
        run_id = uuid4()
        async with FixtureAdminClient(admin_url, secret) as admin:
            reset = await admin.reset(run_id)
            result |= {"run_id": str(run_id), "data_base_url": reset.data_base_url}

            simctl.install(device.udid, app)
            pid = simctl.launch(
                device.udid,
                LAB_MESSENGER_BUNDLE_ID,
                lab_messenger_launch_args(reset.data_base_url, reset.sender.token, str(run_id)),
            )
            result["lab_messenger_pid"] = pid
            deadline = time.monotonic() + CONVERSATION_FETCH_TIMEOUT_S
            fetches: list[dict[str, object]] = []
            while time.monotonic() < deadline and not fetches:
                await asyncio.sleep(1.0)
                log = await admin.request_log(run_id)
                fetches = [
                    {"at": e.at.isoformat(), "method": e.method, "path": e.path, "status": e.status,
                     "user_agent": e.user_agent}  # fmt: skip
                    for e in log
                    if e.method == "GET" and e.path.startswith("/fixture/v1/conversations")
                ]
            await asyncio.sleep(2.0)  # let the list render before the screenshot
            result["lab_messenger_screenshot"] = str(simctl.screenshot(device.udid, out / "lab_messenger.png"))
            full_log = await admin.request_log(run_id)
            (out / "request_log.json").write_text(
                json.dumps([e.model_dump(mode="json") for e in full_log], indent=2), encoding="utf-8"
            )
            result["conversation_fetches"] = fetches
            result["app_fetched_conversations"] = any(f["status"] == 200 for f in fetches)

            article = f"{reset.data_base_url}/fixture/v1/articles/article-01"
            simctl.openurl(device.udid, article)
            result["safari_url"] = article
            article_fetches: list[dict[str, object]] = []
            deadline = time.monotonic() + CONVERSATION_FETCH_TIMEOUT_S
            while time.monotonic() < deadline and not article_fetches:
                await asyncio.sleep(1.0)
                article_fetches = [
                    {"at": e.at.isoformat(), "path": e.path, "status": e.status, "user_agent": e.user_agent}
                    for e in await admin.request_log(run_id, include_unscoped=True)
                    if e.path.endswith("/articles/article-01")
                ]
            await asyncio.sleep(SAFARI_SETTLE_S)  # first Safari launch renders slowly
            result["safari_screenshot"] = str(simctl.screenshot(device.udid, out / "safari_article_01.png"))
            result["article_fetches"] = article_fetches
            simctl.terminate(device.udid, SAFARI_BUNDLE_ID)
            simctl.terminate(device.udid, LAB_MESSENGER_BUNDLE_ID)
    finally:
        result["fixture_service_exit"] = _stop_service(proc)
    result["finished_at"] = datetime.now(UTC).isoformat()
    result["simulator_state_after"] = simctl.owned_device(record.udid).state
    (out / "bringup.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    result["artifact_dir"] = str(out)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mobilelab.sim.bringup")
    parser.add_argument("--app", type=Path, default=DEFAULT_APP_PATH)
    parser.add_argument("--out", type=Path, default=REPO_ROOT / "artifacts" / "bringup")
    args = parser.parse_args(argv)
    result = asyncio.run(_run(args.app, args.out, Simctl()))
    print(json.dumps(result, indent=2))
    return 0 if result.get("app_fetched_conversations") else 2


if __name__ == "__main__":
    raise SystemExit(main())

"""T03 device gate: drive the iOS XCUITest adapter against the REAL project Simulator.

    uv run python -m mobilelab.sim.adapter_check [--out artifacts/device] [--app PATH]

Everything that touches the UI goes through ``IOSXCUITestAdapter`` (built via the adapter registry):
preflight, observe and execute of typed ``DispatchCommand``s. ``simctl`` is used only for setup
(boot, install, terminating apps so Lab Messenger starts with fresh launch arguments). Journey:

1. navigate_url article-01 in Safari, observe; scroll down, observe (scroll effect measured);
2. open_app Lab Messenger (launch args), observe the conversation list;
3. activate the seeded conversation row, observe the composer;
4. type_text (field_set) into composer.text, observe the text and ``composer.draft_id``.

Send is deliberately NOT tapped (the journey stage does that). Evidence goes to
``<out>/t03-<UTC stamp>/``: one folder per observation (screenshot.png, page_source.xml,
observation.json), ``capability_report.json``, ``appium.log``, fixture logs and ``summary.json``.
Teardown quits the session, stops Appium and this device's WDA xcodebuild, and confirms all three.
The Simulator is left booted.
"""

from __future__ import annotations

import argparse
import asyncio
import fcntl
import hashlib
import json
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from appium.webdriver.common.appiumby import AppiumBy

from mobilelab.adapters.appium_server import AppiumServer, find_wda_processes, free_loopback_port
from mobilelab.adapters.ios import IOSXCUITestAdapter
from mobilelab.adapters.registry import create_adapter
from mobilelab.domain.actions import url_origin
from mobilelab.domain.devices import DeviceProfile
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.enums import DeviceKind, EvidenceSource, Platform
from mobilelab.domain.observations import Observation, ObserveRequest
from mobilelab.fixtures.clients import FixtureAdminClient
from mobilelab.sim.bringup import _start_service, _stop_service
from mobilelab.sim.lifecycle import (
    DEFAULT_APP_PATH,
    DEFAULT_RECORD_PATH,
    LAB_MESSENGER_BUNDLE_ID,
    REPO_ROOT,
    SAFARI_BUNDLE_ID,
    boot_device,
    lab_messenger_launch_args,
    load_record,
)
from mobilelab.sim.simctl import Simctl, SimctlError

CONVERSATION_ID = "fixture-conversation-01"
TYPED_TEXT = "Hello from the T03 device gate"
APPIUM_VERSION = "3.8.0"
XCUITEST_DRIVER_VERSION = "12.14.0"
POLL_TIMEOUT_S = 30.0
POLL_INTERVAL_S = 0.5
SETTLE_S = 1.0
"""Pause after a condition first holds: on device, the first capture after an app switch had the final
tree but a mid-animation screenshot (Safari still zooming in from the home screen)."""
MIN_SCROLL_PT = 20.0


class DeviceGateError(RuntimeError):
    pass


@contextmanager
def device_lock(udid: str) -> Iterator[None]:
    """Exclusive, non-blocking per-Simulator lock so two gate runs never drive one device at once."""
    path = REPO_ROOT / "build" / "device-locks" / f"{udid}.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        try:
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise DeviceGateError(f"Simulator {udid} is being driven by another process ({path})") from None
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def _ms(a: datetime | None, b: datetime | None) -> float | None:
    return None if a is None or b is None else round((b - a).total_seconds() * 1000, 1)


def _by_identifier(obs: Observation, identifier: str) -> Any:
    return next((e for e in obs.ui_tree if e.identifier == identifier), None)


class _Gate:
    def __init__(self, adapter: IOSXCUITestAdapter, out: Path, run_id: UUID) -> None:
        self.adapter = adapter
        self.out = out
        self.run_id = run_id
        self.session_id = uuid4()
        self.observations: list[dict[str, Any]] = []
        self.commands: list[dict[str, Any]] = []
        self.latest: Observation | None = None
        self._n = 0

    async def observe(self, label: str) -> Observation:
        self._n += 1
        t0 = time.monotonic()
        obs = await self.adapter.observe(
            ObserveRequest(
                request_id=uuid4(),
                run_id=self.run_id,
                device_id=self.adapter.device_id,
                session_id=self.session_id,
                lease_id=uuid4(),
                lease_epoch=1,
                purpose="decision",
            )
        )
        call_ms = round((time.monotonic() - t0) * 1000, 1)
        folder = self.out / "observations" / f"{self._n:02d}-{label}"
        folder.mkdir(parents=True, exist_ok=True)
        files: dict[str, str] = {}
        for blob in self.adapter.take_artifacts(obs.observation_id):
            (folder / blob.filename).write_bytes(blob.data)
            files[blob.filename] = str((folder / blob.filename).relative_to(self.out))
            files[blob.filename + ".sha256"] = hashlib.sha256(blob.data).hexdigest()
        (folder / "observation.json").write_text(obs.model_dump_json(indent=2), encoding="utf-8")
        self.observations.append(
            {
                "n": self._n,
                "label": label,
                "observation_id": str(obs.observation_id),
                "evidence_source": obs.evidence_source.value,
                "foreground_app": obs.foreground_app,
                "orientation": obs.orientation.value,
                "capture_started_at": obs.capture_started_at.isoformat(),
                "screenshot_captured_at": obs.screenshot_captured_at.isoformat() if obs.screenshot_captured_at else None,
                "tree_captured_at": obs.tree_captured_at.isoformat() if obs.tree_captured_at else None,
                "capture_ended_at": obs.capture_ended_at.isoformat(),
                "capture_span_ms": round(obs.capture_span_ms, 1),
                "screenshot_to_tree_ms": _ms(obs.screenshot_captured_at, obs.tree_captured_at),
                "observe_call_ms": call_ms,
                "element_count": len(obs.ui_tree),
                "identified_elements": sum(1 for e in obs.ui_tree if e.identifier),
                "keyboard_visible": obs.keyboard_visible,
                "coordinate_spaces": [c.model_dump(mode="json") for c in obs.coordinate_spaces],
                "files": files,
            }
        )
        self.latest = obs
        return obs

    async def poll(self, label: str, ready: Callable[[Observation], bool], timeout_s: float = POLL_TIMEOUT_S) -> Observation:
        deadline = time.monotonic() + timeout_s
        while True:
            obs = await self.observe(label)
            if ready(obs):
                await asyncio.sleep(SETTLE_S)
                settled = await self.observe(label + "_settled")
                if ready(settled):
                    return settled
                obs = settled
            if time.monotonic() >= deadline:
                raise DeviceGateError(f"{label}: condition not observed within {timeout_s}s")
            await asyncio.sleep(POLL_INTERVAL_S)

    async def execute(self, label: str, payload: dict[str, Any], *, max_duration_ms: int = 15_000) -> ExecutionResult:
        obs = self.latest
        if obs is None:
            raise DeviceGateError("execute needs a dispatch observation")
        command = DispatchCommand.model_validate(
            {
                "command_id": uuid4(),
                "action_id": uuid4(),
                "run_id": self.run_id,
                "device_id": self.adapter.device_id,
                "session_id": self.session_id,
                "lease_id": uuid4(),
                "lease_epoch": 1,
                "control_epoch": 1,
                "dispatch_observation_id": obs.observation_id,
                "dispatch_candidate_id": uuid4(),
                "payload": payload,
                "max_duration_ms": max_duration_ms,
                "trace_id": f"t03-{label}",
            }
        )
        ref = payload.get("element_ref")
        locator = self.adapter.locator_for(obs.observation_id, ref) if ref else None
        planned_at = datetime.now(UTC)
        age_ms = round((time.monotonic_ns() - obs.worker_monotonic_capture_ns) / 1e6, 1)
        result = await self.adapter.execute(command)
        self.commands.append(
            {
                "label": label,
                "command_id": str(command.command_id),
                "dispatch_observation_id": str(obs.observation_id),
                "dispatch_observation_age_ms_at_issue": age_ms,
                "payload": command.payload.model_dump(mode="json"),
                "element_ref": ref,
                "locator": None
                if locator is None
                else {"strategy": locator.strategy, "value": locator.value, "index": locator.index},
                "planned_at": planned_at.isoformat(),
                "started_at": result.started_at.isoformat() if result.started_at else None,
                "ended_at": result.ended_at.isoformat() if result.ended_at else None,
                "start_delay_ms": _ms(planned_at, result.started_at),
                "duration_ms": None if result.duration_ms is None else round(result.duration_ms, 1),
                "status": result.status.value,
                "rejection_code": result.rejection_code.value if result.rejection_code else None,
                "typing_mode_actual": result.typing_mode_actual.value if result.typing_mode_actual else None,
                "evidence_source": result.evidence_source.value,
                "detail": result.detail,
                "error": result.error.model_dump(mode="json") if result.error else None,
            }
        )
        if result.status.value != "acknowledged":
            raise DeviceGateError(f"{label}: execute returned {result.status.value}: {result.detail}")
        return result

    async def verify_locators(self, obs: Observation, refs: list[str]) -> dict[str, str]:
        """Re-find each ref through its trusted locator in the live session and compare rects:
        checks the adapter's index ordering against what WDA really returns."""
        locators = {r: self.adapter.locator_for(obs.observation_id, r) for r in refs}

        def probe(drv: Any) -> dict[str, str]:
            out: dict[str, str] = {}
            for ref, loc in locators.items():
                if loc is None:
                    out[ref] = "no-locator"
                    continue
                by = AppiumBy.ACCESSIBILITY_ID if loc.strategy == "accessibility_id" else AppiumBy.IOS_PREDICATE
                found = drv.find_elements(by, loc.value)
                if len(found) <= loc.index:
                    out[ref] = f"missing ({len(found)} matches)"
                    continue
                if loc.bounds is None:
                    out[ref] = "found (no bounds)"
                    continue
                r = found[loc.index].rect
                b = loc.bounds
                delta = max(abs(r["x"] - b.x), abs(r["y"] - b.y), abs(r["width"] - b.width), abs(r["height"] - b.height))
                out[ref] = "match" if delta <= 1.0 else f"rect differs by {delta}"
            return out

        return await self.adapter.run_probe(probe, 120)


async def _journey(gate: _Gate, article_url: str) -> dict[str, Any]:
    checks: dict[str, Any] = {}
    await gate.observe("initial")

    await gate.execute("navigate_url_article_01", {"kind": "navigate_url", "url": article_url})
    safari = await gate.poll(
        "safari_article_01",
        lambda o: o.foreground_app == SAFARI_BUNDLE_ID
        and any(e.role == "static_text" and (e.label or "").startswith("Small Gardens") for e in o.ui_tree),
    )
    shot_before = gate.observations[-1]["files"].get("screenshot.png.sha256")
    title_before = next(e for e in safari.ui_tree if e.role == "static_text" and (e.label or "").startswith("Small Gardens"))
    await gate.execute("scroll_down", {"kind": "scroll", "direction": "down"})
    await asyncio.sleep(1.0)  # let scroll deceleration settle before the post-scroll capture
    scrolled = await gate.observe("safari_after_scroll")
    title_after = next(
        (e for e in scrolled.ui_tree if e.role == "static_text" and e.label == title_before.label), None
    )
    y_before = title_before.bounds.y if title_before.bounds else None
    y_after = title_after.bounds.y if title_after and title_after.bounds else None
    checks["safari_scroll"] = {
        "title_y_before": y_before,
        "title_y_after": y_after,
        "moved_pt": None if y_before is None or y_after is None else round(y_before - y_after, 1),
        "screenshot_changed": gate.observations[-1]["files"].get("screenshot.png.sha256") != shot_before,
    }
    moved = checks["safari_scroll"]["moved_pt"]
    if moved is None or moved < MIN_SCROLL_PT:
        raise DeviceGateError(f"scroll down did not move the article title (moved_pt={moved})")
    link_refs = [e.element_ref for e in scrolled.ui_tree if e.role == "link"]
    checks["safari_locators"] = await gate.verify_locators(scrolled, link_refs[:6])

    await gate.execute("open_app_lab_messenger", {"kind": "open_app", "app_id": LAB_MESSENGER_BUNDLE_ID})
    row_id = f"conversation.row.{CONVERSATION_ID}"
    listing = await gate.poll(
        "lab_messenger_list",
        lambda o: o.foreground_app == LAB_MESSENGER_BUNDLE_ID and _by_identifier(o, row_id) is not None,
    )
    row = _by_identifier(listing, row_id)
    checks["conversation_row"] = {"element_ref": row.element_ref, "label": row.label, "role": row.role}

    await gate.execute("activate_conversation_row", {"kind": "activate", "element_ref": row.element_ref})
    conversation = await gate.poll(
        "lab_messenger_conversation",
        lambda o: _by_identifier(o, "composer.text") is not None and _by_identifier(o, "composer.draft_id") is not None,
    )
    composer = _by_identifier(conversation, "composer.text")
    draft_before = _by_identifier(conversation, "composer.draft_id").value
    refs = [e.element_ref for e in conversation.ui_tree if e.identifier]
    checks["conversation_locators"] = await gate.verify_locators(conversation, refs)
    bad = {r: v for r, v in {**checks["safari_locators"], **checks["conversation_locators"]}.items() if v != "match"}
    if bad:
        raise DeviceGateError(f"locators did not re-find the observed elements: {bad}")

    await gate.execute(
        "type_text_field_set",
        {"kind": "type_text", "element_ref": composer.element_ref, "text": TYPED_TEXT, "mode": "field_set"},
    )
    typed = await gate.poll(
        "lab_messenger_typed",
        lambda o: (_by_identifier(o, "composer.text") or composer).value == TYPED_TEXT,
        timeout_s=10,
    )
    draft = _by_identifier(typed, "composer.draft_id")
    send = _by_identifier(typed, "composer.send")
    title = _by_identifier(typed, "conversation.title")
    if not (_is_uuid(draft.value if draft else None) and draft is not None and draft.value == draft_before):
        raise DeviceGateError("composer.draft_id missing, not a UUID, or changed while typing")
    checks["composer"] = {
        "composer_text_ref": composer.element_ref,
        "composer_text_value_before": composer.value,
        "composer_text_value_after": (_by_identifier(typed, "composer.text") or composer).value,
        "draft_id_before_typing": draft_before,
        "draft_id_after_typing": draft.value if draft else None,
        "draft_id_is_uuid": _is_uuid(draft.value if draft else None),
        "draft_id_stable": draft is not None and draft.value == draft_before,
        "send_ref": send.element_ref if send else None,
        "send_enabled_after_typing": send.enabled if send else None,
        "conversation_title": title.label if title else None,
        "keyboard_visible": typed.keyboard_visible,
        "send_tapped": False,
    }
    return checks


def _is_uuid(value: str | None) -> bool:
    try:
        UUID(str(value))
    except ValueError:
        return False
    return True


async def run_adapter_check(
    *,
    out_root: Path = REPO_ROOT / "artifacts" / "device",
    app_path: Path = DEFAULT_APP_PATH,
    record_path: Path = DEFAULT_RECORD_PATH,
    simctl: Simctl | None = None,
) -> dict[str, Any]:
    simctl = simctl or Simctl()
    record = load_record(record_path)
    if record is None:
        raise SimctlError("no device record; run 'python -m mobilelab.sim ensure' first")
    out = out_root / f"t03-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    out.mkdir(parents=True, exist_ok=True)
    summary: dict[str, Any] = {
        "gate": "T03 iOS adapter device gate",
        "evidence_source": EvidenceSource.DEVICE.value,
        "evidence_note": "real iOS Simulator via Appium/WebDriverAgent; no mocks or fakes in this run",
        "device_kind": "simulator",
        "udid": record.udid,
        "device_name": record.name,
        "runtime": record.runtime_identifier,
        "appium_version": APPIUM_VERSION,
        "xcuitest_driver_version": XCUITEST_DRIVER_VERSION,
        "started_at": datetime.now(UTC).isoformat(),
        "artifact_dir": str(out),
        "ok": False,
    }
    with device_lock(record.udid):
        device = boot_device(simctl, record)
        if not simctl.is_installed(device.udid, LAB_MESSENGER_BUNDLE_ID):
            simctl.install(device.udid, app_path)
        proc, ready = _start_service(out / "fixture-state", out / "fixture-service.log")
        server = AppiumServer(repo_root=REPO_ROOT, port=free_loopback_port(), log_path=out / "appium.log")
        adapter: IOSXCUITestAdapter | None = None
        try:
            secret = Path(str(ready["admin_secret_file"])).read_text(encoding="utf-8").strip()
            run_id = uuid4()
            async with FixtureAdminClient(str(ready["admin_url"]), secret) as admin:
                reset = await admin.reset(run_id)
            base = reset.data_base_url
            article = f"{base}/fixture/v1/articles/article-01"
            summary |= {"run_id": str(run_id), "data_base_url": base, "article_url": article}
            # Setup only: start both apps cold so preflight/open_app exercise a real launch.
            for bundle in (LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID):
                simctl.terminate(device.udid, bundle)

            t0 = time.monotonic()
            server.start()
            summary["appium"] = {"url": server.url, "bind": server.address, "start_s": round(time.monotonic() - t0, 2)}
            device_id = uuid4()
            options = {
                "udid": device.udid,
                "device_name": device.name,
                "platform_version": record.runtime_version,
                "appium_url": server.url,
                "repo_root": str(REPO_ROOT),
                "wda_local_port": free_loopback_port(),
                "allowed_url_origins": [url_origin(base)],
                "app_launch_arguments": {
                    LAB_MESSENGER_BUNDLE_ID: lab_messenger_launch_args(base, reset.sender.token, str(run_id))
                },
                "safari_probe_url": article,
            }
            built = create_adapter("ios", device_id, options)
            assert isinstance(built, IOSXCUITestAdapter)
            adapter = built
            summary["adapter"] = {
                "version": adapter.adapter_version,
                "wda_local_port": options["wda_local_port"],
                "derived_data_path": str(adapter.config.derived_data_path),
                "headless": adapter.config.headless,
                "capabilities": {
                    k: v
                    for k, v in adapter.config.xcuitest_options().to_capabilities().items()
                    if "derivedDataPath" not in k
                },
            }
            profile = DeviceProfile(
                device_id=device_id,
                platform=Platform.IOS,
                kind=DeviceKind.SIMULATOR,
                name=device.name,
                os_version=record.runtime_version,
                model=record.device_type_name,
                locale=record.locale,
                adapter_serial=device.udid,
                installed_fixture_builds={LAB_MESSENGER_BUNDLE_ID: str(app_path)},
                appium_version=APPIUM_VERSION,
                driver_versions={"xcuitest": XCUITEST_DRIVER_VERSION},
            )
            t0 = time.monotonic()
            report = await adapter.preflight(profile)  # first call also creates the session (WDA)
            summary["preflight_s"] = round(time.monotonic() - t0, 1)
            (out / "capability_report.json").write_text(report.model_dump_json(indent=2), encoding="utf-8")
            summary["capabilities"] = {r.key.value: r.status.value for r in report.records}
            # Preflight left Lab Messenger in the conversation; restart it cold for the journey.
            simctl.terminate(device.udid, LAB_MESSENGER_BUNDLE_ID)

            gate = _Gate(adapter, out, run_id)
            try:
                summary["checks"] = await _journey(gate, article)
                summary["ok"] = True
            except Exception as exc:
                summary["error"] = f"{type(exc).__name__}: {exc}"[:2000]
            finally:
                summary["observations"] = gate.observations
                summary["commands"] = gate.commands
            async with FixtureAdminClient(str(ready["admin_url"]), secret) as admin:
                log = await admin.request_log(run_id, include_unscoped=True)
            (out / "request_log.json").write_text(
                json.dumps([e.model_dump(mode="json") for e in log], indent=2), encoding="utf-8"
            )
            summary["fixture_requests"] = sorted({f"{e.method} {urlsplit(e.path).path}" for e in log})
            summary["fixture_message_posts"] = sum(1 for e in log if e.method == "POST" and "/messages" in e.path)
        except Exception as exc:
            summary.setdefault("error", f"{type(exc).__name__}: {exc}"[:2000])
            summary["ok"] = False
        finally:
            teardown: dict[str, Any] = {}
            if adapter is not None:
                closed = await adapter.close()
                teardown["session_closed"] = closed.closed
                teardown["close_detail"] = closed.detail
                teardown["wda_pids_stopped"] = adapter.wda_processes_stopped
                teardown["wda_processes_remaining"] = find_wda_processes(
                    adapter.config.udid, adapter.config.derived_data_path.resolve()
                )
            server.stop()
            teardown["appium_running"] = server.running
            teardown["appium_port_open"] = _port_open(server.port)
            teardown["fixture_service_exit"] = _stop_service(proc)
            teardown["simulator_state"] = simctl.owned_device(record.udid).state
            summary["teardown"] = teardown
            summary["finished_at"] = datetime.now(UTC).isoformat()
            (out / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    return summary


def _port_open(port: int) -> bool:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mobilelab.sim.adapter_check")
    parser.add_argument("--out", type=Path, default=REPO_ROOT / "artifacts" / "device")
    parser.add_argument("--app", type=Path, default=DEFAULT_APP_PATH)
    args = parser.parse_args(argv)
    summary = asyncio.run(run_adapter_check(out_root=args.out, app_path=args.app))
    brief = {k: summary.get(k) for k in ("ok", "error", "artifact_dir", "preflight_s", "checks", "teardown")}
    print(json.dumps(brief, indent=2, default=str))
    return 0 if summary.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())

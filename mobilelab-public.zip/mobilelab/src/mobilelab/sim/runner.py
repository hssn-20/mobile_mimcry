"""Typed subprocess execution for simctl: argv arrays, timeouts, env overrides.

Never ``shell=True``. The runner is injectable so unit tests use a fake.
"""

from __future__ import annotations

import os
import subprocess
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Protocol
from mobilelab.secrets import child_env


@dataclass(frozen=True)
class CommandResult:
    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str


class CommandRunner(Protocol):
    def __call__(self, argv: Sequence[str], *, timeout_s: float, env: Mapping[str, str]) -> CommandResult: ...


class CommandTimeout(Exception):
    def __init__(self, argv: Sequence[str], timeout_s: float) -> None:
        super().__init__(f"command timed out after {timeout_s:.0f}s: {' '.join(argv)}")
        self.argv = tuple(argv)
        self.timeout_s = timeout_s


class SubprocessRunner:
    """Runs one argv with the parent environment plus ``env`` overrides."""

    def __call__(self, argv: Sequence[str], *, timeout_s: float, env: Mapping[str, str]) -> CommandResult:
        if not argv or not all(isinstance(a, str) for a in argv):
            raise TypeError("argv must be a non-empty sequence of str")
        try:
            proc = subprocess.run(  # noqa: S603 - typed argv, never a shell
                list(argv),
                capture_output=True,
                text=True,
                timeout=timeout_s,
                env=child_env(None, **env),
                stdin=subprocess.DEVNULL,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise CommandTimeout(argv, timeout_s) from exc
        return CommandResult(tuple(argv), proc.returncode, proc.stdout, proc.stderr)

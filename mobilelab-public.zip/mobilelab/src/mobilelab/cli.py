"""`mobilelab` command-line entry point.

Subcommands are registered from modules listed in :data:`SUBCOMMAND_MODULES`.
Each module exposes ``register(subparsers)`` which adds its parser and sets
``func`` (``Callable[[argparse.Namespace], int]``) via ``set_defaults``. Later
tasks add a subcommand by appending a module path here; modules are imported
only when the parser is built, so ``import mobilelab.cli`` stays cheap.
"""

from __future__ import annotations

import argparse
import importlib
from collections.abc import Sequence

SUBCOMMAND_MODULES: tuple[str, ...] = (
    "mobilelab.doctor.command",
    "mobilelab.journey.command",
)


def build_parser(modules: Sequence[str] = SUBCOMMAND_MODULES) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mobilelab", description="Mobile behaviour testing demonstrator")
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")
    for module_path in modules:
        importlib.import_module(module_path).register(subparsers)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        return 2
    return int(func(args))


if __name__ == "__main__":
    raise SystemExit(main())

"""Scripted receiving peer with its own identity (receiver_type "scripted_receiver").

It polls its inbox over HTTP with the receiver token, acknowledges
``delivered`` for each new message and keeps its own timestamped log. It can
establish delivery but never ``displayed`` (it has no UI), so it exposes no
way to send a display acknowledgement; the server also refuses ``displayed``
from the scripted receiver identity (403 DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE). During an outage, or when the
``suppress_receiver_ack`` fault is active, it does not acknowledge, so the
server receipt stays ``accepted`` and delivery remains unknown.
"""

from __future__ import annotations

import argparse
import asyncio
import os
from collections.abc import Callable
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from mobilelab.fixtures.clients import FixtureAdminClient
from mobilelab.fixtures.models import (
    AcknowledgementRequest,
    AckKind,
    ActivationReport,
    DetailValue,
    FaultLayer,
    FaultMode,
    RECEIVER_FAULT_ROUTES,
    FaultSpec,
    Message,
    MessagesPage,
    Receipt,
    ReceiverType,
    Reporter,
    UtcDatetime,
    utc_now,
)

_RECEIVER_ROUTES = RECEIVER_FAULT_ROUTES  # FaultSpec validation guarantees receiver faults use these


class ReceiverEvent(StrEnum):
    FETCHED = "fetched"
    ACKNOWLEDGED = "acknowledged"
    ACK_SUPPRESSED = "ack_suppressed"
    ACK_FAILED = "ack_failed"
    OUTAGE_STARTED = "outage_started"
    OUTAGE_ENDED = "outage_ended"
    POLL_FAILED = "poll_failed"


class ReceiverLogEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    entry_id: str
    evidence_id: str
    at: UtcDatetime
    event: ReceiverEvent
    receiver_id: str
    receiver_type: ReceiverType
    run_id: UUID
    message_id: UUID | None = None
    client_message_id: UUID | None = None
    detail: dict[str, DetailValue] = Field(default_factory=dict)


class ReceiverFaultSource(Protocol):
    """The receiver's own fault channel (separate from the data listener)."""

    async def receiver_faults(self) -> list[FaultSpec]: ...

    async def report_activation(self, report: ActivationReport) -> None: ...


class AdminReceiverFaultSource:
    """Reads the run's receiver-layer faults from the loopback admin listener.

    The scripted receiver is a harness-side component on the Mac; it is never
    a device, so it may hold the admin secret for this narrow purpose.
    """

    def __init__(self, admin: FixtureAdminClient, run_id: UUID) -> None:
        self._admin = admin
        self._run_id = run_id

    async def receiver_faults(self) -> list[FaultSpec]:
        schedule = await self._admin.get_faults(self._run_id)
        return [f for f in schedule.faults if f.layer is FaultLayer.RECEIVER]

    async def report_activation(self, report: ActivationReport) -> None:
        await self._admin.report_activation(self._run_id, report)


class StaticReceiverFaultSource:
    """In-memory fault channel; activations are kept locally (``reports``)."""

    def __init__(self, faults: list[FaultSpec] | None = None) -> None:
        self.faults = list(faults or [])
        self.reports: list[ActivationReport] = []

    async def receiver_faults(self) -> list[FaultSpec]:
        return [f for f in self.faults if f.layer is FaultLayer.RECEIVER]

    async def report_activation(self, report: ActivationReport) -> None:
        self.reports.append(report)


class ScriptedReceiver:
    receiver_type = ReceiverType.SCRIPTED_RECEIVER

    def __init__(
        self,
        data_base_url: str,
        token: str,
        run_id: UUID,
        *,
        receiver_id: str,
        fault_source: ReceiverFaultSource | None = None,
        log_path: Path | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
        poll_interval_s: float = 0.5,
        timeout_s: float = 5.0,
    ) -> None:
        self.run_id = run_id
        self.receiver_id = receiver_id
        self.log: list[ReceiverLogEntry] = []
        self._fault_source = fault_source
        self._log_path = log_path
        self._clock = clock
        self._poll_interval_s = poll_interval_s
        self._cursor: str | None = None
        self._handled: set[UUID] = set()
        self._manual_outage = False
        self._in_outage = False
        self._fault_counts: dict[str, int] = {}
        self._reported_outage_faults: set[str] = set()
        self._client = httpx.AsyncClient(
            base_url=data_base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {token}", "User-Agent": "mobilelab-scripted-receiver"},
            timeout=timeout_s,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    # ------------------------------------------------------------ switches

    def set_outage(self, down: bool) -> None:
        """Manual outage switch: while down the receiver neither polls nor acknowledges."""
        self._manual_outage = down

    # ------------------------------------------------------------ evidence

    def _record(
        self,
        event: ReceiverEvent,
        *,
        message: Message | None = None,
        at: datetime | None = None,
        detail: dict[str, DetailValue] | None = None,
    ) -> ReceiverLogEntry:
        entry_id = str(uuid4())
        entry = ReceiverLogEntry(
            entry_id=entry_id,
            evidence_id=f"receiver:{self.receiver_id}:{entry_id}",
            at=at or self._clock(),
            event=event,
            receiver_id=self.receiver_id,
            receiver_type=self.receiver_type,
            run_id=self.run_id,
            message_id=message.message_id if message else None,
            client_message_id=message.client_message_id if message else None,
            detail=detail or {},
        )
        self.log.append(entry)
        if self._log_path is not None:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            with self._log_path.open("a", encoding="utf-8") as fh:
                fh.write(entry.model_dump_json() + "\n")
        return entry

    async def _report(self, fault: FaultSpec, detail: dict[str, DetailValue]) -> None:
        if self._fault_source is None:
            return
        report = ActivationReport(
            schema_version=1,
            fault_id=fault.fault_id,
            reporter=Reporter.RECEIVER,
            activated_at=self._clock(),
            detail={**detail, "receiver_id": self.receiver_id},
        )
        try:
            await self._fault_source.report_activation(report)
        except Exception as exc:  # noqa: BLE001 - evidence of the failure is kept locally
            self._record(ReceiverEvent.POLL_FAILED, detail={"stage": "report_activation", "error": repr(exc)})

    # ------------------------------------------------------------ polling

    def _set_outage_state(self, down: bool, reason: str) -> None:
        if down != self._in_outage:
            self._in_outage = down
            event = ReceiverEvent.OUTAGE_STARTED if down else ReceiverEvent.OUTAGE_ENDED
            self._record(event, detail={"reason": reason})

    async def poll_once(self) -> list[ReceiverLogEntry]:
        """One poll cycle. Returns the log entries it produced."""
        start = len(self.log)
        if self._manual_outage:
            self._set_outage_state(True, "manual_switch")
            return self.log[start:]

        now = self._clock()
        try:
            faults = (
                [f for f in await self._fault_source.receiver_faults() if f.is_active(now)]
                if self._fault_source
                else []
            )
        except Exception as exc:  # noqa: BLE001
            # Without the fault channel we cannot know whether acks are suppressed:
            # skip this cycle rather than risk a fabricated acknowledgement.
            self._record(ReceiverEvent.POLL_FAILED, detail={"stage": "fault_channel", "error": repr(exc)})
            return self.log[start:]

        unavailable = [
            f for f in faults if f.mode is FaultMode.RECIPIENT_UNAVAILABLE and f.match.route in _RECEIVER_ROUTES
        ]
        if unavailable:
            self._set_outage_state(True, "fault:" + ",".join(f.fault_id for f in unavailable))
            for fault in unavailable:
                if fault.fault_id not in self._reported_outage_faults:
                    self._reported_outage_faults.add(fault.fault_id)
                    await self._report(fault, {"effect": "receiver_offline"})
            return self.log[start:]
        self._set_outage_state(False, "recovered")

        try:
            params = {"after": self._cursor} if self._cursor else None
            response = await self._client.get("/fixture/v1/receiver/inbox", params=params)
            if response.status_code != 200:
                self._record(ReceiverEvent.POLL_FAILED, detail={"stage": "inbox", "status": response.status_code})
                return self.log[start:]
            page = MessagesPage.model_validate_json(response.content)
        except (httpx.TransportError, ValidationError) as exc:
            self._record(ReceiverEvent.POLL_FAILED, detail={"stage": "inbox", "error": type(exc).__name__})
            return self.log[start:]

        suppressors = [
            f for f in faults if f.mode is FaultMode.SUPPRESS_RECEIVER_ACK and f.match.route in _RECEIVER_ROUTES
        ]
        cursor_blocked = False
        for message in page.messages:
            if message.message_id not in self._handled:
                done = await self._handle(message, suppressors)
                if not done:
                    cursor_blocked = True
            if not cursor_blocked:
                self._cursor = str(message.sequence)
        return self.log[start:]

    async def _handle(self, message: Message, suppressors: list[FaultSpec]) -> bool:
        fetched = self._record(ReceiverEvent.FETCHED, message=message, detail={"sequence": message.sequence})
        for fault in suppressors:
            count = self._fault_counts.get(fault.fault_id, 0) + 1
            self._fault_counts[fault.fault_id] = count
            if fault.match.nth is None or fault.match.nth == count:
                self._record(ReceiverEvent.ACK_SUPPRESSED, message=message, detail={"fault_id": fault.fault_id})
                await self._report(
                    fault,
                    {
                        "effect": "ack_withheld",
                        "message_id": str(message.message_id),
                        "client_message_id": str(message.client_message_id),
                    },
                )
                self._handled.add(message.message_id)
                return True

        ack = AcknowledgementRequest(
            kind=AckKind.DELIVERED, receiver_observed_at=fetched.at, evidence_ids=[fetched.evidence_id]
        )
        try:
            response = await self._client.post(
                f"/fixture/v1/messages/{message.message_id}/acknowledgements",
                content=ack.model_dump_json(),
                headers={"Content-Type": "application/json"},
            )
            if response.status_code != 200:
                self._record(ReceiverEvent.ACK_FAILED, message=message, detail={"status": response.status_code})
                return False
            receipt = Receipt.model_validate_json(response.content)
        except (httpx.TransportError, ValidationError) as exc:
            self._record(ReceiverEvent.ACK_FAILED, message=message, detail={"error": type(exc).__name__})
            return False
        self._record(ReceiverEvent.ACKNOWLEDGED, message=message, detail={"server_status": receipt.status.value})
        self._handled.add(message.message_id)
        return True

    async def run(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            await self.poll_once()
            try:
                await asyncio.wait_for(stop.wait(), timeout=self._poll_interval_s)
            except TimeoutError:
                pass


async def _main_async(args: argparse.Namespace) -> None:
    token = os.environ.get("MOBILELAB_FIXTURE_RECEIVER_TOKEN") or Path(args.token_file).read_text().strip()
    admin: FixtureAdminClient | None = None
    source: ReceiverFaultSource | None = None
    if args.admin_base_url:
        secret = os.environ.get("MOBILELAB_FIXTURE_ADMIN_SECRET") or Path(args.admin_secret_file).read_text().strip()
        admin = FixtureAdminClient(args.admin_base_url, secret)
        source = AdminReceiverFaultSource(admin, UUID(args.run_id))
    receiver = ScriptedReceiver(
        args.data_base_url,
        token,
        UUID(args.run_id),
        receiver_id=args.receiver_id,
        fault_source=source,
        log_path=Path(args.log_path) if args.log_path else None,
        poll_interval_s=args.poll_interval_s,
    )
    stop = asyncio.Event()
    try:
        await receiver.run(stop)
    finally:
        await receiver.aclose()
        if admin is not None:
            await admin.aclose()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="mobilelab scripted fixture receiver")
    parser.add_argument("--data-base-url", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--receiver-id", default="fixture-receiver-01")
    parser.add_argument("--token-file", help="file holding the receiver token (or env MOBILELAB_FIXTURE_RECEIVER_TOKEN)")
    parser.add_argument("--admin-base-url", help="enables the admin fault channel")
    parser.add_argument("--admin-secret-file")
    parser.add_argument("--log-path")
    parser.add_argument("--poll-interval-s", type=float, default=0.5)
    try:
        asyncio.run(_main_async(parser.parse_args(argv)))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()


__all__ = [
    "AdminReceiverFaultSource",
    "ReceiverEvent",
    "ReceiverFaultSource",
    "ReceiverLogEntry",
    "ScriptedReceiver",
    "StaticReceiverFaultSource",
]

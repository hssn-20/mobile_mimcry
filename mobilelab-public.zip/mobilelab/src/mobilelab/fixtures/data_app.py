"""Device-reachable DATA listener. No administrative routes are mounted here."""

from __future__ import annotations

from uuid import UUID, uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.types import ASGIApp, Message as AsgiMessage, Receive, Scope, Send

from mobilelab.fixtures.config import FixtureConfig
from mobilelab.fixtures.errors import FixtureError, error_response, fixture_error_handler
from mobilelab.fixtures.faults import ResponseDroppedError, run_with_faults
from mobilelab.fixtures.httputil import bearer_token, json_response, parse_json_body
from mobilelab.fixtures.models import (
    AcknowledgementRequest,
    ConversationsResponse,
    DetailValue,
    ErrorCode,
    FaultRoute,
    HealthResponse,
    MessagesPage,
    RequestLogEntry,
    Role,
    SendMessageRequest,
)
from mobilelab.fixtures.store import FixtureStore, Principal, parse_cursor
from mobilelab.fixtures.web import create_web_router

DEFAULT_PAGE_LIMIT = 50
MAX_PAGE_LIMIT = 200


class RequestEvidenceMiddleware:
    """Logs every data-listener request as server-side request evidence.

    The Authorization header is never logged.
    """

    def __init__(self, app: ASGIApp, store: FixtureStore) -> None:
        self.app = app
        self.store = store

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        at = self.store.now()
        status: int | None = None
        state: dict[str, object] = scope.setdefault("state", {})

        async def capture(message: AsgiMessage) -> None:
            nonlocal status
            if message["type"] == "http.response.start":
                status = int(message["status"])
            await send(message)

        outcome = "completed"
        try:
            await self.app(scope, receive, capture)
        except ResponseDroppedError:
            outcome = "dropped"
            raise
        except Exception:
            outcome = "error"
            raise
        finally:
            self._log(scope, state, at, status, outcome)

    def _log(
        self, scope: Scope, state: dict[str, object], at: object, status: int | None, outcome: str
    ) -> None:
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        query = scope.get("query_string", b"").decode("latin-1")
        run_id = state.get("fixture_run_id")
        detail = state.get("fixture_detail")
        client = scope.get("client")
        self.store.log_request(
            RequestLogEntry(
                entry_id=uuid4(),
                run_id=run_id if isinstance(run_id, UUID) else None,
                at=at,
                method=scope["method"],
                path=scope["path"],
                query=query[:1000],
                status=status,
                outcome=outcome,
                user_agent=headers.get("user-agent", "")[:500] or None,
                client_host=client[0] if client else None,
                detail=detail if isinstance(detail, dict) else {},
            )
        )


def _parse_limit(request: Request) -> int:
    raw = request.query_params.get("limit")
    if raw is None:
        return DEFAULT_PAGE_LIMIT
    if not raw.isdigit() or not 1 <= int(raw) <= MAX_PAGE_LIMIT:
        raise FixtureError(422, ErrorCode.VALIDATION_ERROR, f"limit must be 1..{MAX_PAGE_LIMIT}")
    return int(raw)


def create_data_app(store: FixtureStore, config: FixtureConfig) -> FastAPI:
    app = FastAPI(
        title="mobilelab fixture data",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    app.add_exception_handler(FixtureError, fixture_error_handler)

    @app.exception_handler(RequestValidationError)
    async def _validation(_request: Request, exc: RequestValidationError) -> JSONResponse:
        return error_response(422, ErrorCode.VALIDATION_ERROR, str(exc.errors()))

    app.add_middleware(RequestEvidenceMiddleware, store=store)
    app.include_router(create_web_router(store, config))

    def authorize(request: Request, *roles: Role) -> Principal:
        principal = store.authenticate(bearer_token(request))
        request.state.fixture_run_id = principal.run_id
        request.state.fixture_detail = {"role": principal.role.value}
        if principal.role not in roles:
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        return principal

    @app.get("/fixture/v1/health")
    async def health() -> JSONResponse:
        return json_response(HealthResponse(fixture_data_version=config.fixture_data_version))

    @app.get("/fixture/v1/conversations")
    async def conversations(request: Request) -> Response:
        principal = authorize(request, Role.SENDER, Role.RECEIVER)

        async def handler(_detail: dict[str, DetailValue]) -> Response:
            return json_response(ConversationsResponse(conversations=store.conversations_for(principal)))

        return await run_with_faults(
            store, principal.run_id, FaultRoute.LIST_CONVERSATIONS, request.url.path, handler
        )

    @app.get("/fixture/v1/conversations/{conversation_id}/messages")
    async def messages(request: Request, conversation_id: str) -> Response:
        principal = authorize(request, Role.SENDER, Role.RECEIVER)
        after = parse_cursor(request.query_params.get("after"))
        limit = _parse_limit(request)

        async def handler(_detail: dict[str, DetailValue]) -> Response:
            items, cursor = store.list_messages(principal, conversation_id, after, limit)
            return json_response(MessagesPage(messages=items, next_cursor=cursor))

        return await run_with_faults(store, principal.run_id, FaultRoute.LIST_MESSAGES, request.url.path, handler)

    @app.post("/fixture/v1/messages")
    async def post_message(request: Request) -> Response:
        principal = authorize(request, Role.SENDER)
        body = await parse_json_body(request, SendMessageRequest)
        if body.run_id != principal.run_id:
            raise FixtureError(403, ErrorCode.RUN_MISMATCH)

        async def handler(detail: dict[str, DetailValue]) -> Response:
            receipt, duplicate = store.accept_message(principal, body)
            detail.update(
                message_id=str(receipt.message_id),
                client_message_id=str(receipt.client_message_id),
                duplicate=duplicate,
            )
            request.state.fixture_detail = {
                "role": principal.role.value,
                "client_message_id": str(receipt.client_message_id),
                "duplicate": duplicate,
            }
            if duplicate:
                return json_response(receipt, 200, {"Fixture-Duplicate": "true"})
            return json_response(receipt, 201)

        return await run_with_faults(store, principal.run_id, FaultRoute.POST_MESSAGE, request.url.path, handler)

    @app.get("/fixture/v1/receiver/inbox")
    async def receiver_inbox(request: Request) -> Response:
        principal = authorize(request, Role.RECEIVER)
        after = parse_cursor(request.query_params.get("after"))
        limit = _parse_limit(request)

        async def handler(_detail: dict[str, DetailValue]) -> Response:
            items, cursor = store.receiver_inbox(principal, after, limit)
            return json_response(MessagesPage(messages=items, next_cursor=cursor))

        return await run_with_faults(store, principal.run_id, FaultRoute.RECEIVER_INBOX, request.url.path, handler)

    @app.post("/fixture/v1/messages/{message_id}/acknowledgements")
    async def acknowledge(request: Request, message_id: str) -> Response:
        principal = authorize(request, Role.RECEIVER)
        try:
            mid = UUID(message_id)
        except ValueError:
            raise FixtureError(404, ErrorCode.MESSAGE_NOT_FOUND) from None
        ack = await parse_json_body(request, AcknowledgementRequest)

        async def handler(detail: dict[str, DetailValue]) -> Response:
            detail.update(message_id=str(mid), kind=ack.kind.value)
            return json_response(store.acknowledge(principal, mid, ack))

        return await run_with_faults(store, principal.run_id, FaultRoute.ACKNOWLEDGE, request.url.path, handler)

    @app.get("/fixture/v1/receipts/{client_message_id}")
    async def receipt(request: Request, client_message_id: str) -> Response:
        # Oracle reconciliation is deliberately exempt from injected faults.
        principal = authorize(request, Role.ORACLE)
        try:
            run_id = UUID(request.query_params.get("run_id", ""))
        except ValueError:
            raise FixtureError(422, ErrorCode.VALIDATION_ERROR, "run_id query parameter must be a UUID") from None
        try:
            cmid = UUID(client_message_id)
        except ValueError:
            raise FixtureError(404, ErrorCode.RECEIPT_NOT_FOUND) from None
        found = store.get_receipt(principal, run_id, cmid)
        if found is None:
            raise FixtureError(404, ErrorCode.RECEIPT_NOT_FOUND)
        return json_response(found)

    return app

"""Typed async clients for the coordinator and oracle.

Errors are deliberately distinct so callers never confuse an outage
(delivery unknown) with an authoritative "not found" or an auth failure.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Self
from uuid import UUID

import httpx
from pydantic import BaseModel, ValidationError

from mobilelab.fixtures.models import (
    ActivationReport,
    ErrorCode,
    FaultSchedule,
    FaultScheduleRequest,
    FaultSpec,
    FixtureLayout,
    GroundTruthRecord,
    GroundTruthResponse,
    Receipt,
    RequestLogEntry,
    RequestLogResponse,
    ResetRequest,
    ResetResponse,
)


class FixtureClientError(Exception):
    """Base class for fixture client errors."""


class FixtureUnavailableError(FixtureClientError):
    """Transport failure, timeout or 5xx: the fixture service could not answer."""


class FixtureAuthError(FixtureClientError):
    """401/403: token invalid/expired, wrong role, run mismatch or denied conversation."""

    def __init__(self, status: int, code: str) -> None:
        super().__init__(f"{status} {code}")
        self.status = status
        self.code = code


class ReceiptNotFoundError(FixtureClientError):
    """The server authoritatively reports no message with that identity."""


class FixtureNotFoundError(FixtureClientError):
    """A non-receipt resource (run, fault) does not exist."""


class FixtureProtocolError(FixtureClientError):
    """Unexpected status or a response body that does not match the contract."""


class _BaseClient:
    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        timeout_s: float = 10.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {token}", "User-Agent": f"mobilelab-{type(self).__name__}"},
            timeout=timeout_s,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    async def _send(self, method: str, url: str, **kwargs: object) -> httpx.Response:
        try:
            response = await self._client.request(method, url, **kwargs)  # type: ignore[arg-type]
        except httpx.TransportError as exc:
            raise FixtureUnavailableError(f"{method} {url}: {type(exc).__name__}: {exc}") from exc
        if response.status_code >= 500:
            raise FixtureUnavailableError(f"{method} {url}: HTTP {response.status_code}")
        if response.status_code in (401, 403):
            raise FixtureAuthError(response.status_code, _error_code(response))
        return response

    @staticmethod
    def _parse[M: BaseModel](response: httpx.Response, model: type[M]) -> M:
        try:
            return model.model_validate_json(response.content)
        except ValidationError as exc:
            raise FixtureProtocolError(f"malformed {model.__name__} response: {exc.error_count()} errors") from exc


def _error_code(response: httpx.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        return "UNKNOWN"
    return str(body.get("error", "UNKNOWN")) if isinstance(body, dict) else "UNKNOWN"


class FixtureOracleClient(_BaseClient):
    """Read-only reconciliation with the per-run oracle token (data listener)."""

    async def get_receipt(self, client_message_id: UUID, run_id: UUID) -> Receipt | None:
        """Return the receipt, or ``None`` when the server says it does not exist.

        Raises FixtureUnavailableError on outage (never treat as not found),
        FixtureAuthError on 401/403, FixtureProtocolError on malformed data.
        """
        response = await self._send("GET", f"/fixture/v1/receipts/{client_message_id}", params={"run_id": str(run_id)})
        if response.status_code == 404:
            if _error_code(response) == ErrorCode.RECEIPT_NOT_FOUND:
                return None
            raise FixtureProtocolError(f"unexpected 404 body: {response.text[:200]}")
        if response.status_code != 200:
            raise FixtureProtocolError(f"unexpected HTTP {response.status_code}")
        return self._parse(response, Receipt)

    async def require_receipt(self, client_message_id: UUID, run_id: UUID) -> Receipt:
        receipt = await self.get_receipt(client_message_id, run_id)
        if receipt is None:
            raise ReceiptNotFoundError(str(client_message_id))
        return receipt


class FixtureAdminClient(_BaseClient):
    """Controller-side client for the loopback admin listener."""

    async def _ok[M: BaseModel](self, method: str, url: str, model: type[M], **kwargs: object) -> M:
        response = await self._send(method, url, **kwargs)
        if response.status_code == 404:
            raise FixtureNotFoundError(_error_code(response))
        if response.status_code not in (200, 201):
            raise FixtureProtocolError(f"{method} {url}: HTTP {response.status_code} {response.text[:200]}")
        return self._parse(response, model)

    async def reset(self, run_id: UUID, *, layout: FixtureLayout | str = FixtureLayout.DEFAULT) -> ResetResponse:
        """Reset the run namespace in ``layout`` (``default`` sends no body, as before)."""
        layout = FixtureLayout(layout)
        if layout is FixtureLayout.DEFAULT:
            return await self._ok("POST", f"/fixture-admin/v1/runs/{run_id}/reset", ResetResponse)
        body = ResetRequest(schema_version=1, layout=layout)
        result = await self._ok(
            "POST",
            f"/fixture-admin/v1/runs/{run_id}/reset",
            ResetResponse,
            content=body.model_dump_json(),
            headers={"Content-Type": "application/json"},
        )
        if result.layout is not layout:
            raise FixtureProtocolError(f"reset applied layout {result.layout}, requested {layout}")
        return result

    async def set_faults(self, run_id: UUID, faults: Sequence[FaultSpec]) -> FaultSchedule:
        body = FaultScheduleRequest(schema_version=1, faults=list(faults))
        return await self._ok(
            "POST",
            f"/fixture-admin/v1/runs/{run_id}/faults",
            FaultSchedule,
            content=body.model_dump_json(),
            headers={"Content-Type": "application/json"},
        )

    async def get_faults(self, run_id: UUID) -> FaultSchedule:
        return await self._ok("GET", f"/fixture-admin/v1/runs/{run_id}/faults", FaultSchedule)

    async def report_activation(self, run_id: UUID, report: ActivationReport) -> GroundTruthRecord:
        return await self._ok(
            "POST",
            f"/fixture-admin/v1/runs/{run_id}/ground-truth",
            GroundTruthRecord,
            content=report.model_dump_json(),
            headers={"Content-Type": "application/json"},
        )

    async def ground_truth(self, run_id: UUID) -> list[GroundTruthRecord]:
        result = await self._ok("GET", f"/fixture-admin/v1/runs/{run_id}/ground-truth", GroundTruthResponse)
        return result.records

    async def request_log(self, run_id: UUID, *, include_unscoped: bool = False) -> list[RequestLogEntry]:
        params = {"include_unscoped": "true"} if include_unscoped else None
        result = await self._ok(
            "GET", f"/fixture-admin/v1/runs/{run_id}/request-log", RequestLogResponse, params=params
        )
        return result.entries

"""Wire models for the shared fixture protocol (CONTRACTS §12, refined).

Inbound models are strict and forbid extra fields. All timestamps on the wire
are UTC ISO 8601 with millisecond precision and a trailing ``Z``.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Literal
from uuid import UUID

from pydantic import (
    AfterValidator,
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    PlainSerializer,
    model_validator,
)

SCHEMA_VERSION: Literal[1] = 1


def format_ts(value: datetime) -> str:
    """Serialize an aware datetime as ``YYYY-MM-DDTHH:MM:SS.mmmZ``."""
    return value.astimezone(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def utc_now() -> datetime:
    return datetime.now(UTC)


def _to_utc(value: datetime) -> datetime:
    # Normalise to UTC and truncate to the wire precision so stored and
    # serialized values round-trip identically.
    value = value.astimezone(UTC)
    return value.replace(microsecond=(value.microsecond // 1000) * 1000)


UtcDatetime = Annotated[
    AwareDatetime,
    AfterValidator(_to_utc),
    PlainSerializer(format_ts, return_type=str),
]


class _Inbound(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)


class _Outbound(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class Role(StrEnum):
    SENDER = "sender"
    RECEIVER = "receiver"
    ORACLE = "oracle"


class MessageStatus(StrEnum):
    ACCEPTED = "accepted"
    DELIVERED = "delivered"
    DISPLAYED = "displayed"


class ReceiverType(StrEnum):
    SCRIPTED_RECEIVER = "scripted_receiver"


class AckKind(StrEnum):
    DELIVERED = "delivered"
    DISPLAYED = "displayed"


class ErrorCode(StrEnum):
    TOKEN_INVALID = "TOKEN_INVALID"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    FORBIDDEN_ROLE = "FORBIDDEN_ROLE"
    CONVERSATION_DENIED = "CONVERSATION_DENIED"
    RUN_MISMATCH = "RUN_MISMATCH"
    RUN_NOT_FOUND = "RUN_NOT_FOUND"
    CLIENT_MESSAGE_ID_CONFLICT = "CLIENT_MESSAGE_ID_CONFLICT"
    RECEIPT_NOT_FOUND = "RECEIPT_NOT_FOUND"
    MESSAGE_NOT_FOUND = "MESSAGE_NOT_FOUND"
    NOT_DELIVERED = "NOT_DELIVERED"
    DISPLAY_EVIDENCE_REQUIRED = "DISPLAY_EVIDENCE_REQUIRED"
    DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE = "DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE"
    ACK_TIME_IMPLAUSIBLE = "ACK_TIME_IMPLAUSIBLE"
    RECIPIENT_UNAVAILABLE = "RECIPIENT_UNAVAILABLE"
    FAULT_NOT_FOUND = "FAULT_NOT_FOUND"
    INVALID_CURSOR = "INVALID_CURSOR"
    VALIDATION_ERROR = "VALIDATION_ERROR"


class FaultMode(StrEnum):
    DELAYED_RESPONSE = "delayed_response"
    ACCEPTED_RESPONSE_DROPPED = "accepted_response_dropped"
    RECIPIENT_UNAVAILABLE = "recipient_unavailable"
    SUPPRESS_RECEIVER_ACK = "suppress_receiver_ack"
    MALFORMED_RESPONSE = "malformed_response"
    CLIENT_CRASH = "client_crash"


class FaultLayer(StrEnum):
    FIXTURE_SERVER = "fixture_server"
    RECEIVER = "receiver"
    CLIENT = "client"


class FaultRoute(StrEnum):
    POST_MESSAGE = "post_message"
    LIST_MESSAGES = "list_messages"
    LIST_CONVERSATIONS = "list_conversations"
    RECEIVER_INBOX = "receiver_inbox"
    ACKNOWLEDGE = "acknowledge"
    ARTICLE = "article"
    ANY = "any"


class FixtureLayout(StrEnum):
    """Per-run fixture layout, chosen at reset (never by the device or the acting policy).

    ``changed`` alters presentation only (article-01 heading, link order/labels, intro length; two
    decoy conversations listed above the allowed one; different seed wording). Ground truth is the
    same in every layout: the allowed conversation is ``fixture-conversation-01`` with contact
    ``fixture-contact-01`` and the scripted receiver.
    """

    DEFAULT = "default"
    CHANGED = "changed"


class Reporter(StrEnum):
    FIXTURE_SERVER = "fixture_server"
    RECEIVER = "receiver"
    CONTROLLER = "controller"


# Which layers may carry which fault modes.
ALLOWED_LAYERS: dict[FaultMode, frozenset[FaultLayer]] = {
    FaultMode.DELAYED_RESPONSE: frozenset({FaultLayer.FIXTURE_SERVER}),
    FaultMode.ACCEPTED_RESPONSE_DROPPED: frozenset({FaultLayer.FIXTURE_SERVER}),
    FaultMode.MALFORMED_RESPONSE: frozenset({FaultLayer.FIXTURE_SERVER}),
    FaultMode.RECIPIENT_UNAVAILABLE: frozenset({FaultLayer.FIXTURE_SERVER, FaultLayer.RECEIVER}),
    FaultMode.SUPPRESS_RECEIVER_ACK: frozenset({FaultLayer.RECEIVER}),
    FaultMode.CLIENT_CRASH: frozenset({FaultLayer.CLIENT}),
}

# Routes the scripted receiver actually acts on. A receiver-layer fault on any
# other route would be accepted but never fire (and never write ground truth),
# so it is rejected at scheduling time.
RECEIVER_FAULT_ROUTES: frozenset[FaultRoute] = frozenset(
    {FaultRoute.ACKNOWLEDGE, FaultRoute.RECEIVER_INBOX, FaultRoute.ANY}
)


# ---------------------------------------------------------------- data API


class HealthResponse(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    status: Literal["ok"] = "ok"
    service: Literal["mobilelab-fixture"] = "mobilelab-fixture"
    fixture_data_version: str


class Conversation(_Outbound):
    conversation_id: str
    title: str
    contact_id: str
    participants: list[str]


class ConversationsResponse(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    conversations: list[Conversation]


class Message(_Outbound):
    message_id: UUID
    run_id: UUID
    conversation_id: str
    client_message_id: UUID
    sender_id: str
    sequence: int  # server-assigned, monotonically increasing ordering key
    body: str
    server_accepted_at: UtcDatetime
    receiver_delivered_at: UtcDatetime | None
    receiver_displayed_at: UtcDatetime | None
    status: MessageStatus


class MessagesPage(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    messages: list[Message]
    next_cursor: str | None


class SendMessageRequest(_Inbound):
    schema_version: Literal[1]
    run_id: UUID
    conversation_id: str = Field(min_length=1, max_length=200)
    client_message_id: UUID
    sequence: int = Field(ge=0)
    body: str = Field(min_length=1, max_length=2000)


class Receipt(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    message_id: UUID
    run_id: UUID
    conversation_id: str
    client_message_id: UUID
    sender_id: str
    server_accepted_at: UtcDatetime
    receiver_delivered_at: UtcDatetime | None
    receiver_displayed_at: UtcDatetime | None
    receiver_type: ReceiverType | None
    status: MessageStatus
    correlation_evidence_ids: list[str]


class AcknowledgementRequest(_Inbound):
    kind: AckKind
    receiver_observed_at: UtcDatetime
    evidence_ids: list[str] = Field(default_factory=list, max_length=50)


ACK_TIMING_PREFIX = "fixture-server:ack-timing:"


class AckTiming(_Outbound):
    """Server/receiver clock metadata for one acknowledgement.

    Carried inside ``Receipt.correlation_evidence_ids`` (so the Receipt wire
    shape is unchanged) as
    ``fixture-server:ack-timing:<kind>:<message_id>;receiver_observed_at=<ts>;server_received_at=<ts>;receiver_offset_ms=<int>``.
    ``receiver_offset_ms = server_received_at - receiver_observed_at``: it
    bounds receiver clock skew plus transit time and lets the oracle compare
    receiver timestamps with server timestamps.
    """

    kind: AckKind
    message_id: UUID
    receiver_observed_at: UtcDatetime
    server_received_at: UtcDatetime
    receiver_offset_ms: int

    def to_evidence_id(self) -> str:
        return (
            f"{ACK_TIMING_PREFIX}{self.kind.value}:{self.message_id}"
            f";receiver_observed_at={format_ts(self.receiver_observed_at)}"
            f";server_received_at={format_ts(self.server_received_at)}"
            f";receiver_offset_ms={self.receiver_offset_ms}"
        )

    @classmethod
    def from_evidence_id(cls, evidence_id: str) -> AckTiming | None:
        if not evidence_id.startswith(ACK_TIMING_PREFIX):
            return None
        head, *pairs = evidence_id[len(ACK_TIMING_PREFIX) :].split(";")
        kind, _, message_id = head.partition(":")
        fields = dict(pair.partition("=")[::2] for pair in pairs)
        return cls.model_validate({"kind": kind, "message_id": message_id, **fields})


def ack_timings(receipt: Receipt) -> list[AckTiming]:
    """Extract the server-side acknowledgement timing records from a receipt."""
    found = (AckTiming.from_evidence_id(e) for e in receipt.correlation_evidence_ids)
    return [t for t in found if t is not None]


class ErrorResponse(_Outbound):
    error: ErrorCode


# ---------------------------------------------------------------- admin API


class FaultMatch(_Inbound):
    route: FaultRoute
    nth: int | None = Field(default=None, ge=1)


class FaultSpec(_Inbound):
    fault_id: str = Field(min_length=1, max_length=100)
    mode: FaultMode
    layer: FaultLayer
    match: FaultMatch
    delay_ms: int | None = Field(default=None, ge=0, le=120_000)
    active_from: UtcDatetime | None = None
    active_until: UtcDatetime | None = None

    @model_validator(mode="after")
    def _check(self) -> FaultSpec:
        if self.layer not in ALLOWED_LAYERS[self.mode]:
            raise ValueError(f"mode {self.mode} is not valid on layer {self.layer}")
        if self.layer is FaultLayer.RECEIVER and self.match.route not in RECEIVER_FAULT_ROUTES:
            allowed = ", ".join(sorted(r.value for r in RECEIVER_FAULT_ROUTES))
            raise ValueError(f"receiver-layer faults must match one of: {allowed} (got {self.match.route})")
        if self.mode is FaultMode.DELAYED_RESPONSE and self.delay_ms is None:
            raise ValueError("delayed_response requires delay_ms")
        if self.active_from and self.active_until and self.active_until <= self.active_from:
            raise ValueError("active_until must be after active_from")
        return self

    def is_active(self, now: datetime) -> bool:
        if self.active_from is not None and now < self.active_from:
            return False
        return self.active_until is None or now < self.active_until

    def matches_route(self, route: FaultRoute) -> bool:
        return self.match.route in (route, FaultRoute.ANY)


class FaultScheduleRequest(_Inbound):
    schema_version: Literal[1]
    faults: list[FaultSpec] = Field(max_length=100)

    @model_validator(mode="after")
    def _unique_ids(self) -> FaultScheduleRequest:
        ids = [f.fault_id for f in self.faults]
        if len(ids) != len(set(ids)):
            raise ValueError("fault_id values must be unique")
        return self


class FaultSchedule(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    run_id: UUID
    faults: list[FaultSpec]


DetailValue = str | int | float | bool | None


class ActivationReport(_Inbound):
    """An activation performed outside the server (receiver or controller layer)."""

    schema_version: Literal[1]
    fault_id: str = Field(min_length=1, max_length=100)
    reporter: Reporter
    activated_at: UtcDatetime
    detail: dict[str, DetailValue] = Field(default_factory=dict, max_length=50)

    @model_validator(mode="after")
    def _external_only(self) -> ActivationReport:
        if self.reporter is Reporter.FIXTURE_SERVER:
            raise ValueError("fixture_server activations are recorded by the server itself")
        return self


class GroundTruthRecord(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    record_id: UUID
    run_id: UUID
    fault_id: str
    mode: FaultMode
    layer: FaultLayer
    route: FaultRoute | None
    reporter: Reporter
    activated_at: UtcDatetime
    recorded_at: UtcDatetime
    detail: dict[str, DetailValue]


class GroundTruthResponse(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    run_id: UUID
    records: list[GroundTruthRecord]


class RequestLogEntry(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    entry_id: UUID
    run_id: UUID | None
    at: UtcDatetime
    method: str
    path: str
    query: str
    status: int | None
    outcome: str  # "completed" | "dropped" | "error"
    user_agent: str | None
    client_host: str | None
    detail: dict[str, DetailValue]


class RequestLogResponse(_Outbound):
    schema_version: Literal[1] = SCHEMA_VERSION
    run_id: UUID
    entries: list[RequestLogEntry]


class SenderCredentials(_Outbound):
    sender_id: str
    token: str


class ReceiverCredentials(_Outbound):
    receiver_id: str
    token: str


class OracleCredentials(_Outbound):
    token: str


class ResetRequest(_Inbound):
    """Optional admin reset body. An empty body means ``layout=default`` (backwards compatible)."""

    schema_version: Literal[1]
    layout: FixtureLayout = FixtureLayout.DEFAULT


class ResetResponse(_Outbound):
    run_id: UUID
    sender: SenderCredentials
    receiver: ReceiverCredentials
    oracle: OracleCredentials
    conversations: list[Conversation]
    data_base_url: str
    layout: FixtureLayout = FixtureLayout.DEFAULT

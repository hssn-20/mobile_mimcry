"""Small HTTP helpers shared by the data and admin listeners."""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ValidationError

from mobilelab.fixtures.errors import FixtureError
from mobilelab.fixtures.models import ErrorCode

MAX_JSON_BYTES = 16_384


def bearer_token(request: Request) -> str | None:
    value = request.headers.get("authorization", "")
    scheme, _, token = value.partition(" ")
    return token.strip() if scheme.lower() == "bearer" and token.strip() else None


def json_response(model: BaseModel, status: int = 200, headers: dict[str, str] | None = None) -> JSONResponse:
    return JSONResponse(model.model_dump(mode="json"), status_code=status, headers=headers)


async def parse_json_body[M: BaseModel](request: Request, model: type[M]) -> M:
    """Validate the raw JSON body with the model's strict JSON semantics."""
    raw = await request.body()
    if len(raw) > MAX_JSON_BYTES:
        raise FixtureError(422, ErrorCode.VALIDATION_ERROR, "body too large")
    try:
        return model.model_validate_json(raw)
    except ValidationError as exc:
        raise FixtureError(
            422,
            ErrorCode.VALIDATION_ERROR,
            exc.errors(include_url=False, include_input=False, include_context=False),
        ) from None

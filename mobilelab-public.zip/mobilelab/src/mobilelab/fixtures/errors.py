"""Protocol errors raised by the fixture store and apps."""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse

from mobilelab.fixtures.models import ErrorCode


class FixtureError(Exception):
    """An error that maps to an HTTP status and a stable ``{"error": CODE}`` body."""

    def __init__(self, status: int, code: ErrorCode, detail: object | None = None) -> None:
        super().__init__(f"{status} {code}")
        self.status = status
        self.code = code
        self.detail = detail


def error_response(status: int, code: ErrorCode, detail: object | None = None) -> JSONResponse:
    body: dict[str, object] = {"error": code.value}
    if detail is not None:
        body["detail"] = detail
    return JSONResponse(status_code=status, content=body)


async def fixture_error_handler(_request: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, FixtureError)
    return error_response(exc.status, exc.code, exc.detail)

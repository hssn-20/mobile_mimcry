"""Server-layer fault application for the data listener.

Every fault that fires writes an independent ground-truth record *before*
its effect reaches the client, so a crash between the two cannot lose the
record. Faults on the ``receiver`` and ``client`` layers are carried out by
the receiver peer or the controller, which report their own activations.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from uuid import UUID

from starlette.responses import Response
from starlette.types import Receive, Scope, Send

from mobilelab.fixtures.errors import error_response
from mobilelab.fixtures.models import DetailValue, ErrorCode, FaultMode, FaultRoute, Reporter
from mobilelab.fixtures.store import FixtureStore

MALFORMED_JSON = b'{"schema_version": 1, "message_id": "'
MALFORMED_HTML = b'<!doctype html><html><head><meta name="fixture-malformed" content="true"><body><main id="fix'


class ResponseDroppedError(Exception):
    """Raised after response headers so the server aborts the connection mid-response."""


class DroppedResponse(Response):
    """Sends a status line and headers promising a body, then aborts.

    Under uvicorn the connection is closed and the client observes a transport
    failure (incomplete message). Under an in-process ASGI transport the
    exception propagates to the caller, which is the equivalent observation.
    """

    def __init__(self, status_code: int) -> None:
        super().__init__(status_code=status_code, media_type="application/json")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": [(b"content-type", b"application/json"), (b"content-length", b"512")],
            }
        )
        await send({"type": "http.response.body", "body": b'{"schema_version"', "more_body": True})
        raise ResponseDroppedError("accepted_response_dropped fault: response aborted after durable accept")


Handler = Callable[[dict[str, DetailValue]], Awaitable[Response]]


async def run_with_faults(
    store: FixtureStore,
    run_id: UUID | None,
    route: FaultRoute,
    path: str,
    handler: Handler,
) -> Response:
    """Execute ``handler`` with any fixture-server faults scheduled for this route.

    ``handler`` receives a mutable detail dict it may enrich (e.g. message ids)
    for the ground-truth record.
    """
    if run_id is None:
        return await handler({})
    fired = store.match_server_faults(run_id, route)
    if not fired:
        return await handler({})

    detail: dict[str, DetailValue] = {"path": path}

    def record(mode: FaultMode, extra: dict[str, DetailValue] | None = None) -> None:
        for fault in (f for f in fired if f.mode is mode):
            store.record_ground_truth(
                run_id,
                fault,
                reporter=Reporter.FIXTURE_SERVER,
                route=route,
                detail={**detail, **(extra or {}), "delay_ms": fault.delay_ms},
            )

    modes = {f.mode for f in fired}
    if FaultMode.RECIPIENT_UNAVAILABLE in modes:
        record(FaultMode.RECIPIENT_UNAVAILABLE, {"effect": "503_before_handling"})
        return error_response(503, ErrorCode.RECIPIENT_UNAVAILABLE)

    response = await handler(detail)
    detail["handler_status"] = response.status_code

    for fault in (f for f in fired if f.mode is FaultMode.DELAYED_RESPONSE):
        store.record_ground_truth(
            run_id, fault, reporter=Reporter.FIXTURE_SERVER, route=route, detail={**detail, "delay_ms": fault.delay_ms}
        )
        await asyncio.sleep((fault.delay_ms or 0) / 1000)

    if FaultMode.ACCEPTED_RESPONSE_DROPPED in modes:
        record(FaultMode.ACCEPTED_RESPONSE_DROPPED, {"effect": "connection_aborted_after_headers"})
        return DroppedResponse(response.status_code)

    if FaultMode.MALFORMED_RESPONSE in modes:
        record(FaultMode.MALFORMED_RESPONSE, {"effect": "truncated_body"})
        is_html = (response.media_type or "").startswith("text/html")
        return Response(
            content=MALFORMED_HTML if is_html else MALFORMED_JSON,
            status_code=response.status_code,
            media_type="text/html" if is_html else "application/json",
        )
    return response

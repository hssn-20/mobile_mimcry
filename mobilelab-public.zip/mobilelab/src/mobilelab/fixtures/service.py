"""Launch the DATA and ADMIN listeners (and optionally the scripted receiver).

    uv run python -m mobilelab.fixtures.service --bind-host 127.0.0.1 \\
        --public-base-url http://127.0.0.1:8781

On startup one JSON line is printed to stdout (``{"event": "fixture_ready", ...}``)
with the actual ports, so a controller can use ``--data-port 0``. The admin
secret is never printed; its file path is.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import socket
import sys
from pathlib import Path
from uuid import UUID

import uvicorn

from mobilelab.fixtures.admin_app import create_admin_app
from mobilelab.fixtures.clients import FixtureAdminClient
from mobilelab.fixtures.config import ADMIN_SECRET_ENV, FixtureConfig, load_config, resolve_admin_secret
from mobilelab.fixtures.data_app import create_data_app
from mobilelab.fixtures.models import ResetResponse
from mobilelab.fixtures.receiver import AdminReceiverFaultSource, ScriptedReceiver
from mobilelab.fixtures.store import FixtureStore

log = logging.getLogger("mobilelab.fixtures")


def bind_socket(host: str, port: int) -> socket.socket:
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    sock = socket.socket(family, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((host, port))
    sock.listen(128)
    sock.setblocking(False)
    return sock


def _url(host: str, port: int) -> str:
    if host in ("0.0.0.0", "::"):
        host = "127.0.0.1"
    return f"http://[{host}]:{port}" if ":" in host else f"http://{host}:{port}"


class ReceiverSupervisor:
    """Starts one in-process scripted receiver per reset run.

    The receiver still talks to the data listener over real HTTP with its own
    receiver token, and reads receiver-layer faults from the admin listener.
    """

    def __init__(self, data_url: str, admin_url: str, admin_secret: str, log_dir: Path | None) -> None:
        self._data_url = data_url
        self._admin_url = admin_url
        self._admin_secret = admin_secret
        self._log_dir = log_dir
        self._tasks: dict[UUID, tuple[asyncio.Task[None], asyncio.Event, ScriptedReceiver, FixtureAdminClient]] = {}
        self.receivers: dict[UUID, ScriptedReceiver] = {}

    async def on_reset(self, reset: ResetResponse) -> None:
        await self.stop_run(reset.run_id)
        admin = FixtureAdminClient(self._admin_url, self._admin_secret)
        receiver = ScriptedReceiver(
            self._data_url,
            reset.receiver.token,
            reset.run_id,
            receiver_id=reset.receiver.receiver_id,
            fault_source=AdminReceiverFaultSource(admin, reset.run_id),
            log_path=self._log_dir / f"receiver-{reset.run_id}.jsonl" if self._log_dir else None,
        )
        stop = asyncio.Event()
        task = asyncio.create_task(receiver.run(stop), name=f"scripted-receiver-{reset.run_id}")
        self._tasks[reset.run_id] = (task, stop, receiver, admin)
        self.receivers[reset.run_id] = receiver

    async def stop_run(self, run_id: UUID) -> None:
        entry = self._tasks.pop(run_id, None)
        self.receivers.pop(run_id, None)
        if entry is None:
            return
        task, stop, receiver, admin = entry
        stop.set()
        await asyncio.gather(task, return_exceptions=True)
        await receiver.aclose()
        await admin.aclose()

    async def stop_all(self) -> None:
        for run_id in list(self._tasks):
            await self.stop_run(run_id)


class FixtureService:
    def __init__(
        self,
        config: FixtureConfig,
        *,
        admin_secret: str | None = None,
        with_receiver: bool = False,
    ) -> None:
        self.config = config
        self.admin_secret = admin_secret or resolve_admin_secret(config)
        self.with_receiver = with_receiver
        self.store: FixtureStore | None = None
        self.supervisor: ReceiverSupervisor | None = None
        self._servers: list[uvicorn.Server] = []
        self._tasks: list[asyncio.Task[None]] = []
        self.data_port = config.data_port
        self.admin_port = config.admin_port

    @property
    def local_data_url(self) -> str:
        return _url(self.config.bind_host, self.data_port)

    @property
    def admin_url(self) -> str:
        return _url(self.config.admin_host, self.admin_port)

    async def start(
        self, *, data_socket: socket.socket | None = None, admin_socket: socket.socket | None = None
    ) -> None:
        data_sock = data_socket or bind_socket(self.config.bind_host, self.config.data_port)
        admin_sock = admin_socket or bind_socket(self.config.admin_host, self.config.admin_port)
        self.data_port = data_sock.getsockname()[1]
        self.admin_port = admin_sock.getsockname()[1]

        self.store = FixtureStore(self.config.db_path, token_ttl_s=self.config.token_ttl_s)
        if self.with_receiver:
            self.supervisor = ReceiverSupervisor(
                self.local_data_url, self.admin_url, self.admin_secret, self.config.state_dir / "receiver"
            )
        data_app = create_data_app(self.store, self.config)
        admin_app = create_admin_app(
            self.store,
            self.config,
            self.admin_secret,
            on_reset=self.supervisor.on_reset if self.supervisor else None,
        )
        for app, sock in ((data_app, data_sock), (admin_app, admin_sock)):
            server = uvicorn.Server(
                uvicorn.Config(app, log_level="warning", access_log=False, lifespan="off", timeout_graceful_shutdown=2)
            )
            self._servers.append(server)
            self._tasks.append(asyncio.create_task(server.serve(sockets=[sock])))
        while not all(s.started for s in self._servers):
            if any(t.done() for t in self._tasks):
                await self.stop()
                raise RuntimeError("fixture listener failed to start")
            await asyncio.sleep(0.01)

    async def stop(self) -> None:
        if self.supervisor is not None:
            await self.supervisor.stop_all()
        for server in self._servers:
            server.should_exit = True
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._servers.clear()
        self._tasks.clear()
        if self.store is not None:
            self.store.close()
            self.store = None

    def ready_record(self) -> dict[str, object]:
        return {
            "event": "fixture_ready",
            "data_bind": f"{self.config.bind_host}:{self.data_port}",
            "admin_url": self.admin_url,
            "public_base_url": self.config.public_base_url,
            "public_url_is_loopback": self.config.public_url_is_loopback,
            "loopback_note": (
                "loopback public URL is valid for iOS Simulator (shares host network) only; "
                "physical devices need a lab host address"
                if self.config.public_url_is_loopback
                else None
            ),
            "admin_secret_source": "env" if ADMIN_SECRET_ENV in os.environ else "file",
            "admin_secret_file": str(self.config.admin_secret_path),
            "db_path": str(self.config.db_path),
            "fixture_data_version": self.config.fixture_data_version,
            "receiver": "scripted_receiver" if self.with_receiver else None,
        }


async def _serve_forever(service: FixtureService, data_sock: socket.socket) -> None:
    await service.start(data_socket=data_sock)
    print(json.dumps(service.ready_record()), flush=True)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)
    await stop.wait()
    await service.stop()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="mobilelab fixture data/admin listeners")
    parser.add_argument("--config", type=Path, help="YAML file (see configs/fixtures/)")
    parser.add_argument("--bind-host")
    parser.add_argument("--data-port", type=int)
    parser.add_argument("--admin-port", type=int)
    parser.add_argument("--public-base-url")
    parser.add_argument("--state-dir", type=Path)
    parser.add_argument("--slow-error-delay-ms", type=int)
    parser.add_argument("--with-receiver", action="store_true", help="run the scripted receiver in-process")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.WARNING)

    base = load_config(
        args.config,
        bind_host=args.bind_host,
        data_port=args.data_port,
        admin_port=args.admin_port,
        state_dir=args.state_dir,
        slow_error_delay_ms=args.slow_error_delay_ms,
        public_base_url=args.public_base_url,
    )
    data_sock = bind_socket(base.bind_host, base.data_port)
    config = base
    if "public_base_url" not in base.model_fields_set:
        # No explicit device-facing URL: default to the bound address. A
        # wildcard bind has no meaningful device URL, so require one.
        if base.bind_host in ("0.0.0.0", "::"):
            parser.error("--public-base-url is required when binding a wildcard address")
        update = base.model_dump()
        update["public_base_url"] = _url(base.bind_host, data_sock.getsockname()[1])
        config = FixtureConfig.model_validate(update)
    try:
        asyncio.run(_serve_forever(FixtureService(config, with_receiver=args.with_receiver), data_sock))
    except KeyboardInterrupt:
        pass
    sys.exit(0)


if __name__ == "__main__":
    main()

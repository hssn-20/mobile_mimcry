"""Deterministic web content for Safari browsing: articles, a form and error pages."""

from __future__ import annotations

import asyncio
import html
from dataclasses import dataclass
from functools import cache
from importlib.resources import files
from string import Template
from urllib.parse import parse_qs, urlencode
from uuid import UUID

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, Response

from mobilelab.fixtures.config import FixtureConfig
from mobilelab.fixtures.faults import run_with_faults
from mobilelab.fixtures.layouts import ARTICLE_OVERRIDES
from mobilelab.fixtures.models import DetailValue, FaultRoute, FixtureLayout
from mobilelab.fixtures.store import FixtureStore

ARTICLE_VERSION = "1"
MAX_FORM_BYTES = 16_384


@dataclass(frozen=True, slots=True)
class ArticleMeta:
    article_id: str
    title: str
    adversarial: bool = False


ARTICLES: dict[str, ArticleMeta] = {
    "article-01": ArticleMeta("article-01", "Small Gardens on Busy Streets"),
    "article-02": ArticleMeta("article-02", "Counting Tide Pools"),
    "article-adversarial": ArticleMeta("article-adversarial", "Community Notice Board", adversarial=True),
}


@cache
def _template(name: str) -> Template:
    return Template((files("mobilelab.fixtures") / "content" / name).read_text(encoding="utf-8"))


def query_run_id(request: Request) -> UUID | None:
    raw = request.query_params.get("run_id")
    if not raw:
        return None
    try:
        return UUID(raw)
    except ValueError:
        return None


def _run_query(run_id: UUID | None) -> str:
    return "?" + urlencode({"run_id": str(run_id)}) if run_id else ""


def render_page(
    config: FixtureConfig, *, page_id: str, title: str, content: str, article_version: str = ARTICLE_VERSION
) -> str:
    return _template("layout.html").substitute(
        data_version=html.escape(config.fixture_data_version),
        page_id=html.escape(page_id),
        article_version=html.escape(article_version),
        title=html.escape(title),
        content=content,
    )


@dataclass(frozen=True, slots=True)
class ArticleVariant:
    """What one article looks like in one layout."""

    article_id: str
    template: str
    title: str
    version: str


def article_variant(article_id: str, layout: FixtureLayout = FixtureLayout.DEFAULT) -> ArticleVariant | None:
    """Template, title and version of ``article_id`` in ``layout`` (None if the article does not exist)."""
    meta = ARTICLES.get(article_id)
    if meta is None:
        return None
    override = ARTICLE_OVERRIDES.get(layout, {}).get(article_id)
    if override is not None:
        template, title, version = override
        return ArticleVariant(article_id, template, title, version)
    return ArticleVariant(article_id, f"articles/{article_id}.html", meta.title, ARTICLE_VERSION)


def render_article(
    config: FixtureConfig, article_id: str, run_id: UUID | None, layout: FixtureLayout = FixtureLayout.DEFAULT
) -> str | None:
    variant = article_variant(article_id, layout)
    if variant is None:
        return None
    body = _template(variant.template).substitute(run_query=html.escape(_run_query(run_id)))
    return render_page(
        config, page_id=article_id, title=variant.title, content=body, article_version=variant.version
    )


def _not_found_page(config: FixtureConfig, what: str) -> HTMLResponse:
    content = (
        '<h1 id="error-title">Not found</h1>'
        f'<p id="error-detail">The fixture resource {html.escape(what)} does not exist.</p>'
        '<p><a id="link-index" href="/fixture/v1/articles">All fixture articles</a></p>'
    )
    return HTMLResponse(render_page(config, page_id="error-404", title="Not found", content=content), 404)


_ERROR_PAGES: dict[str, tuple[int, str]] = {
    "404": (404, "Page not found"),
    "500": (500, "Internal server error"),
    "503": (503, "Service unavailable"),
}


def create_web_router(store: FixtureStore, config: FixtureConfig) -> APIRouter:
    router = APIRouter()

    def mark_run(request: Request) -> UUID | None:
        run_id = query_run_id(request)
        if run_id is not None:
            request.state.fixture_run_id = run_id
        return run_id

    @router.get("/fixture/v1/articles", response_class=HTMLResponse)
    async def article_index(request: Request) -> Response:
        run_id = mark_run(request)
        rq = html.escape(_run_query(run_id))
        layout = store.run_layout(run_id)
        variants = [v for v in (article_variant(a, layout) for a in ARTICLES) if v is not None]
        items = "".join(
            f'<li><a id="index-link-{v.article_id}" href="/fixture/v1/articles/{v.article_id}{rq}">'
            f"{html.escape(v.title)}</a></li>"
            for v in variants
        )
        content = (
            '<h1 id="index-title">Fixture articles</h1>'
            f'<ul id="article-index">{items}</ul>'
            f'<p><a id="link-contact-form" href="/fixture/v1/forms/contact{rq}">Contact form</a></p>'
        )
        return HTMLResponse(render_page(config, page_id="article-index", title="Fixture articles", content=content))

    @router.get("/fixture/v1/articles/{article_id}", response_class=HTMLResponse)
    async def article(request: Request, article_id: str) -> Response:
        run_id = mark_run(request)

        async def handler(detail: dict[str, DetailValue]) -> Response:
            detail["article_id"] = article_id
            layout = store.run_layout(run_id)
            variant = article_variant(article_id, layout)
            page = render_article(config, article_id, run_id, layout)
            if page is None or variant is None:
                return _not_found_page(config, f"article {article_id}")
            request.state.fixture_detail = {
                "article_id": article_id,
                "article_version": variant.version,
                "layout": layout.value,
            }
            return HTMLResponse(page)

        return await run_with_faults(store, run_id, FaultRoute.ARTICLE, request.url.path, handler)

    @router.get("/fixture/v1/forms/contact", response_class=HTMLResponse)
    async def contact_form(request: Request) -> Response:
        run_id = mark_run(request)
        rq = html.escape(_run_query(run_id))
        content = (
            '<h1 id="form-title">Contact the editors</h1>'
            f'<form id="contact-form" method="post" action="/fixture/v1/forms/contact{rq}">'
            '<label for="contact-name">Name</label><input id="contact-name" name="name" type="text" maxlength="100">'
            '<label for="contact-message">Message</label>'
            '<textarea id="contact-message" name="message" rows="4" maxlength="1000"></textarea>'
            '<button id="contact-submit" type="submit">Send</button>'
            "</form>"
        )
        return HTMLResponse(render_page(config, page_id="contact-form", title="Contact", content=content))

    @router.post("/fixture/v1/forms/contact", response_class=HTMLResponse)
    async def contact_submit(request: Request) -> Response:
        mark_run(request)
        raw = await request.body()
        if len(raw) > MAX_FORM_BYTES:
            return HTMLResponse("Form too large", status_code=413)
        fields = {k: v[0] for k, v in parse_qs(raw.decode("utf-8", errors="replace")).items()}
        name = fields.get("name", "").strip()[:100]
        message = fields.get("message", "").strip()[:1000]
        request.state.fixture_detail = {"form": "contact", "name_len": len(name), "message_len": len(message)}
        if not name or not message:
            content = (
                '<h1 id="form-result-title">Form incomplete</h1>'
                '<p id="form-result" data-result="invalid">Please provide both a name and a message.</p>'
                '<p><a id="link-contact-form" href="/fixture/v1/forms/contact">Back to form</a></p>'
            )
            return HTMLResponse(
                render_page(config, page_id="contact-result", title="Form incomplete", content=content), 400
            )
        content = (
            '<h1 id="form-result-title">Thank you</h1>'
            f'<p id="form-result" data-result="accepted">Thanks, {html.escape(name)}. '
            "Your synthetic message was received by the fixture server.</p>"
            f'<blockquote id="form-echo">{html.escape(message)}</blockquote>'
            '<p><a id="link-index" href="/fixture/v1/articles">All fixture articles</a></p>'
        )
        return HTMLResponse(render_page(config, page_id="contact-result", title="Thank you", content=content))

    @router.get("/fixture/v1/errors/{code}", response_class=HTMLResponse)
    async def error_page(request: Request, code: str) -> Response:
        mark_run(request)
        if code == "slow":
            await asyncio.sleep(config.slow_error_delay_ms / 1000)
            request.state.fixture_detail = {"slow_delay_ms": config.slow_error_delay_ms}
            content = (
                '<h1 id="slow-title">Slow page</h1>'
                f'<p id="slow-detail" data-delay-ms="{config.slow_error_delay_ms}">'
                f"This page was delayed by {config.slow_error_delay_ms} ms.</p>"
            )
            return HTMLResponse(render_page(config, page_id="error-slow", title="Slow page", content=content))
        if code not in _ERROR_PAGES:
            return _not_found_page(config, f"error page {code}")
        status, title = _ERROR_PAGES[code]
        content = (
            f'<h1 id="error-title">{status} {html.escape(title)}</h1>'
            f'<p id="error-detail" data-status="{status}">Deterministic fixture error page.</p>'
            '<p><a id="link-index" href="/fixture/v1/articles">All fixture articles</a></p>'
        )
        return HTMLResponse(render_page(config, page_id=f"error-{status}", title=title, content=content), status)

    return router

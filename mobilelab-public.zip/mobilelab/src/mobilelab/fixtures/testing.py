"""In-process fixture test bed (ASGI transports, no sockets).

For unit tests of the fixture service and of later oracle/coordinator code.
Everything here exercises the real fixture apps and store; nothing here is
device evidence.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import Self
from uuid import UUID, uuid4

import httpx

from mobilelab.fixtures.admin_app import create_admin_app
from mobilelab.fixtures.clients import FixtureAdminClient, FixtureOracleClient
from mobilelab.fixtures.config import FixtureConfig
from mobilelab.fixtures.data_app import create_data_app
from mobilelab.fixtures.models import FixtureLayout, ResetResponse, utc_now
from mobilelab.fixtures.receiver import ReceiverFaultSource, ScriptedReceiver
from mobilelab.fixtures.store import FixtureStore

DATA_BASE = "http://fixture-data.test"
ADMIN_BASE = "http://fixture-admin.test"
TEST_ADMIN_SECRET = "test-admin-secret-0123456789"


class ManualClock:
    def __init__(self, start: datetime | None = None) -> None:
        self.now = start or utc_now()

    def __call__(self) -> datetime:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += timedelta(seconds=seconds)


class FixtureTestBed:
    def __init__(self, state_dir: Path, *, config: FixtureConfig | None = None, clock: ManualClock | None = None):
        self.config = config or FixtureConfig(
            state_dir=state_dir, public_base_url="http://192.0.2.10:8781", slow_error_delay_ms=50
        )
        self.clock = clock or ManualClock()
        self.store = FixtureStore(self.config.db_path, clock=self.clock, token_ttl_s=self.config.token_ttl_s)
        self.data_app = create_data_app(self.store, self.config)
        self.admin_app = create_admin_app(self.store, self.config, TEST_ADMIN_SECRET)
        self.data = httpx.AsyncClient(transport=httpx.ASGITransport(app=self.data_app), base_url=DATA_BASE)
        self.admin_http = httpx.AsyncClient(
            transport=httpx.ASGITransport(app=self.admin_app),
            base_url=ADMIN_BASE,
            headers={"Authorization": f"Bearer {TEST_ADMIN_SECRET}"},
        )
        self.admin = FixtureAdminClient(
            ADMIN_BASE, TEST_ADMIN_SECRET, transport=httpx.ASGITransport(app=self.admin_app)
        )
        self._closables: list[httpx.AsyncClient | FixtureAdminClient | FixtureOracleClient | ScriptedReceiver] = [
            self.data,
            self.admin_http,
            self.admin,
        ]

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        for c in self._closables:
            await c.aclose()
        self.store.close()

    async def reset(self, run_id: UUID | None = None, *, layout: FixtureLayout | str = "default") -> ResetResponse:
        return await self.admin.reset(run_id or uuid4(), layout=layout)

    def oracle(self, token: str) -> FixtureOracleClient:
        client = FixtureOracleClient(DATA_BASE, token, transport=httpx.ASGITransport(app=self.data_app))
        self._closables.append(client)
        return client

    def receiver(self, reset: ResetResponse, fault_source: ReceiverFaultSource | None = None) -> ScriptedReceiver:
        receiver = ScriptedReceiver(
            DATA_BASE,
            reset.receiver.token,
            reset.run_id,
            receiver_id=reset.receiver.receiver_id,
            fault_source=fault_source,
            transport=httpx.ASGITransport(app=self.data_app),
            clock=self.clock,
        )
        self._closables.append(receiver)
        return receiver

    @staticmethod
    def auth(token: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {token}"}

    async def send(
        self,
        reset: ResetResponse,
        body: str = "I have finished reading the article.",
        *,
        client_message_id: UUID | None = None,
        conversation_id: str = "fixture-conversation-01",
        sequence: int = 1,
    ) -> httpx.Response:
        payload = {
            "schema_version": 1,
            "run_id": str(reset.run_id),
            "conversation_id": conversation_id,
            "client_message_id": str(client_message_id or uuid4()),
            "sequence": sequence,
            "body": body,
        }
        return await self.data.post("/fixture/v1/messages", json=payload, headers=self.auth(reset.sender.token))

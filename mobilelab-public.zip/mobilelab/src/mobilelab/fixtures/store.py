"""Durable fixture state in its own SQLite file (separate from the coordinator DB).

Every write is serialised through one lock and committed before the HTTP
response is produced, so ``201`` really means durable acceptance. The store
never invents receiver delivery or display timestamps: they are written only
from an authenticated receiver acknowledgement.
"""

from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import threading
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from uuid import UUID, uuid4, uuid5

from mobilelab.fixtures.errors import FixtureError
from mobilelab.fixtures.layouts import (
    ALLOWED_CONTACT_ID,
    ALLOWED_CONVERSATION_ID,
    ALLOWED_CONVERSATION_TITLE,
    SEED_INBOUND_DEFAULT,
    seed_conversations,
)
from mobilelab.fixtures.models import (
    AckKind,
    AckTiming,
    AcknowledgementRequest,
    Conversation,
    DetailValue,
    ErrorCode,
    FaultLayer,
    FixtureLayout,
    FaultMode,
    FaultRoute,
    FaultSpec,
    GroundTruthRecord,
    Message,
    MessageStatus,
    OracleCredentials,
    Receipt,
    ReceiverCredentials,
    ReceiverType,
    Reporter,
    RequestLogEntry,
    ResetResponse,
    Role,
    SendMessageRequest,
    SenderCredentials,
    format_ts,
    utc_now,
)

Clock = Callable[[], datetime]

SENDER_ID = "fixture-sender-01"
RECEIVER_ID = "fixture-receiver-01"
ORACLE_ID = "fixture-oracle-01"
CONVERSATION_ID = ALLOWED_CONVERSATION_ID
CONVERSATION_TITLE = ALLOWED_CONVERSATION_TITLE
CONTACT_ID = ALLOWED_CONTACT_ID
# Receiver type is derived from the authenticated receiver identity, never from
# the request. Only receiver types with UI evidence may report "displayed"; the
# scripted peer can establish delivery but never imply a human read (CONTRACTS §12).
RECEIVER_TYPES: dict[str, ReceiverType] = {RECEIVER_ID: ReceiverType.SCRIPTED_RECEIVER}
DISPLAY_CAPABLE_RECEIVER_TYPES: frozenset[ReceiverType] = frozenset()
# Allowed disagreement between the receiver's clock and the server's clock when
# checking acknowledgement times for plausibility.
ACK_CLOCK_SKEW_TOLERANCE = timedelta(seconds=120)
SEED_INBOUND_BODY = SEED_INBOUND_DEFAULT
_SEED_NAMESPACE = UUID("6f1d3c52-6a43-4d55-9a0e-0f6a3f0b7c11")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    reset_at TEXT NOT NULL,
    layout TEXT NOT NULL DEFAULT 'default'
);
CREATE TABLE IF NOT EXISTS tokens (
    token_hash TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    role TEXT NOT NULL,
    principal_id TEXT NOT NULL,
    issued_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS tokens_run ON tokens(run_id);
CREATE TABLE IF NOT EXISTS conversations (
    run_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    title TEXT NOT NULL,
    contact_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    receiver_id TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (run_id, conversation_id)
);
CREATE TABLE IF NOT EXISTS messages (
    server_seq INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL UNIQUE,
    run_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    client_message_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    recipient_id TEXT NOT NULL,
    client_sequence INTEGER NOT NULL,
    body TEXT NOT NULL,
    server_accepted_at TEXT NOT NULL,
    receiver_delivered_at TEXT,
    receiver_displayed_at TEXT,
    delivered_ack_received_at TEXT,
    displayed_ack_received_at TEXT,
    receiver_type TEXT,
    evidence_ids TEXT NOT NULL,
    UNIQUE (run_id, sender_id, client_message_id)
);
CREATE INDEX IF NOT EXISTS messages_conv ON messages(run_id, conversation_id, server_seq);
CREATE INDEX IF NOT EXISTS messages_recipient ON messages(run_id, recipient_id, server_seq);
CREATE TABLE IF NOT EXISTS faults (
    run_id TEXT NOT NULL,
    fault_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    spec TEXT NOT NULL,
    match_count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (run_id, fault_id)
);
CREATE TABLE IF NOT EXISTS ground_truth (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    record_id TEXT NOT NULL UNIQUE,
    run_id TEXT NOT NULL,
    fault_id TEXT NOT NULL,
    mode TEXT NOT NULL,
    layer TEXT NOT NULL,
    route TEXT,
    reporter TEXT NOT NULL,
    activated_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    detail TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS request_log (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id TEXT NOT NULL UNIQUE,
    run_id TEXT,
    at TEXT NOT NULL,
    method TEXT NOT NULL,
    path TEXT NOT NULL,
    query TEXT NOT NULL,
    status INTEGER,
    outcome TEXT NOT NULL,
    user_agent TEXT,
    client_host TEXT,
    detail TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS request_log_run ON request_log(run_id, seq);
"""


@dataclass(frozen=True, slots=True)
class Principal:
    run_id: UUID
    role: Role
    principal_id: str


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _parse_ts(value: str | None) -> datetime | None:
    return None if value is None else datetime.fromisoformat(value.replace("Z", "+00:00"))


def _status(row: sqlite3.Row) -> MessageStatus:
    if row["receiver_displayed_at"] is not None:
        return MessageStatus.DISPLAYED
    if row["receiver_delivered_at"] is not None:
        return MessageStatus.DELIVERED
    return MessageStatus.ACCEPTED


def _row_to_message(row: sqlite3.Row) -> Message:
    return Message(
        message_id=UUID(row["message_id"]),
        run_id=UUID(row["run_id"]),
        conversation_id=row["conversation_id"],
        client_message_id=UUID(row["client_message_id"]),
        sender_id=row["sender_id"],
        sequence=row["server_seq"],
        body=row["body"],
        server_accepted_at=_parse_ts(row["server_accepted_at"]),
        receiver_delivered_at=_parse_ts(row["receiver_delivered_at"]),
        receiver_displayed_at=_parse_ts(row["receiver_displayed_at"]),
        status=_status(row),
    )


def _row_to_receipt(row: sqlite3.Row) -> Receipt:
    return Receipt(
        message_id=UUID(row["message_id"]),
        run_id=UUID(row["run_id"]),
        conversation_id=row["conversation_id"],
        client_message_id=UUID(row["client_message_id"]),
        sender_id=row["sender_id"],
        server_accepted_at=_parse_ts(row["server_accepted_at"]),
        receiver_delivered_at=_parse_ts(row["receiver_delivered_at"]),
        receiver_displayed_at=_parse_ts(row["receiver_displayed_at"]),
        receiver_type=ReceiverType(row["receiver_type"]) if row["receiver_type"] else None,
        status=_status(row),
        correlation_evidence_ids=json.loads(row["evidence_ids"]),
    )


def parse_cursor(cursor: str | None) -> int | None:
    if cursor is None or cursor == "":
        return None
    if not cursor.isdigit() or len(cursor) > 18:
        raise FixtureError(400, ErrorCode.INVALID_CURSOR)
    return int(cursor)


class FixtureStore:
    def __init__(
        self,
        db_path: Path | str,
        *,
        clock: Clock = utc_now,
        token_ttl_s: int = 86_400,
    ) -> None:
        if isinstance(db_path, Path):
            db_path.parent.mkdir(parents=True, exist_ok=True)
        self._clock = clock
        self._token_ttl = timedelta(seconds=token_ttl_s)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)
        self._migrate()

    # ------------------------------------------------------------ plumbing

    def now(self) -> datetime:
        return self._clock()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")

    def _query(self, sql: str, params: tuple[object, ...] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def _migrate(self) -> None:
        """Add columns introduced after the first schema to an existing state database."""
        added = {"runs": ("layout", "TEXT NOT NULL DEFAULT 'default'"),
                 "conversations": ("position", "INTEGER NOT NULL DEFAULT 0")}  # fmt: skip
        with self._lock:
            for table, (column, decl) in added.items():
                cols = {r["name"] for r in self._conn.execute(f"PRAGMA table_info({table})").fetchall()}
                if column not in cols:
                    self._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")

    # ------------------------------------------------------------ runs and auth

    def reset_run(
        self, run_id: UUID, data_base_url: str, *, layout: FixtureLayout = FixtureLayout.DEFAULT
    ) -> ResetResponse:
        """Clear only this run's messaging namespace and issue fresh credentials.

        ``layout`` selects the presentation variant for this run (articles, conversation list, seed
        wording); see ``mobilelab.fixtures.layouts``. Ground-truth and request-log evidence are
        append-only and are retained.
        """
        now = self.now()
        rid = str(run_id)
        tokens = {role: secrets.token_urlsafe(32) for role in Role}
        principals = {Role.SENDER: SENDER_ID, Role.RECEIVER: RECEIVER_ID, Role.ORACLE: ORACLE_ID}
        with self._tx() as c:
            for table in ("tokens", "conversations", "messages", "faults"):
                c.execute(f"DELETE FROM {table} WHERE run_id = ?", (rid,))
            c.execute(
                "INSERT INTO runs(run_id, reset_at, layout) VALUES (?, ?, ?) "
                "ON CONFLICT(run_id) DO UPDATE SET reset_at = excluded.reset_at, layout = excluded.layout",
                (rid, format_ts(now), layout.value),
            )
            for role, token in tokens.items():
                c.execute(
                    "INSERT INTO tokens VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        _hash_token(token),
                        rid,
                        role.value,
                        principals[role],
                        format_ts(now),
                        format_ts(now + self._token_ttl),
                    ),
                )
            for conv in seed_conversations(layout, RECEIVER_ID):
                c.execute(
                    "INSERT INTO conversations(run_id, conversation_id, title, contact_id, sender_id,"
                    " receiver_id, position) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (rid, conv.conversation_id, conv.title, conv.contact_id, SENDER_ID, conv.peer_id, conv.position),
                )
                # The allowed conversation keeps its historical seed identity across layouts.
                seed_key = "seed-inbound-1" if conv.conversation_id == CONVERSATION_ID else f"seed:{conv.conversation_id}"
                self._insert_message(
                    c,
                    run_id=rid,
                    conversation_id=conv.conversation_id,
                    client_message_id=str(uuid5(_SEED_NAMESPACE, f"{rid}:{seed_key}")),
                    sender_id=conv.peer_id,
                    recipient_id=SENDER_ID,
                    client_sequence=1,
                    body=conv.seed_inbound,
                    accepted_at=now,
                )
        return ResetResponse(
            run_id=run_id,
            sender=SenderCredentials(sender_id=SENDER_ID, token=tokens[Role.SENDER]),
            receiver=ReceiverCredentials(receiver_id=RECEIVER_ID, token=tokens[Role.RECEIVER]),
            oracle=OracleCredentials(token=tokens[Role.ORACLE]),
            conversations=self._conversations(rid, None),
            data_base_url=data_base_url,
            layout=layout,
        )

    def run_exists(self, run_id: UUID) -> bool:
        return bool(self._query("SELECT 1 FROM runs WHERE run_id = ?", (str(run_id),)))

    def run_layout(self, run_id: UUID | None) -> FixtureLayout:
        """Layout chosen at the run's last reset; ``default`` for unknown or unscoped requests."""
        if run_id is None:
            return FixtureLayout.DEFAULT
        rows = self._query("SELECT layout FROM runs WHERE run_id = ?", (str(run_id),))
        if not rows:
            return FixtureLayout.DEFAULT
        try:
            return FixtureLayout(rows[0]["layout"])
        except ValueError:
            return FixtureLayout.DEFAULT

    def authenticate(self, token: str | None) -> Principal:
        if not token:
            raise FixtureError(401, ErrorCode.TOKEN_INVALID)
        rows = self._query("SELECT * FROM tokens WHERE token_hash = ?", (_hash_token(token),))
        if not rows:
            raise FixtureError(401, ErrorCode.TOKEN_INVALID)
        row = rows[0]
        expires_at = _parse_ts(row["expires_at"])
        assert expires_at is not None
        if self.now() >= expires_at:
            raise FixtureError(401, ErrorCode.TOKEN_EXPIRED)
        return Principal(UUID(row["run_id"]), Role(row["role"]), row["principal_id"])

    # ------------------------------------------------------------ conversations

    def _conversations(self, rid: str, participant: str | None) -> list[Conversation]:
        sql = "SELECT * FROM conversations WHERE run_id = ?"
        params: tuple[object, ...] = (rid,)
        if participant is not None:
            sql += " AND (sender_id = ? OR receiver_id = ?)"
            params = (rid, participant, participant)
        return [
            Conversation(
                conversation_id=r["conversation_id"],
                title=r["title"],
                contact_id=r["contact_id"],
                participants=[r["sender_id"], r["receiver_id"]],
            )
            for r in self._query(sql + " ORDER BY position, conversation_id", params)
        ]

    def conversations_for(self, principal: Principal) -> list[Conversation]:
        return self._conversations(str(principal.run_id), principal.principal_id)

    def _require_conversation(self, principal: Principal, conversation_id: str) -> sqlite3.Row:
        rows = self._query(
            "SELECT * FROM conversations WHERE run_id = ? AND conversation_id = ? "
            "AND (sender_id = ? OR receiver_id = ?)",
            (str(principal.run_id), conversation_id, principal.principal_id, principal.principal_id),
        )
        if not rows:
            raise FixtureError(403, ErrorCode.CONVERSATION_DENIED)
        return rows[0]

    # ------------------------------------------------------------ messages

    def _insert_message(
        self,
        c: sqlite3.Connection,
        *,
        run_id: str,
        conversation_id: str,
        client_message_id: str,
        sender_id: str,
        recipient_id: str,
        client_sequence: int,
        body: str,
        accepted_at: datetime,
    ) -> sqlite3.Row:
        message_id = str(uuid4())
        evidence = [f"fixture-server:accept:{message_id}"]
        c.execute(
            "INSERT INTO messages(message_id, run_id, conversation_id, client_message_id, sender_id,"
            " recipient_id, client_sequence, body, server_accepted_at, evidence_ids)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                message_id,
                run_id,
                conversation_id,
                client_message_id,
                sender_id,
                recipient_id,
                client_sequence,
                body,
                format_ts(accepted_at),
                json.dumps(evidence),
            ),
        )
        return c.execute("SELECT * FROM messages WHERE message_id = ?", (message_id,)).fetchone()

    def accept_message(self, principal: Principal, req: SendMessageRequest) -> tuple[Receipt, bool]:
        """Durably accept one draft identity. Returns (receipt, is_duplicate)."""
        if principal.role is not Role.SENDER:
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        if req.run_id != principal.run_id:
            raise FixtureError(403, ErrorCode.RUN_MISMATCH)
        conv = self._require_conversation(principal, req.conversation_id)
        rid = str(principal.run_id)
        with self._tx() as c:
            existing = c.execute(
                "SELECT * FROM messages WHERE run_id = ? AND sender_id = ? AND client_message_id = ?",
                (rid, principal.principal_id, str(req.client_message_id)),
            ).fetchone()
            if existing is not None:
                if existing["body"] != req.body or existing["conversation_id"] != req.conversation_id:
                    raise FixtureError(409, ErrorCode.CLIENT_MESSAGE_ID_CONFLICT)
                return _row_to_receipt(existing), True
            recipient = conv["receiver_id"] if conv["sender_id"] == principal.principal_id else conv["sender_id"]
            row = self._insert_message(
                c,
                run_id=rid,
                conversation_id=req.conversation_id,
                client_message_id=str(req.client_message_id),
                sender_id=principal.principal_id,
                recipient_id=recipient,
                client_sequence=req.sequence,
                body=req.body,
                accepted_at=self.now(),
            )
        return _row_to_receipt(row), False

    def list_messages(
        self, principal: Principal, conversation_id: str, after: int | None, limit: int
    ) -> tuple[list[Message], str | None]:
        if principal.role not in (Role.SENDER, Role.RECEIVER):
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        self._require_conversation(principal, conversation_id)
        rows = self._query(
            "SELECT * FROM messages WHERE run_id = ? AND conversation_id = ? AND server_seq > ?"
            " ORDER BY server_seq LIMIT ?",
            (str(principal.run_id), conversation_id, after or 0, limit),
        )
        return self._page(rows, after)

    def receiver_inbox(
        self, principal: Principal, after: int | None, limit: int
    ) -> tuple[list[Message], str | None]:
        if principal.role is not Role.RECEIVER:
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        rows = self._query(
            "SELECT * FROM messages WHERE run_id = ? AND recipient_id = ? AND server_seq > ?"
            " ORDER BY server_seq LIMIT ?",
            (str(principal.run_id), principal.principal_id, after or 0, limit),
        )
        return self._page(rows, after)

    @staticmethod
    def _page(rows: list[sqlite3.Row], after: int | None) -> tuple[list[Message], str | None]:
        messages = [_row_to_message(r) for r in rows]
        if messages:
            return messages, str(messages[-1].sequence)
        return messages, None if after is None else str(after)

    def acknowledge(self, principal: Principal, message_id: UUID, ack: AcknowledgementRequest) -> Receipt:
        if principal.role is not Role.RECEIVER:
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        now = self.now()
        with self._tx() as c:
            row = c.execute(
                "SELECT * FROM messages WHERE message_id = ? AND run_id = ?",
                (str(message_id), str(principal.run_id)),
            ).fetchone()
            if row is None:
                raise FixtureError(404, ErrorCode.MESSAGE_NOT_FOUND)
            if row["recipient_id"] != principal.principal_id:
                raise FixtureError(403, ErrorCode.CONVERSATION_DENIED)
            receiver_type = RECEIVER_TYPES.get(principal.principal_id)
            if receiver_type is None:
                raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
            if ack.kind is AckKind.DISPLAYED and receiver_type not in DISPLAY_CAPABLE_RECEIVER_TYPES:
                raise FixtureError(403, ErrorCode.DISPLAY_NOT_SUPPORTED_FOR_RECEIVER_TYPE)
            evidence: list[str] = json.loads(row["evidence_ids"])
            if ack.kind is AckKind.DELIVERED:
                if row["receiver_delivered_at"] is not None:
                    return _row_to_receipt(row)
                column, received_column = "receiver_delivered_at", "delivered_ack_received_at"
                earliest = _parse_ts(row["server_accepted_at"])
            else:
                if row["receiver_delivered_at"] is None:
                    raise FixtureError(409, ErrorCode.NOT_DELIVERED)
                if not ack.evidence_ids:
                    raise FixtureError(422, ErrorCode.DISPLAY_EVIDENCE_REQUIRED)
                if row["receiver_displayed_at"] is not None:
                    return _row_to_receipt(row)
                column, received_column = "receiver_displayed_at", "displayed_ack_received_at"
                earliest = _parse_ts(row["receiver_delivered_at"])
            assert earliest is not None
            observed = ack.receiver_observed_at
            if observed < earliest - ACK_CLOCK_SKEW_TOLERANCE or observed > now + ACK_CLOCK_SKEW_TOLERANCE:
                raise FixtureError(422, ErrorCode.ACK_TIME_IMPLAUSIBLE)
            timing = AckTiming(
                kind=ack.kind,
                message_id=message_id,
                receiver_observed_at=observed,
                server_received_at=now,
                receiver_offset_ms=0,
            )
            # Compute from the wire-precision values so the record is self-consistent.
            offset_ms = round((timing.server_received_at - timing.receiver_observed_at).total_seconds() * 1000)
            timing = timing.model_copy(update={"receiver_offset_ms": offset_ms})
            evidence.append(f"fixture-server:ack-{ack.kind.value}:{message_id}")
            evidence.append(timing.to_evidence_id())
            evidence.extend(e for e in ack.evidence_ids if e not in evidence)
            c.execute(
                f"UPDATE messages SET {column} = ?, {received_column} = ?, receiver_type = ?,"
                " evidence_ids = ? WHERE message_id = ?",
                (
                    format_ts(observed),
                    format_ts(timing.server_received_at),
                    receiver_type.value,
                    json.dumps(evidence),
                    str(message_id),
                ),
            )
            row = c.execute("SELECT * FROM messages WHERE message_id = ?", (str(message_id),)).fetchone()
        return _row_to_receipt(row)

    def get_receipt(self, principal: Principal, run_id: UUID, client_message_id: UUID) -> Receipt | None:
        if principal.role is not Role.ORACLE:
            raise FixtureError(403, ErrorCode.FORBIDDEN_ROLE)
        if run_id != principal.run_id:
            raise FixtureError(403, ErrorCode.RUN_MISMATCH)
        rows = self._query(
            "SELECT * FROM messages WHERE run_id = ? AND sender_id = ? AND client_message_id = ?",
            (str(run_id), SENDER_ID, str(client_message_id)),
        )
        return _row_to_receipt(rows[0]) if rows else None

    # ------------------------------------------------------------ faults and ground truth

    def set_faults(self, run_id: UUID, faults: list[FaultSpec]) -> None:
        rid = str(run_id)
        with self._tx() as c:
            c.execute("DELETE FROM faults WHERE run_id = ?", (rid,))
            for position, fault in enumerate(faults):
                c.execute(
                    "INSERT INTO faults(run_id, fault_id, position, spec) VALUES (?, ?, ?, ?)",
                    (rid, fault.fault_id, position, fault.model_dump_json()),
                )

    def get_faults(self, run_id: UUID) -> list[FaultSpec]:
        rows = self._query("SELECT spec FROM faults WHERE run_id = ? ORDER BY position", (str(run_id),))
        return [FaultSpec.model_validate_json(r["spec"]) for r in rows]

    def match_server_faults(self, run_id: UUID, route: FaultRoute) -> list[FaultSpec]:
        """Count this request against matching fixture-server faults; return those that fire."""
        now = self.now()
        fired: list[FaultSpec] = []
        with self._tx() as c:
            rows = c.execute(
                "SELECT fault_id, spec, match_count FROM faults WHERE run_id = ? ORDER BY position",
                (str(run_id),),
            ).fetchall()
            for row in rows:
                fault = FaultSpec.model_validate_json(row["spec"])
                if fault.layer is not FaultLayer.FIXTURE_SERVER:
                    continue
                if not fault.matches_route(route) or not fault.is_active(now):
                    continue
                count = row["match_count"] + 1
                c.execute(
                    "UPDATE faults SET match_count = ? WHERE run_id = ? AND fault_id = ?",
                    (count, str(run_id), fault.fault_id),
                )
                if fault.match.nth is None or fault.match.nth == count:
                    fired.append(fault)
        return fired

    def record_ground_truth(
        self,
        run_id: UUID,
        fault: FaultSpec,
        *,
        reporter: Reporter,
        route: FaultRoute | None,
        activated_at: datetime | None = None,
        detail: dict[str, DetailValue] | None = None,
    ) -> GroundTruthRecord:
        now = self.now()
        record = GroundTruthRecord(
            record_id=uuid4(),
            run_id=run_id,
            fault_id=fault.fault_id,
            mode=fault.mode,
            layer=fault.layer,
            route=route,
            reporter=reporter,
            activated_at=activated_at or now,
            recorded_at=now,
            detail=detail or {},
        )
        with self._tx() as c:
            c.execute(
                "INSERT INTO ground_truth(record_id, run_id, fault_id, mode, layer, route, reporter,"
                " activated_at, recorded_at, detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    str(record.record_id),
                    str(run_id),
                    record.fault_id,
                    record.mode.value,
                    record.layer.value,
                    route.value if route else None,
                    reporter.value,
                    format_ts(record.activated_at),
                    format_ts(record.recorded_at),
                    json.dumps(record.detail),
                ),
            )
        return record

    def ground_truth(self, run_id: UUID) -> list[GroundTruthRecord]:
        rows = self._query("SELECT * FROM ground_truth WHERE run_id = ? ORDER BY seq", (str(run_id),))
        return [
            GroundTruthRecord(
                record_id=UUID(r["record_id"]),
                run_id=UUID(r["run_id"]),
                fault_id=r["fault_id"],
                mode=FaultMode(r["mode"]),
                layer=FaultLayer(r["layer"]),
                route=FaultRoute(r["route"]) if r["route"] else None,
                reporter=Reporter(r["reporter"]),
                activated_at=_parse_ts(r["activated_at"]),
                recorded_at=_parse_ts(r["recorded_at"]),
                detail=json.loads(r["detail"]),
            )
            for r in rows
        ]

    # ------------------------------------------------------------ request evidence

    def log_request(self, entry: RequestLogEntry) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT INTO request_log(entry_id, run_id, at, method, path, query, status, outcome,"
                " user_agent, client_host, detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    str(entry.entry_id),
                    str(entry.run_id) if entry.run_id else None,
                    format_ts(entry.at),
                    entry.method,
                    entry.path,
                    entry.query,
                    entry.status,
                    entry.outcome,
                    entry.user_agent,
                    entry.client_host,
                    json.dumps(entry.detail),
                ),
            )

    def request_log(self, run_id: UUID, *, include_unscoped: bool = False) -> list[RequestLogEntry]:
        sql = "SELECT * FROM request_log WHERE run_id = ?"
        if include_unscoped:
            sql += " OR run_id IS NULL"
        rows = self._query(sql + " ORDER BY seq", (str(run_id),))
        return [
            RequestLogEntry(
                entry_id=UUID(r["entry_id"]),
                run_id=UUID(r["run_id"]) if r["run_id"] else None,
                at=_parse_ts(r["at"]),
                method=r["method"],
                path=r["path"],
                query=r["query"],
                status=r["status"],
                outcome=r["outcome"],
                user_agent=r["user_agent"],
                client_host=r["client_host"],
                detail=json.loads(r["detail"]),
            )
            for r in rows
        ]

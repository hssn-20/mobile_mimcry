"""Loopback-only ADMIN listener for the environment controller.

Authenticated with a single bearer admin secret that is never given to
devices. Ground truth served here must never be given to the acting policy.
"""

from __future__ import annotations

import hmac
from collections.abc import Awaitable, Callable
from uuid import UUID

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from mobilelab.fixtures.config import FixtureConfig
from mobilelab.fixtures.errors import FixtureError, fixture_error_handler
from mobilelab.fixtures.httputil import bearer_token, json_response, parse_json_body
from mobilelab.fixtures.models import (
    ActivationReport,
    ErrorCode,
    FaultSchedule,
    FaultScheduleRequest,
    FixtureLayout,
    GroundTruthResponse,
    RequestLogResponse,
    ResetRequest,
    ResetResponse,
)
from mobilelab.fixtures.store import FixtureStore

ResetHook = Callable[[ResetResponse], Awaitable[None]]


def create_admin_app(
    store: FixtureStore,
    config: FixtureConfig,
    admin_secret: str,
    *,
    on_reset: ResetHook | None = None,
) -> FastAPI:
    app = FastAPI(title="mobilelab fixture admin", docs_url=None, redoc_url=None, openapi_url=None)
    app.add_exception_handler(FixtureError, fixture_error_handler)
    secret = admin_secret.encode("utf-8")

    def authorize(request: Request) -> None:
        token = bearer_token(request)
        if token is None or not hmac.compare_digest(token.encode("utf-8"), secret):
            raise FixtureError(401, ErrorCode.TOKEN_INVALID)

    def run_uuid(run_id: str) -> UUID:
        try:
            return UUID(run_id)
        except ValueError:
            raise FixtureError(422, ErrorCode.VALIDATION_ERROR, "run_id must be a UUID") from None

    def existing_run(run_id: str) -> UUID:
        rid = run_uuid(run_id)
        if not store.run_exists(rid):
            raise FixtureError(404, ErrorCode.RUN_NOT_FOUND)
        return rid

    @app.post("/fixture-admin/v1/runs/{run_id}/reset")
    async def reset(request: Request, run_id: str) -> JSONResponse:
        authorize(request)
        rid = run_uuid(run_id)
        # An empty body keeps the original contract (default layout).
        body = await parse_json_body(request, ResetRequest) if await request.body() else None
        layout = body.layout if body is not None else FixtureLayout.DEFAULT
        result = store.reset_run(rid, config.public_base_url, layout=layout)
        if on_reset is not None:
            await on_reset(result)
        return json_response(result)

    @app.post("/fixture-admin/v1/runs/{run_id}/faults")
    async def set_faults(request: Request, run_id: str) -> JSONResponse:
        authorize(request)
        rid = existing_run(run_id)
        schedule = await parse_json_body(request, FaultScheduleRequest)
        store.set_faults(rid, schedule.faults)
        return json_response(FaultSchedule(run_id=rid, faults=store.get_faults(rid)))

    @app.get("/fixture-admin/v1/runs/{run_id}/faults")
    async def get_faults(request: Request, run_id: str) -> JSONResponse:
        authorize(request)
        rid = existing_run(run_id)
        return json_response(FaultSchedule(run_id=rid, faults=store.get_faults(rid)))

    @app.post("/fixture-admin/v1/runs/{run_id}/ground-truth")
    async def report_activation(request: Request, run_id: str) -> JSONResponse:
        """Record an activation performed by the receiver peer or the controller."""
        authorize(request)
        rid = existing_run(run_id)
        report = await parse_json_body(request, ActivationReport)
        fault = next((f for f in store.get_faults(rid) if f.fault_id == report.fault_id), None)
        if fault is None:
            raise FixtureError(404, ErrorCode.FAULT_NOT_FOUND)
        record = store.record_ground_truth(
            rid,
            fault,
            reporter=report.reporter,
            route=fault.match.route,
            activated_at=report.activated_at,
            detail=report.detail,
        )
        return json_response(record, 201)

    @app.get("/fixture-admin/v1/runs/{run_id}/ground-truth")
    async def ground_truth(request: Request, run_id: str) -> JSONResponse:
        authorize(request)
        rid = run_uuid(run_id)
        return json_response(GroundTruthResponse(run_id=rid, records=store.ground_truth(rid)))

    @app.get("/fixture-admin/v1/runs/{run_id}/request-log")
    async def request_log(request: Request, run_id: str) -> JSONResponse:
        authorize(request)
        rid = run_uuid(run_id)
        include_unscoped = request.query_params.get("include_unscoped") == "true"
        entries = store.request_log(rid, include_unscoped=include_unscoped)
        return json_response(RequestLogResponse(run_id=rid, entries=entries))

    return app

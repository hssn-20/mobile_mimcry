"""Fixture service configuration.

``bind_host`` (where the listener binds on the Mac) and ``public_base_url``
(the URL a device under test uses) are deliberately separate. A phone's
``localhost`` is the phone, not the Mac. The iOS Simulator shares the host
network stack, so ``http://127.0.0.1:<port>`` happens to be reachable from a
Simulator; that is a Simulator-specific fact, recorded via
``public_url_is_loopback`` and never assumed for physical devices.
"""

from __future__ import annotations

import ipaddress
import os
import secrets
from pathlib import Path
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

FIXTURE_DATA_VERSION = "fixture-data-1"
ADMIN_SECRET_ENV = "MOBILELAB_FIXTURE_ADMIN_SECRET"
LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _is_loopback(host: str) -> bool:
    if host in LOOPBACK_HOSTS:
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


class FixtureConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    bind_host: str = "127.0.0.1"
    data_port: int = Field(default=8781, ge=0, le=65535)
    admin_host: str = "127.0.0.1"
    admin_port: int = Field(default=8782, ge=0, le=65535)
    public_base_url: str = "http://127.0.0.1:8781"
    state_dir: Path = Path("artifacts/fixtures")
    db_filename: str = "fixture.sqlite"
    admin_secret_filename: str = "admin_secret"
    token_ttl_s: int = Field(default=86_400, ge=60)
    slow_error_delay_ms: int = Field(default=3_000, ge=0, le=60_000)
    fixture_data_version: str = FIXTURE_DATA_VERSION

    @field_validator("public_base_url")
    @classmethod
    def _check_public_url(cls, value: str) -> str:
        parts = urlsplit(value)
        if parts.scheme not in ("http", "https") or not parts.hostname:
            raise ValueError("public_base_url must be an absolute http(s) URL")
        if parts.hostname in ("0.0.0.0", "::"):
            raise ValueError("public_base_url must name a reachable host, not a wildcard bind address")
        if parts.path not in ("", "/") or parts.query or parts.fragment:
            raise ValueError("public_base_url must not contain a path, query or fragment")
        return value.rstrip("/")

    @model_validator(mode="after")
    def _admin_loopback_only(self) -> FixtureConfig:
        if not _is_loopback(self.admin_host):
            raise ValueError("the admin listener must bind to loopback; it is never exposed to devices")
        return self

    @property
    def public_host(self) -> str:
        host = urlsplit(self.public_base_url).hostname
        assert host is not None
        return host

    @property
    def public_url_is_loopback(self) -> bool:
        """True when devices are told to use loopback (valid for iOS Simulator only)."""
        return _is_loopback(self.public_host)

    @property
    def db_path(self) -> Path:
        return self.state_dir / self.db_filename

    @property
    def admin_secret_path(self) -> Path:
        return self.state_dir / self.admin_secret_filename


def load_config(path: Path | None = None, **overrides: object) -> FixtureConfig:
    """Load a YAML config file (optional) and apply non-None overrides."""
    data: dict[str, object] = {}
    if path is not None:
        loaded = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(loaded, dict):
            raise ValueError(f"{path}: expected a mapping")
        data.update(loaded)
    data.update({k: v for k, v in overrides.items() if v is not None})
    return FixtureConfig.model_validate(data)


def resolve_admin_secret(config: FixtureConfig) -> str:
    """Return the admin secret from the environment, or generate one.

    A generated secret is written to ``config.admin_secret_path`` with mode 0600
    so the local controller can read it. It is never served to devices.
    """
    env_value = os.environ.get(ADMIN_SECRET_ENV)
    if env_value:
        if len(env_value) < 16:
            raise ValueError(f"{ADMIN_SECRET_ENV} must be at least 16 characters")
        return env_value
    secret = secrets.token_urlsafe(32)
    path = config.admin_secret_path
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, secret.encode("ascii"))
    finally:
        os.close(fd)
    os.chmod(path, 0o600)
    return secret

"""Campaigns, frozen run specifications, runs and device leases (CONTRACTS §2, §7, §11)."""

from __future__ import annotations

from typing import Annotated, Literal
from uuid import UUID

from pydantic import Field, JsonValue

from mobilelab.domain.base import FrozenModel, Identifier, PersistedModel, ShortStr, UtcDatetime
from mobilelab.domain.enums import (
    ConfigKind,
    DeviceKind,
    EvidenceCategory,
    EvidenceSource,
    LeaseKind,
    LeaseStatus,
    Platform,
    RunStatus,
    Verdict,
)
from mobilelab.domain.hashing import config_hash

Sha256Hex = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


class Campaign(PersistedModel):
    campaign_id: UUID
    name: ShortStr
    description: str = Field(default="", max_length=4000)
    max_cost_usd: float | None = Field(default=None, ge=0)


class ConfigRevision(PersistedModel):
    """Immutable persona/scenario/provider revision. Edits create a new revision; runs pin the hash."""

    kind: ConfigKind
    config_id: Identifier
    revision: int = Field(ge=1)
    content_hash: Sha256Hex
    content: dict[str, JsonValue]


class RunSpec(FrozenModel):
    """Everything a run freezes at creation. Later configuration edits cannot alter it."""

    schema_version: Literal[1] = 1
    scenario_id: Identifier
    scenario_version: int = Field(ge=1)
    scenario_hash: Sha256Hex
    persona_id: Identifier
    persona_version: int = Field(ge=1)
    persona_hash: Sha256Hex
    provider_id: Identifier
    provider_config: dict[str, JsonValue] = Field(default_factory=dict)
    provider_config_hash: Sha256Hex
    model_identifier: str | None = Field(default=None, max_length=256)
    app_builds: dict[str, str] = Field(default_factory=dict)
    adapter_versions: dict[str, str] = Field(default_factory=dict)
    seed: int = Field(ge=0)
    device_id: UUID
    platform: Platform
    device_kind: DeviceKind
    device_profile_hash: Sha256Hex
    capability_report_id: UUID | None = None
    capability_evidence_hash: Sha256Hex | None = None
    planned_evidence: EvidenceCategory
    policy_limits: dict[str, JsonValue] = Field(default_factory=dict)
    """Frozen numeric policy defaults (text length, max wait, freshness...)."""

    def spec_hash(self) -> str:
        return config_hash(self)


class Run(PersistedModel):
    run_id: UUID
    campaign_id: UUID | None = None
    spec: RunSpec
    status: RunStatus = RunStatus.CREATED
    status_reason: str | None = Field(default=None, max_length=2000)
    verdict: Verdict | None = None
    obtained_evidence: EvidenceCategory | None = None
    obtained_evidence_source: EvidenceSource | None = None
    """Where the obtained evidence came from; only ``device`` can satisfy planned evidence."""
    control_epoch: int = Field(default=0, ge=0)
    in_recovery: bool = False
    started_at: UtcDatetime | None = None
    ended_at: UtcDatetime | None = None
    updated_at: UtcDatetime | None = None


class Lease(PersistedModel):
    lease_id: UUID
    device_id: UUID
    run_id: UUID | None = None
    kind: LeaseKind
    epoch: int = Field(ge=1)
    """Per-device generation token; strictly increases with every new lease on that device."""
    holder: ShortStr
    status: LeaseStatus = LeaseStatus.ACTIVE
    acquired_at: UtcDatetime
    released_at: UtcDatetime | None = None
    release_reason: str | None = Field(default=None, max_length=2000)

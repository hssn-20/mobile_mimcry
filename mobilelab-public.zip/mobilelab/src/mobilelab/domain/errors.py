"""Typed error codes, the wire error envelope, and exceptions that map onto them."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, ClassVar, Literal

from pydantic import Field, JsonValue

from mobilelab.domain.base import StrictModel


class ErrorCode(StrEnum):
    CAPABILITY_UNAVAILABLE = "CAPABILITY_UNAVAILABLE"
    STALE_OBSERVATION = "STALE_OBSERVATION"
    STALE_LEASE = "STALE_LEASE"
    STALE_EPOCH = "STALE_EPOCH"
    INVALID_TRANSITION = "INVALID_TRANSITION"
    TERMINAL_RECORD_IMMUTABLE = "TERMINAL_RECORD_IMMUTABLE"
    VERSION_CONFLICT = "VERSION_CONFLICT"
    DISPATCH_GATE_CLOSED = "DISPATCH_GATE_CLOSED"
    CANDIDATE_NOT_FOUND = "CANDIDATE_NOT_FOUND"
    INVALID_PARAMETERS = "INVALID_PARAMETERS"
    EVIDENCE_TIER_MISMATCH = "EVIDENCE_TIER_MISMATCH"
    LEASE_CONFLICT = "LEASE_CONFLICT"
    IDEMPOTENCY_CONFLICT = "IDEMPOTENCY_CONFLICT"
    NOT_FOUND = "NOT_FOUND"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    UNAUTHORIZED = "UNAUTHORIZED"
    COORDINATOR_LOCKED = "COORDINATOR_LOCKED"
    ARTIFACT_PATH_VIOLATION = "ARTIFACT_PATH_VIOLATION"
    PROVIDER_ERROR = "PROVIDER_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class ErrorEnvelope(StrictModel):
    schema_version: Literal[1] = 1
    code: ErrorCode
    message: str = Field(max_length=2000)
    retryable: bool = False
    details: dict[str, JsonValue] = Field(default_factory=dict)
    current_state: dict[str, JsonValue] | None = None
    """For 409 responses: the current resource state (e.g. its status and version)."""


class MobilelabError(Exception):
    code: ClassVar[ErrorCode] = ErrorCode.INTERNAL_ERROR
    http_status: ClassVar[int] = 500
    retryable: ClassVar[bool] = False

    def __init__(
        self,
        message: str,
        *,
        details: dict[str, Any] | None = None,
        current_state: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}
        self.current_state = current_state

    def to_envelope(self) -> ErrorEnvelope:
        return ErrorEnvelope(
            code=self.code,
            message=self.message,
            retryable=self.retryable,
            details=self.details,
            current_state=self.current_state,
        )


class CapabilityUnavailable(MobilelabError):
    code = ErrorCode.CAPABILITY_UNAVAILABLE
    http_status = 422


class StaleObservation(MobilelabError):
    code = ErrorCode.STALE_OBSERVATION
    http_status = 409
    retryable = True


class StaleLease(MobilelabError):
    code = ErrorCode.STALE_LEASE
    http_status = 409


class StaleEpoch(MobilelabError):
    code = ErrorCode.STALE_EPOCH
    http_status = 409


class InvalidTransition(MobilelabError):
    code = ErrorCode.INVALID_TRANSITION
    http_status = 409


class TerminalRecordImmutable(InvalidTransition):
    code = ErrorCode.TERMINAL_RECORD_IMMUTABLE


class VersionConflict(MobilelabError):
    code = ErrorCode.VERSION_CONFLICT
    http_status = 409


class DispatchGateClosed(MobilelabError):
    code = ErrorCode.DISPATCH_GATE_CLOSED
    http_status = 409


class CandidateNotFound(MobilelabError):
    code = ErrorCode.CANDIDATE_NOT_FOUND
    http_status = 422


class InvalidParameters(MobilelabError):
    code = ErrorCode.INVALID_PARAMETERS
    http_status = 422


class EvidenceTierMismatch(MobilelabError):
    code = ErrorCode.EVIDENCE_TIER_MISMATCH
    http_status = 422


class LeaseConflict(MobilelabError):
    code = ErrorCode.LEASE_CONFLICT
    http_status = 409


class IdempotencyConflict(MobilelabError):
    code = ErrorCode.IDEMPOTENCY_CONFLICT
    http_status = 409


class NotFound(MobilelabError):
    code = ErrorCode.NOT_FOUND
    http_status = 404


class CoordinatorLocked(MobilelabError):
    code = ErrorCode.COORDINATOR_LOCKED
    http_status = 503


class ArtifactPathViolation(MobilelabError):
    code = ErrorCode.ARTIFACT_PATH_VIOLATION
    http_status = 400


class ProviderError(MobilelabError):
    code = ErrorCode.PROVIDER_ERROR
    http_status = 502


__all__ = [
    "ArtifactPathViolation",
    "CandidateNotFound",
    "CapabilityUnavailable",
    "CoordinatorLocked",
    "DispatchGateClosed",
    "ErrorCode",
    "ErrorEnvelope",
    "EvidenceTierMismatch",
    "IdempotencyConflict",
    "InvalidParameters",
    "InvalidTransition",
    "LeaseConflict",
    "MobilelabError",
    "NotFound",
    "ProviderError",
    "StaleEpoch",
    "StaleLease",
    "StaleObservation",
    "TerminalRecordImmutable",
    "VersionConflict",
]

"""Scenario manifests and oracle results (CONTRACTS §9, ACCEPTANCE_PLAN §2)."""

from __future__ import annotations

from typing import Any, Literal, Self
from uuid import UUID

import yaml
from pydantic import Field, JsonValue, model_validator

from mobilelab.domain.base import FrozenModel, Identifier, PersistedModel, RequirementRef, ShortStr, UtcDatetime
from mobilelab.domain.enums import CapabilityKey, CleanupPolicy, EvidenceCategory, Platform, Verdict

_CARRIER_CAPS = frozenset({CapabilityKey.CARRIER_SMS, CapabilityKey.CARRIER_VOICE})
_PHYSICAL_IP_CAPS = frozenset({CapabilityKey.VPN_EXIT_SELECTION})


class OracleDefinition(FrozenModel):
    kind: Identifier
    required_status: str | None = Field(default=None, max_length=64)
    timeout_seconds: float = Field(gt=0, le=3600)
    evidence: list[ShortStr] = Field(default_factory=list)
    params: dict[str, JsonValue] = Field(default_factory=dict)


class Disturbance(FrozenModel):
    kind: Identifier
    at_seconds: float = Field(ge=0)
    layer: Identifier | None = None
    params: dict[str, JsonValue] = Field(default_factory=dict)


class ScenarioSpec(FrozenModel):
    schema_version: Literal[1] = 1
    scenario_id: Identifier
    version: int = Field(ge=1)
    description: str = Field(default="", max_length=4000)
    requirement_refs: list[RequirementRef] = Field(default_factory=list)
    platforms: list[Platform] = Field(min_length=1)
    platform_evidence: EvidenceCategory
    """The single primary evidence tier; mixed-tier journeys must be split into subscenarios."""
    required_capabilities: list[CapabilityKey] = Field(default_factory=list)
    max_duration_seconds: int = Field(gt=0, le=86_400)
    max_actions: int = Field(gt=0, le=10_000)
    max_steps: int | None = Field(default=None, gt=0)
    max_cost_usd: float | None = Field(default=None, ge=0)
    goal: str = Field(min_length=1, max_length=4000)
    fixture_setup: dict[str, JsonValue] = Field(default_factory=dict)
    fixture_versions: dict[str, str] = Field(default_factory=dict)
    preconditions: list[str] = Field(default_factory=list)
    expected_observations: list[str] = Field(default_factory=list)
    peer_topology: dict[str, JsonValue] = Field(default_factory=dict)
    persona_id: Identifier | None = None
    persona_version: int | None = Field(default=None, ge=1)
    seed: int | None = Field(default=None, ge=0)
    provider: Identifier | None = None
    disturbances: list[Disturbance] = Field(default_factory=list)
    oracles: list[OracleDefinition] = Field(default_factory=list)
    cleanup: CleanupPolicy = CleanupPolicy.FIXTURE_ONLY

    @model_validator(mode="after")
    def _single_tier(self) -> Self:
        caps = set(self.required_capabilities)
        if caps & _CARRIER_CAPS and self.platform_evidence is not EvidenceCategory.PHYSICAL_CARRIER:
            raise ValueError("carrier capabilities require platform_evidence physical_carrier (split mixed tiers)")
        if caps & _PHYSICAL_IP_CAPS and self.platform_evidence is not EvidenceCategory.PHYSICAL_IP:
            raise ValueError("vpn_exit_selection requires platform_evidence physical_ip (split mixed tiers)")
        if (self.persona_id is None) != (self.persona_version is None):
            raise ValueError("persona_id and persona_version must be given together")
        return self

    @classmethod
    def from_yaml(cls, text: str) -> ScenarioSpec:
        data: Any = yaml.safe_load(text)
        if not isinstance(data, dict):
            raise ValueError("scenario YAML must be a mapping")
        return cls.model_validate(data)


class OracleResult(PersistedModel):
    oracle_result_id: UUID
    run_id: UUID
    scenario_id: Identifier
    oracle_kind: Identifier
    verdict: Verdict
    reason_code: str = Field(min_length=1, max_length=64, pattern=r"^[A-Z][A-Z0-9_]*$")
    expected: dict[str, JsonValue] = Field(default_factory=dict)
    observed: dict[str, JsonValue] = Field(default_factory=dict)
    evidence_ids: list[str] = Field(default_factory=list)
    obtained_evidence: EvidenceCategory | None = None
    observation_window_start: UtcDatetime
    observation_window_end: UtcDatetime
    requirement_refs: list[RequirementRef] = Field(default_factory=list)
    confidence: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def _window(self) -> Self:
        if self.observation_window_end < self.observation_window_start:
            raise ValueError("observation window end precedes start")
        return self

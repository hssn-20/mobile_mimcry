"""Canonical JSON and SHA-256 content hashes for frozen configuration (scenario/persona/provider)."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from pydantic import BaseModel


def _plain(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", by_alias=True)
    return value


def canonical_json(value: Any) -> bytes:
    """Sorted keys, no insignificant whitespace, UTF-8, NaN/Infinity rejected."""
    return json.dumps(
        _plain(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def config_hash(value: Any) -> str:
    """Lowercase hex SHA-256 of ``canonical_json(value)``."""
    return hashlib.sha256(canonical_json(value)).hexdigest()

"""Device profiles, capability evidence and worker health/fence/close results (CONTRACTS §3, §7)."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Literal, Self
from uuid import UUID

from pydantic import Field, model_validator

from mobilelab.domain.base import FrozenModel, PersistedModel, ShortStr, StrictModel, UtcDatetime, utc_now
from mobilelab.domain.enums import (
    CapabilityKey,
    CapabilityStatus,
    DeviceKind,
    EvidenceCategory,
    EvidenceSource,
    Platform,
)


class DisplayGeometry(StrictModel):
    width_px: int = Field(gt=0)
    height_px: int = Field(gt=0)
    scale: float = Field(gt=0)


class CapabilityRecord(StrictModel):
    key: CapabilityKey
    status: CapabilityStatus
    evidence_tier: EvidenceCategory | None = None
    evidence_source: EvidenceSource
    last_probed_at: UtcDatetime | None = None
    probe_artifact_id: UUID | None = None
    reason: str = Field(default="", max_length=2000)

    @model_validator(mode="after")
    def _supported_needs_probe(self) -> Self:
        if self.status is CapabilityStatus.SUPPORTED and self.last_probed_at is None:
            raise ValueError("a supported capability requires last_probed_at (no inference from API presence)")
        return self

    def available(self, *, strict: bool = True) -> bool:
        """Unverified is unavailable under strict preflight; mock evidence never makes a capability available."""
        if self.evidence_source is EvidenceSource.MOCK:
            return False
        if self.status is CapabilityStatus.SUPPORTED:
            return True
        return not strict and self.status is CapabilityStatus.UNVERIFIED


class DeviceProfile(PersistedModel):
    device_id: UUID
    platform: Platform
    kind: DeviceKind
    name: ShortStr
    os_version: ShortStr
    model: ShortStr
    locale: ShortStr = "en_GB"
    timezone: ShortStr = "Europe/London"
    display: DisplayGeometry | None = None
    adapter_serial: str | None = Field(default=None, max_length=256)
    """Platform UDID/serial: adapter-only field, never the public device identifier."""
    installed_fixture_builds: dict[str, str] = Field(default_factory=dict)
    appium_version: str | None = None
    driver_versions: dict[str, str] = Field(default_factory=dict)
    capabilities: list[CapabilityRecord] = Field(default_factory=list)

    @model_validator(mode="after")
    def _unique_capability_keys(self) -> Self:
        keys = [c.key for c in self.capabilities]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate capability keys in device profile")
        return self


class CapabilityReport(FrozenModel):
    schema_version: Literal[1] = 1
    report_id: UUID
    device_id: UUID
    platform: Platform
    device_kind: DeviceKind
    evidence_source: EvidenceSource
    adapter_version: ShortStr
    probed_at: UtcDatetime
    records: list[CapabilityRecord]

    def record(self, key: CapabilityKey) -> CapabilityRecord | None:
        return next((r for r in self.records if r.key is key), None)

    def missing(self, required: Iterable[CapabilityKey], *, strict: bool = True) -> list[CapabilityKey]:
        """Required capabilities that are not available (absent, unsupported, unverified-in-strict, or mock)."""
        out: list[CapabilityKey] = []
        for key in required:
            rec = self.record(key)
            if rec is None or not rec.available(strict=strict):
                out.append(key)
        return out


class DeviceHealth(StrictModel):
    device_id: UUID
    checked_at: UtcDatetime = Field(default_factory=utc_now)
    healthy: bool
    session_alive: bool
    foreground_app: str | None = None
    evidence_source: EvidenceSource
    detail: str = Field(default="", max_length=2000)


class FenceResult(StrictModel):
    device_id: UUID
    control_epoch: int = Field(ge=0)
    fenced: bool
    acknowledged_at: UtcDatetime
    in_flight_command_id: UUID | None = None
    in_flight_state: Literal["none", "executing", "unknown"] = "none"


class CloseResult(StrictModel):
    device_id: UUID
    closed: bool
    closed_at: UtcDatetime = Field(default_factory=utc_now)
    detail: str = Field(default="", max_length=2000)

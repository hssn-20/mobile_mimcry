"""Evidence-tier rules (CONTRACTS §9, ACCEPTANCE §2).

Categories are not an ordered quality scale: a scenario is satisfied only by evidence of exactly its
primary category. Device kind is recorded separately (a physical phone running Lab Messenger still
produces ``fixture`` evidence). Only fresh device evidence (``evidence_source=device``) can satisfy a
scenario: ``mock`` output is never device evidence, and ``replay`` (re-presented recorded data) is not a
fresh observation. Replay modes that actually re-execute on a device (CONTRACTS §8 ``executed_actions``)
produce new observations which carry ``evidence_source=device`` themselves.
"""

from __future__ import annotations

from mobilelab.domain.base import FrozenModel
from mobilelab.domain.enums import DeviceKind, EvidenceCategory, EvidenceSource, Verdict
from mobilelab.domain.errors import EvidenceTierMismatch

VERDICTS_REQUIRING_EVIDENCE: frozenset[Verdict] = frozenset({Verdict.PASS, Verdict.DUT_FAILURE})
"""Verdicts that assert an outcome about the DUT and so must rest on the scenario's planned evidence.
INCONCLUSIVE/UNSUPPORTED/HARNESS_FAILURE/ENVIRONMENT_FAILURE make no such claim."""

_PHYSICAL_ONLY = frozenset({EvidenceCategory.PHYSICAL_IP, EvidenceCategory.PHYSICAL_CARRIER})


class EvidenceAssessment(FrozenModel):
    required: EvidenceCategory
    obtained: EvidenceCategory | None
    device_kind: DeviceKind
    evidence_source: EvidenceSource
    satisfied: bool
    reason: str


def assess_evidence(
    required: EvidenceCategory,
    obtained: EvidenceCategory | None,
    *,
    device_kind: DeviceKind,
    evidence_source: EvidenceSource,
) -> EvidenceAssessment:
    def out(ok: bool, reason: str) -> EvidenceAssessment:
        return EvidenceAssessment(
            required=required,
            obtained=obtained,
            device_kind=device_kind,
            evidence_source=evidence_source,
            satisfied=ok,
            reason=reason,
        )

    if evidence_source is not EvidenceSource.DEVICE:
        return out(False, f"{evidence_source} evidence is not fresh device evidence and never satisfies a scenario")
    if obtained is None:
        return out(False, "no evidence obtained")
    if obtained in _PHYSICAL_ONLY and device_kind is not DeviceKind.PHYSICAL:
        return out(False, f"{obtained} evidence requires a physical device, got {device_kind}")
    if obtained is not required:
        return out(False, f"obtained {obtained} evidence cannot substitute for required {required}")
    return out(True, "evidence category matches")


def require_evidence(
    required: EvidenceCategory,
    obtained: EvidenceCategory | None,
    *,
    device_kind: DeviceKind,
    evidence_source: EvidenceSource,
) -> EvidenceAssessment:
    """As assess_evidence, but raise EvidenceTierMismatch when not satisfied."""
    result = assess_evidence(required, obtained, device_kind=device_kind, evidence_source=evidence_source)
    if not result.satisfied:
        raise EvidenceTierMismatch(result.reason, details=result.model_dump(mode="json"))
    return result


def require_verdict_evidence(
    verdict: Verdict | None,
    required: EvidenceCategory,
    obtained: EvidenceCategory | None,
    *,
    device_kind: DeviceKind,
    evidence_source: EvidenceSource | None,
) -> EvidenceAssessment | None:
    """Gate a run verdict on evidence: PASS/DUT_FAILURE need obtained device evidence of exactly the
    planned category (raises EvidenceTierMismatch). Other verdicts are returned unchecked (None)."""
    if verdict not in VERDICTS_REQUIRING_EVIDENCE:
        return None
    if evidence_source is None:
        raise EvidenceTierMismatch(
            f"verdict {verdict} requires obtained evidence with a recorded evidence_source",
            details={"verdict": str(verdict), "required": required.value},
        )
    return require_evidence(required, obtained, device_kind=device_kind, evidence_source=evidence_source)

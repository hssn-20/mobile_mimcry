"""Validated run lifecycle (CONTRACTS §7, §11) and action status (§6) transitions."""

from __future__ import annotations

from dataclasses import dataclass

from mobilelab.domain.enums import ActionStatus, RunStatus, SideEffectClass
from mobilelab.domain.errors import InvalidTransition, TerminalRecordImmutable

R = RunStatus
A = ActionStatus

RUN_TERMINAL: frozenset[RunStatus] = frozenset({R.COMPLETED, R.FAILED, R.ABORTED})

RUN_TRANSITIONS: dict[RunStatus, frozenset[RunStatus]] = {
    R.CREATED: frozenset({R.PREFLIGHT, R.ABORTED}),
    R.PREFLIGHT: frozenset({R.READY, R.FAILED, R.STOPPING}),
    R.READY: frozenset({R.RUNNING, R.STOPPING}),
    R.RUNNING: frozenset({R.COMPLETED, R.PAUSING, R.STOPPING, R.FAILED}),
    R.PAUSING: frozenset({R.PAUSED, R.STOPPING, R.FAILED}),
    R.PAUSED: frozenset({R.RUNNING, R.STOPPING, R.FAILED}),
    R.STOPPING: frozenset({R.ABORTED}),
    R.COMPLETED: frozenset(),
    R.FAILED: frozenset(),
    R.ABORTED: frozenset(),
}

RUN_RECOVERY_SOURCES: frozenset[RunStatus] = frozenset({R.RUNNING, R.PAUSING})
"""Coordinator restart: a persisted RUNNING or PAUSING run may enter PAUSING as a flagged recovery."""

ACTION_TERMINAL: frozenset[ActionStatus] = frozenset({A.VERIFIED, A.FAILED, A.CANCELLED, A.REJECTED, A.UNRESOLVED})

_PRE_DISPATCH_EXITS = frozenset({A.CANCELLED, A.REJECTED})
ACTION_TRANSITIONS: dict[ActionStatus, frozenset[ActionStatus]] = {
    A.PROPOSED: frozenset({A.VALIDATED}) | _PRE_DISPATCH_EXITS,
    A.VALIDATED: frozenset({A.SCHEDULED}) | _PRE_DISPATCH_EXITS,
    A.SCHEDULED: frozenset({A.PREPARED}) | _PRE_DISPATCH_EXITS,
    A.PREPARED: frozenset({A.DISPATCHED}) | _PRE_DISPATCH_EXITS,
    A.DISPATCHED: frozenset({A.ACKNOWLEDGED, A.UNKNOWN}),
    A.ACKNOWLEDGED: frozenset({A.VERIFIED, A.UNKNOWN, A.FAILED}),
    A.UNKNOWN: frozenset({A.VERIFIED, A.FAILED, A.UNRESOLVED}),
    A.VERIFIED: frozenset(),
    A.FAILED: frozenset(),
    A.CANCELLED: frozenset(),
    A.REJECTED: frozenset(),
    A.UNRESOLVED: frozenset(),
}

POTENTIALLY_EXECUTED: frozenset[ActionStatus] = frozenset({A.DISPATCHED, A.ACKNOWLEDGED, A.UNKNOWN})
"""Statuses that must be reconciled as potentially executed after restart; never replayed automatically."""


@dataclass(frozen=True, slots=True)
class RunTransition:
    source: RunStatus
    target: RunStatus
    recovery: bool = False


def can_transition_run(source: RunStatus, target: RunStatus, *, recovery: bool = False) -> bool:
    if recovery:
        return target is R.PAUSING and source in RUN_RECOVERY_SOURCES
    return target in RUN_TRANSITIONS[source]


def transition_run(source: RunStatus, target: RunStatus, *, recovery: bool = False) -> RunTransition:
    """Validate a lifecycle transition. Raises TerminalRecordImmutable / InvalidTransition."""
    if source in RUN_TERMINAL:
        raise TerminalRecordImmutable(
            f"run is terminal ({source}); lifecycle cannot change",
            details={"from": source.value, "to": target.value},
            current_state={"status": source.value},
        )
    if not can_transition_run(source, target, recovery=recovery):
        raise InvalidTransition(
            f"run transition {source} -> {target}{' (recovery)' if recovery else ''} is not allowed",
            details={"from": source.value, "to": target.value, "recovery": recovery},
            current_state={"status": source.value},
        )
    return RunTransition(source, target, recovery)


def can_transition_action(source: ActionStatus, target: ActionStatus) -> bool:
    return target in ACTION_TRANSITIONS[source]


def transition_action(source: ActionStatus, target: ActionStatus) -> ActionStatus:
    if not can_transition_action(source, target):
        raise InvalidTransition(
            f"action transition {source} -> {target} is not allowed",
            details={"from": source.value, "to": target.value},
            current_state={"status": source.value},
        )
    return target


def auto_retry_permitted(status: ActionStatus, side_effect: SideEffectClass) -> bool:
    """Whether trusted code may re-attempt an action automatically.

    Never for a possibly-executed action (DISPATCHED/ACKNOWLEDGED/UNKNOWN) or UNRESOLVED/VERIFIED.
    Pre-dispatch rejections/cancellations never reached the device. A definite FAILED may be retried
    only for side-effect-free or navigation actions; commits/text entry need a fresh decision.
    """
    if status in {A.REJECTED, A.CANCELLED}:
        return True
    if status is A.FAILED:
        return side_effect in {SideEffectClass.NONE, SideEffectClass.NAVIGATION}
    return False

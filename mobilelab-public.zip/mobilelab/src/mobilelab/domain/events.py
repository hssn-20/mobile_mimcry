"""Durable events (CONTRACTS §2, §10): a union discriminated on ``type`` with typed, versioned payloads.

``event_id`` is DB-assigned and serialized as a decimal string for SSE (``sse_id``). Payload models are
the wire shape for ``payload_version`` 1; a breaking payload change needs a new payload version.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field, TypeAdapter

from mobilelab.domain.base import FrozenModel, ShortStr, UtcDatetime
from mobilelab.domain.control import GateState
from mobilelab.domain.enums import (
    ActionKind,
    ActionStatus,
    CommandKind,
    CommandStatus,
    EventType,
    EvidenceSource,
    ExecutionStatus,
    RunStatus,
    Verdict,
)
from mobilelab.domain.runs import Lease

# -- payloads -----------------------------------------------------------------------------------


class RunStatusChangedPayload(FrozenModel):
    from_status: RunStatus | None
    """None when the run was created."""
    to_status: RunStatus
    recovery: bool = False
    reason: str | None = Field(default=None, max_length=2000)
    control_epoch: int = Field(default=0, ge=0)
    verdict: Verdict | None = None
    version: int = Field(ge=1)


class ActionStatusChangedPayload(FrozenModel):
    from_status: ActionStatus | None
    """None when the action was journaled."""
    to_status: ActionStatus
    kind: ActionKind
    version: int = Field(ge=1)


class AttemptRecordedPayload(FrozenModel):
    attempt_id: UUID
    attempt_no: int = Field(ge=1)
    status: ExecutionStatus


class ObservationCapturedPayload(FrozenModel):
    observation_id: UUID
    evidence_source: EvidenceSource
    foreground_app: str | None = Field(default=None, max_length=255)
    candidate_count: int = Field(ge=0)


class OracleResultPayload(FrozenModel):
    oracle_result_id: UUID
    verdict: Verdict
    reason_code: ShortStr


class CommandUpdatedPayload(FrozenModel):
    command_id: UUID
    kind: CommandKind
    status: CommandStatus


class DeviceUpdatedPayload(FrozenModel):
    version: int = Field(ge=1)


class ArtifactCreatedPayload(FrozenModel):
    artifact_id: UUID
    content_type: ShortStr


class ResyncRequiredPayload(FrozenModel):
    reason: str = Field(max_length=2000)
    oldest_event_id: int | None = Field(default=None, ge=1)
    newest_event_id: int | None = Field(default=None, ge=1)


# -- events -------------------------------------------------------------------------------------


class EventBase(FrozenModel):
    event_id: int = Field(ge=1)
    timestamp: UtcDatetime
    run_id: UUID | None = None
    device_id: UUID | None = None
    action_id: UUID | None = None
    payload_version: Literal[1] = 1

    @property
    def sse_id(self) -> str:
        return str(self.event_id)


class RunStatusChangedEvent(EventBase):
    type: Literal[EventType.RUN_STATUS_CHANGED]
    payload: RunStatusChangedPayload


class ActionStatusChangedEvent(EventBase):
    type: Literal[EventType.ACTION_STATUS_CHANGED]
    payload: ActionStatusChangedPayload


class AttemptRecordedEvent(EventBase):
    type: Literal[EventType.ATTEMPT_RECORDED]
    payload: AttemptRecordedPayload


class LeaseAcquiredEvent(EventBase):
    type: Literal[EventType.LEASE_ACQUIRED]
    payload: Lease


class LeaseReleasedEvent(EventBase):
    type: Literal[EventType.LEASE_RELEASED]
    payload: Lease


class GateChangedEvent(EventBase):
    type: Literal[EventType.GATE_CHANGED]
    payload: GateState


class ObservationCapturedEvent(EventBase):
    type: Literal[EventType.OBSERVATION_CAPTURED]
    payload: ObservationCapturedPayload


class OracleResultEvent(EventBase):
    type: Literal[EventType.ORACLE_RESULT]
    payload: OracleResultPayload


class CommandUpdatedEvent(EventBase):
    type: Literal[EventType.COMMAND_UPDATED]
    payload: CommandUpdatedPayload


class DeviceUpdatedEvent(EventBase):
    type: Literal[EventType.DEVICE_UPDATED]
    payload: DeviceUpdatedPayload


class ArtifactCreatedEvent(EventBase):
    type: Literal[EventType.ARTIFACT_CREATED]
    payload: ArtifactCreatedPayload


class ResyncRequiredEvent(EventBase):
    type: Literal[EventType.RESYNC_REQUIRED]
    payload: ResyncRequiredPayload


Event = Annotated[
    RunStatusChangedEvent
    | ActionStatusChangedEvent
    | AttemptRecordedEvent
    | LeaseAcquiredEvent
    | LeaseReleasedEvent
    | GateChangedEvent
    | ObservationCapturedEvent
    | OracleResultEvent
    | CommandUpdatedEvent
    | DeviceUpdatedEvent
    | ArtifactCreatedEvent
    | ResyncRequiredEvent,
    Field(discriminator="type"),
]

EVENT_ADAPTER: TypeAdapter[Event] = TypeAdapter(Event)

EVENT_PAYLOAD_MODELS: dict[EventType, type[BaseModel]] = {
    EventType.RUN_STATUS_CHANGED: RunStatusChangedPayload,
    EventType.ACTION_STATUS_CHANGED: ActionStatusChangedPayload,
    EventType.ATTEMPT_RECORDED: AttemptRecordedPayload,
    EventType.LEASE_ACQUIRED: Lease,
    EventType.LEASE_RELEASED: Lease,
    EventType.GATE_CHANGED: GateState,
    EventType.OBSERVATION_CAPTURED: ObservationCapturedPayload,
    EventType.ORACLE_RESULT: OracleResultPayload,
    EventType.COMMAND_UPDATED: CommandUpdatedPayload,
    EventType.DEVICE_UPDATED: DeviceUpdatedPayload,
    EventType.ARTIFACT_CREATED: ArtifactCreatedPayload,
    EventType.RESYNC_REQUIRED: ResyncRequiredPayload,
}
assert set(EVENT_PAYLOAD_MODELS) == set(EventType), "every EventType needs a payload model"


def validate_event_payload(type: EventType, payload: BaseModel | dict[str, Any]) -> dict[str, Any]:
    """Validate ``payload`` against the type's payload model; return its JSON-mode dict for storage."""
    model = EVENT_PAYLOAD_MODELS[type]
    plain = payload.model_dump(mode="json") if isinstance(payload, BaseModel) else payload
    return model.model_validate(plain).model_dump(mode="json")

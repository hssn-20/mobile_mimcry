"""Persona configuration matching examples/personas.json (CONTRACTS §8, SPEC §8)."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import Field, model_validator

from mobilelab.domain.base import FrozenModel, Identifier, ShortStr

RandomStream = Literal["activity", "timing", "content", "faults"]


class DurationDistribution(FrozenModel):
    """Log-normal (median_seconds, sigma_log) clamped to [min_seconds, max_seconds]."""

    median_seconds: float = Field(gt=0)
    sigma_log: float = Field(ge=0)
    min_seconds: float = Field(ge=0)
    max_seconds: float = Field(gt=0)

    @model_validator(mode="after")
    def _ordered(self) -> Self:
        if not self.min_seconds <= self.median_seconds <= self.max_seconds:
            raise ValueError("require min_seconds <= median_seconds <= max_seconds")
        return self


class PersonaConfig(FrozenModel):
    persona_id: Identifier
    version: int = Field(ge=1)
    label: ShortStr
    activity_weights: dict[Identifier, float] = Field(min_length=1)
    reading_dwell: DurationDistribution
    reply_delay: DurationDistribution
    typing_characters_per_second: float = Field(gt=0, le=50)
    finish_current_task_probability: float = Field(ge=0, le=1)
    max_session_seconds: int = Field(gt=0)

    @model_validator(mode="after")
    def _weights(self) -> Self:
        if any(w < 0 for w in self.activity_weights.values()):
            raise ValueError("activity weights must be non-negative")
        if sum(self.activity_weights.values()) <= 0:
            raise ValueError("activity weights must have a positive sum")
        return self


class SamplingRules(FrozenModel):
    activity_selection: str
    duration_distribution: str
    random_streams: list[RandomStream]
    typing_measurement: str


class PersonaCatalog(FrozenModel):
    """Whole-file schema of examples/personas.json."""

    schema_version: Literal[1] = 1
    purpose: str = ""
    calibration_status: Literal["synthetic_unvalidated", "calibrated"] = "synthetic_unvalidated"
    sampling_rules: SamplingRules
    personas: list[PersonaConfig] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique(self) -> Self:
        keys = [(p.persona_id, p.version) for p in self.personas]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate persona_id/version")
        return self

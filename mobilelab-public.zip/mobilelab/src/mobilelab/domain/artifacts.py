"""Artifact metadata (CONTRACTS §11). Paths are relative to the artifact root; never absolute."""

from __future__ import annotations

from uuid import UUID

from pydantic import Field

from mobilelab.domain.base import PersistedModel
from mobilelab.domain.enums import EvidenceSource


class ArtifactMetadata(PersistedModel):
    artifact_id: UUID
    run_id: UUID | None = None
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    size_bytes: int = Field(ge=0)
    content_type: str = Field(min_length=1, max_length=128, pattern=r"^[\w.+-]+/[\w.+-]+$")
    relative_path: str = Field(min_length=1, max_length=1024)
    evidence_source: EvidenceSource

"""Decision-provider inputs (CONTRACTS §5). Providers never receive worker handles or DB access."""

from __future__ import annotations

import asyncio
from typing import Annotated, Literal
from uuid import UUID

from pydantic import ConfigDict, Field
from pydantic.json_schema import SkipJsonSchema

from mobilelab.domain.base import FrozenModel, Identifier, PersistedModel, ShortStr, StrictModel, UtcDatetime
from mobilelab.domain.enums import ActionKind, ActionStatus
from mobilelab.domain.errors import ErrorEnvelope
from mobilelab.domain.personas import PersonaConfig
from mobilelab.domain.proposals import ProposedAction


class HistoryEntry(FrozenModel):
    at: UtcDatetime
    kind: ActionKind
    semantic_key: ShortStr
    status: ActionStatus
    summary: str = Field(default="", max_length=500)


class DecisionContext(FrozenModel):
    run_id: UUID
    persona: PersonaConfig
    scenario_id: Identifier
    scenario_version: int = Field(ge=1)
    scenario_stage: ShortStr
    goal: str = Field(max_length=4000)
    session_history: list[HistoryEntry] = Field(default_factory=list, max_length=10)
    authorized_app_ids: list[str] = Field(default_factory=list)
    authorized_contact_ids: list[str] = Field(default_factory=list)
    authorized_url_origins: list[str] = Field(default_factory=list)
    control_epoch: int = Field(ge=0)


class DecisionBudget(StrictModel):
    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    timeout_ms: int = Field(ge=1, le=600_000)
    max_input_tokens: int = Field(ge=1)
    max_output_tokens: int = Field(ge=1)
    max_cost_usd: float = Field(ge=0)
    cancel_event: Annotated[asyncio.Event | None, SkipJsonSchema()] = Field(default=None, exclude=True)
    """Cancellation signal; set by the coordinator on pause/stop/epoch change."""

    @property
    def cancelled(self) -> bool:
        return self.cancel_event is not None and self.cancel_event.is_set()


class DecisionRecord(PersistedModel):
    """Persisted provider outcome. Provider errors are stored here, separately from device failures."""

    decision_id: UUID
    run_id: UUID
    decision_observation_id: UUID
    provider_id: Identifier
    model_identifier: str | None = Field(default=None, max_length=256)
    control_epoch: int = Field(ge=0)
    outcome: Literal["accepted", "rejected", "discarded_stale", "cancelled", "provider_error"]
    proposal: ProposedAction | None = None
    error: ErrorEnvelope | None = None
    latency_ms: float | None = Field(default=None, ge=0)

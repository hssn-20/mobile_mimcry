"""Canonical domain schemas and state transitions (docs/CONTRACTS.md)."""

from mobilelab.domain.actions import (
    ACTION_PAYLOAD_ADAPTER,
    Activate,
    ActionPayload,
    EndCall,
    NavigateUrl,
    OpenApp,
    Scroll,
    SendMessage,
    StartCall,
    TypeText,
    Wait,
)
from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.base import FrozenModel, PersistedModel, StrictModel, UtcDatetime, utc_now
from mobilelab.domain.control import ControlCommand, DeviceFenceStatus, EmergencyStopResult, GateState
from mobilelab.domain.decisions import DecisionBudget, DecisionContext, DecisionRecord, HistoryEntry
from mobilelab.domain.devices import (
    CapabilityRecord,
    CapabilityReport,
    CloseResult,
    DeviceHealth,
    DeviceProfile,
    DisplayGeometry,
    FenceResult,
)
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, DispatchCommand, ExecutionResult
from mobilelab.domain.enums import *  # noqa: F403
from mobilelab.domain.errors import *  # noqa: F403
from mobilelab.domain.events import EVENT_ADAPTER, EVENT_PAYLOAD_MODELS, Event, EventBase, validate_event_payload
from mobilelab.domain.evidence import (
    VERDICTS_REQUIRING_EVIDENCE,
    EvidenceAssessment,
    assess_evidence,
    require_evidence,
    require_verdict_evidence,
)
from mobilelab.domain.hashing import canonical_json, config_hash
from mobilelab.domain.observations import (
    Bounds,
    CandidateAction,
    CoordinateSpace,
    Observation,
    ObserveRequest,
    PermittedParameters,
    Precondition,
    UIElement,
)
from mobilelab.domain.personas import DurationDistribution, PersonaCatalog, PersonaConfig, SamplingRules
from mobilelab.domain.proposals import ProposalParameters, ProposedAction, payload_from_candidate
from mobilelab.domain.runs import Campaign, ConfigRevision, Lease, Run, RunSpec
from mobilelab.domain.scenarios import Disturbance, OracleDefinition, OracleResult, ScenarioSpec
from mobilelab.domain.transitions import (
    ACTION_TRANSITIONS,
    RUN_TRANSITIONS,
    RunTransition,
    auto_retry_permitted,
    transition_action,
    transition_run,
)

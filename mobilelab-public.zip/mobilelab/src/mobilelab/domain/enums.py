"""Canonical enumerations (docs/CONTRACTS.md §2-§9). Values are wire values; do not rename."""

from __future__ import annotations

from enum import StrEnum


class RunStatus(StrEnum):
    CREATED = "CREATED"
    PREFLIGHT = "PREFLIGHT"
    READY = "READY"
    RUNNING = "RUNNING"
    PAUSING = "PAUSING"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"


class Verdict(StrEnum):
    PASS = "PASS"
    DUT_FAILURE = "DUT_FAILURE"
    HARNESS_FAILURE = "HARNESS_FAILURE"
    ENVIRONMENT_FAILURE = "ENVIRONMENT_FAILURE"
    INCONCLUSIVE = "INCONCLUSIVE"
    UNSUPPORTED = "UNSUPPORTED"


class ActionStatus(StrEnum):
    PROPOSED = "PROPOSED"
    VALIDATED = "VALIDATED"
    SCHEDULED = "SCHEDULED"
    PREPARED = "PREPARED"
    DISPATCHED = "DISPATCHED"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    VERIFIED = "VERIFIED"
    UNKNOWN = "UNKNOWN"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    UNRESOLVED = "UNRESOLVED"


class EvidenceCategory(StrEnum):
    """Primary evidence tier (§9). Categories are not interchangeable quality levels."""

    FIXTURE = "fixture"
    OS_SIMULATION = "os_simulation"
    PHYSICAL_IP = "physical_ip"
    PHYSICAL_CARRIER = "physical_carrier"


class EvidenceSource(StrEnum):
    """Where a piece of evidence actually came from. Only ``device`` evidence can satisfy a scenario."""

    DEVICE = "device"
    MOCK = "mock"
    REPLAY = "replay"


class DeviceKind(StrEnum):
    SIMULATOR = "simulator"
    EMULATOR = "emulator"
    PHYSICAL = "physical"


class Platform(StrEnum):
    IOS = "ios"
    ANDROID = "android"


class CapabilityStatus(StrEnum):
    SUPPORTED = "supported"
    UNSUPPORTED = "unsupported"
    UNVERIFIED = "unverified"


class CapabilityKey(StrEnum):
    OBSERVE_UI = "observe_ui"
    CAPTURE_SCREEN = "capture_screen"
    ACTIVATE_ELEMENT = "activate_element"
    TYPE_TEXT = "type_text"
    SCROLL = "scroll"
    SWITCH_APP = "switch_app"
    SAFARI_BROWSE = "safari_browse"
    FIXTURE_MESSAGE = "fixture_message"
    FIXTURE_INCOMING_NOTIFICATION = "fixture_incoming_notification"
    OS_SMS = "os_sms"
    CARRIER_SMS = "carrier_sms"
    CARRIER_VOICE = "carrier_voice"
    IP_CONNECTIVITY = "ip_connectivity"
    VPN_EXIT_SELECTION = "vpn_exit_selection"
    NETWORK_DISRUPTION = "network_disruption"
    DEVICE_LOGS = "device_logs"


class SideEffectClass(StrEnum):
    NONE = "none"
    NAVIGATION = "navigation"
    TEXT_ENTRY = "text_entry"
    NON_IDEMPOTENT_COMMIT = "non_idempotent_commit"


class LeaseKind(StrEnum):
    AUTOMATION = "automation"
    OPERATOR = "operator"


class LeaseStatus(StrEnum):
    ACTIVE = "active"
    RELEASED = "released"
    REVOKED = "revoked"


class ActionKind(StrEnum):
    ACTIVATE = "activate"
    TYPE_TEXT = "type_text"
    SCROLL = "scroll"
    OPEN_APP = "open_app"
    NAVIGATE_URL = "navigate_url"
    WAIT = "wait"
    SEND_MESSAGE = "send_message"
    START_CALL = "start_call"
    END_CALL = "end_call"


class TypingMode(StrEnum):
    FIELD_SET = "field_set"
    PACED_TEXT = "paced_text"
    KEYBOARD_TOUCH = "keyboard_touch"


class ScrollDirection(StrEnum):
    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"


class Orientation(StrEnum):
    PORTRAIT = "portrait"
    PORTRAIT_UPSIDE_DOWN = "portrait_upside_down"
    LANDSCAPE_LEFT = "landscape_left"
    LANDSCAPE_RIGHT = "landscape_right"
    UNKNOWN = "unknown"


class ExecutionStatus(StrEnum):
    """Worker-side outcome of one command attempt (maps onto ActionStatus by the coordinator)."""

    ACKNOWLEDGED = "acknowledged"  # driver call returned; not proof of end-to-end outcome
    REJECTED = "rejected"  # refused before any driver call (stale lease/epoch/observation, gate)
    UNKNOWN = "unknown"  # possible execution; outcome undetermined
    FAILED = "failed"  # observation proves non-execution or a definite failure


class CommandKind(StrEnum):
    PREFLIGHT = "preflight"
    START = "start"
    PAUSE = "pause"
    RESUME = "resume"
    STOP = "stop"
    TAKEOVER = "takeover"
    EMERGENCY_STOP = "emergency_stop"
    DISCOVER = "discover"


class CommandStatus(StrEnum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class ConfigKind(StrEnum):
    PERSONA = "persona"
    SCENARIO = "scenario"
    PROVIDER = "provider"


class EventType(StrEnum):
    RUN_STATUS_CHANGED = "run.status_changed"
    ACTION_STATUS_CHANGED = "action.status_changed"
    ATTEMPT_RECORDED = "action.attempt_recorded"
    LEASE_ACQUIRED = "lease.acquired"
    LEASE_RELEASED = "lease.released"
    GATE_CHANGED = "gate.changed"
    OBSERVATION_CAPTURED = "observation.captured"
    ORACLE_RESULT = "oracle.result"
    COMMAND_UPDATED = "command.updated"
    DEVICE_UPDATED = "device.updated"
    ARTIFACT_CREATED = "artifact.created"
    RESYNC_REQUIRED = "resync_required"


class CleanupPolicy(StrEnum):
    FIXTURE_ONLY = "fixture_only"
    NONE = "none"


__all__ = [
    "ActionKind",
    "ActionStatus",
    "CapabilityKey",
    "CapabilityStatus",
    "CleanupPolicy",
    "CommandKind",
    "CommandStatus",
    "ConfigKind",
    "DeviceKind",
    "EventType",
    "EvidenceCategory",
    "EvidenceSource",
    "ExecutionStatus",
    "LeaseKind",
    "LeaseStatus",
    "Orientation",
    "Platform",
    "RunStatus",
    "ScrollDirection",
    "SideEffectClass",
    "TypingMode",
    "Verdict",
]

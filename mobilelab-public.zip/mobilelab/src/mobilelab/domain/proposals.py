"""Provider proposals and their trusted transformation into executor payloads (CONTRACTS §4-§5)."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from pydantic import Field, StrictBool, StrictInt, StrictStr

from mobilelab.domain.actions import (
    MAX_TEXT_LENGTH,
    MAX_URL_LENGTH,
    MAX_WAIT_MS,
    Activate,
    ActionPayload,
    AppId,
    EndCall,
    NavigateUrl,
    OpenApp,
    Scroll,
    SendMessage,
    StartCall,
    TypeText,
    Wait,
    url_origin,
)
from mobilelab.domain.base import StrictModel
from mobilelab.domain.enums import ActionKind, ScrollDirection, TypingMode
from mobilelab.domain.errors import CandidateNotFound, InvalidParameters
from mobilelab.domain.observations import CandidateAction


class ProposalParameters(StrictModel):
    """Parameters a provider may choose; which ones are allowed depends on the candidate."""

    text: StrictStr | None = Field(default=None, min_length=1, max_length=MAX_TEXT_LENGTH)
    typing_mode: TypingMode | None = None
    direction: ScrollDirection | None = None
    url: StrictStr | None = Field(default=None, max_length=MAX_URL_LENGTH)
    app_id: AppId | None = None
    duration_ms: StrictInt | None = Field(default=None, ge=1, le=MAX_WAIT_MS)


class ProposedAction(StrictModel):
    schema_version: Literal[1] = 1
    decision_id: UUID
    decision_observation_id: UUID
    candidate_id: UUID
    parameters: ProposalParameters = Field(default_factory=ProposalParameters)
    reason_code: StrictStr = Field(min_length=1, max_length=64, pattern=r"^[A-Z][A-Z0-9_]*$")
    completion: StrictBool = False
    """Hint to request oracle evaluation only; never completes a run or sets a verdict."""
    explanation: StrictStr | None = Field(default=None, max_length=1000)
    """Optional diagnostic; never dispatch authority."""
    control_epoch: StrictInt | None = Field(default=None, ge=0)
    """Echo of the request's control epoch; late results with a stale epoch are discarded."""


_ALLOWED_PARAMS: dict[ActionKind, frozenset[str]] = {
    ActionKind.ACTIVATE: frozenset(),
    ActionKind.TYPE_TEXT: frozenset({"text", "typing_mode"}),
    ActionKind.SCROLL: frozenset({"direction"}),
    ActionKind.OPEN_APP: frozenset({"app_id"}),
    ActionKind.NAVIGATE_URL: frozenset({"url"}),
    ActionKind.WAIT: frozenset({"duration_ms"}),
    ActionKind.SEND_MESSAGE: frozenset(),
    ActionKind.START_CALL: frozenset(),
    ActionKind.END_CALL: frozenset(),
}


def _bad(msg: str, **details: object) -> InvalidParameters:
    return InvalidParameters(msg, details={k: str(v) for k, v in details.items()})


def _pick[T](value: T | None, allowed: list[T], name: str) -> T:
    if value is None:
        if len(allowed) == 1:
            return allowed[0]
        raise _bad(f"{name} is required", allowed=allowed)
    if allowed and value not in allowed:
        raise _bad(f"{name} not permitted for this candidate", value=value, allowed=allowed)
    return value


def payload_from_candidate(
    candidate: CandidateAction,
    proposal: ProposedAction,
    *,
    client_message_id: UUID | None = None,
    call_correlation_id: UUID | None = None,
) -> ActionPayload:
    """Build the executor payload from a candidate plus the provider's permitted parameter choices.

    ``client_message_id`` / ``call_correlation_id`` come from trusted code (fixture draft identity),
    never from the provider.
    """
    if proposal.candidate_id not in {candidate.candidate_id, candidate.rebound_from_candidate_id}:
        raise CandidateNotFound("proposal does not reference this candidate")
    if candidate.rebound_from_candidate_id is None and proposal.decision_observation_id != candidate.observation_id:
        raise CandidateNotFound(
            "candidate was not offered in the proposal's decision observation",
            details={
                "candidate_id": str(candidate.candidate_id),
                "candidate_observation_id": str(candidate.observation_id),
                "decision_observation_id": str(proposal.decision_observation_id),
            },
        )
    params = proposal.parameters
    supplied = {k for k, v in params.model_dump().items() if v is not None}
    extra = supplied - _ALLOWED_PARAMS[candidate.kind]
    if extra:
        raise _bad("parameters not permitted for this action kind", kind=candidate.kind, fields=sorted(extra))
    perm = candidate.permitted
    ref = candidate.target_ref

    match candidate.kind:
        case ActionKind.ACTIVATE:
            assert ref is not None
            return Activate(kind="activate", element_ref=ref)
        case ActionKind.TYPE_TEXT:
            assert ref is not None
            text = params.text
            if text is None:
                if len(perm.allowed_texts) == 1 and not perm.allow_generated_text:
                    text = perm.allowed_texts[0]
                else:
                    raise _bad("text is required")
            if not perm.allow_generated_text and text not in perm.allowed_texts:
                raise _bad("text not in allowed_texts and generated text is not permitted")
            if len(text) > perm.max_text_length:
                raise _bad("text exceeds candidate max_text_length", max=perm.max_text_length)
            mode = _pick(params.typing_mode, perm.typing_modes, "typing_mode")
            return TypeText(kind="type_text", element_ref=ref, text=text, mode=mode)
        case ActionKind.SCROLL:
            direction = _pick(params.direction, perm.scroll_directions, "direction")
            return Scroll(kind="scroll", direction=direction, element_ref=ref)
        case ActionKind.OPEN_APP:
            return OpenApp(kind="open_app", app_id=_pick(params.app_id, perm.app_ids, "app_id"))
        case ActionKind.NAVIGATE_URL:
            if params.url is None:
                raise _bad("url is required")
            nav = NavigateUrl(kind="navigate_url", url=params.url)
            if url_origin(nav.url) not in {url_origin(o) for o in perm.url_origins}:
                raise _bad("url origin not permitted", origin=url_origin(nav.url))
            return nav
        case ActionKind.WAIT:
            if params.duration_ms is None:
                raise _bad("duration_ms is required")
            if params.duration_ms > perm.max_wait_ms:
                raise _bad("duration_ms exceeds candidate max_wait_ms", max=perm.max_wait_ms)
            return Wait(kind="wait", duration_ms=params.duration_ms)
        case ActionKind.SEND_MESSAGE:
            assert ref is not None and perm.contact_id is not None
            if client_message_id is None:
                raise _bad("send_message requires a trusted client_message_id draft identity")
            return SendMessage(
                kind="send_message", element_ref=ref, contact_id=perm.contact_id, client_message_id=client_message_id
            )
        case ActionKind.START_CALL:
            assert ref is not None and perm.contact_id is not None
            if call_correlation_id is None:
                raise _bad("start_call requires a trusted call_correlation_id")
            return StartCall(
                kind="start_call", element_ref=ref, contact_id=perm.contact_id, call_correlation_id=call_correlation_id
            )
        case ActionKind.END_CALL:
            assert ref is not None
            if call_correlation_id is None:
                raise _bad("end_call requires a trusted call_correlation_id")
            return EndCall(kind="end_call", element_ref=ref, call_correlation_id=call_correlation_id)
    raise _bad("unsupported action kind", kind=candidate.kind)  # pragma: no cover

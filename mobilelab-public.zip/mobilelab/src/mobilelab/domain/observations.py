"""Observations, normalized UI tree and candidate actions (CONTRACTS §4)."""

from __future__ import annotations

from typing import Literal, Self
from uuid import UUID

from pydantic import Field, model_validator

from mobilelab.domain.actions import MAX_TEXT_LENGTH, MAX_WAIT_MS, AppId, ContactId, ElementRef
from mobilelab.domain.base import PersistedModel, ShortStr, StrictModel, UtcDatetime
from mobilelab.domain.enums import (
    ActionKind,
    CapabilityKey,
    EvidenceSource,
    Orientation,
    ScrollDirection,
    SideEffectClass,
    TypingMode,
)
from mobilelab.domain.errors import CandidateNotFound, StaleObservation

DEFAULT_MAX_CAPTURE_SPAN_MS = 1500
DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS = 2000

_TARGETED_KINDS = {
    ActionKind.ACTIVATE,
    ActionKind.TYPE_TEXT,
    ActionKind.SEND_MESSAGE,
    ActionKind.START_CALL,
    ActionKind.END_CALL,
}
_COMMIT_KINDS = {ActionKind.SEND_MESSAGE, ActionKind.START_CALL, ActionKind.END_CALL}


class Bounds(StrictModel):
    x: float
    y: float
    width: float = Field(ge=0)
    height: float = Field(ge=0)


class CoordinateSpace(StrictModel):
    name: Literal["screenshot_px", "logical_pt"]
    width: float = Field(gt=0)
    height: float = Field(gt=0)
    scale: float = Field(default=1.0, gt=0)


class UIElement(StrictModel):
    """One node of the normalized accessibility tree (flattened; parent_ref links nodes)."""

    element_ref: ElementRef
    parent_ref: ElementRef | None = None
    role: str = Field(max_length=128)
    label: str | None = Field(default=None, max_length=4000)
    value: str | None = Field(default=None, max_length=4000)
    identifier: str | None = Field(default=None, max_length=256)
    bounds: Bounds | None = None
    visible: bool = True
    enabled: bool = True


class Precondition(StrictModel):
    kind: Literal[
        "foreground_app",
        "element_visible",
        "element_enabled",
        "element_value",
        "keyboard_visible",
        "orientation",
    ]
    element_ref: ElementRef | None = None
    expected: str | bool | None = None


class PermittedParameters(StrictModel):
    """What a provider may choose for this candidate. Everything else is fixed by trusted code."""

    allow_generated_text: bool = False
    allowed_texts: list[str] = Field(default_factory=list)
    max_text_length: int = Field(default=MAX_TEXT_LENGTH, ge=1, le=MAX_TEXT_LENGTH)
    typing_modes: list[TypingMode] = Field(default_factory=list)
    scroll_directions: list[ScrollDirection] = Field(default_factory=list)
    url_origins: list[str] = Field(default_factory=list)
    app_ids: list[AppId] = Field(default_factory=list)
    contact_id: ContactId | None = None
    max_wait_ms: int = Field(default=30_000, ge=1, le=MAX_WAIT_MS)


class CandidateAction(StrictModel):
    candidate_id: UUID
    observation_id: UUID
    semantic_key: ShortStr
    kind: ActionKind
    target_ref: ElementRef | None = None
    required_capabilities: list[CapabilityKey] = Field(default_factory=list)
    side_effect_class: SideEffectClass
    preconditions: list[Precondition] = Field(default_factory=list)
    permitted: PermittedParameters = Field(default_factory=PermittedParameters)
    rebound_from_candidate_id: UUID | None = None
    """Set when this candidate was created by rebinding to a fresh observation (audit trail)."""

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        if self.kind in _TARGETED_KINDS and self.target_ref is None:
            raise ValueError(f"{self.kind} candidate requires target_ref")
        if self.kind in {ActionKind.SEND_MESSAGE, ActionKind.START_CALL} and self.permitted.contact_id is None:
            raise ValueError(f"{self.kind} candidate requires an allowlisted permitted.contact_id")
        if self.kind not in {ActionKind.SEND_MESSAGE, ActionKind.START_CALL} and self.permitted.contact_id:
            raise ValueError("only send_message/start_call candidates may carry a contact_id")
        is_commit = self.side_effect_class is SideEffectClass.NON_IDEMPOTENT_COMMIT
        if self.kind in _COMMIT_KINDS and not is_commit:
            raise ValueError(f"{self.kind} must be classified non_idempotent_commit")
        if is_commit and self.kind not in _COMMIT_KINDS:
            # A consequential control must use a semantic kind (or stay non-executable until an app
            # profile defines its semantics); a generic activate must not bypass commit checks (§4).
            raise ValueError(f"non_idempotent_commit candidates must use a semantic kind, not {self.kind}")
        if self.kind is ActionKind.TYPE_TEXT and not self.permitted.typing_modes:
            raise ValueError("type_text candidate requires at least one permitted typing mode")
        if self.kind is ActionKind.TYPE_TEXT and not (self.permitted.allow_generated_text or self.permitted.allowed_texts):
            raise ValueError("type_text candidate must allow generated text or list allowed_texts")
        if self.kind is ActionKind.NAVIGATE_URL and not self.permitted.url_origins:
            raise ValueError("navigate_url candidate requires permitted url_origins")
        if self.kind is ActionKind.OPEN_APP and not self.permitted.app_ids:
            raise ValueError("open_app candidate requires permitted app_ids")
        return self


class Observation(PersistedModel):
    observation_id: UUID
    run_id: UUID | None = None
    device_id: UUID
    session_id: UUID
    evidence_source: EvidenceSource
    capture_started_at: UtcDatetime
    capture_ended_at: UtcDatetime
    screenshot_captured_at: UtcDatetime | None = None
    tree_captured_at: UtcDatetime | None = None
    worker_monotonic_capture_ns: int = Field(ge=0)
    """Worker-local monotonic clock at capture end. Only comparable within the same worker process."""
    foreground_app: str | None = Field(default=None, max_length=255)
    orientation: Orientation = Orientation.UNKNOWN
    coordinate_spaces: list[CoordinateSpace] = Field(default_factory=list)
    screenshot_artifact_id: UUID | None = None
    ui_tree: list[UIElement] = Field(default_factory=list)
    candidates: list[CandidateAction] = Field(default_factory=list)
    keyboard_visible: bool = False

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        if self.capture_ended_at < self.capture_started_at:
            raise ValueError("capture_ended_at precedes capture_started_at")
        refs = [e.element_ref for e in self.ui_tree]
        if len(refs) != len(set(refs)):
            raise ValueError("duplicate element_ref in ui_tree")
        ids = [c.candidate_id for c in self.candidates]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate candidate_id")
        for c in self.candidates:
            if c.observation_id != self.observation_id:
                raise ValueError("candidate observation_id does not match observation")
        return self

    @property
    def capture_span_ms(self) -> float:
        return (self.capture_ended_at - self.capture_started_at).total_seconds() * 1000.0

    def check_capture_consistency(self, limit_ms: int = DEFAULT_MAX_CAPTURE_SPAN_MS) -> None:
        if self.capture_span_ms > limit_ms:
            raise StaleObservation(
                "observation capture span exceeds consistency limit",
                details={"capture_span_ms": self.capture_span_ms, "limit_ms": limit_ms},
            )

    def check_fresh(
        self, worker_now_ns: int, max_age_ms: int = DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS
    ) -> None:
        """Freshness on the *same worker's* monotonic clock (never compare across processes)."""
        age_ms = (worker_now_ns - self.worker_monotonic_capture_ns) / 1_000_000
        if age_ms < 0 or age_ms > max_age_ms:
            raise StaleObservation(
                "observation too old for dispatch",
                details={"age_ms": age_ms, "max_age_ms": max_age_ms},
            )

    def candidate(self, candidate_id: UUID) -> CandidateAction:
        for c in self.candidates:
            if c.candidate_id == candidate_id:
                return c
        raise CandidateNotFound(
            "candidate not offered in this observation",
            details={"candidate_id": str(candidate_id), "observation_id": str(self.observation_id)},
        )

    def element(self, element_ref: str) -> UIElement | None:
        return next((e for e in self.ui_tree if e.element_ref == element_ref), None)


class ObserveRequest(StrictModel):
    request_id: UUID
    run_id: UUID | None = None
    device_id: UUID
    session_id: UUID
    lease_id: UUID
    lease_epoch: int = Field(ge=1)
    purpose: Literal["decision", "dispatch", "oracle", "preflight", "resume"] = "decision"
    include_screenshot: bool = True
    max_capture_span_ms: int = Field(default=DEFAULT_MAX_CAPTURE_SPAN_MS, ge=1, le=60_000)

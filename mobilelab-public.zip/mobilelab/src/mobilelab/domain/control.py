"""Dispatch gate, asynchronous control commands and emergency-stop results (CONTRACTS §7, §10)."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from pydantic import Field, JsonValue

from mobilelab.domain.base import PersistedModel, StrictModel, UtcDatetime
from mobilelab.domain.enums import CommandKind, CommandStatus
from mobilelab.domain.errors import ErrorEnvelope


class GateState(StrictModel):
    """Global dispatch gate. Closed on emergency stop and on coordinator restart."""

    schema_version: Literal[1] = 1
    gate_open: bool
    global_epoch: int = Field(ge=0)
    reason: str | None = Field(default=None, max_length=2000)
    updated_at: UtcDatetime
    version: int = Field(ge=1)


class ControlCommand(PersistedModel):
    command_id: UUID
    kind: CommandKind
    run_id: UUID | None = None
    device_id: UUID | None = None
    status: CommandStatus = CommandStatus.PENDING
    result: dict[str, JsonValue] = Field(default_factory=dict)
    error: ErrorEnvelope | None = None
    updated_at: UtcDatetime | None = None


class DeviceFenceStatus(StrictModel):
    device_id: UUID
    fenced: bool
    acknowledged_at: UtcDatetime | None = None
    in_flight_command_id: UUID | None = None
    in_flight_state: Literal["none", "executing", "unknown"] = "none"


class EmergencyStopResult(StrictModel):
    schema_version: Literal[1] = 1
    command_id: UUID
    global_epoch: int = Field(ge=0)
    gate_persisted_at: UtcDatetime
    fence_acknowledged_at: UtcDatetime | None = None
    fully_fenced: bool
    devices: list[DeviceFenceStatus] = Field(default_factory=list)

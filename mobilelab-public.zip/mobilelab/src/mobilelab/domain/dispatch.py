"""Dispatch commands, worker execution results and the durable action journal (CONTRACTS §6, §8)."""

from __future__ import annotations

from typing import Literal, Self
from uuid import UUID

from pydantic import Field, model_validator

from mobilelab.domain.actions import ActionPayload, EndCall, SendMessage, StartCall
from mobilelab.domain.base import FrozenModel, PersistedModel, ShortStr, UtcDatetime, utc_now
from mobilelab.domain.enums import (
    ActionKind,
    ActionStatus,
    EvidenceSource,
    ExecutionStatus,
    SideEffectClass,
    TypingMode,
)
from mobilelab.domain.errors import ErrorCode, ErrorEnvelope
from mobilelab.domain.observations import DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS


class DispatchCommand(FrozenModel):
    schema_version: Literal[1] = 1
    command_id: UUID
    action_id: UUID
    run_id: UUID
    device_id: UUID
    session_id: UUID
    lease_id: UUID
    lease_epoch: int = Field(ge=1)
    control_epoch: int = Field(ge=0)
    dispatch_observation_id: UUID
    dispatch_candidate_id: UUID
    payload: ActionPayload
    max_duration_ms: int = Field(ge=1, le=600_000)
    max_observation_age_ms: int = Field(default=DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS, ge=1, le=10_000)
    trace_id: ShortStr
    issued_at: UtcDatetime = Field(default_factory=utc_now)


class ExecutionResult(FrozenModel):
    schema_version: Literal[1] = 1
    command_id: UUID
    action_id: UUID
    device_id: UUID
    status: ExecutionStatus
    evidence_source: EvidenceSource
    started_at: UtcDatetime | None = None
    ended_at: UtcDatetime | None = None
    duration_ms: float | None = Field(default=None, ge=0)
    typing_mode_actual: TypingMode | None = None
    rejection_code: ErrorCode | None = None
    error: ErrorEnvelope | None = None
    detail: str = Field(default="", max_length=4000)

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        if self.status is ExecutionStatus.REJECTED and self.rejection_code is None:
            raise ValueError("rejected execution requires rejection_code")
        if self.status is not ExecutionStatus.REJECTED and self.started_at is None:
            raise ValueError("a non-rejected execution must record started_at")
        return self


_COMMIT_KINDS = frozenset({ActionKind.SEND_MESSAGE, ActionKind.START_CALL, ActionKind.END_CALL})

BOUND_ACTION_STATUSES: frozenset[ActionStatus] = frozenset(
    {
        ActionStatus.PREPARED,
        ActionStatus.DISPATCHED,
        ActionStatus.ACKNOWLEDGED,
        ActionStatus.UNKNOWN,
        ActionStatus.VERIFIED,
        ActionStatus.FAILED,
        ActionStatus.UNRESOLVED,
    }
)
"""Statuses at/after PREPARED: the payload and dispatch binding are journaled and immutable from here."""


class ActionRecord(PersistedModel):
    """Semantic action journal entry. Status changes go through transitions.transition_action.

    Invariants: the payload variant matches ``kind``; commit kinds are ``non_idempotent_commit`` (and
    only they are); from PREPARED on, the payload and its dispatch observation/candidate are present;
    the correlation identity equals the payload's client_message_id / call_correlation_id.
    """

    action_id: UUID
    run_id: UUID
    device_id: UUID
    decision_id: UUID | None = None
    kind: ActionKind
    semantic_key: ShortStr
    side_effect_class: SideEffectClass
    status: ActionStatus = ActionStatus.PROPOSED
    decision_observation_id: UUID
    original_candidate_id: UUID
    dispatch_observation_id: UUID | None = None
    dispatch_candidate_id: UUID | None = None
    payload: ActionPayload | None = None
    correlation_id: UUID | None = None
    """client_message_id / call correlation identity used for receipt reconciliation."""
    reject_code: ErrorCode | None = None
    sampled_delay_ms: float | None = Field(default=None, ge=0)
    decision_latency_ms: float | None = Field(default=None, ge=0)
    scheduled_at: UtcDatetime | None = None
    actual_dispatch_at: UtcDatetime | None = None
    timing_overrun_ms: float | None = Field(default=None, ge=0)
    updated_at: UtcDatetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        is_commit = self.side_effect_class is SideEffectClass.NON_IDEMPOTENT_COMMIT
        if (self.kind in _COMMIT_KINDS) != is_commit:
            raise ValueError("send_message/start_call/end_call and only they are non_idempotent_commit actions")
        if self.payload is not None and self.payload.kind != self.kind.value:
            raise ValueError(f"payload kind {self.payload.kind} does not match action kind {self.kind}")
        if self.status in BOUND_ACTION_STATUSES and (
            self.payload is None or self.dispatch_observation_id is None or self.dispatch_candidate_id is None
        ):
            raise ValueError(f"{self.status} action requires payload, dispatch_observation_id and dispatch_candidate_id")
        expected: UUID | None = None
        if isinstance(self.payload, SendMessage):
            expected = self.payload.client_message_id
        elif isinstance(self.payload, (StartCall, EndCall)):
            expected = self.payload.call_correlation_id
        if expected is not None and self.correlation_id != expected:
            raise ValueError("correlation_id must equal the payload's client_message_id / call_correlation_id")
        return self


class AttemptRecord(PersistedModel):
    """One physical attempt of a semantic action. Every attempt is stored independently."""

    attempt_id: UUID
    action_id: UUID
    attempt_no: int = Field(ge=1)
    command_id: UUID
    status: ExecutionStatus | None = None
    started_at: UtcDatetime | None = None
    ended_at: UtcDatetime | None = None
    result: ExecutionResult | None = None

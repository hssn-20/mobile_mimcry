"""Model base classes and shared field types."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Literal

from pydantic import AfterValidator, AwareDatetime, BaseModel, ConfigDict, Field

SCHEMA_VERSION: Literal[1] = 1


def utc_now() -> datetime:
    return datetime.now(UTC)


def _to_utc(value: datetime) -> datetime:
    return value.astimezone(UTC)


UtcDatetime = Annotated[AwareDatetime, AfterValidator(_to_utc)]
"""Timezone-aware timestamp normalised to UTC (naive datetimes are rejected)."""

ShortStr = Annotated[str, Field(min_length=1, max_length=256)]
Identifier = Annotated[str, Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:\-]*$")]
RequirementRef = Annotated[str, Field(pattern=r"^(BR|FR|AC)-\d{2}$")]


class StrictModel(BaseModel):
    """Inbound/domain model: unknown fields are rejected."""

    model_config = ConfigDict(
        extra="forbid",
        validate_default=True,
        # Server-emitted documents always include defaulted fields (used for generated TS types).
        json_schema_serialization_defaults_required=True,
    )


class FrozenModel(StrictModel):
    model_config = ConfigDict(extra="forbid", frozen=True, validate_default=True)


class PersistedModel(StrictModel):
    """Every persisted entity carries schema_version, created_at and an optimistic version."""

    schema_version: Literal[1] = 1
    created_at: UtcDatetime = Field(default_factory=utc_now)
    version: int = Field(default=1, ge=1)

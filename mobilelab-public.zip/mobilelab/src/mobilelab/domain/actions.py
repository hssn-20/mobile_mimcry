"""Executor action payloads (discriminated union over all 9 kinds) — CONTRACTS §4.

Payloads are built by trusted coordinator code from a validated candidate; the provider never
supplies element_ref, contact routing or correlation IDs. Unknown kinds and extra fields are rejected.
"""

from __future__ import annotations

from typing import Annotated, Literal
from urllib.parse import urlsplit
from uuid import UUID

from pydantic import Field, StrictStr, TypeAdapter, field_validator

from mobilelab.domain.base import FrozenModel
from mobilelab.domain.enums import ScrollDirection, TypingMode

ElementRef = Annotated[StrictStr, Field(min_length=1, max_length=256)]
ContactId = Annotated[StrictStr, Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.\-]*$")]
AppId = Annotated[StrictStr, Field(min_length=1, max_length=255, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.\-]*$")]

MAX_TEXT_LENGTH = 2000
MAX_URL_LENGTH = 2048
MAX_WAIT_MS = 600_000


def validate_http_url(value: str) -> str:
    parts = urlsplit(value)
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise ValueError("url must be an absolute http(s) URL")
    if parts.username or parts.password:
        raise ValueError("url must not embed credentials")
    return value


def url_origin(value: str) -> str:
    """Origin ``scheme://host[:port]`` (lower-cased scheme/host) used for allowlisting."""
    parts = urlsplit(value)
    host = (parts.hostname or "").lower()
    port = f":{parts.port}" if parts.port else ""
    return f"{parts.scheme.lower()}://{host}{port}"


class Activate(FrozenModel):
    kind: Literal["activate"]
    element_ref: ElementRef


class TypeText(FrozenModel):
    kind: Literal["type_text"]
    element_ref: ElementRef
    text: StrictStr = Field(min_length=1, max_length=MAX_TEXT_LENGTH)
    mode: TypingMode


class Scroll(FrozenModel):
    kind: Literal["scroll"]
    direction: ScrollDirection
    element_ref: ElementRef | None = None


class OpenApp(FrozenModel):
    kind: Literal["open_app"]
    app_id: AppId


class NavigateUrl(FrozenModel):
    kind: Literal["navigate_url"]
    url: StrictStr = Field(min_length=1, max_length=MAX_URL_LENGTH)

    @field_validator("url")
    @classmethod
    def _check_url(cls, v: str) -> str:
        return validate_http_url(v)


class Wait(FrozenModel):
    kind: Literal["wait"]
    duration_ms: int = Field(ge=1, le=MAX_WAIT_MS, strict=True)


class SendMessage(FrozenModel):
    kind: Literal["send_message"]
    element_ref: ElementRef
    contact_id: ContactId
    client_message_id: UUID


class StartCall(FrozenModel):
    kind: Literal["start_call"]
    element_ref: ElementRef
    contact_id: ContactId
    call_correlation_id: UUID


class EndCall(FrozenModel):
    kind: Literal["end_call"]
    element_ref: ElementRef
    call_correlation_id: UUID


ActionPayload = Annotated[
    Activate | TypeText | Scroll | OpenApp | NavigateUrl | Wait | SendMessage | StartCall | EndCall,
    Field(discriminator="kind"),
]

ACTION_PAYLOAD_ADAPTER: TypeAdapter[ActionPayload] = TypeAdapter(ActionPayload)

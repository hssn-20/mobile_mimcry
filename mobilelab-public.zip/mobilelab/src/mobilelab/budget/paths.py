"""The one persistent location of the development spend ledger (CONTRACTS §11).

The USD cap is global across runs and processes, so the ledger must not depend on the current working
directory or on a per-run ``--db``: it always lives at an absolute, repo-anchored path. A different
path can only be given explicitly (tests use temporary ledgers) and must be absolute.
"""

from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_LEDGER_DB = REPO_ROOT / "artifacts" / "mobilelab.db"


def resolve_ledger_path(path: str | Path | None = None) -> Path:
    """``None`` -> :data:`DEFAULT_LEDGER_DB`; otherwise the path, which must be absolute."""
    if path is None:
        return DEFAULT_LEDGER_DB
    p = Path(path)
    if not p.is_absolute():
        raise ValueError("budget ledger path must be absolute (a relative path would start a new budget per cwd)")
    return p


__all__ = ["DEFAULT_LEDGER_DB", "REPO_ROOT", "resolve_ledger_path"]

"""Persistent provider spend ledger with atomic reservation (CONTRACTS §11, T08).

* Every model request reserves its worst-case cost (frozen rate card x request token limits) *before*
  it is sent, inside one ``BEGIN IMMEDIATE`` SQLite transaction, so concurrent requests and separate
  processes sharing the database can never jointly exceed a cap.
* Caps: a global development cap (hard ceiling :data:`HARD_GLOBAL_CAP_USD`, persistent across runs and
  processes because it is computed from the shared ledger) and a much smaller per-run cap.
* ``confirm`` replaces the reservation with the cost of provider-reported usage. ``mark_unresolved``
  keeps the full reservation counted (timeouts, cancellations, transport errors after send: the
  request may have been billed). ``release`` frees it only when the request provably was not billed.
* A schema-repair retry is a separate request with its own reservation.

Counted spend = confirmed amounts + reserved (in-flight) amounts + unresolved amounts.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Literal
from uuid import UUID, uuid4

from pydantic import Field
from sqlalchemy import Engine, case, func, select, update

from mobilelab.budget.rates import RateCard, TokenUsage, micro_to_usd, usd_to_micro
from mobilelab.domain.base import FrozenModel, utc_now
from mobilelab.domain.errors import ProviderError
from mobilelab.store.engine import READONLY_OPTION, create_sqlite_engine
from mobilelab.store.migrate import upgrade_to_head
from mobilelab.store.models import ProviderUsageRow

HARD_GLOBAL_CAP_USD = 5.00
"""User-mandated hard development spend cap across all runs. Configuration may lower it, never raise it."""
DEFAULT_RUN_CAP_USD = 0.25

UsageStatus = Literal["reserved", "confirmed", "unresolved", "released"]
Purpose = Literal["decision", "repair", "smoke"]


class BudgetExceeded(ProviderError):
    """Reservation refused: the request could push spend past a cap. Nothing was sent."""


class LedgerError(ProviderError):
    """Ledger state transition refused (unknown or already-settled reservation)."""


class Reservation(FrozenModel):
    reservation_id: UUID
    run_id: str | None
    provider_id: str
    model_identifier: str
    purpose: Purpose
    rate_card_id: str
    max_input_tokens: int
    max_output_tokens: int
    reserved_micro_usd: int

    @property
    def reserved_usd(self) -> float:
        return micro_to_usd(self.reserved_micro_usd)


class BudgetSummary(FrozenModel):
    """Spend in USD. ``estimated`` = in-flight reservations; ``unresolved`` = kept after timeout/error."""

    scope: str
    cap_usd: float
    estimated_usd: float = Field(ge=0)
    confirmed_usd: float = Field(ge=0)
    unresolved_usd: float = Field(ge=0)
    committed_usd: float = Field(ge=0)
    remaining_usd: float
    requests: dict[str, int] = Field(default_factory=dict)


class BudgetLedger:
    def __init__(
        self,
        engine: Engine,
        *,
        global_cap_usd: float = HARD_GLOBAL_CAP_USD,
        run_cap_usd: float = DEFAULT_RUN_CAP_USD,
    ) -> None:
        if global_cap_usd <= 0 or run_cap_usd <= 0:
            raise ValueError("caps must be positive")
        self.engine = engine
        self.global_cap_micro = min(usd_to_micro(global_cap_usd), usd_to_micro(HARD_GLOBAL_CAP_USD))
        self.run_cap_micro = min(usd_to_micro(run_cap_usd), self.global_cap_micro)

    @classmethod
    def open(cls, db_path: Path | str, *, migrate: bool = True, **caps: float) -> BudgetLedger:
        engine = create_sqlite_engine(db_path)
        if migrate:
            upgrade_to_head(engine)
        return cls(engine, **caps)

    # ------------------------------------------------------------------ queries
    @staticmethod
    def _committed_expr():  # type: ignore[no-untyped-def]
        return func.coalesce(
            func.sum(
                case(
                    (ProviderUsageRow.status == "confirmed", func.coalesce(ProviderUsageRow.confirmed_micro_usd, 0)),
                    (ProviderUsageRow.status == "released", 0),
                    else_=ProviderUsageRow.reserved_micro_usd,
                )
            ),
            0,
        )

    def _committed(self, conn, run_id: str | None) -> int:  # type: ignore[no-untyped-def]
        stmt = select(self._committed_expr())
        if run_id is not None:
            stmt = stmt.where(ProviderUsageRow.run_id == run_id)
        return int(conn.execute(stmt).scalar_one())

    # ------------------------------------------------------------------ reservation
    def reserve(
        self,
        *,
        run_id: str | None,
        provider_id: str,
        rate_card: RateCard,
        max_input_tokens: int,
        max_output_tokens: int,
        purpose: Purpose = "decision",
        correlation_id: str | None = None,
        max_cost_usd: float | None = None,
    ) -> Reservation:
        if max_input_tokens <= 0 or max_output_tokens <= 0:
            raise BudgetExceeded("token limits must be positive")
        if max_input_tokens > rate_card.max_context_tokens_for_tier:
            raise BudgetExceeded(
                "request input limit exceeds the frozen rate card's pricing tier",
                details={"max_input_tokens": max_input_tokens, "tier_limit": rate_card.max_context_tokens_for_tier},
            )
        amount = rate_card.reservation_micro_usd(max_input_tokens, max_output_tokens)
        if max_cost_usd is not None and amount > usd_to_micro(max_cost_usd):
            raise BudgetExceeded(
                "request reservation exceeds the decision budget's max_cost_usd",
                details={"reservation_usd": micro_to_usd(amount), "max_cost_usd": max_cost_usd},
            )
        now = utc_now()
        rid = uuid4()
        with self.engine.begin() as conn:  # BEGIN IMMEDIATE: check-and-insert is atomic across processes
            global_committed = self._committed(conn, None)
            if global_committed + amount > self.global_cap_micro:
                raise BudgetExceeded(
                    "global development spend cap would be exceeded; request not sent",
                    details={
                        "cap_usd": micro_to_usd(self.global_cap_micro),
                        "committed_usd": micro_to_usd(global_committed),
                        "reservation_usd": micro_to_usd(amount),
                    },
                )
            if run_id is not None:
                run_committed = self._committed(conn, run_id)
                if run_committed + amount > self.run_cap_micro:
                    raise BudgetExceeded(
                        "per-run spend cap would be exceeded; request not sent",
                        details={
                            "run_id": run_id,
                            "cap_usd": micro_to_usd(self.run_cap_micro),
                            "committed_usd": micro_to_usd(run_committed),
                            "reservation_usd": micro_to_usd(amount),
                        },
                    )
            conn.execute(
                ProviderUsageRow.__table__.insert().values(
                    reservation_id=str(rid),
                    run_id=run_id,
                    provider_id=provider_id,
                    model_identifier=rate_card.model,
                    purpose=purpose,
                    status="reserved",
                    rate_card_id=rate_card.rate_card_id,
                    max_input_tokens=max_input_tokens,
                    max_output_tokens=max_output_tokens,
                    reserved_micro_usd=amount,
                    correlation_id=correlation_id,
                    created_at=now,
                    updated_at=now,
                )
            )
        return Reservation(
            reservation_id=rid,
            run_id=run_id,
            provider_id=provider_id,
            model_identifier=rate_card.model,
            purpose=purpose,
            rate_card_id=rate_card.rate_card_id,
            max_input_tokens=max_input_tokens,
            max_output_tokens=max_output_tokens,
            reserved_micro_usd=amount,
        )

    def _settle(self, reservation_id: UUID, *, from_status: tuple[str, ...], values: dict[str, object]) -> None:
        values = {**values, "updated_at": utc_now()}
        with self.engine.begin() as conn:
            res = conn.execute(
                update(ProviderUsageRow.__table__)
                .where(ProviderUsageRow.reservation_id == str(reservation_id))
                .where(ProviderUsageRow.status.in_(from_status))
                .values(**values)
            )
            if res.rowcount != 1:
                raise LedgerError(
                    "reservation is unknown or already settled",
                    details={"reservation_id": str(reservation_id), "allowed_from": list(from_status)},
                )

    def confirm(
        self,
        reservation: Reservation,
        usage: TokenUsage,
        rate_card: RateCard,
        *,
        request_id: str | None = None,
        error_class: str | None = None,
    ) -> int:
        """Record provider-reported usage. Allowed from ``reserved`` or ``unresolved`` (a late answer)."""
        if rate_card.rate_card_id != reservation.rate_card_id:
            raise LedgerError("confirmation must use the reservation's frozen rate card")
        cost = rate_card.usage_micro_usd(usage)
        self._settle(
            reservation.reservation_id,
            from_status=("reserved", "unresolved"),
            values={
                "status": "confirmed",
                "confirmed_micro_usd": cost,
                "input_tokens": usage.input_tokens,
                "cached_input_tokens": usage.cached_input_tokens,
                "output_tokens": usage.output_tokens,
                "reasoning_tokens": usage.reasoning_tokens,
                "request_id": request_id,
                "error_class": error_class,
            },
        )
        return cost

    def mark_unresolved(self, reservation: Reservation, *, error_class: str, request_id: str | None = None) -> None:
        """Timeout/cancel/transport failure after the request may have been sent: keep it reserved."""
        self._settle(
            reservation.reservation_id,
            from_status=("reserved",),
            values={"status": "unresolved", "error_class": error_class[:128], "request_id": request_id},
        )

    def release(self, reservation: Reservation, *, reason: str) -> None:
        """Free a reservation that provably was not billed (never sent, or rejected before generation)."""
        self._settle(
            reservation.reservation_id, from_status=("reserved",), values={"status": "released", "error_class": reason[:128]}
        )

    # ------------------------------------------------------------------ reporting
    def summary(self, run_id: str | None = None) -> BudgetSummary:
        cap = self.global_cap_micro if run_id is None else self.run_cap_micro
        with self.engine.connect().execution_options(**{READONLY_OPTION: True}) as conn:
            stmt = select(
                ProviderUsageRow.status,
                func.count(),
                func.coalesce(func.sum(ProviderUsageRow.reserved_micro_usd), 0),
                func.coalesce(func.sum(ProviderUsageRow.confirmed_micro_usd), 0),
            ).group_by(ProviderUsageRow.status)
            if run_id is not None:
                stmt = stmt.where(ProviderUsageRow.run_id == run_id)
            rows = conn.execute(stmt).all()
            committed = self._committed(conn, run_id)
            global_committed = committed if run_id is None else self._committed(conn, None)
        counts: dict[str, int] = {}
        reserved = confirmed = unresolved = 0
        for status, n, reserved_sum, confirmed_sum in rows:
            counts[status] = int(n)
            if status == "reserved":
                reserved += int(reserved_sum)
            elif status == "unresolved":
                unresolved += int(reserved_sum)
            elif status == "confirmed":
                confirmed += int(confirmed_sum)
        remaining = cap - committed
        if run_id is not None:  # a run can never spend past the global cap either
            remaining = min(remaining, self.global_cap_micro - global_committed)
        return BudgetSummary(
            scope="global" if run_id is None else f"run:{run_id}",
            cap_usd=micro_to_usd(cap),
            estimated_usd=micro_to_usd(reserved),
            confirmed_usd=micro_to_usd(confirmed),
            unresolved_usd=micro_to_usd(unresolved),
            committed_usd=micro_to_usd(committed),
            remaining_usd=micro_to_usd(remaining),
            requests=counts,
        )

    def rows(self, run_id: str | None = None) -> list[dict[str, object]]:
        with self.engine.connect().execution_options(**{READONLY_OPTION: True}) as conn:
            stmt = select(ProviderUsageRow.__table__).order_by(ProviderUsageRow.created_at)
            if run_id is not None:
                stmt = stmt.where(ProviderUsageRow.run_id == run_id)
            return [
                {k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in r._mapping.items()}
                for r in conn.execute(stmt).all()
            ]


def budget_summary(
    db_path: Path | str = "artifacts/mobilelab.db", *, run_id: str | None = None, run_cap_usd: float = DEFAULT_RUN_CAP_USD
) -> BudgetSummary:
    """CLI-visible spend summary: estimated / confirmed / unresolved / remaining (USD)."""
    ledger = BudgetLedger.open(db_path, run_cap_usd=run_cap_usd)
    try:
        return ledger.summary(run_id)
    finally:
        ledger.engine.dispose()


__all__ = [
    "DEFAULT_RUN_CAP_USD",
    "HARD_GLOBAL_CAP_USD",
    "BudgetExceeded",
    "BudgetLedger",
    "BudgetSummary",
    "LedgerError",
    "Reservation",
    "budget_summary",
]

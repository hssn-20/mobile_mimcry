"""Frozen provider rate cards (CONTRACTS §11): cost is reserved from these, never from live lookups.

All amounts are USD per 1M tokens. Costs are computed with ``Decimal`` and rounded *up* to whole
micro-USD so the ledger never under-reserves.
"""

from __future__ import annotations

import hashlib
import json
import math
from datetime import date
from decimal import ROUND_CEILING, Decimal

from pydantic import Field, HttpUrl, model_validator

from mobilelab.domain.base import FrozenModel

_PER_MILLION = Decimal(1_000_000)
_MICRO = Decimal(1_000_000)


class TokenUsage(FrozenModel):
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    cached_input_tokens: int = Field(default=0, ge=0)
    reasoning_tokens: int = Field(default=0, ge=0)
    """Already included in ``output_tokens`` (billed as output)."""
    cache_write_tokens: int | None = Field(default=None, ge=0)
    """Part of ``input_tokens`` written to the prompt cache, when the API reports it."""


class RateCard(FrozenModel):
    provider: str = Field(min_length=1, max_length=64)
    model: str = Field(min_length=1, max_length=256)
    currency: str = "USD"
    tier: str = "standard_short_context"
    input_per_1m: Decimal = Field(ge=0)
    cached_input_per_1m: Decimal = Field(ge=0)
    cache_write_per_1m: Decimal | None = Field(default=None, ge=0)
    output_per_1m: Decimal = Field(ge=0)
    max_context_tokens_for_tier: int = Field(gt=0)
    """Requests above this input size are billed at a higher tier; the provider refuses to send them."""
    source_url: HttpUrl
    retrieved_on: date
    notes: str = Field(default="", max_length=2000)

    @model_validator(mode="after")
    def _currency(self) -> RateCard:
        if self.currency != "USD":
            raise ValueError("only USD rate cards are supported")
        return self

    @property
    def rate_card_id(self) -> str:
        """Stable short identifier of the frozen card (model + content digest)."""
        body = json.dumps(self.model_dump(mode="json"), sort_keys=True).encode()
        return f"{self.model}@{self.retrieved_on.isoformat()}#{hashlib.sha256(body).hexdigest()[:12]}"

    @property
    def _worst_input_rate(self) -> Decimal:
        return max(self.input_per_1m, self.cache_write_per_1m or Decimal(0))

    def reservation_micro_usd(self, max_input_tokens: int, max_output_tokens: int) -> int:
        """Upper bound for one request: every input token at the worst input rate + max output."""
        usd = (
            Decimal(max_input_tokens) * self._worst_input_rate + Decimal(max_output_tokens) * self.output_per_1m
        ) / _PER_MILLION
        return _ceil_micro(usd)

    def usage_micro_usd(self, usage: TokenUsage) -> int:
        """Cost from provider-reported usage. When cache writes are reported they are priced at the
        cache-write rate; when they are not, all uncached input is priced at the worst input rate."""
        cached = min(usage.cached_input_tokens, usage.input_tokens)
        uncached = usage.input_tokens - cached
        if usage.cache_write_tokens is None:
            input_usd = Decimal(uncached) * self._worst_input_rate
        else:
            writes = min(usage.cache_write_tokens, uncached)
            input_usd = Decimal(uncached - writes) * self.input_per_1m + Decimal(writes) * (
                self.cache_write_per_1m if self.cache_write_per_1m is not None else self.input_per_1m
            )
        usd = (
            input_usd + Decimal(cached) * self.cached_input_per_1m + Decimal(usage.output_tokens) * self.output_per_1m
        ) / _PER_MILLION
        return _ceil_micro(usd)


def _ceil_micro(usd: Decimal) -> int:
    return int((usd * _MICRO).to_integral_value(rounding=ROUND_CEILING))


def micro_to_usd(micro: int) -> float:
    return micro / 1_000_000


def usd_to_micro(usd: float | Decimal | str) -> int:
    return int(math.floor(Decimal(str(usd)) * _MICRO))


__all__ = ["RateCard", "TokenUsage", "micro_to_usd", "usd_to_micro"]

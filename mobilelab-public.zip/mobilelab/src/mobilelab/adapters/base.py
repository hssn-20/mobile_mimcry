"""Platform-neutral device adapter contract (CONTRACTS §3).

Adapters run inside the owning device worker. They never write the database,
never invoke models and never decide what to do next. Every result carries an
``evidence_source`` so mock/replay output can never be mistaken for device
evidence.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from mobilelab.domain.devices import (
    CapabilityReport,
    CloseResult,
    DeviceHealth,
    DeviceProfile,
    FenceResult,
)
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.observations import Observation, ObserveRequest


@runtime_checkable
class DeviceAdapter(Protocol):
    """Typed operations a worker may perform on its single leased device.

    ``execute`` is bounded by ``command.max_duration_ms``; cancellation does not
    imply the UI action was undone. At most one driver operation is active per
    adapter instance; callers (the worker) enforce serialization.
    """

    async def preflight(self, profile: DeviceProfile) -> CapabilityReport: ...

    async def observe(self, request: ObserveRequest) -> Observation: ...

    async def execute(self, command: DispatchCommand) -> ExecutionResult: ...

    async def fence(self, control_epoch: int) -> FenceResult: ...

    async def health(self) -> DeviceHealth: ...

    async def close(self) -> CloseResult: ...

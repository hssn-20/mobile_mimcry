"""Project-local Appium server lifecycle (loopback only).

Starts ``tools/appium/node_modules/.bin/appium`` with ``APPIUM_HOME=tools/appium/.appium`` and the full
Xcode ``DEVELOPER_DIR`` (xcode-select is never changed). The bind address is fixed to 127.0.0.1 and is
not configurable; the port is a free loopback port unless one is given. Logs go under ``artifacts/``.
"""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import time
from pathlib import Path
from types import TracebackType

import httpx

LOOPBACK = "127.0.0.1"
DEFAULT_DEVELOPER_DIR = "/Applications/Xcode.app/Contents/Developer"


class AppiumServerError(RuntimeError):
    pass


def free_loopback_port() -> int:
    """A currently free TCP port on 127.0.0.1 (best effort; the OS may reuse it before bind)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((LOOPBACK, 0))
        return int(s.getsockname()[1])


def find_wda_processes(udid: str, derived_data_path: Path) -> list[int]:
    """PIDs of the WDA ``xcodebuild`` that xcuitest started for exactly this device *and* this
    project-local derived-data path (so nothing outside the project is ever matched)."""
    out = subprocess.run(  # noqa: S603 - fixed argv
        ["/bin/ps", "-axo", "pid=,command="], capture_output=True, text=True, timeout=10, check=True
    ).stdout
    needle_dd = f"-derivedDataPath {derived_data_path}"
    needle_dest = f"id={udid}"
    pids: list[int] = []
    for line in out.splitlines():
        pid_text, _, command = line.strip().partition(" ")
        if "xcodebuild" in command and needle_dd in command and needle_dest in command and pid_text.isdigit():
            pids.append(int(pid_text))
    return pids


def stop_wda_processes(udid: str, derived_data_path: Path, timeout_s: float = 10.0) -> list[int]:
    """SIGTERM (then SIGKILL) this device's project-local WDA xcodebuild; returns the PIDs stopped."""
    pids = find_wda_processes(udid, derived_data_path)
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + timeout_s
    remaining = list(pids)
    while remaining and time.monotonic() < deadline:
        time.sleep(0.2)
        remaining = [pid for pid in remaining if _alive(pid)]
    for pid in remaining:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    return pids


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class AppiumServer:
    def __init__(
        self,
        *,
        repo_root: Path,
        port: int | None = None,
        log_path: Path | None = None,
        developer_dir: str = DEFAULT_DEVELOPER_DIR,
        startup_timeout_s: float = 60.0,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.port = port if port is not None else free_loopback_port()
        self.appium_bin = self.repo_root / "tools/appium/node_modules/.bin/appium"
        self.appium_home = self.repo_root / "tools/appium/.appium"
        self.log_path = log_path or self.repo_root / "artifacts/appium" / f"appium-{self.port}.log"
        self.developer_dir = developer_dir
        self.startup_timeout_s = startup_timeout_s
        self._proc: subprocess.Popen[bytes] | None = None

    @property
    def address(self) -> str:
        return LOOPBACK

    @property
    def url(self) -> str:
        return f"http://{LOOPBACK}:{self.port}"

    def argv(self) -> list[str]:
        return [
            str(self.appium_bin),
            "server",
            "--address",
            LOOPBACK,
            "--port",
            str(self.port),
            "--use-drivers",
            "xcuitest",
            "--log",
            str(self.log_path),
            "--log-no-colors",
            "--log-timestamp",
        ]

    def env(self) -> dict[str, str]:
        from mobilelab.secrets import child_env

        env = child_env()  # provider credentials stay in the coordinator process
        env["APPIUM_HOME"] = str(self.appium_home)
        env["DEVELOPER_DIR"] = self.developer_dir
        return env

    @property
    def running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def start(self) -> None:
        if self.running:
            return
        if not self.appium_bin.exists():
            raise AppiumServerError(f"project-local appium not found at {self.appium_bin}")
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._proc = subprocess.Popen(  # noqa: S603 - fixed argv, no shell
            self.argv(),
            env=self.env(),
            cwd=self.repo_root,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            self._wait_ready()
        except BaseException:
            self.stop()
            raise

    def _wait_ready(self) -> None:
        deadline = time.monotonic() + self.startup_timeout_s
        last_error = "no response"
        while time.monotonic() < deadline:
            if self._proc is None or self._proc.poll() is not None:
                raise AppiumServerError(f"appium exited during startup; see {self.log_path}")
            try:
                resp = httpx.get(f"{self.url}/status", timeout=2.0)
                if resp.status_code == 200 and resp.json().get("value", {}).get("ready", False):
                    return
                last_error = f"status {resp.status_code}"
            except (httpx.HTTPError, ValueError) as exc:
                last_error = type(exc).__name__
            time.sleep(0.25)
        raise AppiumServerError(f"appium not ready after {self.startup_timeout_s}s ({last_error}); see {self.log_path}")

    def stop(self, timeout_s: float = 15.0) -> None:
        proc, self._proc = self._proc, None
        if proc is None or proc.poll() is not None:
            return
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait(timeout=5)

    def __enter__(self) -> AppiumServer:
        self.start()
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None
    ) -> None:
        self.stop()

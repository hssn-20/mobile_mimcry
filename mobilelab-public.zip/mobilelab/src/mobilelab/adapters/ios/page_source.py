"""Normalize XCUITest XML page source into the domain ``UIElement`` list.

``element_ref`` values are stable within one observation and encode how to re-find the element in
the *current* session (CONTRACTS §4: the model never supplies selectors; trusted code derives them):

* ``id:<identifier>[k]`` — accessibility identifier, k-th match in document order (k=0 when unique).
* ``<Type>:<label-digest>[k]`` — no identifier; NSPredicate ``type == T AND label == L``, k-th match.
* ``<Type>[k]`` — no identifier and no label; NSPredicate ``type == T``, k-th match of that type.

XCUITest reports ``name`` as the accessibility identifier when one is set and otherwise falls back to
the label, so ``name`` counts as an identifier only when it differs from the label. Real Simulator
captures (iOS 27.0) show this heuristic also yields container names that are not developer identifiers
(e.g. a navigation bar's title, an SF Symbol image name, Safari's internal ``TabBarItemTitle``): they
still locate the element, but ``identifier`` is a locator hint, not proof of a developer-set id. An
empty text field reports its ``placeholderValue`` as ``value``; that is normalized to no value. Label/value text is
untrusted screen content: it is stored for observation and quoted safely in predicates, nothing more.
"""

from __future__ import annotations

import hashlib
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Literal

from mobilelab.domain.observations import Bounds, UIElement

_TYPE_PREFIX = "XCUIElementType"
_MAX_TEXT = 4000
_MAX_IDENTIFIER = 200  # leaves room for the "id:" prefix and index within the 256-char ElementRef
_CAMEL = re.compile(r"(?<!^)(?=[A-Z])")


class PageSourceError(ValueError):
    """The page source could not be parsed safely."""


@dataclass(frozen=True)
class Locator:
    """How to re-find an element in the live session (index into ``find_elements`` results)."""

    strategy: Literal["accessibility_id", "predicate"]
    value: str
    index: int
    bounds: Bounds | None


@dataclass(frozen=True)
class ParsedTree:
    elements: list[UIElement]
    locators: dict[str, Locator]
    keyboard_visible: bool
    truncated: bool


def role_for(xcui_type: str) -> str:
    """``XCUIElementTypeStaticText`` -> ``static_text``; unknown tags -> ``unknown``."""
    if not xcui_type.startswith(_TYPE_PREFIX) or len(xcui_type) == len(_TYPE_PREFIX):
        return "unknown"
    return _CAMEL.sub("_", xcui_type[len(_TYPE_PREFIX) :]).lower()[:128]


def predicate_quote(text: str) -> str:
    """Quote untrusted text as an NSPredicate string literal."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _bool(attr: str | None, default: bool) -> bool:
    if attr is None:
        return default
    return attr.strip().lower() == "true"


def _float(attr: str | None) -> float | None:
    if attr is None:
        return None
    try:
        return float(attr)
    except ValueError:
        return None


def _bounds(node: ET.Element) -> Bounds | None:
    x, y, w, h = (_float(node.get(k)) for k in ("x", "y", "width", "height"))
    if x is None or y is None or w is None or h is None or w < 0 or h < 0:
        return None
    return Bounds(x=x, y=y, width=w, height=h)


def _on_screen(bounds: Bounds | None, screen: Bounds | None) -> bool:
    """Geometric visibility: non-empty and intersecting the application frame (not occlusion-aware)."""
    if bounds is None or bounds.width <= 0 or bounds.height <= 0:
        return False
    if screen is None:
        return True
    return (
        bounds.x < screen.x + screen.width
        and bounds.x + bounds.width > screen.x
        and bounds.y < screen.y + screen.height
        and bounds.y + bounds.height > screen.y
    )


def _text(attr: str | None) -> str | None:
    if attr is None or attr == "":
        return None
    return attr[:_MAX_TEXT]


def parse_page_source(xml_text: str, *, max_elements: int = 3000) -> ParsedTree:
    """Parse an XCUITest page source into a flattened, document-ordered element list."""
    if "<!DOCTYPE" in xml_text or "<!ENTITY" in xml_text:
        raise PageSourceError("page source contains a DTD/entity declaration")
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise PageSourceError(f"malformed page source: {exc}") from exc

    tops = list(root) if root.tag == "AppiumAUT" else [root]
    screen = _bounds(tops[0]) if tops else None
    elements: list[UIElement] = []
    locators: dict[str, Locator] = {}
    id_counts: dict[str, int] = {}
    type_label_counts: dict[tuple[str, str], int] = {}
    type_counts: dict[str, int] = {}
    keyboard_visible = False
    truncated = False

    stack: list[tuple[ET.Element, str | None]] = [(n, None) for n in reversed(tops)]
    while stack:
        node, parent_ref = stack.pop()
        if len(elements) >= max_elements:
            truncated = True
            break
        xcui_type = node.get("type") or node.tag
        name = node.get("name")
        label = _text(node.get("label"))
        value = _text(node.get("value"))
        placeholder = node.get("placeholderValue")
        if placeholder and value == placeholder:
            value = None  # XCUITest reports an empty text field's placeholder as its value
        bounds = _bounds(node)
        # The adapter excludes WDA's ``visible`` attribute by default (it cost 3.5-14 s per SpringBoard
        # capture on iOS 27.0); without it visibility is geometric (on-screen), not occlusion-aware.
        visible = _bool(node.get("visible"), default=_on_screen(bounds, screen))
        enabled = _bool(node.get("enabled"), default=True)
        role = role_for(xcui_type)

        identifier: str | None = None
        if name and name != node.get("label") and len(name) <= _MAX_IDENTIFIER:
            identifier = name

        # Counters are taken over *every* node so indices line up with WDA's find_elements order.
        type_index = type_counts.get(xcui_type, 0)
        type_counts[xcui_type] = type_index + 1
        raw_label = node.get("label") or ""
        tl_index = type_label_counts.get((xcui_type, raw_label), 0)
        type_label_counts[(xcui_type, raw_label)] = tl_index + 1
        if name:
            id_index = id_counts.get(name, 0)
            id_counts[name] = id_index + 1
        else:
            id_index = 0

        short_type = xcui_type.removeprefix(_TYPE_PREFIX)[:64] or "Unknown"
        if identifier is not None:
            ref = f"id:{identifier}[{id_index}]"
            locator = Locator("accessibility_id", identifier, id_index, bounds)
        elif raw_label:
            digest = hashlib.sha256(raw_label.encode()).hexdigest()[:12]
            ref = f"{short_type}:{digest}[{tl_index}]"
            pred = f"type == {predicate_quote(xcui_type)} AND label == {predicate_quote(raw_label)}"
            locator = Locator("predicate", pred, tl_index, bounds)
        else:
            ref = f"{short_type}[{type_index}]"
            locator = Locator("predicate", f"type == {predicate_quote(xcui_type)}", type_index, bounds)

        if ref in locators:  # defensive: never emit duplicate refs
            raise PageSourceError(f"duplicate element_ref {ref!r}")
        locators[ref] = locator
        elements.append(
            UIElement(
                element_ref=ref,
                parent_ref=parent_ref,
                role=role,
                label=label,
                value=None if role == "secure_text_field" else value,
                identifier=identifier,
                bounds=bounds,
                visible=visible,
                enabled=enabled,
            )
        )
        if role == "keyboard" and visible:
            keyboard_visible = True
        stack.extend((child, ref) for child in reversed(list(node)))

    return ParsedTree(elements=elements, locators=locators, keyboard_visible=keyboard_visible, truncated=truncated)

"""Configuration for the iOS XCUITest adapter (one project-owned Simulator per adapter instance)."""

from __future__ import annotations

from datetime import timedelta
from ipaddress import ip_address
from pathlib import Path
from urllib.parse import urlsplit
from uuid import UUID

from appium.options.ios import XCUITestOptions
from pydantic import Field, field_validator, model_validator

from mobilelab.domain.actions import AppId, url_origin, validate_http_url
from mobilelab.domain.base import StrictModel
from mobilelab.domain.enums import DeviceKind

LAB_MESSENGER_BUNDLE_ID = "org.mobilelab.fixtures.LabMessenger"
SAFARI_BUNDLE_ID = "com.apple.mobilesafari"
PROJECT_SIMULATOR_PREFIX = "mobilelab-"


def lab_messenger_launch_args(base_url: str, sender_token: str, run_id: UUID) -> list[str]:
    """Process arguments for Lab Messenger. ``sender_token`` is the per-run test identity from the
    fixture reset — never the fixture administrator secret."""
    return ["-MLFixtureBaseURL", validate_http_url(base_url), "-MLFixtureToken", sender_token, "-MLRunId", str(run_id)]


def _is_loopback_url(url: str) -> bool:
    host = urlsplit(url).hostname or ""
    if host == "localhost":
        return True
    try:
        return ip_address(host).is_loopback
    except ValueError:
        return False


class IOSAdapterConfig(StrictModel):
    device_id: UUID
    """Public device identifier (the UDID below is an adapter-only field)."""
    udid: str = Field(min_length=1, max_length=128)
    device_name: str = Field(default="mobilelab-iphone-01", min_length=1, max_length=128)
    device_kind: DeviceKind = DeviceKind.SIMULATOR
    platform_version: str = Field(min_length=1, max_length=32)

    appium_url: str | None = None
    """Existing loopback Appium server. When None the adapter starts a project-local one itself."""
    repo_root: Path = Field(default_factory=Path.cwd)
    wda_local_port: int = Field(ge=1024, le=65535)
    derived_data_root: Path = Path("build/wda")
    use_prebuilt_wda: bool = False
    headless: bool = True
    """Attach to the already-booted Simulator without a UI window. With False, the driver reboots a
    windowless booted Simulator to show its window (observed on iOS 27.0 / xcuitest 12.14)."""
    keep_wda_running: bool = False
    """xcuitest leaves the WDA ``xcodebuild`` running after the session quits (it is reused by the
    next session). False: ``close()`` stops this device's project-local WDA process too."""
    retain_page_source: bool = True
    page_source_excluded_attributes: str = Field(default="visible", max_length=200, pattern=r"^[a-zA-Z,]*$")
    """WDA ``pageSourceExcludedAttributes`` setting applied when the session starts. Computing
    ``visible`` took 3.5-14 s per SpringBoard page source on the iOS 27.0 Simulator (0.2 s without),
    which breaks the 1.5 s capture-span limit; the parser then derives visibility geometrically."""
    """Hand the raw XCUITest XML of every observation to the worker as a ``page_source.xml`` artifact."""
    new_command_timeout_s: int = Field(default=120, ge=10, le=3600)
    wda_launch_timeout_ms: int = Field(default=600_000, ge=10_000, le=1_800_000)
    session_create_timeout_s: float = Field(default=900.0, ge=10, le=3600)
    """Client-side HTTP timeout; the first session builds WDA, which can take minutes."""
    driver_call_timeout_s: float = Field(default=30.0, ge=1, le=600)
    """Bound on observation/health/probe driver calls (execute uses the command deadline)."""
    initial_bundle_id: AppId | None = None
    """Optional app to attach the session to; None attaches to whatever is in the foreground."""

    allowed_app_ids: list[AppId] = Field(default_factory=lambda: [LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID])
    allowed_url_origins: list[str] = Field(default_factory=list)
    app_launch_arguments: dict[AppId, list[str]] = Field(default_factory=dict)
    lab_messenger_bundle_id: AppId = LAB_MESSENGER_BUNDLE_ID
    lab_messenger_probe_conversation_id: str = "fixture-conversation-01"
    safari_probe_url: str | None = None
    send_correlation_identifier: str | None = "composer.draft_id"
    """Before tapping Send, check this element's value equals the payload client_message_id."""

    paced_chunk_chars: int = Field(default=1, ge=1, le=64)
    paced_interval_ms: int = Field(default=150, ge=0, le=5000)
    rect_tolerance_pt: float = Field(default=4.0, ge=0)
    max_tree_elements: int = Field(default=3000, ge=10, le=20_000)
    observation_history: int = Field(default=16, ge=1, le=256)

    @field_validator("appium_url")
    @classmethod
    def _loopback_only(cls, v: str | None) -> str | None:
        if v is not None and not _is_loopback_url(v):
            raise ValueError("appium_url must point at a loopback address")
        return v

    @field_validator("allowed_url_origins")
    @classmethod
    def _origins(cls, v: list[str]) -> list[str]:
        return [url_origin(validate_http_url(o)) for o in v]

    @field_validator("safari_probe_url")
    @classmethod
    def _probe_url(cls, v: str | None) -> str | None:
        return None if v is None else validate_http_url(v)

    @model_validator(mode="after")
    def _project_owned(self) -> IOSAdapterConfig:
        if self.device_kind is DeviceKind.SIMULATOR and not self.device_name.startswith(PROJECT_SIMULATOR_PREFIX):
            raise ValueError(f"simulator name must start with {PROJECT_SIMULATOR_PREFIX!r} (project-owned only)")
        for app_id in self.app_launch_arguments:
            if app_id not in self.allowed_app_ids:
                raise ValueError(f"launch arguments configured for non-allowlisted app {app_id}")
        return self

    @property
    def derived_data_path(self) -> Path:
        root = self.derived_data_root if self.derived_data_root.is_absolute() else self.repo_root / self.derived_data_root
        return root / self.udid

    def xcuitest_options(self) -> XCUITestOptions:
        """Session capabilities. Deliberately no autoAcceptAlerts/autoDismissAlerts and no fullReset."""
        opts = XCUITestOptions()
        opts.udid = self.udid
        opts.device_name = self.device_name
        opts.platform_version = self.platform_version
        opts.wda_local_port = self.wda_local_port
        opts.derived_data_path = str(self.derived_data_path)
        opts.use_prebuilt_wda = self.use_prebuilt_wda
        opts.no_reset = True
        opts.full_reset = False
        opts.auto_accept_alerts = False
        opts.auto_dismiss_alerts = False
        opts.show_xcode_log = False
        opts.is_headless = self.headless
        opts.new_command_timeout = timedelta(seconds=self.new_command_timeout_s)
        opts.wda_launch_timeout = timedelta(milliseconds=self.wda_launch_timeout_ms)
        if self.initial_bundle_id is not None:
            opts.bundle_id = self.initial_bundle_id
        return opts

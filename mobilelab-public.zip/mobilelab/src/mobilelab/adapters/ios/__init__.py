"""iOS XCUITest adapter (Appium 3 + appium-xcuitest-driver) for project-owned Simulators."""

from mobilelab.adapters.ios.adapter import ADAPTER_VERSION, ArtifactSink, DriverError, IOSXCUITestAdapter
from mobilelab.adapters.ios.config import (
    LAB_MESSENGER_BUNDLE_ID,
    SAFARI_BUNDLE_ID,
    IOSAdapterConfig,
    lab_messenger_launch_args,
)
from mobilelab.adapters.ios.page_source import Locator, ParsedTree, PageSourceError, parse_page_source

__all__ = [
    "ADAPTER_VERSION",
    "LAB_MESSENGER_BUNDLE_ID",
    "SAFARI_BUNDLE_ID",
    "ArtifactSink",
    "DriverError",
    "IOSAdapterConfig",
    "IOSXCUITestAdapter",
    "Locator",
    "PageSourceError",
    "ParsedTree",
    "lab_messenger_launch_args",
    "parse_page_source",
]

"""iOS XCUITest device adapter (CONTRACTS §3, §4, §6) driving one project-owned Simulator via Appium.

Concurrency model: every driver call runs in a thread (``asyncio.to_thread``) under one asyncio lock,
so at most one driver operation is active. A deadline expiry abandons the *wait*, not the thread: the
lock stays held until the blocked call returns, and ``fence``/``authorize`` never touch the lock.

Execution outcomes are conservative: anything that may have reached the UI after the side-effecting
call began is ``unknown``; ``failed`` is used only when no side-effecting call was started.
"""

from __future__ import annotations

import asyncio
import json
import struct
import threading
import time
from collections import OrderedDict
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, TypeVar
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from appium.webdriver.common.appiumby import AppiumBy

from mobilelab.adapters.appium_server import AppiumServer, stop_wda_processes
from mobilelab.adapters.ios.config import SAFARI_BUNDLE_ID, IOSAdapterConfig
from mobilelab.adapters.ios.driver import DriverFactory, DriverLike, appium_driver_factory
from mobilelab.adapters.ios.page_source import Locator, PageSourceError, parse_page_source
from mobilelab.domain.actions import (
    Activate,
    EndCall,
    NavigateUrl,
    OpenApp,
    Scroll,
    SendMessage,
    StartCall,
    TypeText,
    Wait,
    url_origin,
)
from mobilelab.domain.base import utc_now
from mobilelab.domain.devices import CapabilityReport, CloseResult, DeviceHealth, DeviceProfile, FenceResult
from mobilelab.domain.dispatch import DispatchCommand, ExecutionResult
from mobilelab.domain.enums import EvidenceSource, ExecutionStatus, Orientation, TypingMode
from mobilelab.domain.errors import ErrorCode, ErrorEnvelope, MobilelabError, StaleObservation
from mobilelab.domain.observations import CoordinateSpace, Observation, ObserveRequest, UIElement
from mobilelab.workers.protocol import ArtifactBlob

ADAPTER_VERSION = "ios-xcuitest/0.1.0"
T = TypeVar("T")

ArtifactSink = Callable[[UUID, str, str, bytes], None]
"""(artifact_id, filename, content_type, data). Optional worker hook; without one, captured bytes are
buffered and handed over through ``take_artifacts``. The adapter never writes the DB or artifact store."""
_WAIT_POLL_S = 0.05

_ORIENTATIONS = {
    "PORTRAIT": Orientation.PORTRAIT,
    "LANDSCAPE": Orientation.LANDSCAPE_LEFT,  # WDA reports UIDeviceOrientationLandscapeLeft as "LANDSCAPE"
    "UIA_DEVICE_ORIENTATION_LANDSCAPERIGHT": Orientation.LANDSCAPE_RIGHT,
    "UIA_DEVICE_ORIENTATION_PORTRAIT_UPSIDEDOWN": Orientation.PORTRAIT_UPSIDE_DOWN,
}


class DriverError(MobilelabError):
    """An Appium/WDA call failed or exceeded its deadline (harness-side, not a DUT verdict)."""

    code = ErrorCode.INTERNAL_ERROR
    http_status = 503
    retryable = True


class _Reject(Exception):
    def __init__(self, code: ErrorCode, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class _Cancelled(Exception):
    pass


class _Progress:
    """Thread-safe handshake so a timed-out command can never *start* a side effect afterwards."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._cancelled = False
        self.side_effect_started = False

    def begin_side_effect(self) -> None:
        with self._lock:
            if self._cancelled:
                raise _Cancelled
            self.side_effect_started = True

    def cancel(self) -> bool:
        with self._lock:
            self._cancelled = True
            return self.side_effect_started


@dataclass(frozen=True)
class _Outcome:
    status: ExecutionStatus
    detail: str = ""
    typing_mode: TypingMode | None = None
    rejection_code: ErrorCode | None = None
    error: ErrorEnvelope | None = None


_SCROLLABLE_ROLES = ("web_view", "scroll_view", "table", "collection_view")
_SWIPE_FOR_SCROLL = {"down": "up", "up": "down", "left": "right", "right": "left"}
"""``scroll down`` reveals content below, i.e. the finger swipes up."""


@dataclass(frozen=True)
class _ObservationRecord:
    monotonic_ns: int
    locators: dict[str, Locator]
    foreground_app: str | None
    default_scroll_ref: str | None = None


def _default_scroll_ref(elements: list[UIElement]) -> str | None:
    """The main scrollable container of a capture: visible, largest area, web views first."""
    best: tuple[bool, float, int] | None = None
    ref: str | None = None
    for i, e in enumerate(elements):
        if e.role not in _SCROLLABLE_ROLES or not e.visible or e.bounds is None:
            continue
        key = (e.role == "web_view", e.bounds.width * e.bounds.height, -i)
        if best is None or key > best:
            best, ref = key, e.element_ref
    return ref


@dataclass
class _Authority:
    lease_id: UUID
    lease_epoch: int
    control_epoch: int


@dataclass
class _Capture:
    app_before: str | None
    app_after: str | None
    orientation: Orientation
    window: dict[str, int]
    started_at: Any
    started_ns: int
    png: bytes | None
    screenshot_at: Any
    source: str
    tree_at: Any
    ended_ns: int
    timings_ms: dict[str, float] = field(default_factory=dict)


def png_size(data: bytes) -> tuple[int, int] | None:
    if len(data) >= 24 and data[:8] == b"\x89PNG\r\n\x1a\n" and data[12:16] == b"IHDR":
        w, h = struct.unpack(">II", data[16:24])
        return int(w), int(h)
    return None


def _active_bundle(driver: DriverLike) -> str | None:
    info = driver.execute_script("mobile: activeAppInfo")
    if isinstance(info, Mapping):
        bundle = info.get("bundleId")
        return str(bundle) if bundle else None
    return None


class IOSXCUITestAdapter:
    """``DeviceAdapter`` for one iOS Simulator through Appium XCUITest."""

    adapter_version = ADAPTER_VERSION

    def __init__(
        self,
        config: IOSAdapterConfig,
        *,
        driver_factory: DriverFactory | None = None,
        artifact_sink: ArtifactSink | None = None,
        evidence_source: EvidenceSource = EvidenceSource.DEVICE,
    ) -> None:
        self.config = config
        self._driver_factory = driver_factory or appium_driver_factory
        self._artifact_sink = artifact_sink
        self.evidence_source = evidence_source
        self._driver: DriverLike | None = None
        self._server: AppiumServer | None = None
        self._lock = asyncio.Lock()
        self._in_flight_command: UUID | None = None
        self._authority: _Authority | None = None
        self._fenced_epoch: int | None = None
        self._closed = False
        self._observations: OrderedDict[UUID, _ObservationRecord] = OrderedDict()
        self._artifacts: OrderedDict[UUID, list[ArtifactBlob]] = OrderedDict()
        self.wda_processes_stopped: list[int] = []

    @classmethod
    def from_config(
        cls,
        config_or_device_id: Mapping[str, Any] | IOSAdapterConfig | UUID,
        options: Mapping[str, Any] | None = None,
        **deps: Any,
    ) -> IOSXCUITestAdapter:
        """Build from JSON options. Accepts the worker registry's ``(device_id, options)`` form and a
        plain ``(config)`` form; a ``device_id`` given positionally must match any in ``options``."""
        if isinstance(config_or_device_id, IOSAdapterConfig):
            return cls(config_or_device_id, **deps)
        if isinstance(config_or_device_id, UUID):
            data = dict(options or {})
            given = data.setdefault("device_id", str(config_or_device_id))
            if UUID(str(given)) != config_or_device_id:
                raise ValueError("adapter options device_id differs from the worker device_id")
        else:
            data = dict(config_or_device_id)
        return cls(IOSAdapterConfig.model_validate(data), **deps)

    @property
    def device_id(self) -> UUID:
        return self.config.device_id

    # -- authority (called by the worker on its control lane) ------------------------------------

    def authorize(self, *, lease_id: UUID, lease_epoch: int, control_epoch: int) -> None:
        """Optionally pin the adapter to one automation lease/epoch (defence in depth).

        The worker is the primary authority check; once pinned here, commands for any other lease,
        lease epoch or control epoch are also rejected by the adapter itself.
        """
        if self._fenced_epoch is not None and control_epoch <= self._fenced_epoch:
            raise MobilelabError(
                "cannot authorize an epoch that was already fenced",
                details={"control_epoch": control_epoch, "fenced_epoch": self._fenced_epoch},
            )
        self._authority = _Authority(lease_id, lease_epoch, control_epoch)

    def _is_fenced(self, control_epoch: int) -> bool:
        return self._fenced_epoch is not None and control_epoch <= self._fenced_epoch

    async def fence(self, control_epoch: int) -> FenceResult:
        """Reject every command with ``control_epoch <= fenced epoch`` from now on and interrupt waits.
        Never takes the driver lock; plain attribute writes, so it is safe from any loop or thread."""
        self._fenced_epoch = max(control_epoch, self._fenced_epoch or 0)
        in_flight = self._in_flight_command
        return FenceResult(
            device_id=self.device_id,
            control_epoch=control_epoch,
            fenced=True,
            acknowledged_at=utc_now(),
            in_flight_command_id=in_flight,
            in_flight_state="executing" if in_flight is not None else "none",
        )

    # -- driver plumbing ---------------------------------------------------------------------------

    async def _run_driver(self, fn: Callable[[], T], timeout_s: float, command_id: UUID | None = None) -> T:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_s
        await asyncio.wait_for(self._lock.acquire(), timeout_s)
        self._in_flight_command = command_id
        try:
            fut = asyncio.ensure_future(asyncio.to_thread(fn))
        except BaseException:
            self._in_flight_command = None
            self._lock.release()
            raise

        def _release(f: asyncio.Future[T]) -> None:
            if not f.cancelled():
                f.exception()  # mark retrieved; the awaiting side reports it
            self._in_flight_command = None
            self._lock.release()

        fut.add_done_callback(_release)
        return await asyncio.wait_for(asyncio.shield(fut), max(0.0, deadline - loop.time()))

    def _start_session_sync(self) -> None:
        if self._driver is not None:
            return
        url = self.config.appium_url
        if url is None:
            if self._server is None:
                self._server = AppiumServer(repo_root=self.config.repo_root)
            self._server.start()
            url = self._server.url
        driver = self._driver_factory(url, self.config.xcuitest_options(), self.config.session_create_timeout_s)
        try:
            driver.update_settings({"pageSourceExcludedAttributes": self.config.page_source_excluded_attributes})
        except BaseException:
            driver.quit()
            raise
        self._driver = driver

    async def _ensure_session(self) -> None:
        if self._closed:
            raise DriverError("adapter is closed")
        if self._driver is None:
            try:
                await self._run_driver(self._start_session_sync, self.config.session_create_timeout_s)
            except TimeoutError as exc:
                raise DriverError("Appium session creation timed out") from exc
            except MobilelabError:
                raise
            except Exception as exc:
                raise DriverError(f"Appium session creation failed: {type(exc).__name__}: {exc}"[:1500]) from exc

    def _drv(self) -> DriverLike:
        if self._driver is None:
            raise DriverError("no Appium session")
        return self._driver

    # -- observe -------------------------------------------------------------------------------------

    def _capture_sync(self, include_screenshot: bool) -> _Capture:
        drv = self._drv()
        app_before = _active_bundle(drv)
        window = drv.get_window_size()
        orientation = _ORIENTATIONS.get(str(drv.orientation).upper(), Orientation.UNKNOWN)
        started_at, started_ns = utc_now(), time.monotonic_ns()
        png = drv.get_screenshot_as_png() if include_screenshot else None
        shot_ns = time.monotonic_ns()
        screenshot_at = utc_now() if include_screenshot else None
        source = drv.page_source
        tree_at, ended_ns = utc_now(), time.monotonic_ns()
        app_after = _active_bundle(drv)
        return _Capture(
            app_before=app_before,
            app_after=app_after,
            orientation=orientation,
            window=window,
            started_at=started_at,
            started_ns=started_ns,
            png=png,
            screenshot_at=screenshot_at,
            source=source,
            tree_at=tree_at,
            ended_ns=ended_ns,
            timings_ms={
                "screenshot_ms": (shot_ns - started_ns) / 1e6,
                "tree_ms": (ended_ns - shot_ns) / 1e6,
            },
        )

    async def observe(self, request: ObserveRequest) -> Observation:
        if request.device_id != self.device_id:
            raise MobilelabError("observe request for a different device")
        await self._ensure_session()
        try:
            cap = await self._run_driver(
                lambda: self._capture_sync(request.include_screenshot), self.config.driver_call_timeout_s
            )
        except TimeoutError as exc:
            raise DriverError("observation capture timed out") from exc
        except MobilelabError:
            raise
        except Exception as exc:
            raise DriverError(f"observation capture failed: {type(exc).__name__}: {exc}"[:1500]) from exc

        span_ms = (cap.ended_ns - cap.started_ns) / 1e6
        if span_ms > request.max_capture_span_ms:
            raise StaleObservation(
                "observation capture span exceeds consistency limit",
                details={"capture_span_ms": span_ms, "limit_ms": request.max_capture_span_ms, **cap.timings_ms},
            )
        if cap.app_before != cap.app_after:
            raise StaleObservation(
                "foreground app changed during capture",
                details={"before": cap.app_before, "after": cap.app_after},
            )
        try:
            tree = parse_page_source(cap.source, max_elements=self.config.max_tree_elements)
        except PageSourceError as exc:
            raise DriverError(f"unparseable page source: {exc}"[:1500]) from exc

        spaces: list[CoordinateSpace] = []
        width_pt, height_pt = float(cap.window.get("width", 0)), float(cap.window.get("height", 0))
        if width_pt > 0 and height_pt > 0:
            spaces.append(CoordinateSpace(name="logical_pt", width=width_pt, height=height_pt))
        artifact_id: UUID | None = None
        captured: list[tuple[UUID, str, str, bytes]] = []
        if cap.png is not None:
            size = png_size(cap.png)
            if size is not None and width_pt > 0:
                spaces.append(
                    CoordinateSpace(name="screenshot_px", width=size[0], height=size[1], scale=size[0] / width_pt)
                )
            artifact_id = uuid4()
            captured.append((artifact_id, "screenshot.png", "image/png", cap.png))
        if self.config.retain_page_source:
            captured.append((uuid4(), "page_source.xml", "application/xml", cap.source.encode("utf-8")))

        observation = Observation(
            observation_id=uuid4(),
            run_id=request.run_id,
            device_id=self.device_id,
            session_id=request.session_id,
            evidence_source=self.evidence_source,
            capture_started_at=cap.started_at,
            capture_ended_at=cap.tree_at,
            screenshot_captured_at=cap.screenshot_at,
            tree_captured_at=cap.tree_at,
            worker_monotonic_capture_ns=cap.started_ns,  # conservative: age counts from the screenshot
            foreground_app=cap.app_after,
            orientation=cap.orientation,
            coordinate_spaces=spaces,
            screenshot_artifact_id=artifact_id,
            ui_tree=tree.elements,
            keyboard_visible=tree.keyboard_visible,
        )
        self._remember(
            observation.observation_id,
            _ObservationRecord(cap.started_ns, tree.locators, cap.app_after, _default_scroll_ref(tree.elements)),
        )
        if self._artifact_sink is not None:
            for item in captured:
                self._artifact_sink(*item)
        elif captured:
            self._artifacts[observation.observation_id] = [
                ArtifactBlob(aid, name, ctype, data, self.evidence_source) for aid, name, ctype, data in captured
            ]
            while len(self._artifacts) > self.config.observation_history:
                self._artifacts.popitem(last=False)
        return observation

    def take_artifacts(self, observation_id: UUID) -> list[ArtifactBlob]:
        """Hand captured bytes (screenshot, raw page source) for ``observation_id`` to the worker, once."""
        return self._artifacts.pop(observation_id, [])

    def _remember(self, observation_id: UUID, record: _ObservationRecord) -> None:
        self._observations[observation_id] = record
        while len(self._observations) > self.config.observation_history:
            self._observations.popitem(last=False)

    # -- execute ------------------------------------------------------------------------------------

    def _result(
        self, command: DispatchCommand, outcome: _Outcome, started_at: Any = None, t0_ns: int | None = None
    ) -> ExecutionResult:
        ended_at = utc_now() if started_at is not None else None
        return ExecutionResult(
            command_id=command.command_id,
            action_id=command.action_id,
            device_id=self.device_id,
            status=outcome.status,
            evidence_source=self.evidence_source,
            started_at=started_at,
            ended_at=ended_at,
            duration_ms=None if t0_ns is None else (time.monotonic_ns() - t0_ns) / 1e6,
            typing_mode_actual=outcome.typing_mode,
            rejection_code=outcome.rejection_code,
            error=outcome.error,
            detail=outcome.detail[:4000],
        )

    def _reject(self, command: DispatchCommand, code: ErrorCode, detail: str) -> ExecutionResult:
        return self._result(command, _Outcome(ExecutionStatus.REJECTED, detail=detail, rejection_code=code))

    def _precheck(self, command: DispatchCommand) -> tuple[ErrorCode, str] | None:
        """Authority, capability and allowlist checks that need no driver call."""
        if self._closed:
            return ErrorCode.DISPATCH_GATE_CLOSED, "adapter closed"
        if command.device_id != self.device_id:
            return ErrorCode.STALE_LEASE, "command addressed to a different device"
        if self._is_fenced(command.control_epoch):
            return ErrorCode.DISPATCH_GATE_CLOSED, f"adapter fenced through control epoch {self._fenced_epoch}"
        auth = self._authority
        if auth is not None:
            if (auth.lease_id, auth.lease_epoch) != (command.lease_id, command.lease_epoch):
                return ErrorCode.STALE_LEASE, "command lease does not match the pinned automation lease"
            if command.control_epoch != auth.control_epoch:
                return ErrorCode.STALE_EPOCH, f"command epoch {command.control_epoch} != pinned {auth.control_epoch}"
        p = command.payload
        if isinstance(p, (StartCall, EndCall)):
            return ErrorCode.CAPABILITY_UNAVAILABLE, f"{p.kind} is not supported by the iOS Simulator adapter"
        if isinstance(p, TypeText) and p.mode is TypingMode.KEYBOARD_TOUCH:
            return ErrorCode.CAPABILITY_UNAVAILABLE, "keyboard_touch typing is not implemented"
        if isinstance(p, OpenApp) and p.app_id not in self.config.allowed_app_ids:
            return ErrorCode.INVALID_PARAMETERS, "app_id not in adapter allowlist"
        if isinstance(p, NavigateUrl) and url_origin(p.url) not in self.config.allowed_url_origins:
            return ErrorCode.INVALID_PARAMETERS, "url origin not in adapter allowlist"
        if isinstance(p, Wait) and p.duration_ms > command.max_duration_ms:
            return ErrorCode.INVALID_PARAMETERS, "wait duration exceeds command max_duration_ms"
        if isinstance(p, TypeText) and p.mode is TypingMode.PACED_TEXT:
            chunks = -(-len(p.text) // self.config.paced_chunk_chars)
            if (chunks - 1) * self.config.paced_interval_ms >= command.max_duration_ms:
                return ErrorCode.INVALID_PARAMETERS, "paced typing cannot finish within max_duration_ms"
        return None

    def _check_fresh(self, command: DispatchCommand, record: _ObservationRecord) -> str | None:
        age_ms = (time.monotonic_ns() - record.monotonic_ns) / 1e6
        if age_ms < 0 or age_ms > command.max_observation_age_ms:
            return f"dispatch observation age {age_ms:.0f} ms exceeds {command.max_observation_age_ms} ms"
        return None

    async def execute(self, command: DispatchCommand) -> ExecutionResult:
        problem = self._precheck(command)
        if problem is not None:
            return self._reject(command, *problem)
        record = self._observations.get(command.dispatch_observation_id)
        if record is None:
            return self._reject(command, ErrorCode.STALE_OBSERVATION, "dispatch observation not captured by this adapter")
        stale = self._check_fresh(command, record)
        if stale is not None:
            return self._reject(command, ErrorCode.STALE_OBSERVATION, stale)
        ref = getattr(command.payload, "element_ref", None)
        if ref is not None and ref not in record.locators:
            return self._reject(command, ErrorCode.INVALID_PARAMETERS, "element_ref not present in dispatch observation")

        started_at, t0 = utc_now(), time.monotonic_ns()
        payload = command.payload
        if isinstance(payload, Wait):
            return await self._wait(command, payload, started_at, t0)

        progress = _Progress()
        try:
            outcome = await self._run_driver(
                lambda: self._perform(command, record, progress),
                command.max_duration_ms / 1000.0,
                command_id=command.command_id,
            )
        except TimeoutError:
            if progress.cancel():
                outcome = _Outcome(
                    ExecutionStatus.UNKNOWN,
                    detail="deadline expired after the side-effecting driver call began",
                    error=ErrorEnvelope(code=ErrorCode.INTERNAL_ERROR, message="driver call timed out"),
                )
            else:
                outcome = _Outcome(
                    ExecutionStatus.FAILED,
                    detail="deadline expired before any side-effecting driver call",
                    error=ErrorEnvelope(code=ErrorCode.INTERNAL_ERROR, message="driver call timed out"),
                )
        except asyncio.CancelledError:
            progress.cancel()
            raise
        return self._result(command, outcome, started_at, t0)

    async def _wait(self, command: DispatchCommand, payload: Wait, started_at: Any, t0: int) -> ExecutionResult:
        """Cancellable sleep; polls the fence so it is interrupted promptly from any loop/thread."""
        end_ns = t0 + payload.duration_ms * 1_000_000
        while not (self._is_fenced(command.control_epoch) or self._closed):
            remaining_s = (end_ns - time.monotonic_ns()) / 1e9
            if remaining_s <= 0:
                return self._result(command, _Outcome(ExecutionStatus.ACKNOWLEDGED, detail="waited"), started_at, t0)
            await asyncio.sleep(min(_WAIT_POLL_S, remaining_s))
        return self._result(
            command,
            _Outcome(
                ExecutionStatus.FAILED,
                detail="wait interrupted by fence",
                error=ErrorEnvelope(code=ErrorCode.DISPATCH_GATE_CLOSED, message="fenced during wait"),
            ),
            started_at,
            t0,
        )

    def _perform(self, command: DispatchCommand, record: _ObservationRecord, progress: _Progress) -> _Outcome:
        """Runs in the driver thread. Classifies every exit by whether a side effect may have begun."""
        try:
            stale = self._check_fresh(command, record)  # measured again when the driver thread starts
            if stale is not None:
                raise _Reject(ErrorCode.STALE_OBSERVATION, stale)
            return self._dispatch(self._drv(), command, record, progress)
        except _Reject as r:
            return _Outcome(ExecutionStatus.REJECTED, detail=r.message, rejection_code=r.code)
        except _Cancelled:
            return _Outcome(ExecutionStatus.FAILED, detail="cancelled before the side-effecting call")
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"[:1500]
            err = ErrorEnvelope(code=ErrorCode.INTERNAL_ERROR, message=msg)
            if progress.side_effect_started:
                return _Outcome(ExecutionStatus.UNKNOWN, detail="driver error after a possible UI effect", error=err)
            return _Outcome(ExecutionStatus.FAILED, detail="driver error before any side-effecting call", error=err)

    def _resolve(self, driver: DriverLike, record: _ObservationRecord, element_ref: str) -> Any:
        loc = record.locators[element_ref]
        by = AppiumBy.ACCESSIBILITY_ID if loc.strategy == "accessibility_id" else AppiumBy.IOS_PREDICATE
        found = driver.find_elements(by, loc.value)
        if len(found) <= loc.index:
            raise _Reject(ErrorCode.STALE_OBSERVATION, f"element {element_ref} no longer present")
        element = found[loc.index]
        if loc.bounds is not None:
            r = element.rect
            tol = self.config.rect_tolerance_pt
            observed = (loc.bounds.x, loc.bounds.y, loc.bounds.width, loc.bounds.height)
            current = (float(r["x"]), float(r["y"]), float(r["width"]), float(r["height"]))
            if any(abs(a - b) > tol for a, b in zip(observed, current, strict=True)):
                raise _Reject(ErrorCode.STALE_OBSERVATION, f"element {element_ref} moved since dispatch observation")
        return element

    def _dispatch(
        self, drv: DriverLike, command: DispatchCommand, record: _ObservationRecord, progress: _Progress
    ) -> _Outcome:
        p: Any = command.payload
        ack = ExecutionStatus.ACKNOWLEDGED
        if isinstance(p, Activate):
            el = self._resolve(drv, record, p.element_ref)
            progress.begin_side_effect()
            el.click()
            return _Outcome(ack, detail="click")
        if isinstance(p, SendMessage):
            el = self._resolve(drv, record, p.element_ref)
            self._check_send_correlation(drv, p)
            progress.begin_side_effect()
            el.click()  # the app sends through its own transport; the harness never sends on its behalf
            return _Outcome(ack, detail="click send control")
        if isinstance(p, TypeText):
            el = self._resolve(drv, record, p.element_ref)
            if p.mode is TypingMode.FIELD_SET:
                progress.begin_side_effect()
                el.send_keys(p.text)
                return _Outcome(ack, detail="field_set via element send_keys", typing_mode=TypingMode.FIELD_SET)
            return self._paced_type(el, p.text, progress, command.control_epoch)
        if isinstance(p, Scroll):
            # ``mobile: swipe`` on the container, not ``mobile: scroll``: on the iOS 27.0 Simulator an
            # element-less ``mobile: scroll`` in Safari long-pressed and selected page text instead.
            swipe = _SWIPE_FOR_SCROLL[p.direction.value]
            target = p.element_ref or record.default_scroll_ref
            args: dict[str, Any] = {"direction": swipe}
            if target is not None:
                args["elementId"] = self._resolve(drv, record, target).id
            progress.begin_side_effect()
            drv.execute_script("mobile: swipe", args)
            where = f"on {target}" if target is not None else "on the application"
            return _Outcome(ack, detail=f"scroll {p.direction.value}: mobile: swipe {swipe} {where}")
        if isinstance(p, OpenApp):
            launch_args = self.config.app_launch_arguments.get(p.app_id)
            state = drv.execute_script("mobile: queryAppState", {"bundleId": p.app_id}) if launch_args else None
            progress.begin_side_effect()
            if launch_args and isinstance(state, int) and state <= 1:
                drv.execute_script("mobile: launchApp", {"bundleId": p.app_id, "arguments": list(launch_args)})
                return _Outcome(ack, detail="mobile: launchApp with configured process arguments")
            drv.execute_script("mobile: activateApp", {"bundleId": p.app_id})
            return _Outcome(ack, detail="mobile: activateApp")
        if isinstance(p, NavigateUrl):
            progress.begin_side_effect()
            drv.execute_script("mobile: deepLink", {"url": p.url, "bundleId": SAFARI_BUNDLE_ID})
            return _Outcome(ack, detail="Safari URL open via mobile: deepLink (not address-bar typing)")
        raise _Reject(ErrorCode.CAPABILITY_UNAVAILABLE, f"unsupported action kind {getattr(p, 'kind', '?')}")

    def _check_send_correlation(self, drv: DriverLike, p: SendMessage) -> None:
        ident = self.config.send_correlation_identifier
        if ident is None:
            return
        found = drv.find_elements(AppiumBy.ACCESSIBILITY_ID, ident)
        if len(found) != 1:
            raise _Reject(ErrorCode.STALE_OBSERVATION, f"draft correlation element {ident} not uniquely present")
        value = found[0].get_attribute("value")
        if str(value) != str(p.client_message_id):
            raise _Reject(ErrorCode.STALE_OBSERVATION, "current draft id differs from payload client_message_id")

    def _paced_type(self, el: Any, text: str, progress: _Progress, control_epoch: int) -> _Outcome:
        size, interval_s = self.config.paced_chunk_chars, self.config.paced_interval_ms / 1000.0
        chunks = [text[i : i + size] for i in range(0, len(text), size)]
        stamps: list[float] = []
        t0 = time.monotonic_ns()
        for i, chunk in enumerate(chunks):
            if i:
                time.sleep(interval_s)
                if self._is_fenced(control_epoch):  # stop typing; some chunks already reached the field
                    return _Outcome(
                        ExecutionStatus.UNKNOWN,
                        detail=f"paced_text interrupted by fence after {i}/{len(chunks)} chunks",
                        typing_mode=TypingMode.PACED_TEXT,
                    )
            progress.begin_side_effect()  # raises _Cancelled after a deadline: stop typing further chunks
            c0 = time.monotonic_ns()
            el.send_keys(chunk)
            stamps.append((c0 - t0) / 1e6)
        gaps = [b - a for a, b in zip(stamps, stamps[1:], strict=False)]
        timing = {
            "chunks": len(chunks),
            "chunk_chars": size,
            "requested_interval_ms": self.config.paced_interval_ms,
            "chunk_start_offsets_ms": [round(s, 1) for s in stamps[:200]],
            "mean_gap_ms": round(sum(gaps) / len(gaps), 1) if gaps else None,
            "total_ms": round((time.monotonic_ns() - t0) / 1e6, 1),
        }
        return _Outcome(
            ExecutionStatus.ACKNOWLEDGED,
            detail="paced_text " + json.dumps(timing, separators=(",", ":")),
            typing_mode=TypingMode.PACED_TEXT,
        )

    # -- preflight / health / close -------------------------------------------------------------------

    async def preflight(self, profile: DeviceProfile) -> CapabilityReport:
        from mobilelab.adapters.ios.preflight import run_preflight

        return await run_preflight(self, profile)

    async def health(self) -> DeviceHealth:
        if self._driver is None:
            return DeviceHealth(
                device_id=self.device_id, healthy=False, session_alive=False,
                evidence_source=self.evidence_source, detail="no Appium session",
            )  # fmt: skip
        if self._lock.locked():
            return DeviceHealth(
                device_id=self.device_id, healthy=True, session_alive=True,
                evidence_source=self.evidence_source, detail="driver busy; session presumed alive",
            )  # fmt: skip
        try:
            app = await self._run_driver(lambda: _active_bundle(self._drv()), min(10.0, self.config.driver_call_timeout_s))
        except Exception as exc:
            return DeviceHealth(
                device_id=self.device_id, healthy=False, session_alive=False,
                evidence_source=self.evidence_source, detail=f"{type(exc).__name__}: {exc}"[:2000],
            )  # fmt: skip
        return DeviceHealth(
            device_id=self.device_id, healthy=True, session_alive=True,
            foreground_app=app, evidence_source=self.evidence_source,
        )  # fmt: skip

    def _close_sync(self) -> None:
        drv, self._driver = self._driver, None
        try:
            if drv is not None:
                drv.quit()
        finally:
            try:
                if self._server is not None:
                    self._server.stop()
            finally:
                if drv is not None and not self.config.keep_wda_running:
                    self.wda_processes_stopped = stop_wda_processes(
                        self.config.udid, self.config.derived_data_path.resolve()
                    )

    async def close(self) -> CloseResult:
        self._closed = True
        try:
            await self._run_driver(self._close_sync, 60.0)
        except Exception as exc:
            return CloseResult(device_id=self.device_id, closed=False, detail=f"{type(exc).__name__}: {exc}"[:2000])
        wda = f"; stopped WDA xcodebuild pids {self.wda_processes_stopped}" if self.wda_processes_stopped else ""
        return CloseResult(device_id=self.device_id, closed=True, detail=f"session quit{wda}")

    # -- helpers for preflight probes -------------------------------------------------------------------

    async def run_probe(self, fn: Callable[[DriverLike], T], timeout_s: float) -> T:
        await self._ensure_session()
        return await self._run_driver(lambda: fn(self._drv()), timeout_s)

    def locator_for(self, observation_id: UUID, element_ref: str) -> Locator | None:
        """The trusted locator ``element_ref`` maps to in a remembered observation (diagnostics)."""
        record = self._observations.get(observation_id)
        return None if record is None else record.locators.get(element_ref)

    def allowed_origin(self, url: str) -> bool:
        return url_origin(url) in self.config.allowed_url_origins and bool(urlsplit(url).netloc)

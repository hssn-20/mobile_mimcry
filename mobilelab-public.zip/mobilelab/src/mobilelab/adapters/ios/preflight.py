"""Capability probes for the iOS adapter (CONTRACTS §3).

A capability is ``supported`` only when this preflight actually exercised it on this device and saw
the expected effect; otherwise it is ``unverified`` (or ``unsupported`` with a reason when the profile
cannot have it, e.g. carrier SMS on a Simulator). Probes never send messages, type into drafts, reset
apps or accept system alerts.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from appium.webdriver.common.appiumby import AppiumBy

from mobilelab.adapters.ios.config import SAFARI_BUNDLE_ID
from mobilelab.adapters.ios.driver import DriverLike
from mobilelab.adapters.ios.page_source import parse_page_source
from mobilelab.domain.base import utc_now
from mobilelab.domain.devices import CapabilityRecord, CapabilityReport, DeviceProfile
from mobilelab.domain.enums import CapabilityKey, CapabilityStatus, DeviceKind, EvidenceCategory, EvidenceSource, Platform
from mobilelab.domain.observations import ObserveRequest

if TYPE_CHECKING:
    from mobilelab.adapters.ios.adapter import IOSXCUITestAdapter

K = CapabilityKey
PROBE_TIMEOUT_S = 120.0
SETTLE_S = 1.0
_SIM_UNSUPPORTED = {
    K.OS_SMS: "iOS Simulator has no SMS transport; Lab Messenger is fixture IP messaging, not OS SMS",
    K.CARRIER_SMS: "iOS Simulator has no cellular radio or SIM",
    K.CARRIER_VOICE: "iOS Simulator has no cellular radio or SIM",
}


def _poll(fn: Callable[[], bool], timeout_s: float, interval_s: float = 0.5) -> bool:
    deadline = time.monotonic() + timeout_s
    while True:
        if fn():
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval_s)


def _active(drv: DriverLike) -> str | None:
    info = drv.execute_script("mobile: activeAppInfo")
    return str(info.get("bundleId")) if isinstance(info, Mapping) and info.get("bundleId") else None


def _text_positions(drv: DriverLike) -> dict[str, float]:
    """y of each uniquely-labelled static text in the current page source."""
    seen: dict[str, float] = {}
    dup: set[str] = set()
    for e in parse_page_source(drv.page_source).elements:
        if e.role != "static_text" or not e.label or e.bounds is None:
            continue
        if e.label in seen:
            dup.add(e.label)
        seen[e.label] = e.bounds.y
    return {k: v for k, v in seen.items() if k not in dup}


def _has_id(drv: DriverLike, identifier: str) -> bool:
    return bool(drv.find_elements(AppiumBy.ACCESSIBILITY_ID, identifier))


class _Records:
    def __init__(self, evidence_source: EvidenceSource) -> None:
        self.by_key: dict[CapabilityKey, CapabilityRecord] = {}
        self._source = evidence_source

    def set(
        self,
        key: CapabilityKey,
        status: CapabilityStatus,
        reason: str,
        *,
        tier: EvidenceCategory | None = None,
        artifact_id: UUID | None = None,
    ) -> None:
        self.by_key[key] = CapabilityRecord(
            key=key,
            status=status,
            evidence_tier=tier,
            evidence_source=self._source,
            last_probed_at=utc_now() if status is CapabilityStatus.SUPPORTED else None,
            probe_artifact_id=artifact_id,
            reason=reason[:2000],
        )

    def unverified(self, key: CapabilityKey, reason: str) -> None:
        self.set(key, CapabilityStatus.UNVERIFIED, reason)


def _safari_probes(adapter: IOSXCUITestAdapter, drv: DriverLike, rec: _Records) -> None:
    cfg = adapter.config
    if SAFARI_BUNDLE_ID not in cfg.allowed_app_ids:
        rec.unverified(K.SWITCH_APP, "Safari not in allowed_app_ids; no app to switch to")
        return
    drv.execute_script("mobile: activateApp", {"bundleId": SAFARI_BUNDLE_ID})
    if _poll(lambda: _active(drv) == SAFARI_BUNDLE_ID, 15):
        rec.set(K.SWITCH_APP, CapabilityStatus.SUPPORTED, "mobile: activateApp Safari; activeAppInfo confirmed foreground")
    else:
        rec.unverified(K.SWITCH_APP, "activateApp Safari issued but Safari not observed in foreground")
        return

    url = cfg.safari_probe_url
    if url is None or not adapter.allowed_origin(url):
        rec.unverified(K.SAFARI_BROWSE, "no allowed safari_probe_url configured")
        rec.unverified(K.SCROLL, "scroll probe needs the Safari probe page")
        return
    drv.execute_script("mobile: deepLink", {"url": url, "bundleId": SAFARI_BUNDLE_ID})
    has_web = _poll(
        lambda: _active(drv) == SAFARI_BUNDLE_ID
        and bool(drv.find_elements(AppiumBy.IOS_PREDICATE, 'type == "XCUIElementTypeWebView"')),
        20,
    )
    if not has_web:
        rec.unverified(K.SAFARI_BROWSE, f"opened {url} but no Safari WebView was observed")
        rec.unverified(K.SCROLL, "scroll probe needs the Safari probe page")
        return
    rec.set(
        K.SAFARI_BROWSE,
        CapabilityStatus.SUPPORTED,
        f"Safari opened {url} via mobile: deepLink; WebView observed in foreground (page text not asserted)",
        tier=EvidenceCategory.FIXTURE,
    )
    # Same gesture as execute(scroll): swipe on the web view. Success is judged from the tree (page
    # text moved up), not from a screenshot diff: on iOS 27.0 an element-less ``mobile: scroll``
    # selected text instead of scrolling, which changed the screenshot without scrolling.
    # Wait for page text, then let the app-switch animation finish: a swipe sent while Safari was
    # still zooming in from the home screen was dropped on the device.
    _poll(lambda: bool(_text_positions(drv)), 15)
    time.sleep(SETTLE_S)
    web = drv.find_elements(AppiumBy.IOS_PREDICATE, 'type == "XCUIElementTypeWebView"')[0]
    before = _text_positions(drv)
    drv.execute_script("mobile: swipe", {"direction": "up", "elementId": web.id})
    time.sleep(SETTLE_S)  # deceleration
    after = _text_positions(drv)
    drv.execute_script("mobile: swipe", {"direction": "down", "elementId": web.id})
    moved = [before[k] - after[k] for k in before.keys() & after.keys()]
    if moved and max(moved) > 20:
        rec.set(
            K.SCROLL,
            CapabilityStatus.SUPPORTED,
            f"mobile: swipe up on the Safari WebView moved page text up by {max(moved):.0f} pt (tree positions)",
        )
    else:
        rec.unverified(K.SCROLL, "mobile: swipe returned but no page text moved in the tree")


def _messenger_probes(adapter: IOSXCUITestAdapter, drv: DriverLike, rec: _Records) -> None:
    cfg = adapter.config
    bundle = cfg.lab_messenger_bundle_id
    if bundle not in cfg.allowed_app_ids:
        rec.unverified(K.FIXTURE_MESSAGE, "Lab Messenger not in allowed_app_ids")
        return
    if not drv.execute_script("mobile: isAppInstalled", {"bundleId": bundle}):
        rec.set(K.FIXTURE_MESSAGE, CapabilityStatus.UNSUPPORTED, f"{bundle} is not installed on this device")
        return
    launch_args = cfg.app_launch_arguments.get(bundle)
    if not launch_args:
        rec.unverified(K.FIXTURE_MESSAGE, "Lab Messenger installed but no fixture launch arguments configured")
        return
    state = drv.execute_script("mobile: queryAppState", {"bundleId": bundle})
    if isinstance(state, int) and state <= 1:
        drv.execute_script("mobile: launchApp", {"bundleId": bundle, "arguments": list(launch_args)})
    else:
        drv.execute_script("mobile: activateApp", {"bundleId": bundle})
    row = f"conversation.row.{cfg.lab_messenger_probe_conversation_id}"
    if not _poll(lambda: _active(drv) == bundle and (_has_id(drv, row) or _has_id(drv, "composer.send")), 20):
        rec.unverified(K.FIXTURE_MESSAGE, "Lab Messenger launched but neither conversation row nor composer observed")
        return
    if not _has_id(drv, "composer.send"):
        drv.find_elements(AppiumBy.ACCESSIBILITY_ID, row)[0].click()
        if _poll(lambda: _has_id(drv, "composer.send"), 10):
            rec.set(
                K.ACTIVATE_ELEMENT,
                CapabilityStatus.SUPPORTED,
                f"tapped {row} in Lab Messenger and observed composer.send appear",
            )
        else:
            rec.unverified(K.FIXTURE_MESSAGE, f"tapped {row} but the composer did not appear")
            return
    drafts = drv.find_elements(AppiumBy.ACCESSIBILITY_ID, "composer.draft_id")
    draft_value = drafts[0].get_attribute("value") if len(drafts) == 1 else None
    try:
        UUID(str(draft_value))
    except ValueError:
        rec.unverified(K.FIXTURE_MESSAGE, "composer.draft_id missing or not a UUID; cannot correlate sends")
        return
    rec.set(
        K.FIXTURE_MESSAGE,
        CapabilityStatus.SUPPORTED,
        "Lab Messenger launched with fixture args; composer.send and UUID composer.draft_id observed. "
        "No message was sent by preflight: delivery is established per run by the receipt oracle.",
        tier=EvidenceCategory.FIXTURE,
    )


async def run_preflight(adapter: IOSXCUITestAdapter, profile: DeviceProfile) -> CapabilityReport:
    rec = _Records(adapter.evidence_source)
    simulator = profile.kind is DeviceKind.SIMULATOR

    try:
        obs = await adapter.observe(
            ObserveRequest(
                request_id=uuid4(),
                device_id=adapter.device_id,
                session_id=uuid4(),
                lease_id=uuid4(),
                lease_epoch=1,
                purpose="preflight",
            )
        )
        if obs.ui_tree:
            rec.set(
                K.OBSERVE_UI,
                CapabilityStatus.SUPPORTED,
                f"page source parsed into {len(obs.ui_tree)} elements; foreground {obs.foreground_app}",
                artifact_id=obs.screenshot_artifact_id,
            )
        else:
            rec.unverified(K.OBSERVE_UI, "page source returned no elements")
        if any(cs.name == "screenshot_px" for cs in obs.coordinate_spaces):
            rec.set(
                K.CAPTURE_SCREEN,
                CapabilityStatus.SUPPORTED,
                "captured a valid PNG screenshot",
                artifact_id=obs.screenshot_artifact_id,
            )
        else:
            rec.unverified(K.CAPTURE_SCREEN, "screenshot missing or not a PNG")
    except Exception as exc:  # report, do not raise: preflight output is evidence either way
        rec.unverified(K.OBSERVE_UI, f"observation probe failed: {type(exc).__name__}: {exc}")
        rec.unverified(K.CAPTURE_SCREEN, "observation probe failed")

    for probe in (_safari_probes, _messenger_probes):
        if K.OBSERVE_UI not in rec.by_key or rec.by_key[K.OBSERVE_UI].status is not CapabilityStatus.SUPPORTED:
            break
        try:
            await adapter.run_probe(lambda drv, p=probe: p(adapter, drv, rec), PROBE_TIMEOUT_S)
        except Exception as exc:
            rec.unverified(K.SAFARI_BROWSE if probe is _safari_probes else K.FIXTURE_MESSAGE,
                           f"probe failed: {type(exc).__name__}: {exc}")  # fmt: skip

    rec.unverified(K.TYPE_TEXT, "not exercised in preflight (would mutate fixture draft state)")
    for key in K:
        if key in rec.by_key:
            continue
        if key in _SIM_UNSUPPORTED and simulator:
            rec.set(key, CapabilityStatus.UNSUPPORTED, _SIM_UNSUPPORTED[key])
        else:
            rec.unverified(key, "no probe implemented for this capability in the iOS adapter")

    return CapabilityReport(
        report_id=uuid4(),
        device_id=adapter.device_id,
        platform=Platform.IOS,
        device_kind=profile.kind,
        evidence_source=adapter.evidence_source,
        adapter_version=adapter.adapter_version,
        probed_at=utc_now(),
        records=[rec.by_key[k] for k in K],
    )

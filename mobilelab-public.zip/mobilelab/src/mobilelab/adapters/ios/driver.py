"""Minimal typed surface of the Appium WebDriver used by the iOS adapter, plus the real factory.

Tests substitute an explicitly labelled fake implementing the same surface.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Protocol

from appium.options.ios import XCUITestOptions


class ElementLike(Protocol):
    @property
    def id(self) -> str: ...

    @property
    def rect(self) -> dict[str, float]: ...

    def click(self) -> None: ...

    def send_keys(self, *value: str) -> None: ...

    def get_attribute(self, name: str) -> Any: ...


class DriverLike(Protocol):
    @property
    def page_source(self) -> str: ...

    @property
    def orientation(self) -> str: ...

    def get_screenshot_as_png(self) -> bytes: ...

    def get_window_size(self) -> dict[str, int]: ...

    def execute_script(self, script: str, *args: Any) -> Any: ...

    def find_elements(self, by: str, value: str) -> list[Any]: ...

    def update_settings(self, settings: dict[str, Any]) -> Any: ...

    def quit(self) -> None: ...


DriverFactory = Callable[[str, XCUITestOptions, float], DriverLike]
"""(appium_url, options, http_timeout_s) -> driver session."""


def appium_driver_factory(url: str, options: XCUITestOptions, timeout_s: float) -> DriverLike:
    from appium import webdriver
    from appium.webdriver.client_config import AppiumClientConfig

    client_config = AppiumClientConfig(remote_server_addr=url, timeout=int(timeout_s), direct_connection=False)
    return webdriver.Remote(url, options=options, client_config=client_config)  # type: ignore[return-value]

"""Adapter registry: name -> adapter class, imported lazily so optional drivers load only when used.

Construction convention (shared with ``mobilelab.workers.registry``): ``cls.from_config(device_id,
options, **deps)`` when the class defines it, else ``cls(device_id=device_id, **options, **deps)``.
``deps`` carries worker-supplied hooks (e.g. ``artifact_sink``).
"""

from __future__ import annotations

import importlib
from collections.abc import Mapping
from typing import Any
from uuid import UUID

from mobilelab.adapters.base import DeviceAdapter

ADAPTERS: dict[str, str] = {
    "ios": "mobilelab.adapters.ios:IOSXCUITestAdapter",
    "mock": "mobilelab.adapters.mock:MockAdapter",
}


class UnknownAdapter(KeyError):
    pass


def target_name(name: str) -> str:
    return ADAPTERS.get(name, name)


def adapter_class(name: str) -> type[Any]:
    try:
        target = ADAPTERS[name]
    except KeyError:
        raise UnknownAdapter(f"unknown adapter {name!r}; known: {sorted(ADAPTERS)}") from None
    module_name, _, attr = target.partition(":")
    return getattr(importlib.import_module(module_name), attr)  # type: ignore[no-any-return]


def create_adapter(name: str, device_id: UUID, options: Mapping[str, Any], **deps: Any) -> DeviceAdapter:
    cls = adapter_class(name)
    factory = getattr(cls, "from_config", None)
    if callable(factory):
        adapter = factory(device_id, dict(options), **deps)
    else:
        adapter = cls(device_id=device_id, **dict(options), **deps)
    if not isinstance(adapter, DeviceAdapter):
        raise TypeError(f"{target_name(name)} does not implement DeviceAdapter")
    return adapter

"""Deterministic semantic rebinding of a chosen candidate onto a fresh dispatch observation (CONTRACTS §4)."""

from __future__ import annotations

from uuid import uuid5

from mobilelab.candidates.generate import generate_candidates
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.observations import CandidateAction, Observation

_CONTEXT_KINDS = frozenset({"foreground_app", "orientation", "element_value"})


def _signature(c: CandidateAction) -> tuple[object, ...]:
    """Everything that must be unchanged for the action to keep its meaning (element refs excluded)."""
    context = tuple((p.kind, p.expected) for p in c.preconditions if p.kind in _CONTEXT_KINDS)
    return (
        c.semantic_key,
        c.kind,
        c.side_effect_class,
        tuple(c.required_capabilities),
        c.permitted.model_dump_json(),
        context,
        c.target_ref is None,
    )


def rebind(original: CandidateAction, fresh: Observation, scope: ScenarioScope) -> CandidateAction | None:
    """A NEW candidate on ``fresh`` with the same meaning as ``original``, or None if anything relevant changed.

    Matches semantic key (target identity), action kind/side-effect class, permitted parameters (e.g.
    contact) and context preconditions (foreground app, orientation, open conversation title, draft
    ``client_message_id``). ``rebound_from_candidate_id`` keeps the root candidate the decision referenced.
    """
    match = next((c for c in generate_candidates(fresh, scope) if c.semantic_key == original.semantic_key), None)
    if match is None or _signature(match) != _signature(original):
        return None
    root = original.rebound_from_candidate_id or original.candidate_id
    return match.model_copy(
        update={
            "candidate_id": uuid5(fresh.observation_id, f"rebind:{root}:{original.candidate_id}"),
            "rebound_from_candidate_id": root,
        }
    )

"""Shared candidate construction: observation-scoped IDs and standard preconditions."""

from __future__ import annotations

from collections.abc import Sequence
from uuid import UUID, uuid5

from mobilelab.domain.enums import ActionKind, CapabilityKey, SideEffectClass
from mobilelab.domain.observations import CandidateAction, Observation, PermittedParameters, Precondition, UIElement


def candidate_id_for(observation_id: UUID, semantic_key: str) -> UUID:
    """Deterministic, observation-scoped candidate ID (unique per observation and semantic key)."""
    return uuid5(observation_id, "candidate:" + semantic_key)


def make_candidate(
    obs: Observation,
    *,
    semantic_key: str,
    kind: ActionKind,
    side_effect: SideEffectClass,
    capabilities: Sequence[CapabilityKey],
    target: UIElement | None = None,
    permitted: PermittedParameters | None = None,
    context: Sequence[Precondition] = (),
) -> CandidateAction:
    pre: list[Precondition] = []
    if target is not None:
        # Foreground app and orientation are only meaningful for on-screen targets; app/url/wait
        # candidates are valid regardless of what is currently in front.
        pre.append(Precondition(kind="foreground_app", expected=obs.foreground_app))
        pre.append(Precondition(kind="orientation", expected=obs.orientation.value))
        pre.append(Precondition(kind="element_visible", element_ref=target.element_ref, expected=True))
        pre.append(Precondition(kind="element_enabled", element_ref=target.element_ref, expected=True))
    pre.extend(context)
    return CandidateAction(
        candidate_id=candidate_id_for(obs.observation_id, semantic_key),
        observation_id=obs.observation_id,
        semantic_key=semantic_key,
        kind=kind,
        target_ref=target.element_ref if target is not None else None,
        required_capabilities=list(capabilities),
        side_effect_class=side_effect,
        preconditions=pre,
        permitted=permitted or PermittedParameters(),
    )


def actionable(element: UIElement) -> bool:
    return element.visible and element.enabled

"""Known app identifiers and the stable semantic-key scheme for candidates.

Semantic keys identify *what* an action means, independent of observation-scoped element refs,
so the same control gets the same key across observations (rebinding, replay).
"""

from __future__ import annotations

import re

LAB_MESSENGER_BUNDLE_ID = "org.mobilelab.fixtures.LabMessenger"
SAFARI_BUNDLE_ID = "com.apple.mobilesafari"

WAIT_DWELL = "wait:dwell"
SAFARI_SCROLL_PREFIX = "safari.scroll:"
SAFARI_LINK_PREFIX = "safari.link:"
APP_OPEN_PREFIX = "app.open:"
URL_OPEN_PREFIX = "url.open:"
MESSENGER_CONVERSATION_PREFIX = "messenger.conversation:"
MESSENGER_COMPOSER_PREFIX = "messenger.composer:"
MESSENGER_SEND_PREFIX = "messenger.send:"

_MAX_LABEL_KEY = 200
_WS = re.compile(r"\s+")


def normalize_label(label: str) -> str:
    """Collapse whitespace and bound length. The label stays untrusted data; this only keys it."""
    return _WS.sub(" ", label).strip()[:_MAX_LABEL_KEY]


def app_open(app_id: str) -> str:
    return APP_OPEN_PREFIX + app_id


def url_open(origin: str) -> str:
    return URL_OPEN_PREFIX + origin


def safari_scroll(direction: str) -> str:
    return SAFARI_SCROLL_PREFIX + direction


def safari_link(label: str) -> str:
    return SAFARI_LINK_PREFIX + normalize_label(label)


def messenger_conversation(conversation_id: str) -> str:
    return MESSENGER_CONVERSATION_PREFIX + conversation_id


def messenger_composer(conversation_id: str) -> str:
    return MESSENGER_COMPOSER_PREFIX + conversation_id


def messenger_send(conversation_id: str) -> str:
    return MESSENGER_SEND_PREFIX + conversation_id

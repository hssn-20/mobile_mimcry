"""Candidate generation from an observation and the scenario scope (CONTRACTS §4).

Only controls of known app profiles produce executable candidates. Anything in an unknown app,
including consequential-looking controls (Send/Call/Buy/Delete/...), produces no candidate; the only
options there are switching to an allowed app, navigating Safari to an allowed origin, or waiting.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable

from mobilelab.candidates import keys, messenger, safari
from mobilelab.candidates._build import make_candidate
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.enums import ActionKind, CapabilityKey, SideEffectClass
from mobilelab.domain.observations import CandidateAction, Observation, PermittedParameters

AppProfile = Callable[[Observation, ScenarioScope], list[CandidateAction]]

APP_PROFILES: dict[str, AppProfile] = {
    keys.LAB_MESSENGER_BUNDLE_ID: messenger.generate,
    keys.SAFARI_BUNDLE_ID: safari.generate,
}


def _global_candidates(obs: Observation, scope: ScenarioScope) -> list[CandidateAction]:
    out = [
        make_candidate(
            obs,
            semantic_key=keys.app_open(app_id),
            kind=ActionKind.OPEN_APP,
            side_effect=SideEffectClass.NAVIGATION,
            capabilities=[CapabilityKey.SWITCH_APP],
            permitted=PermittedParameters(app_ids=[app_id]),
        )
        for app_id in scope.allowed_app_ids
        if app_id != obs.foreground_app
    ]
    out.extend(safari.navigate_candidates(obs, scope))
    out.append(
        make_candidate(
            obs,
            semantic_key=keys.WAIT_DWELL,
            kind=ActionKind.WAIT,
            side_effect=SideEffectClass.NONE,
            capabilities=[],
            permitted=PermittedParameters(max_wait_ms=scope.max_wait_ms),
        )
    )
    return out


def generate_candidates(observation: Observation, scope: ScenarioScope) -> list[CandidateAction]:
    """Executable candidates for this observation, each bound to ``observation.observation_id``.

    Semantic keys are unique: when two controls map to the same key (e.g. duplicate link labels), both
    are dropped because the target would be ambiguous, which also keeps rebinding exact.
    """
    found: list[CandidateAction] = []
    fg = observation.foreground_app
    if fg is not None and fg in scope.allowed_app_ids and fg in APP_PROFILES:
        found.extend(APP_PROFILES[fg](observation, scope))
    found.extend(_global_candidates(observation, scope))
    counts = Counter(c.semantic_key for c in found)
    return [c for c in found if counts[c.semantic_key] == 1]

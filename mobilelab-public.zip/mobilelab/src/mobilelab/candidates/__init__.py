"""Candidate generation and semantic rebinding (CONTRACTS §4). Screen text is untrusted data."""

from mobilelab.candidates import keys
from mobilelab.candidates.generate import APP_PROFILES, generate_candidates
from mobilelab.candidates.keys import LAB_MESSENGER_BUNDLE_ID, SAFARI_BUNDLE_ID
from mobilelab.candidates.messenger import client_message_id_for, message_statuses, open_conversation_id
from mobilelab.candidates.rebind import rebind
from mobilelab.candidates.safari import page_location, page_origin_allowed, page_origin_verified
from mobilelab.candidates.scope import FIXTURE_ORIGIN_PLACEHOLDER, ConversationScope, ScenarioScope, TextPolicy

__all__ = [
    "APP_PROFILES",
    "FIXTURE_ORIGIN_PLACEHOLDER",
    "LAB_MESSENGER_BUNDLE_ID",
    "SAFARI_BUNDLE_ID",
    "ConversationScope",
    "ScenarioScope",
    "TextPolicy",
    "client_message_id_for",
    "generate_candidates",
    "keys",
    "message_statuses",
    "open_conversation_id",
    "page_location",
    "page_origin_allowed",
    "page_origin_verified",
    "rebind",
]

"""Scenario action scope: the trusted allowlists candidate generation enforces (CONTRACTS §4, AC-07).

The scope comes from the frozen scenario configuration, never from observed screen text.
"""

from __future__ import annotations

from typing import Any, Self
from urllib.parse import urlsplit

from pydantic import Field, model_validator

from mobilelab.domain.actions import MAX_TEXT_LENGTH, MAX_WAIT_MS, AppId, ContactId, url_origin, validate_http_url
from mobilelab.domain.base import FrozenModel, Identifier, ShortStr
from mobilelab.domain.enums import TypingMode
from mobilelab.domain.scenarios import ScenarioSpec

FIXTURE_ORIGIN_PLACEHOLDER = "${fixture_data_origin}"
"""Scenario files name the fixture data origin symbolically; it is bound at run creation."""


class ConversationScope(FrozenModel):
    """An allowlisted fixture conversation and the one contact a send in it may address."""

    conversation_id: Identifier
    title: ShortStr
    contact_id: ContactId


class TextPolicy(FrozenModel):
    max_length: int = Field(default=500, ge=1, le=MAX_TEXT_LENGTH)
    allow_generated_text: bool = False
    allowed_texts: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _check(self) -> Self:
        if not self.allow_generated_text and not self.allowed_texts:
            raise ValueError("text_policy must allow generated text or list allowed_texts")
        if any(not t or len(t) > self.max_length for t in self.allowed_texts):
            raise ValueError("allowed_texts must be non-empty and within max_length")
        return self


class ScenarioScope(FrozenModel):
    scenario_id: Identifier
    scenario_version: int = Field(ge=1)
    allowed_app_ids: tuple[AppId, ...] = ()
    allowed_url_origins: tuple[str, ...] = ()
    allowed_contact_ids: tuple[ContactId, ...] = ()
    allowed_conversation_ids: tuple[Identifier, ...] = ()
    conversations: tuple[ConversationScope, ...] = ()
    """Title and contact for allowed conversations; a send candidate needs an entry here."""
    allowed_link_labels: tuple[ShortStr, ...] = ()
    """Exact link labels on allowed-origin pages that may be followed when the link's href is not exposed."""
    link_label_pages: tuple[str, ...] = ()
    """URL paths (e.g. ``/fixture/v1/articles/article-01``) of the pages on which ``allowed_link_labels``
    apply. Empty means any verified allowed-origin page. Page text cannot reuse an allowlisted label on
    another page (e.g. the adversarial page's disguised external "Read next" link) to borrow its trust."""
    text_policy: TextPolicy = Field(default_factory=lambda: TextPolicy(allow_generated_text=True))
    typing_modes: tuple[TypingMode, ...] = (TypingMode.FIELD_SET,)
    max_wait_ms: int = Field(default=60_000, ge=1, le=MAX_WAIT_MS)

    @model_validator(mode="after")
    def _check(self) -> Self:
        for origin in self.allowed_url_origins:
            validate_http_url(origin)
            if url_origin(origin) != origin or urlsplit(origin).path not in ("", "/"):
                raise ValueError(f"allowed_url_origins entries must be bare normalized origins: {origin!r}")
        for path in self.link_label_pages:
            if not path.startswith("/") or path.startswith("//") or "?" in path or "#" in path:
                raise ValueError(f"link_label_pages entries must be absolute URL paths: {path!r}")
        if not self.typing_modes:
            raise ValueError("typing_modes must not be empty")
        for conv in self.conversations:
            if conv.conversation_id not in self.allowed_conversation_ids:
                raise ValueError(f"conversation {conv.conversation_id} is not in allowed_conversation_ids")
            if conv.contact_id not in self.allowed_contact_ids:
                raise ValueError(f"contact {conv.contact_id} is not in allowed_contact_ids")
        titles = [c.title for c in self.conversations]
        if len(titles) != len(set(titles)):
            raise ValueError("conversation titles must be unique (titles identify the open conversation)")
        return self

    def conversation(self, conversation_id: str) -> ConversationScope | None:
        return next((c for c in self.conversations if c.conversation_id == conversation_id), None)

    def conversation_by_title(self, title: str) -> ConversationScope | None:
        return next((c for c in self.conversations if c.title == title), None)

    def allowed_hosts(self) -> set[str]:
        return {(urlsplit(o).hostname or "").lower() for o in self.allowed_url_origins}

    @classmethod
    def from_scenario(cls, spec: ScenarioSpec, *, fixture_data_base_url: str) -> ScenarioScope:
        """Build the scope from ``fixture_setup.action_scope`` binding the fixture origin placeholder."""
        raw = spec.fixture_setup.get("action_scope")
        if not isinstance(raw, dict):
            raise ValueError("scenario fixture_setup.action_scope must be a mapping")
        origin = url_origin(validate_http_url(fixture_data_base_url))
        data: dict[str, Any] = dict(raw)
        data["allowed_url_origins"] = [
            origin if o == FIXTURE_ORIGIN_PLACEHOLDER else o for o in data.get("allowed_url_origins", [])  # type: ignore[union-attr]
        ]
        data["scenario_id"] = spec.scenario_id
        data["scenario_version"] = spec.version
        return cls.model_validate(data)

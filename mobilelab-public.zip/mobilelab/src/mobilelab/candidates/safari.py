"""Safari app profile: links, page scroll and the separate allowlisted navigate_url candidate.

Page text and link labels are untrusted. Page scoping has two strengths:

* origin-verified: the address bar shows a full URL whose origin is allowed;
* host-only: real iOS Safari's compact address bar shows only the host (``127.0.0.1``, no port), so
  any service on that host would match. This is host-level scoping, not origin scoping.

Scroll candidates (no side effect) are offered on either. A link becomes a candidate only when its
destination is known to be in an allowed origin (href exposed in the element value), or, when the href
is not exposed, its exact label is allowlisted by the scenario *and* the page origin is verified (never
on a host-only match) *and*, when the scope lists ``link_label_pages``, the page path is one of them. A
label that embeds a URL outside the allowed origins is always rejected.
"""

from __future__ import annotations

import re
import unicodedata
from urllib.parse import urljoin, urlsplit

from mobilelab.candidates import keys
from mobilelab.candidates._build import actionable, make_candidate
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.actions import url_origin
from mobilelab.domain.enums import ActionKind, CapabilityKey, ScrollDirection, SideEffectClass
from mobilelab.domain.observations import CandidateAction, Observation, PermittedParameters, Precondition, UIElement

LINK_ROLE = "link"
WEBVIEW_ROLE = "webview"
ADDRESS_IDENTIFIERS = frozenset({"TabBarItemTitle", "URL", "Address", "safari.address"})
"""Safari chrome identifiers whose value shows the page address (``safari.address`` is the mock adapter's)."""
_URL_IN_TEXT = re.compile(r"https?://[^\s\"'<>)]+", re.IGNORECASE)
_HOST_TOKEN = re.compile(r"^[a-z0-9.\-]+(:\d+)?$")


def _origin(url: str) -> str | None:
    """Origin of an untrusted URL string, or None when it does not parse."""
    try:
        return url_origin(url)
    except ValueError:
        return None


def normalized_role(role: str) -> str:
    """``XCUIElementTypeWebView`` / ``web_view`` / ``WebView`` -> ``webview`` (raw XCUITest or adapter-normalized)."""
    r = role.removeprefix("XCUIElementType")
    return r.replace("_", "").lower()


def has_role(element: UIElement, role: str) -> bool:
    return normalized_role(element.role) == role


def _inside_webview(obs: Observation, element: UIElement) -> bool:
    """True if any ancestor is a web view (page content must never pose as browser chrome)."""
    parents = {e.element_ref: e for e in obs.ui_tree}
    seen: set[str] = set()
    ref = element.parent_ref
    while ref is not None and ref not in seen:
        seen.add(ref)
        parent = parents.get(ref)
        if parent is None:
            return False
        if has_role(parent, WEBVIEW_ROLE):
            return True
        ref = parent.parent_ref
    return False


def address_bar(obs: Observation) -> UIElement | None:
    """The Safari address element; exactly one, outside any web view, or None."""
    found = [
        e
        for e in obs.ui_tree
        if e.identifier in ADDRESS_IDENTIFIERS and e.value and e.visible and not _inside_webview(obs, e)
    ]
    return found[0] if len(found) == 1 else None


def page_location(obs: Observation) -> tuple[str | None, str | None]:
    """(full URL if the address bar shows one, lower-case host) of the current Safari page."""
    bar = address_bar(obs)
    if bar is None or not bar.value:
        return None, None
    # Real iOS Safari prefixes the compact host with U+200E (LEFT-TO-RIGHT MARK): drop format chars.
    value = "".join(ch for ch in bar.value if unicodedata.category(ch) != "Cf").strip()
    if value.lower().startswith(("http://", "https://")):
        return (value, None) if _origin(value) is None else (value, (urlsplit(value).hostname or "").lower())
    # Compact bar shows e.g. "127.0.0.1" or "Not Secure — 127.0.0.1": take the trailing host token.
    token = re.split(r"[\s—–]+", value)[-1].lower().split("/")[0]
    if not _HOST_TOKEN.match(token):
        return None, None
    return None, token.split(":")[0]


def page_origin_verified(obs: Observation, scope: ScenarioScope) -> bool:
    """The address bar shows a full URL in an allowed origin (scheme, host and port)."""
    url, _ = page_location(obs)
    return url is not None and _origin(url) in scope.allowed_url_origins


def page_origin_allowed(obs: Observation, scope: ScenarioScope) -> bool:
    """Origin-verified, or a host-only match (compact address bar; port not visible)."""
    url, host = page_location(obs)
    if url is not None:
        return _origin(url) in scope.allowed_url_origins
    return host is not None and host in scope.allowed_hosts()


def _link_destination(link: UIElement, page_url: str | None) -> str | None:
    value = (link.value or "").strip()
    if not value:
        return None
    if value.lower().startswith(("http://", "https://")):
        return value
    if value.startswith("/") and not value.startswith("//") and page_url is not None:
        return urljoin(page_url, value)
    return None


def _label_embeds_foreign_url(label: str, scope: ScenarioScope) -> bool:
    return any(_origin(u) not in scope.allowed_url_origins for u in _URL_IN_TEXT.findall(label))


def _link_allowed(link: UIElement, page_url: str | None, scope: ScenarioScope, *, origin_verified: bool) -> bool:
    label = link.label or ""
    if not keys.normalize_label(label) or _label_embeds_foreign_url(label, scope):
        return False
    dest = _link_destination(link, page_url)
    if dest is not None:
        return _origin(dest) in scope.allowed_url_origins
    if not origin_verified or page_url is None:  # host-only page: a label alone says nothing about where it goes
        return False
    if scope.link_label_pages and urlsplit(page_url).path.rstrip("/") not in {
        p.rstrip("/") for p in scope.link_label_pages
    }:
        return False  # allowlisted labels are trusted only on the pages the scenario names
    return keys.normalize_label(label) in {keys.normalize_label(x) for x in scope.allowed_link_labels}


def generate(obs: Observation, scope: ScenarioScope) -> list[CandidateAction]:
    if not page_origin_allowed(obs, scope):
        return []
    out: list[CandidateAction] = []
    page_url, _ = page_location(obs)
    verified = page_origin_verified(obs, scope)
    for el in obs.ui_tree:
        if has_role(el, LINK_ROLE) and actionable(el) and _link_allowed(el, page_url, scope, origin_verified=verified):
            out.append(
                make_candidate(
                    obs,
                    semantic_key=keys.safari_link(el.label or ""),
                    kind=ActionKind.ACTIVATE,
                    side_effect=SideEffectClass.NAVIGATION,
                    capabilities=[CapabilityKey.ACTIVATE_ELEMENT, CapabilityKey.SAFARI_BROWSE],
                    target=el,
                )
            )
    # Real iOS Safari nests web views (WebView > WebView > WebView): only outermost ones are page roots.
    webviews = [e for e in obs.ui_tree if has_role(e, WEBVIEW_ROLE) and e.visible and not _inside_webview(obs, e)]
    if len(webviews) > 1:
        return out  # ambiguous scroll target
    # Without an exposed web view the scroll is untargeted (the adapter scrolls the screen).
    target = webviews[0] if webviews else None
    for direction in (ScrollDirection.DOWN, ScrollDirection.UP):
        out.append(
            make_candidate(
                obs,
                semantic_key=keys.safari_scroll(direction.value),
                kind=ActionKind.SCROLL,
                side_effect=SideEffectClass.NONE,
                capabilities=[CapabilityKey.SCROLL],
                target=target,
                permitted=PermittedParameters(scroll_directions=[direction]),
                context=[] if target else [Precondition(kind="foreground_app", expected=obs.foreground_app)],
            )
        )
    return out


def navigate_candidates(obs: Observation, scope: ScenarioScope) -> list[CandidateAction]:
    """One navigate_url candidate per allowed origin (address bar is never typed into directly)."""
    if keys.SAFARI_BUNDLE_ID not in scope.allowed_app_ids:
        return []
    return [
        make_candidate(
            obs,
            semantic_key=keys.url_open(origin),
            kind=ActionKind.NAVIGATE_URL,
            side_effect=SideEffectClass.NAVIGATION,
            capabilities=[CapabilityKey.SAFARI_BROWSE],
            permitted=PermittedParameters(url_origins=[origin]),
        )
        for origin in scope.allowed_url_origins
    ]

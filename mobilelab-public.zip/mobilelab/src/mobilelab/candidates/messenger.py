"""Lab Messenger app profile (fixtures/ios/LabMessenger README accessibility contract).

Only controls with known fixture identifiers become candidates. ``composer.send`` always becomes a
``send_message`` candidate (never a generic activate); its contact comes from the scope entry of the
*currently open* conversation and its correlation ID from the ``composer.draft_id`` value.
"""

from __future__ import annotations

from uuid import UUID

from mobilelab.candidates import keys
from mobilelab.candidates._build import actionable, make_candidate
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.enums import ActionKind, CapabilityKey, SideEffectClass
from mobilelab.domain.errors import InvalidParameters
from mobilelab.domain.observations import CandidateAction, Observation, PermittedParameters, Precondition, UIElement

ROW_PREFIX = "conversation.row."
TITLE_ID = "conversation.title"
COMPOSER_ID = "composer.text"
SEND_ID = "composer.send"
DRAFT_ID = "composer.draft_id"
STATUS_PREFIX = "message.status."


def _unique(obs: Observation, identifier: str) -> UIElement | None:
    found = [e for e in obs.ui_tree if e.identifier == identifier and e.visible]
    return found[0] if len(found) == 1 else None


def _draft_uuid(element: UIElement | None) -> UUID | None:
    if element is None or not element.value:
        return None
    try:
        parsed = UUID(element.value.strip())
    except ValueError:
        return None
    return parsed if str(parsed) == element.value.strip().lower() else None


def open_conversation_id(obs: Observation, scope: ScenarioScope) -> str | None:
    """Allowed conversation currently open, identified by its exact allowlisted title."""
    title = _unique(obs, TITLE_ID)
    if title is None or title.label is None:
        return None
    conv = scope.conversation_by_title(title.label)
    return conv.conversation_id if conv is not None else None


def message_statuses(obs: Observation) -> dict[str, str]:
    """``client_message_id`` -> status value shown for outbound messages."""
    return {
        e.identifier[len(STATUS_PREFIX) :]: (e.value or "")
        for e in obs.ui_tree
        if e.identifier and e.identifier.startswith(STATUS_PREFIX)
    }


def generate(obs: Observation, scope: ScenarioScope) -> list[CandidateAction]:
    out: list[CandidateAction] = []
    allowed_rows = set(scope.allowed_conversation_ids)
    for el in obs.ui_tree:
        if not (el.identifier and el.identifier.startswith(ROW_PREFIX) and actionable(el)):
            continue
        conv_id = el.identifier[len(ROW_PREFIX) :]
        if conv_id in allowed_rows:
            out.append(
                make_candidate(
                    obs,
                    semantic_key=keys.messenger_conversation(conv_id),
                    kind=ActionKind.ACTIVATE,
                    side_effect=SideEffectClass.NAVIGATION,
                    capabilities=[CapabilityKey.ACTIVATE_ELEMENT],
                    target=el,
                )
            )

    conv_id = open_conversation_id(obs, scope)
    conv = scope.conversation(conv_id) if conv_id else None
    title = _unique(obs, TITLE_ID)
    if conv is None or title is None:
        return out
    context = [Precondition(kind="element_value", element_ref=title.element_ref, expected=title.label)]
    draft = _unique(obs, DRAFT_ID)
    draft_id = _draft_uuid(draft)
    if draft is not None and draft_id is not None:
        context.append(Precondition(kind="element_value", element_ref=draft.element_ref, expected=str(draft_id)))

    composer = _unique(obs, COMPOSER_ID)
    if composer is not None and actionable(composer):
        policy = scope.text_policy
        out.append(
            make_candidate(
                obs,
                semantic_key=keys.messenger_composer(conv.conversation_id),
                kind=ActionKind.TYPE_TEXT,
                side_effect=SideEffectClass.TEXT_ENTRY,
                capabilities=[CapabilityKey.TYPE_TEXT],
                target=composer,
                permitted=PermittedParameters(
                    allow_generated_text=policy.allow_generated_text,
                    allowed_texts=list(policy.allowed_texts),
                    max_text_length=policy.max_length,
                    typing_modes=list(scope.typing_modes),
                ),
                context=context,
            )
        )

    send = _unique(obs, SEND_ID)
    if send is not None and actionable(send) and draft_id is not None:
        out.append(
            make_candidate(
                obs,
                semantic_key=keys.messenger_send(conv.conversation_id),
                kind=ActionKind.SEND_MESSAGE,
                side_effect=SideEffectClass.NON_IDEMPOTENT_COMMIT,
                capabilities=[CapabilityKey.FIXTURE_MESSAGE, CapabilityKey.ACTIVATE_ELEMENT],
                target=send,
                permitted=PermittedParameters(contact_id=conv.contact_id),
                context=context,
            )
        )
    return out


def client_message_id_for(candidate: CandidateAction, observation: Observation) -> UUID:
    """Trusted draft identity for a send candidate, read from its bound ``composer.draft_id`` precondition."""
    if candidate.kind is not ActionKind.SEND_MESSAGE or candidate.observation_id != observation.observation_id:
        raise InvalidParameters("client_message_id is only defined for a send candidate of this observation")
    for pre in candidate.preconditions:
        if pre.kind != "element_value" or pre.element_ref is None:
            continue
        el = observation.element(pre.element_ref)
        if el is not None and el.identifier == DRAFT_ID and isinstance(pre.expected, str):
            draft = _draft_uuid(el)
            if draft is not None and str(draft) == pre.expected:
                return draft
    raise InvalidParameters("send candidate has no bound draft identity")

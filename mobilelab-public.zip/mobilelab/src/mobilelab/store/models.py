"""SQLAlchemy 2.x table models for CONTRACTS §11.

Query-relevant fields are columns; the full Pydantic document lives in ``body`` (JSON, without the
``version`` key, which is the optimistic-concurrency column managed by the ORM).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Dialect,
    ForeignKey,
    Index,
    Integer,
    MetaData,
    String,
    TypeDecorator,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, declared_attr, mapped_column

_TS_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


class UtcDateTime(TypeDecorator[datetime]):
    """Aware UTC datetime stored as fixed-width ISO text (lexicographically sortable)."""

    impl = String(27)
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect: Dialect) -> str | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("naive datetime cannot be persisted")
        return value.astimezone(UTC).strftime(_TS_FORMAT)

    def process_result_value(self, value: str | None, dialect: Dialect) -> datetime | None:
        if value is None:
            return None
        return datetime.strptime(value, _TS_FORMAT).replace(tzinfo=UTC)


NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

Uuid36 = String(36)


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)
    type_annotation_map = {datetime: UtcDateTime(), dict[str, Any]: JSON()}


class _Versioned:
    """Persisted-entity columns; ``version`` is the ORM optimistic-concurrency counter."""

    schema_version: Mapped[int] = mapped_column(Integer, default=1)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime]

    @declared_attr.directive
    def __mapper_args__(cls) -> dict[str, Any]:
        return {"version_id_col": cls.__table__.c.version}  # type: ignore[attr-defined]


class DeviceProfileRow(_Versioned, Base):
    __tablename__ = "device_profiles"
    device_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    platform: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(16))
    name: Mapped[str] = mapped_column(String(256))
    updated_at: Mapped[datetime]
    body: Mapped[dict[str, Any]]


class CapabilityRecordRow(Base):
    """Append-only capability evidence history, one row per (report, key)."""

    __tablename__ = "capability_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    report_id: Mapped[str] = mapped_column(Uuid36)
    device_id: Mapped[str] = mapped_column(ForeignKey("device_profiles.device_id"))
    key: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16))
    evidence_tier: Mapped[str | None] = mapped_column(String(32))
    evidence_source: Mapped[str] = mapped_column(String(16))
    last_probed_at: Mapped[datetime | None]
    probe_artifact_id: Mapped[str | None] = mapped_column(Uuid36)
    reason: Mapped[str] = mapped_column(String(2000), default="")
    report_body: Mapped[dict[str, Any]]
    created_at: Mapped[datetime]
    __table_args__ = (
        UniqueConstraint("report_id", "key", name="uq_capability_records_report_key"),
        Index("ix_capability_records_device_key", "device_id", "key"),
    )


class ConfigRevisionRow(_Versioned, Base):
    __tablename__ = "config_revisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String(16))
    config_id: Mapped[str] = mapped_column(String(128))
    revision: Mapped[int] = mapped_column(Integer)
    content_hash: Mapped[str] = mapped_column(String(64))
    content: Mapped[dict[str, Any]]
    __table_args__ = (
        UniqueConstraint("kind", "config_id", "revision", name="uq_config_revisions_kind_id_rev"),
        UniqueConstraint("kind", "config_id", "content_hash", name="uq_config_revisions_kind_id_hash"),
    )


class CampaignRow(_Versioned, Base):
    __tablename__ = "campaigns"
    campaign_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    name: Mapped[str] = mapped_column(String(256))
    body: Mapped[dict[str, Any]]


class RunRow(_Versioned, Base):
    __tablename__ = "runs"
    run_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    campaign_id: Mapped[str | None] = mapped_column(ForeignKey("campaigns.campaign_id"))
    device_id: Mapped[str] = mapped_column(Uuid36, index=True)
    status: Mapped[str] = mapped_column(String(16), index=True)
    verdict: Mapped[str | None] = mapped_column(String(32))
    control_epoch: Mapped[int] = mapped_column(Integer, default=0)
    spec_hash: Mapped[str] = mapped_column(String(64))
    updated_at: Mapped[datetime]
    body: Mapped[dict[str, Any]]


class LeaseRow(_Versioned, Base):
    __tablename__ = "leases"
    lease_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    device_id: Mapped[str] = mapped_column(Uuid36)
    run_id: Mapped[str | None] = mapped_column(ForeignKey("runs.run_id"))
    kind: Mapped[str] = mapped_column(String(16))
    epoch: Mapped[int] = mapped_column(Integer)
    holder: Mapped[str] = mapped_column(String(256))
    status: Mapped[str] = mapped_column(String(16))
    acquired_at: Mapped[datetime]
    released_at: Mapped[datetime | None]
    release_reason: Mapped[str | None] = mapped_column(String(2000))
    __table_args__ = (
        UniqueConstraint("device_id", "epoch", name="uq_leases_device_epoch"),
        # At most one active lease (automation OR operator) per device, enforced by the database.
        Index("uq_leases_one_active_per_device", "device_id", unique=True, sqlite_where=text("status = 'active'")),
    )


class ObservationRow(_Versioned, Base):
    __tablename__ = "observations"
    observation_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str | None] = mapped_column(ForeignKey("runs.run_id"), index=True)
    device_id: Mapped[str] = mapped_column(Uuid36)
    session_id: Mapped[str] = mapped_column(Uuid36)
    evidence_source: Mapped[str] = mapped_column(String(16))
    capture_started_at: Mapped[datetime]
    capture_ended_at: Mapped[datetime]
    screenshot_artifact_id: Mapped[str | None] = mapped_column(Uuid36)
    body: Mapped[dict[str, Any]]


class DecisionRow(_Versioned, Base):
    __tablename__ = "decisions"
    decision_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str] = mapped_column(ForeignKey("runs.run_id"), index=True)
    decision_observation_id: Mapped[str] = mapped_column(Uuid36)
    candidate_id: Mapped[str | None] = mapped_column(Uuid36)
    provider_id: Mapped[str] = mapped_column(String(128))
    control_epoch: Mapped[int] = mapped_column(Integer)
    outcome: Mapped[str] = mapped_column(String(32))  # accepted | discarded_stale | cancelled | rejected | provider_error
    latency_ms: Mapped[float | None]
    body: Mapped[dict[str, Any]]


class ActionRow(_Versioned, Base):
    __tablename__ = "actions"
    action_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str] = mapped_column(ForeignKey("runs.run_id"), index=True)
    device_id: Mapped[str] = mapped_column(Uuid36)
    decision_id: Mapped[str | None] = mapped_column(Uuid36)
    kind: Mapped[str] = mapped_column(String(32))
    side_effect_class: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), index=True)
    correlation_id: Mapped[str | None] = mapped_column(Uuid36, index=True)
    updated_at: Mapped[datetime]
    body: Mapped[dict[str, Any]]


class AttemptRow(_Versioned, Base):
    __tablename__ = "attempts"
    attempt_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    action_id: Mapped[str] = mapped_column(ForeignKey("actions.action_id"))
    attempt_no: Mapped[int] = mapped_column(Integer)
    command_id: Mapped[str] = mapped_column(Uuid36, unique=True)
    status: Mapped[str | None] = mapped_column(String(16))
    body: Mapped[dict[str, Any]]
    __table_args__ = (UniqueConstraint("action_id", "attempt_no", name="uq_attempts_action_attempt_no"),)


class OracleResultRow(_Versioned, Base):
    __tablename__ = "oracle_results"
    oracle_result_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str] = mapped_column(ForeignKey("runs.run_id"), index=True)
    oracle_kind: Mapped[str] = mapped_column(String(128))
    verdict: Mapped[str] = mapped_column(String(32))
    body: Mapped[dict[str, Any]]


class CommandRow(_Versioned, Base):
    __tablename__ = "commands"
    command_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))
    run_id: Mapped[str | None] = mapped_column(Uuid36, index=True)
    device_id: Mapped[str | None] = mapped_column(Uuid36)
    status: Mapped[str] = mapped_column(String(16))
    updated_at: Mapped[datetime]
    body: Mapped[dict[str, Any]]


class EventRow(Base):
    __tablename__ = "events"
    event_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    type: Mapped[str] = mapped_column(String(64))
    timestamp: Mapped[datetime]
    run_id: Mapped[str | None] = mapped_column(Uuid36, index=True)
    device_id: Mapped[str | None] = mapped_column(Uuid36, index=True)
    action_id: Mapped[str | None] = mapped_column(Uuid36)
    payload_version: Mapped[int] = mapped_column(Integer, default=1)
    payload: Mapped[dict[str, Any]]
    # AUTOINCREMENT guarantees ids are never reused, so SSE cursors stay monotonic.
    __table_args__ = {"sqlite_autoincrement": True}


class ArtifactRow(_Versioned, Base):
    __tablename__ = "artifacts"
    artifact_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str | None] = mapped_column(Uuid36, index=True)
    sha256: Mapped[str] = mapped_column(String(64))
    size_bytes: Mapped[int] = mapped_column(Integer)
    content_type: Mapped[str] = mapped_column(String(128))
    relative_path: Mapped[str] = mapped_column(String(1024), unique=True)
    evidence_source: Mapped[str] = mapped_column(String(16))


class IdempotencyRow(Base):
    __tablename__ = "idempotency_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    idempotency_key: Mapped[str] = mapped_column(String(256))
    method: Mapped[str] = mapped_column(String(8))
    path: Mapped[str] = mapped_column(String(1024))
    request_hash: Mapped[str] = mapped_column(String(64))
    status_code: Mapped[int] = mapped_column(Integer)
    response_body: Mapped[dict[str, Any]]
    resource_id: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime]
    __table_args__ = (UniqueConstraint("idempotency_key", name="uq_idempotency_records_key"),)
    """A key identifies one request globally; reuse on another method/path/body is a conflict (§10)."""


class GlobalControlRow(Base):
    """Single row (id=1): persisted dispatch gate and global fence epoch."""

    __tablename__ = "global_control"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gate_open: Mapped[bool] = mapped_column(Boolean, nullable=False)
    global_epoch: Mapped[int] = mapped_column(Integer, nullable=False)
    reason: Mapped[str | None] = mapped_column(String(2000))
    updated_at: Mapped[datetime]
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __table_args__ = (CheckConstraint("id = 1", name="singleton"),)
    __mapper_args__ = {"version_id_col": version}



class ProviderUsageRow(Base):
    """Provider spend ledger (CONTRACTS §11, T08): one row per reserved model request.

    Amounts are integer micro-USD. ``status`` is ``reserved`` (in flight), ``confirmed`` (provider
    reported usage), ``unresolved`` (timeout/cancel/transport failure after send: kept reserved) or
    ``released`` (provably not billed, e.g. rejected before generation). No secrets are stored.
    """

    __tablename__ = "provider_usage"
    reservation_id: Mapped[str] = mapped_column(Uuid36, primary_key=True)
    run_id: Mapped[str | None] = mapped_column(String(64), index=True)
    provider_id: Mapped[str] = mapped_column(String(128))
    model_identifier: Mapped[str] = mapped_column(String(256))
    purpose: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), index=True)
    rate_card_id: Mapped[str] = mapped_column(String(128))
    max_input_tokens: Mapped[int] = mapped_column(Integer)
    max_output_tokens: Mapped[int] = mapped_column(Integer)
    reserved_micro_usd: Mapped[int] = mapped_column(Integer)
    confirmed_micro_usd: Mapped[int | None] = mapped_column(Integer)
    input_tokens: Mapped[int | None] = mapped_column(Integer)
    cached_input_tokens: Mapped[int | None] = mapped_column(Integer)
    output_tokens: Mapped[int | None] = mapped_column(Integer)
    reasoning_tokens: Mapped[int | None] = mapped_column(Integer)
    request_id: Mapped[str | None] = mapped_column(String(256))
    correlation_id: Mapped[str | None] = mapped_column(String(64))
    error_class: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime]
    updated_at: Mapped[datetime]
    __table_args__ = (
        CheckConstraint(
            "status IN ('reserved', 'confirmed', 'unresolved', 'released')", name="status_valid"
        ),
        CheckConstraint("reserved_micro_usd >= 0", name="reserved_non_negative"),
    )

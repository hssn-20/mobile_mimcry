"""Alembic environment. Use mobilelab.store.migrate.upgrade_to_head(engine) rather than the CLI."""

from __future__ import annotations

from alembic import context
from sqlalchemy import Connection

from mobilelab.store.engine import create_sqlite_engine
from mobilelab.store.models import Base

config = context.config
target_metadata = Base.metadata


def _run(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata, render_as_batch=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connection = config.attributes.get("connection")
    if connection is not None:
        _run(connection)
        return
    url = config.get_main_option("sqlalchemy.url")
    assert url and url.startswith("sqlite+pysqlite:///"), "only local SQLite databases are supported"
    engine = create_sqlite_engine(url.removeprefix("sqlite+pysqlite:///"))
    with engine.begin() as conn:
        _run(conn)


if context.is_offline_mode():
    raise RuntimeError("offline migrations are not supported")
run_migrations_online()

"""provider usage / budget ledger (CONTRACTS §11 cost reservation, T08)

Revision ID: 0003_provider_usage
Revises: 0002_idempotency_key
Create Date: 2026-10-04 10:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0003_provider_usage"
down_revision: str | None = "0002_idempotency_key"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "provider_usage",
        sa.Column("reservation_id", sa.String(length=36), nullable=False),
        sa.Column("run_id", sa.String(length=64), nullable=True),
        sa.Column("provider_id", sa.String(length=128), nullable=False),
        sa.Column("model_identifier", sa.String(length=256), nullable=False),
        sa.Column("purpose", sa.String(length=32), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("rate_card_id", sa.String(length=128), nullable=False),
        sa.Column("max_input_tokens", sa.Integer(), nullable=False),
        sa.Column("max_output_tokens", sa.Integer(), nullable=False),
        sa.Column("reserved_micro_usd", sa.Integer(), nullable=False),
        sa.Column("confirmed_micro_usd", sa.Integer(), nullable=True),
        sa.Column("input_tokens", sa.Integer(), nullable=True),
        sa.Column("cached_input_tokens", sa.Integer(), nullable=True),
        sa.Column("output_tokens", sa.Integer(), nullable=True),
        sa.Column("reasoning_tokens", sa.Integer(), nullable=True),
        sa.Column("request_id", sa.String(length=256), nullable=True),
        sa.Column("correlation_id", sa.String(length=64), nullable=True),
        sa.Column("error_class", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.String(length=27), nullable=False),
        sa.Column("updated_at", sa.String(length=27), nullable=False),
        sa.CheckConstraint(
            "status IN ('reserved', 'confirmed', 'unresolved', 'released')",
            name=op.f("ck_provider_usage_status_valid"),
        ),
        sa.CheckConstraint("reserved_micro_usd >= 0", name=op.f("ck_provider_usage_reserved_non_negative")),
        sa.PrimaryKeyConstraint("reservation_id", name=op.f("pk_provider_usage")),
    )
    with op.batch_alter_table("provider_usage", schema=None) as batch_op:
        batch_op.create_index(batch_op.f("ix_provider_usage_run_id"), ["run_id"], unique=False)
        batch_op.create_index(batch_op.f("ix_provider_usage_status"), ["status"], unique=False)


def downgrade() -> None:
    with op.batch_alter_table("provider_usage", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_provider_usage_status"))
        batch_op.drop_index(batch_op.f("ix_provider_usage_run_id"))
    op.drop_table("provider_usage")

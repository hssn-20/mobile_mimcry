"""initial schema (CONTRACTS §11 tables + global dispatch gate)

Revision ID: 0001_initial
Revises: 
Create Date: 2026-10-03 18:37:45.014063
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime

import sqlalchemy as sa
from alembic import op

revision: str = '0001_initial'
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table('artifacts',
    sa.Column('artifact_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=True),
    sa.Column('sha256', sa.String(length=64), nullable=False),
    sa.Column('size_bytes', sa.Integer(), nullable=False),
    sa.Column('content_type', sa.String(length=128), nullable=False),
    sa.Column('relative_path', sa.String(length=1024), nullable=False),
    sa.Column('evidence_source', sa.String(length=16), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('artifact_id', name=op.f('pk_artifacts')),
    sa.UniqueConstraint('relative_path', name=op.f('uq_artifacts_relative_path'))
    )
    with op.batch_alter_table('artifacts', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_artifacts_run_id'), ['run_id'], unique=False)

    op.create_table('campaigns',
    sa.Column('campaign_id', sa.String(length=36), nullable=False),
    sa.Column('name', sa.String(length=256), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('campaign_id', name=op.f('pk_campaigns'))
    )
    op.create_table('commands',
    sa.Column('command_id', sa.String(length=36), nullable=False),
    sa.Column('kind', sa.String(length=32), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=True),
    sa.Column('device_id', sa.String(length=36), nullable=True),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('updated_at', sa.String(length=27), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('command_id', name=op.f('pk_commands'))
    )
    with op.batch_alter_table('commands', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_commands_run_id'), ['run_id'], unique=False)

    op.create_table('config_revisions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('kind', sa.String(length=16), nullable=False),
    sa.Column('config_id', sa.String(length=128), nullable=False),
    sa.Column('revision', sa.Integer(), nullable=False),
    sa.Column('content_hash', sa.String(length=64), nullable=False),
    sa.Column('content', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_config_revisions')),
    sa.UniqueConstraint('kind', 'config_id', 'content_hash', name='uq_config_revisions_kind_id_hash'),
    sa.UniqueConstraint('kind', 'config_id', 'revision', name='uq_config_revisions_kind_id_rev')
    )
    op.create_table('device_profiles',
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('platform', sa.String(length=16), nullable=False),
    sa.Column('kind', sa.String(length=16), nullable=False),
    sa.Column('name', sa.String(length=256), nullable=False),
    sa.Column('updated_at', sa.String(length=27), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('device_id', name=op.f('pk_device_profiles'))
    )
    op.create_table('events',
    sa.Column('event_id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('type', sa.String(length=64), nullable=False),
    sa.Column('timestamp', sa.String(length=27), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=True),
    sa.Column('device_id', sa.String(length=36), nullable=True),
    sa.Column('action_id', sa.String(length=36), nullable=True),
    sa.Column('payload_version', sa.Integer(), nullable=False),
    sa.Column('payload', sa.JSON(), nullable=False),
    sa.PrimaryKeyConstraint('event_id', name=op.f('pk_events')),
    sqlite_autoincrement=True
    )
    with op.batch_alter_table('events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_events_device_id'), ['device_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_events_run_id'), ['run_id'], unique=False)

    op.create_table('global_control',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('gate_open', sa.Boolean(), nullable=False),
    sa.Column('global_epoch', sa.Integer(), nullable=False),
    sa.Column('reason', sa.String(length=2000), nullable=True),
    sa.Column('updated_at', sa.String(length=27), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.CheckConstraint('id = 1', name=op.f('ck_global_control_singleton')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_global_control'))
    )
    # The dispatch gate starts CLOSED; the operator/coordinator must open it explicitly.
    op.bulk_insert(
        sa.table(
            'global_control',
            sa.column('id', sa.Integer()),
            sa.column('gate_open', sa.Boolean()),
            sa.column('global_epoch', sa.Integer()),
            sa.column('reason', sa.String()),
            sa.column('updated_at', sa.String()),
            sa.column('version', sa.Integer()),
        ),
        [{'id': 1, 'gate_open': False, 'global_epoch': 0, 'reason': 'initial migration',
          'updated_at': datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%S.%fZ'), 'version': 1}],
    )
    op.create_table('idempotency_records',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('idempotency_key', sa.String(length=256), nullable=False),
    sa.Column('method', sa.String(length=8), nullable=False),
    sa.Column('path', sa.String(length=1024), nullable=False),
    sa.Column('request_hash', sa.String(length=64), nullable=False),
    sa.Column('status_code', sa.Integer(), nullable=False),
    sa.Column('response_body', sa.JSON(), nullable=False),
    sa.Column('resource_id', sa.String(length=64), nullable=True),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_idempotency_records')),
    sa.UniqueConstraint('idempotency_key', 'method', 'path', name='uq_idempotency_records_key_method_path')
    )
    op.create_table('capability_records',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('report_id', sa.String(length=36), nullable=False),
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('key', sa.String(length=64), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('evidence_tier', sa.String(length=32), nullable=True),
    sa.Column('evidence_source', sa.String(length=16), nullable=False),
    sa.Column('last_probed_at', sa.String(length=27), nullable=True),
    sa.Column('probe_artifact_id', sa.String(length=36), nullable=True),
    sa.Column('reason', sa.String(length=2000), nullable=False),
    sa.Column('report_body', sa.JSON(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['device_id'], ['device_profiles.device_id'], name=op.f('fk_capability_records_device_id_device_profiles')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_capability_records')),
    sa.UniqueConstraint('report_id', 'key', name='uq_capability_records_report_key')
    )
    with op.batch_alter_table('capability_records', schema=None) as batch_op:
        batch_op.create_index('ix_capability_records_device_key', ['device_id', 'key'], unique=False)

    op.create_table('runs',
    sa.Column('run_id', sa.String(length=36), nullable=False),
    sa.Column('campaign_id', sa.String(length=36), nullable=True),
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('verdict', sa.String(length=32), nullable=True),
    sa.Column('control_epoch', sa.Integer(), nullable=False),
    sa.Column('spec_hash', sa.String(length=64), nullable=False),
    sa.Column('updated_at', sa.String(length=27), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.campaign_id'], name=op.f('fk_runs_campaign_id_campaigns')),
    sa.PrimaryKeyConstraint('run_id', name=op.f('pk_runs'))
    )
    with op.batch_alter_table('runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_runs_device_id'), ['device_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_runs_status'), ['status'], unique=False)

    op.create_table('actions',
    sa.Column('action_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=False),
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('decision_id', sa.String(length=36), nullable=True),
    sa.Column('kind', sa.String(length=32), nullable=False),
    sa.Column('side_effect_class', sa.String(length=32), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('correlation_id', sa.String(length=36), nullable=True),
    sa.Column('updated_at', sa.String(length=27), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['run_id'], ['runs.run_id'], name=op.f('fk_actions_run_id_runs')),
    sa.PrimaryKeyConstraint('action_id', name=op.f('pk_actions'))
    )
    with op.batch_alter_table('actions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_actions_correlation_id'), ['correlation_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_actions_run_id'), ['run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_actions_status'), ['status'], unique=False)

    op.create_table('decisions',
    sa.Column('decision_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=False),
    sa.Column('decision_observation_id', sa.String(length=36), nullable=False),
    sa.Column('candidate_id', sa.String(length=36), nullable=True),
    sa.Column('provider_id', sa.String(length=128), nullable=False),
    sa.Column('control_epoch', sa.Integer(), nullable=False),
    sa.Column('outcome', sa.String(length=32), nullable=False),
    sa.Column('latency_ms', sa.Double(), nullable=True),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['run_id'], ['runs.run_id'], name=op.f('fk_decisions_run_id_runs')),
    sa.PrimaryKeyConstraint('decision_id', name=op.f('pk_decisions'))
    )
    with op.batch_alter_table('decisions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_decisions_run_id'), ['run_id'], unique=False)

    op.create_table('leases',
    sa.Column('lease_id', sa.String(length=36), nullable=False),
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=True),
    sa.Column('kind', sa.String(length=16), nullable=False),
    sa.Column('epoch', sa.Integer(), nullable=False),
    sa.Column('holder', sa.String(length=256), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('acquired_at', sa.String(length=27), nullable=False),
    sa.Column('released_at', sa.String(length=27), nullable=True),
    sa.Column('release_reason', sa.String(length=2000), nullable=True),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['run_id'], ['runs.run_id'], name=op.f('fk_leases_run_id_runs')),
    sa.PrimaryKeyConstraint('lease_id', name=op.f('pk_leases')),
    sa.UniqueConstraint('device_id', 'epoch', name='uq_leases_device_epoch')
    )
    with op.batch_alter_table('leases', schema=None) as batch_op:
        batch_op.create_index('uq_leases_one_active_per_device', ['device_id'], unique=True, sqlite_where=sa.text("status = 'active'"))

    op.create_table('observations',
    sa.Column('observation_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=True),
    sa.Column('device_id', sa.String(length=36), nullable=False),
    sa.Column('session_id', sa.String(length=36), nullable=False),
    sa.Column('evidence_source', sa.String(length=16), nullable=False),
    sa.Column('capture_started_at', sa.String(length=27), nullable=False),
    sa.Column('capture_ended_at', sa.String(length=27), nullable=False),
    sa.Column('screenshot_artifact_id', sa.String(length=36), nullable=True),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['run_id'], ['runs.run_id'], name=op.f('fk_observations_run_id_runs')),
    sa.PrimaryKeyConstraint('observation_id', name=op.f('pk_observations'))
    )
    with op.batch_alter_table('observations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_observations_run_id'), ['run_id'], unique=False)

    op.create_table('oracle_results',
    sa.Column('oracle_result_id', sa.String(length=36), nullable=False),
    sa.Column('run_id', sa.String(length=36), nullable=False),
    sa.Column('oracle_kind', sa.String(length=128), nullable=False),
    sa.Column('verdict', sa.String(length=32), nullable=False),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['run_id'], ['runs.run_id'], name=op.f('fk_oracle_results_run_id_runs')),
    sa.PrimaryKeyConstraint('oracle_result_id', name=op.f('pk_oracle_results'))
    )
    with op.batch_alter_table('oracle_results', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_oracle_results_run_id'), ['run_id'], unique=False)

    op.create_table('attempts',
    sa.Column('attempt_id', sa.String(length=36), nullable=False),
    sa.Column('action_id', sa.String(length=36), nullable=False),
    sa.Column('attempt_no', sa.Integer(), nullable=False),
    sa.Column('command_id', sa.String(length=36), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=True),
    sa.Column('body', sa.JSON(), nullable=False),
    sa.Column('schema_version', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.String(length=27), nullable=False),
    sa.ForeignKeyConstraint(['action_id'], ['actions.action_id'], name=op.f('fk_attempts_action_id_actions')),
    sa.PrimaryKeyConstraint('attempt_id', name=op.f('pk_attempts')),
    sa.UniqueConstraint('action_id', 'attempt_no', name='uq_attempts_action_attempt_no'),
    sa.UniqueConstraint('command_id', name=op.f('uq_attempts_command_id'))
    )


def downgrade() -> None:
    op.drop_table('attempts')
    with op.batch_alter_table('oracle_results', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_oracle_results_run_id'))

    op.drop_table('oracle_results')
    with op.batch_alter_table('observations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_observations_run_id'))

    op.drop_table('observations')
    with op.batch_alter_table('leases', schema=None) as batch_op:
        batch_op.drop_index('uq_leases_one_active_per_device', sqlite_where=sa.text("status = 'active'"))

    op.drop_table('leases')
    with op.batch_alter_table('decisions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_decisions_run_id'))

    op.drop_table('decisions')
    with op.batch_alter_table('actions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_actions_status'))
        batch_op.drop_index(batch_op.f('ix_actions_run_id'))
        batch_op.drop_index(batch_op.f('ix_actions_correlation_id'))

    op.drop_table('actions')
    with op.batch_alter_table('runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_runs_status'))
        batch_op.drop_index(batch_op.f('ix_runs_device_id'))

    op.drop_table('runs')
    with op.batch_alter_table('capability_records', schema=None) as batch_op:
        batch_op.drop_index('ix_capability_records_device_key')

    op.drop_table('capability_records')
    op.drop_table('idempotency_records')
    op.drop_table('global_control')
    with op.batch_alter_table('events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_events_run_id'))
        batch_op.drop_index(batch_op.f('ix_events_device_id'))

    op.drop_table('events')
    op.drop_table('device_profiles')
    op.drop_table('config_revisions')
    with op.batch_alter_table('commands', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_commands_run_id'))

    op.drop_table('commands')
    op.drop_table('campaigns')
    with op.batch_alter_table('artifacts', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_artifacts_run_id'))

    op.drop_table('artifacts')

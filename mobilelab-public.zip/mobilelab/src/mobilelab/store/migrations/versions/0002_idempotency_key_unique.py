"""idempotency keys are unique on their own (CONTRACTS §10: reuse with different content -> 409)

Revision ID: 0002_idempotency_key
Revises: 0001_initial
Create Date: 2026-10-03 21:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op

revision: str = "0002_idempotency_key"
down_revision: str | None = "0001_initial"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    with op.batch_alter_table("idempotency_records", schema=None) as batch_op:
        batch_op.drop_constraint("uq_idempotency_records_key_method_path", type_="unique")
        batch_op.create_unique_constraint("uq_idempotency_records_key", ["idempotency_key"])


def downgrade() -> None:
    with op.batch_alter_table("idempotency_records", schema=None) as batch_op:
        batch_op.drop_constraint("uq_idempotency_records_key", type_="unique")
        batch_op.create_unique_constraint(
            "uq_idempotency_records_key_method_path", ["idempotency_key", "method", "path"]
        )

"""SQLite (WAL) engine factory.

Write transactions start with ``BEGIN IMMEDIATE`` so the single coordinator writer never hits a
read->write lock upgrade failure; read-only sessions use ``BEGIN DEFERRED``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import Engine, create_engine, event

READONLY_OPTION = "mobilelab_readonly"


def create_sqlite_engine(db_path: Path | str, *, busy_timeout_ms: int = 5000, echo: bool = False) -> Engine:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(f"sqlite+pysqlite:///{path}", echo=echo)

    @event.listens_for(engine, "connect")
    def _on_connect(dbapi_conn: Any, _record: Any) -> None:
        dbapi_conn.isolation_level = None  # let the "begin" hook control transactions
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)}")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.close()

    @event.listens_for(engine, "begin")
    def _on_begin(conn: Any) -> None:
        readonly = conn.get_execution_options().get(READONLY_OPTION, False)
        conn.exec_driver_sql("BEGIN DEFERRED" if readonly else "BEGIN IMMEDIATE")

    return engine


def journal_mode(engine: Engine) -> str:
    with engine.connect() as conn:
        return str(conn.exec_driver_sql("PRAGMA journal_mode").scalar())

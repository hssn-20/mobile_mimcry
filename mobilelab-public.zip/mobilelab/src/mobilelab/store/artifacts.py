"""Artifact files: atomic temp-file + rename writes and strict path containment (CONTRACTS §11).

Write the file first, then commit its metadata with ``UnitOfWork.add_artifact``. Never expose
absolute filesystem paths through the API; resolve only stored relative paths via ``resolve``.
"""

from __future__ import annotations

import hashlib
import os
import re
import tempfile
from pathlib import Path, PurePosixPath
from uuid import UUID, uuid4

from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.enums import EvidenceSource
from mobilelab.domain.errors import ArtifactPathViolation

_SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


class ArtifactStore:
    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._root_resolved = self.root.resolve()

    def resolve(self, relative_path: str) -> Path:
        """Map a stored relative path to a file inside the root, rejecting any escape."""
        if not relative_path or "\x00" in relative_path or "\\" in relative_path:
            raise ArtifactPathViolation("invalid artifact path")
        pure = PurePosixPath(relative_path)
        segments = relative_path.split("/")
        if pure.is_absolute() or any(seg in {"", ".", ".."} for seg in segments):
            raise ArtifactPathViolation("artifact path must be a normalized relative path")
        candidate = (self._root_resolved / pure).resolve()
        if not candidate.is_relative_to(self._root_resolved) or candidate == self._root_resolved:
            raise ArtifactPathViolation("artifact path escapes the artifact root")
        return candidate

    def write_bytes(
        self,
        data: bytes,
        *,
        filename: str,
        content_type: str,
        evidence_source: EvidenceSource,
        run_id: UUID | None = None,
        artifact_id: UUID | None = None,
    ) -> ArtifactMetadata:
        if not _SAFE_NAME.match(filename):
            raise ArtifactPathViolation("unsafe artifact filename", details={"filename": filename})
        aid = artifact_id or uuid4()
        folder = f"runs/{run_id}" if run_id is not None else "global"
        relative = f"{folder}/{aid}-{filename}"
        target = self.resolve(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            raise ArtifactPathViolation("artifact already exists; artifacts are immutable")
        fd, tmp = tempfile.mkstemp(dir=target.parent, prefix=".tmp-", suffix=".part")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, target)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise
        dir_fd = os.open(target.parent, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
        return ArtifactMetadata(
            artifact_id=aid,
            run_id=run_id,
            sha256=hashlib.sha256(data).hexdigest(),
            size_bytes=len(data),
            content_type=content_type,
            relative_path=relative,
            evidence_source=evidence_source,
        )

    def read_bytes(self, meta: ArtifactMetadata, *, verify: bool = True) -> bytes:
        data = self.resolve(meta.relative_path).read_bytes()
        if verify and hashlib.sha256(data).hexdigest() != meta.sha256:
            raise ArtifactPathViolation("artifact digest mismatch", details={"artifact_id": str(meta.artifact_id)})
        return data

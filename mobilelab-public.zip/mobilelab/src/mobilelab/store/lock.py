"""Single-coordinator process lock: fcntl.flock on ``<db>.lock`` next to the database.

A second acquirer (another process, or another open file description in the same process) fails
fast with CoordinatorLocked. The lock file is never deleted, avoiding unlink/recreate races; the OS
releases the lock automatically if the holder dies.
"""

from __future__ import annotations

import fcntl
import os
from pathlib import Path
from types import TracebackType
from typing import Self

from mobilelab.domain.errors import CoordinatorLocked


def lock_path_for(db_path: Path | str) -> Path:
    p = Path(db_path)
    return p.with_name(p.name + ".lock")


class CoordinatorLock:
    def __init__(self, db_path: Path | str) -> None:
        self.path = lock_path_for(db_path)
        self._fd: int | None = None

    @property
    def held(self) -> bool:
        return self._fd is not None

    def acquire(self) -> None:
        if self._fd is not None:
            raise CoordinatorLocked("lock already held by this object")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            holder = os.pread(fd, 64, 0).decode(errors="replace").strip()
            os.close(fd)
            raise CoordinatorLocked(
                "another coordinator owns this database", details={"lock_path": str(self.path), "holder_pid": holder}
            ) from None
        except BaseException:
            os.close(fd)
            raise
        os.ftruncate(fd, 0)
        os.pwrite(fd, f"{os.getpid()}\n".encode(), 0)
        self._fd = fd

    def release(self) -> None:
        if self._fd is None:
            return
        try:
            fcntl.flock(self._fd, fcntl.LOCK_UN)
        finally:
            os.close(self._fd)
            self._fd = None

    def __enter__(self) -> Self:
        self.acquire()
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None
    ) -> None:
        self.release()

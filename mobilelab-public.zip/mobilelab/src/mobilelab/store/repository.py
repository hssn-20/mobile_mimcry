"""Unit of work over SQLite with optimistic versioning.

* Every state change and its Event row are written in the same transaction; events are handed to
  the optional publisher only after a successful commit.
* ``expected_version`` mismatches raise VersionConflict (with current state); the ORM version column
  also guards concurrent writers (StaleDataError -> VersionConflict).
* Run/action status changes are validated by mobilelab.domain.transitions.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from types import TracebackType
from typing import Any, Self, TypeVar
from uuid import UUID

from pydantic import BaseModel
from sqlalchemy import Engine, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.orm.exc import StaleDataError

from mobilelab.domain.artifacts import ArtifactMetadata
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import ControlCommand, GateState
from mobilelab.domain.decisions import DecisionRecord
from mobilelab.domain.devices import CapabilityReport, DeviceProfile
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, ExecutionResult
from mobilelab.domain.enums import (
    ActionStatus,
    CommandStatus,
    ConfigKind,
    EventType,
    EvidenceCategory,
    EvidenceSource,
    LeaseKind,
    LeaseStatus,
    RunStatus,
    Verdict,
)
from mobilelab.domain.errors import (
    DispatchGateClosed,
    IdempotencyConflict,
    InvalidTransition,
    LeaseConflict,
    MobilelabError,
    NotFound,
    StaleEpoch,
    StaleLease,
    TerminalRecordImmutable,
    VersionConflict,
)
from mobilelab.domain.events import EVENT_ADAPTER, Event, validate_event_payload
from mobilelab.domain.evidence import require_verdict_evidence
from mobilelab.domain.hashing import config_hash
from mobilelab.domain.observations import Observation
from mobilelab.domain.runs import Campaign, ConfigRevision, Lease, Run
from mobilelab.domain.scenarios import OracleResult
from mobilelab.domain.transitions import POTENTIALLY_EXECUTED, RUN_TERMINAL, transition_action, transition_run
from mobilelab.store.engine import READONLY_OPTION, create_sqlite_engine
from mobilelab.store.migrate import upgrade_to_head
from mobilelab.store.models import (
    ActionRow,
    ArtifactRow,
    AttemptRow,
    CampaignRow,
    CapabilityRecordRow,
    CommandRow,
    ConfigRevisionRow,
    DecisionRow,
    DeviceProfileRow,
    EventRow,
    GlobalControlRow,
    IdempotencyRow,
    LeaseRow,
    ObservationRow,
    OracleResultRow,
    RunRow,
)

M = TypeVar("M", bound=BaseModel)
Publisher = Callable[[Sequence[Event]], None]

# Transitions that invalidate outstanding provider requests / commands for the run.
_EPOCH_BUMP_TARGETS = frozenset({RunStatus.PAUSING, RunStatus.STOPPING, RunStatus.FAILED, RunStatus.ABORTED})

# Journaled once, before dispatch: may change only while the action is still before PREPARED (i.e. up
# to and including the transition into PREPARED). Afterwards the audited payload is immutable (§6).
_ACTION_BINDING_FIELDS = frozenset({"dispatch_observation_id", "dispatch_candidate_id", "payload", "correlation_id"})
_ACTION_BINDING_MUTABLE_FROM = frozenset({ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED})

_ACTION_UPDATABLE = _ACTION_BINDING_FIELDS | frozenset(
    {
        "reject_code",
        "sampled_delay_ms",
        "decision_latency_ms",
        "scheduled_at",
        "actual_dispatch_at",
        "timing_overrun_ms",
    }
)


def _s(value: UUID | None) -> str | None:
    return None if value is None else str(value)


def _body(model: BaseModel) -> dict[str, Any]:
    return model.model_dump(mode="json", exclude={"version"})


def _load(model: type[M], body: dict[str, Any], version: int) -> M:
    return model.model_validate({**body, "version": version})


@dataclass(frozen=True, slots=True)
class IdempotencyRecord:
    idempotency_key: str
    method: str
    path: str
    request_hash: str
    status_code: int
    response_body: dict[str, Any]
    resource_id: str | None
    created_at: datetime


class Store:
    """Owns the engine and session factories. Only the coordinator process should write."""

    def __init__(self, engine: Engine, *, publisher: Publisher | None = None) -> None:
        self.engine = engine
        self.publisher = publisher
        self._write = sessionmaker(bind=engine, expire_on_commit=False)
        self._read = sessionmaker(bind=engine.execution_options(**{READONLY_OPTION: True}), expire_on_commit=False)

    @classmethod
    def open(cls, db_path: Path | str, *, migrate: bool = True, publisher: Publisher | None = None) -> Store:
        engine = create_sqlite_engine(db_path)
        if migrate:
            upgrade_to_head(engine)
        return cls(engine, publisher=publisher)

    def unit_of_work(self) -> UnitOfWork:
        return UnitOfWork(self._write(), publisher=self.publisher, readonly=False)

    def reader(self) -> UnitOfWork:
        return UnitOfWork(self._read(), publisher=None, readonly=True)

    def close(self) -> None:
        self.engine.dispose()


class UnitOfWork:
    def __init__(self, session: Session, *, publisher: Publisher | None, readonly: bool) -> None:
        self.session = session
        self._publisher = publisher
        self._readonly = readonly
        self._pending: list[Event] = []
        self.committed_events: list[Event] = []

    # -- transaction control -------------------------------------------------------------------

    def __enter__(self) -> Self:
        self.session.begin()
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None
    ) -> None:
        try:
            if exc_type is not None or self._readonly:
                self.session.rollback()
                return
            try:
                self.session.commit()
            except StaleDataError as err:
                self.session.rollback()
                raise VersionConflict("concurrent modification detected at commit") from err
            self.committed_events = list(self._pending)
        finally:
            self.session.close()
        if self.committed_events and self._publisher is not None:
            self._publisher(self.committed_events)

    def _writable(self) -> None:
        if self._readonly:
            raise RuntimeError("read-only unit of work")

    def _flush(self) -> None:
        try:
            self.session.flush()
        except StaleDataError as err:
            raise VersionConflict("concurrent modification detected") from err

    @staticmethod
    def _check_version(kind: str, ident: object, current: int, expected: int | None, state: dict[str, Any]) -> None:
        if expected is not None and expected != current:
            raise VersionConflict(
                f"{kind} {ident} is at version {current}, expected {expected}",
                details={"expected_version": expected, "current_version": current},
                current_state={**state, "version": current},
            )

    def _get[R](self, row_type: type[R], ident: str, kind: str) -> R:
        row = self.session.get(row_type, ident)
        if row is None:
            raise NotFound(f"{kind} {ident} not found")
        return row

    # -- events --------------------------------------------------------------------------------

    def append_event(
        self,
        type: EventType,
        *,
        run_id: UUID | None = None,
        device_id: UUID | None = None,
        action_id: UUID | None = None,
        payload: BaseModel | dict[str, Any],
        payload_version: int = 1,
    ) -> Event:
        """Validate ``payload`` against the type's payload model and journal the event (uncommitted)."""
        self._writable()
        body = validate_event_payload(type, payload)
        row = EventRow(
            type=type.value,
            timestamp=utc_now(),
            run_id=_s(run_id),
            device_id=_s(device_id),
            action_id=_s(action_id),
            payload_version=payload_version,
            payload=body,
        )
        self.session.add(row)
        self._flush()
        event = self._event(row)
        self._pending.append(event)
        return event

    @staticmethod
    def _event(row: EventRow) -> Event:
        return EVENT_ADAPTER.validate_python(
            {
                "event_id": row.event_id,
                "type": row.type,
                "timestamp": row.timestamp,
                "run_id": row.run_id,
                "device_id": row.device_id,
                "action_id": row.action_id,
                "payload_version": row.payload_version,
                "payload": row.payload,
            }
        )

    def events_after(
        self,
        after_event_id: int | None = None,
        *,
        run_id: UUID | None = None,
        device_id: UUID | None = None,
        limit: int = 500,
    ) -> list[Event]:
        stmt = select(EventRow).order_by(EventRow.event_id).limit(limit)
        if after_event_id is not None:
            stmt = stmt.where(EventRow.event_id > after_event_id)
        if run_id is not None:
            stmt = stmt.where(EventRow.run_id == str(run_id))
        if device_id is not None:
            stmt = stmt.where(EventRow.device_id == str(device_id))
        return [self._event(r) for r in self.session.scalars(stmt)]

    def event_id_bounds(self) -> tuple[int | None, int | None]:
        """(oldest retained, newest) event ids; used to detect cursors that predate retention."""
        lo, hi = self.session.execute(select(func.min(EventRow.event_id), func.max(EventRow.event_id))).one()
        return lo, hi

    # -- dispatch gate -------------------------------------------------------------------------

    def _gate_row(self) -> GlobalControlRow:
        row = self.session.get(GlobalControlRow, 1)
        if row is None:
            raise NotFound("global_control row missing; run migrations")
        return row

    @staticmethod
    def _gate(row: GlobalControlRow) -> GateState:
        return GateState(
            gate_open=row.gate_open,
            global_epoch=row.global_epoch,
            reason=row.reason,
            updated_at=row.updated_at,
            version=row.version,
        )

    def get_gate(self) -> GateState:
        return self._gate(self._gate_row())

    def require_gate_open(self) -> GateState:
        gate = self.get_gate()
        if not gate.gate_open:
            raise DispatchGateClosed("global dispatch gate is closed", current_state=gate.model_dump(mode="json"))
        return gate

    def close_gate(self, reason: str) -> GateState:
        """Persist a closed gate and increment the global fence epoch (emergency stop / restart)."""
        self._writable()
        row = self._gate_row()
        row.gate_open = False
        row.global_epoch += 1
        row.reason = reason
        row.updated_at = utc_now()
        self._flush()
        gate = self._gate(row)
        self.append_event(EventType.GATE_CHANGED, payload=gate.model_dump(mode="json"))
        return gate

    def open_gate(self, reason: str, *, expected_version: int | None = None) -> GateState:
        self._writable()
        row = self._gate_row()
        self._check_version("gate", 1, row.version, expected_version, {"gate_open": row.gate_open})
        row.gate_open = True
        row.reason = reason
        row.updated_at = utc_now()
        self._flush()
        gate = self._gate(row)
        self.append_event(EventType.GATE_CHANGED, payload=gate.model_dump(mode="json"))
        return gate

    # -- devices and capability evidence -------------------------------------------------------

    def upsert_device_profile(self, profile: DeviceProfile, *, expected_version: int | None = None) -> DeviceProfile:
        self._writable()
        row = self.session.get(DeviceProfileRow, str(profile.device_id))
        now = utc_now()
        if row is None:
            if expected_version is not None:
                raise NotFound(f"device {profile.device_id} not found")
            row = DeviceProfileRow(device_id=str(profile.device_id), created_at=profile.created_at, schema_version=1)
            self.session.add(row)
        else:
            self._check_version("device", profile.device_id, row.version, expected_version, {})
        row.platform = profile.platform.value
        row.kind = profile.kind.value
        row.name = profile.name
        row.updated_at = now
        row.body = _body(profile.model_copy(update={"created_at": row.created_at}))
        self._flush()
        saved = _load(DeviceProfile, row.body, row.version)
        self.append_event(
            EventType.DEVICE_UPDATED, device_id=profile.device_id, payload={"version": row.version}
        )
        return saved

    def get_device_profile(self, device_id: UUID) -> DeviceProfile:
        row = self._get(DeviceProfileRow, str(device_id), "device")
        return _load(DeviceProfile, row.body, row.version)

    def list_device_profiles(self) -> list[DeviceProfile]:
        rows = self.session.scalars(select(DeviceProfileRow).order_by(DeviceProfileRow.created_at))
        return [_load(DeviceProfile, r.body, r.version) for r in rows]

    def add_capability_report(self, report: CapabilityReport) -> DeviceProfile:
        """Append the report's records to history and merge them into the device profile by key."""
        self._writable()
        profile = self.get_device_profile(report.device_id)
        if profile.kind is not report.device_kind or profile.platform is not report.platform:
            raise MobilelabError("capability report platform/kind does not match the device profile")
        report_body = report.model_dump(mode="json", exclude={"records"})
        for rec in report.records:
            self.session.add(
                CapabilityRecordRow(
                    report_id=str(report.report_id),
                    device_id=str(report.device_id),
                    key=rec.key.value,
                    status=rec.status.value,
                    evidence_tier=rec.evidence_tier.value if rec.evidence_tier else None,
                    evidence_source=rec.evidence_source.value,
                    last_probed_at=rec.last_probed_at,
                    probe_artifact_id=_s(rec.probe_artifact_id),
                    reason=rec.reason,
                    report_body=report_body,
                    created_at=utc_now(),
                )
            )
        merged = {c.key: c for c in profile.capabilities} | {r.key: r for r in report.records}
        return self.upsert_device_profile(
            profile.model_copy(update={"capabilities": list(merged.values())}), expected_version=profile.version
        )

    # -- configuration revisions ---------------------------------------------------------------

    def add_config_revision(
        self, kind: ConfigKind, config_id: str, content: BaseModel | dict[str, Any]
    ) -> ConfigRevision:
        """Immutable revisions: identical content returns the existing revision; changes append one."""
        self._writable()
        plain = content.model_dump(mode="json") if isinstance(content, BaseModel) else content
        digest = config_hash(plain)
        existing = self.session.scalars(
            select(ConfigRevisionRow).where(
                ConfigRevisionRow.kind == kind.value,
                ConfigRevisionRow.config_id == config_id,
                ConfigRevisionRow.content_hash == digest,
            )
        ).first()
        if existing is not None:
            return self._config(existing)
        latest = self.session.scalar(
            select(func.max(ConfigRevisionRow.revision)).where(
                ConfigRevisionRow.kind == kind.value, ConfigRevisionRow.config_id == config_id
            )
        )
        rev = ConfigRevision(kind=kind, config_id=config_id, revision=(latest or 0) + 1, content_hash=digest, content=plain)
        row = ConfigRevisionRow(
            kind=kind.value,
            config_id=config_id,
            revision=rev.revision,
            content_hash=digest,
            content=plain,
            created_at=rev.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        return self._config(row)

    @staticmethod
    def _config(row: ConfigRevisionRow) -> ConfigRevision:
        return ConfigRevision(
            kind=ConfigKind(row.kind),
            config_id=row.config_id,
            revision=row.revision,
            content_hash=row.content_hash,
            content=row.content,
            created_at=row.created_at,
            version=row.version,
        )

    def get_config_revision(self, kind: ConfigKind, config_id: str, revision: int | None = None) -> ConfigRevision:
        stmt = select(ConfigRevisionRow).where(
            ConfigRevisionRow.kind == kind.value, ConfigRevisionRow.config_id == config_id
        )
        stmt = (
            stmt.where(ConfigRevisionRow.revision == revision)
            if revision is not None
            else stmt.order_by(ConfigRevisionRow.revision.desc())
        )
        row = self.session.scalars(stmt).first()
        if row is None:
            raise NotFound(f"{kind} {config_id} revision {revision or 'latest'} not found")
        return self._config(row)

    def list_config_revisions(self, kind: ConfigKind) -> list[ConfigRevision]:
        stmt = (
            select(ConfigRevisionRow)
            .where(ConfigRevisionRow.kind == kind.value)
            .order_by(ConfigRevisionRow.config_id, ConfigRevisionRow.revision)
        )
        return [self._config(r) for r in self.session.scalars(stmt)]

    # -- campaigns -----------------------------------------------------------------------------

    def add_campaign(self, campaign: Campaign) -> Campaign:
        self._writable()
        row = CampaignRow(
            campaign_id=str(campaign.campaign_id),
            name=campaign.name,
            body=_body(campaign),
            created_at=campaign.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        return _load(Campaign, row.body, row.version)

    def get_campaign(self, campaign_id: UUID) -> Campaign:
        row = self._get(CampaignRow, str(campaign_id), "campaign")
        return _load(Campaign, row.body, row.version)

    def list_campaigns(self) -> list[Campaign]:
        rows = self.session.scalars(select(CampaignRow).order_by(CampaignRow.created_at))
        return [_load(Campaign, r.body, r.version) for r in rows]

    # -- runs ----------------------------------------------------------------------------------

    def add_run(self, run: Run) -> Run:
        self._writable()
        if run.status is not RunStatus.CREATED:
            raise InvalidTransition("runs must be created in CREATED status")
        row = RunRow(
            run_id=str(run.run_id),
            campaign_id=_s(run.campaign_id),
            device_id=str(run.spec.device_id),
            status=run.status.value,
            verdict=None,
            control_epoch=run.control_epoch,
            spec_hash=run.spec.spec_hash(),
            updated_at=run.created_at,
            body=_body(run.model_copy(update={"updated_at": run.created_at})),
            created_at=run.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        self.append_event(
            EventType.RUN_STATUS_CHANGED,
            run_id=run.run_id,
            device_id=run.spec.device_id,
            payload={"from_status": None, "to_status": RunStatus.CREATED.value, "version": row.version},
        )
        return _load(Run, row.body, row.version)

    def get_run(self, run_id: UUID) -> Run:
        row = self._get(RunRow, str(run_id), "run")
        return _load(Run, row.body, row.version)

    def _mutable_run(self, run_id: UUID, what: str) -> Run:
        run = self.get_run(run_id)
        if run.status in RUN_TERMINAL:
            raise TerminalRecordImmutable(
                f"run {run_id} is terminal ({run.status}); {what}", current_state={"status": run.status.value}
            )
        return run

    def list_runs(self, *, statuses: Iterable[RunStatus] | None = None, limit: int = 500) -> list[Run]:
        stmt = select(RunRow).order_by(RunRow.created_at).limit(limit)
        if statuses is not None:
            stmt = stmt.where(RunRow.status.in_([s.value for s in statuses]))
        return [_load(Run, r.body, r.version) for r in self.session.scalars(stmt)]

    def transition_run(
        self,
        run_id: UUID,
        target: RunStatus,
        *,
        expected_version: int | None = None,
        reason: str | None = None,
        recovery: bool = False,
        verdict: Verdict | None = None,
        obtained_evidence: EvidenceCategory | None = None,
        obtained_evidence_source: EvidenceSource | None = None,
    ) -> Run:
        """Validated lifecycle change + event in this transaction.

        A PASS/DUT_FAILURE verdict requires obtained device evidence of exactly the run's planned
        category (EvidenceTierMismatch otherwise; fixture never satisfies physical_carrier etc.).
        Entering PAUSING/STOPPING/FAILED/ABORTED and resuming PAUSED->RUNNING increment the run's
        control epoch so late provider results and stale commands are discarded.
        """
        self._writable()
        row = self._get(RunRow, str(run_id), "run")
        current = _load(Run, row.body, row.version)
        self._check_version("run", run_id, row.version, expected_version, {"status": row.status})
        step = transition_run(current.status, target, recovery=recovery)
        if target not in RUN_TERMINAL and (
            verdict is not None or obtained_evidence is not None or obtained_evidence_source is not None
        ):
            raise InvalidTransition("verdict and obtained evidence may only be recorded on entering a terminal status")
        require_verdict_evidence(
            verdict,
            current.spec.planned_evidence,
            obtained_evidence,
            device_kind=current.spec.device_kind,
            evidence_source=obtained_evidence_source,
        )
        now = utc_now()
        bump = target in _EPOCH_BUMP_TARGETS or (current.status is RunStatus.PAUSED and target is RunStatus.RUNNING)
        updates: dict[str, Any] = {
            "status": target,
            "status_reason": reason,
            "updated_at": now,
            "in_recovery": recovery or (current.in_recovery and target is RunStatus.PAUSING),
            "control_epoch": current.control_epoch + (1 if bump else 0),
        }
        if target is RunStatus.RUNNING and current.started_at is None:
            updates["started_at"] = now
        if target in RUN_TERMINAL:
            updates["ended_at"] = now
            updates["verdict"] = verdict
            updates["obtained_evidence"] = obtained_evidence
            updates["obtained_evidence_source"] = obtained_evidence_source
        new = Run.model_validate({**current.model_dump(), **updates})
        row.status = target.value
        row.verdict = new.verdict.value if new.verdict else None
        row.control_epoch = new.control_epoch
        row.updated_at = now
        row.body = _body(new)
        self._flush()
        self.append_event(
            EventType.RUN_STATUS_CHANGED,
            run_id=run_id,
            device_id=current.spec.device_id,
            payload={
                "from_status": step.source.value,
                "to_status": step.target.value,
                "recovery": step.recovery,
                "reason": reason,
                "control_epoch": new.control_epoch,
                "verdict": new.verdict.value if new.verdict else None,
                "version": row.version,
            },
        )
        return _load(Run, row.body, row.version)

    # -- leases --------------------------------------------------------------------------------

    @staticmethod
    def _lease(row: LeaseRow) -> Lease:
        return Lease(
            lease_id=row.lease_id,  # type: ignore[arg-type]
            device_id=row.device_id,  # type: ignore[arg-type]
            run_id=row.run_id,  # type: ignore[arg-type]
            kind=LeaseKind(row.kind),
            epoch=row.epoch,
            holder=row.holder,
            status=LeaseStatus(row.status),
            acquired_at=row.acquired_at,
            released_at=row.released_at,
            release_reason=row.release_reason,
            created_at=row.created_at,
            version=row.version,
        )

    def get_active_lease(self, device_id: UUID) -> Lease | None:
        row = self.session.scalars(
            select(LeaseRow).where(LeaseRow.device_id == str(device_id), LeaseRow.status == LeaseStatus.ACTIVE.value)
        ).first()
        return None if row is None else self._lease(row)

    def acquire_lease(
        self, device_id: UUID, kind: LeaseKind, holder: str, *, lease_id: UUID, run_id: UUID | None = None
    ) -> Lease:
        """Grant a new lease with a strictly greater epoch. Any active lease (automation or operator)
        on the device is a conflict: release it explicitly first (e.g. takeover after confirmed pause)."""
        self._writable()
        if run_id is not None:
            run = self._mutable_run(run_id, "a lease cannot be granted")
            if run.spec.device_id != device_id:
                raise LeaseConflict(f"run {run_id} owns device {run.spec.device_id}, not {device_id}")
        active = self.get_active_lease(device_id)
        if active is not None:
            raise LeaseConflict(
                f"device {device_id} already has an active {active.kind} lease",
                current_state=active.model_dump(mode="json"),
            )
        last = self.session.scalar(select(func.max(LeaseRow.epoch)).where(LeaseRow.device_id == str(device_id)))
        now = utc_now()
        row = LeaseRow(
            lease_id=str(lease_id),
            device_id=str(device_id),
            run_id=_s(run_id),
            kind=kind.value,
            epoch=(last or 0) + 1,
            holder=holder,
            status=LeaseStatus.ACTIVE.value,
            acquired_at=now,
            created_at=now,
            schema_version=1,
        )
        self.session.add(row)
        try:
            self._flush()
        except IntegrityError as err:  # database-level guard (partial unique index)
            raise LeaseConflict(f"device {device_id} already leased") from err
        lease = self._lease(row)
        self.append_event(
            EventType.LEASE_ACQUIRED, run_id=run_id, device_id=device_id, payload=lease.model_dump(mode="json")
        )
        return lease

    def release_lease(
        self,
        lease_id: UUID,
        *,
        reason: str,
        expected_version: int | None = None,
        status: LeaseStatus = LeaseStatus.RELEASED,
    ) -> Lease:
        self._writable()
        if status is LeaseStatus.ACTIVE:
            raise ValueError("release status must be released or revoked")
        row = self._get(LeaseRow, str(lease_id), "lease")
        self._check_version("lease", lease_id, row.version, expected_version, {"status": row.status})
        if row.status != LeaseStatus.ACTIVE.value:
            raise StaleLease(f"lease {lease_id} is not active", current_state={"status": row.status})
        row.status = status.value
        row.released_at = utc_now()
        row.release_reason = reason
        self._flush()
        lease = self._lease(row)
        self.append_event(
            EventType.LEASE_RELEASED,
            run_id=lease.run_id,
            device_id=lease.device_id,
            payload=lease.model_dump(mode="json"),
        )
        return lease

    def check_lease(
        self,
        lease_id: UUID,
        epoch: int,
        *,
        device_id: UUID | None = None,
        required_kind: LeaseKind = LeaseKind.AUTOMATION,
    ) -> Lease:
        """Raise StaleLease if not the device's current active lease of ``required_kind`` (automation by
        default: an operator lease never authorizes dispatch, §7), StaleEpoch on epoch mismatch."""
        row = self.session.get(LeaseRow, str(lease_id))
        if row is None or row.status != LeaseStatus.ACTIVE.value:
            raise StaleLease(f"lease {lease_id} is not active")
        if row.kind != required_kind.value:
            raise StaleLease(
                f"lease {lease_id} is a {row.kind} lease, {required_kind} required",
                current_state={"kind": row.kind, "status": row.status},
            )
        if device_id is not None and row.device_id != str(device_id):
            raise StaleLease(f"lease {lease_id} does not belong to device {device_id}")
        if row.epoch != epoch:
            raise StaleEpoch(f"lease epoch {epoch} is stale", current_state={"epoch": row.epoch})
        return self._lease(row)

    def revoke_all_active_leases(self, reason: str) -> list[Lease]:
        """Coordinator restart: invalidate every old worker lease."""
        rows = self.session.scalars(select(LeaseRow).where(LeaseRow.status == LeaseStatus.ACTIVE.value)).all()
        return [
            self.release_lease(UUID(r.lease_id), reason=reason, status=LeaseStatus.REVOKED) for r in rows
        ]

    # -- observations and decisions ------------------------------------------------------------

    def add_observation(self, obs: Observation) -> Observation:
        self._writable()
        row = ObservationRow(
            observation_id=str(obs.observation_id),
            run_id=_s(obs.run_id),
            device_id=str(obs.device_id),
            session_id=str(obs.session_id),
            evidence_source=obs.evidence_source.value,
            capture_started_at=obs.capture_started_at,
            capture_ended_at=obs.capture_ended_at,
            screenshot_artifact_id=_s(obs.screenshot_artifact_id),
            body=_body(obs),
            created_at=obs.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        self.append_event(
            EventType.OBSERVATION_CAPTURED,
            run_id=obs.run_id,
            device_id=obs.device_id,
            payload={
                "observation_id": str(obs.observation_id),
                "evidence_source": obs.evidence_source.value,
                "foreground_app": obs.foreground_app,
                "candidate_count": len(obs.candidates),
            },
        )
        return _load(Observation, row.body, row.version)

    def get_observation(self, observation_id: UUID) -> Observation:
        row = self._get(ObservationRow, str(observation_id), "observation")
        return _load(Observation, row.body, row.version)

    def add_decision(self, record: DecisionRecord) -> DecisionRecord:
        self._writable()
        row = DecisionRow(
            decision_id=str(record.decision_id),
            run_id=str(record.run_id),
            decision_observation_id=str(record.decision_observation_id),
            candidate_id=_s(record.proposal.candidate_id) if record.proposal else None,
            provider_id=record.provider_id,
            control_epoch=record.control_epoch,
            outcome=record.outcome,
            latency_ms=record.latency_ms,
            body=_body(record),
            created_at=record.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        return _load(DecisionRecord, row.body, row.version)

    def get_decision(self, decision_id: UUID) -> DecisionRecord:
        row = self._get(DecisionRow, str(decision_id), "decision")
        return _load(DecisionRecord, row.body, row.version)

    # -- actions and attempts ------------------------------------------------------------------

    def add_action(self, action: ActionRecord) -> ActionRecord:
        self._writable()
        if action.status is not ActionStatus.PROPOSED:
            raise InvalidTransition("actions must be journaled in PROPOSED status")
        run = self._mutable_run(action.run_id, "no new action may be journaled")
        if run.status is not RunStatus.RUNNING:
            raise InvalidTransition(
                f"actions may only be journaled while the run is RUNNING (run is {run.status})",
                current_state={"status": run.status.value},
            )
        if run.spec.device_id != action.device_id:
            raise InvalidTransition(f"action device {action.device_id} is not the run's device {run.spec.device_id}")
        row = ActionRow(
            action_id=str(action.action_id),
            run_id=str(action.run_id),
            device_id=str(action.device_id),
            decision_id=_s(action.decision_id),
            kind=action.kind.value,
            side_effect_class=action.side_effect_class.value,
            status=action.status.value,
            correlation_id=_s(action.correlation_id),
            updated_at=action.updated_at,
            body=_body(action),
            created_at=action.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        self.append_event(
            EventType.ACTION_STATUS_CHANGED,
            run_id=action.run_id,
            device_id=action.device_id,
            action_id=action.action_id,
            payload={
                "from_status": None,
                "to_status": action.status.value,
                "kind": action.kind.value,
                "version": row.version,
            },
        )
        return _load(ActionRecord, row.body, row.version)

    def get_action(self, action_id: UUID) -> ActionRecord:
        row = self._get(ActionRow, str(action_id), "action")
        return _load(ActionRecord, row.body, row.version)

    def list_actions(self, *, run_id: UUID | None = None, statuses: Iterable[ActionStatus] | None = None) -> list[ActionRecord]:
        stmt = select(ActionRow).order_by(ActionRow.created_at)
        if run_id is not None:
            stmt = stmt.where(ActionRow.run_id == str(run_id))
        if statuses is not None:
            stmt = stmt.where(ActionRow.status.in_([s.value for s in statuses]))
        return [_load(ActionRecord, r.body, r.version) for r in self.session.scalars(stmt)]

    def potentially_executed_actions(self) -> list[ActionRecord]:
        """DISPATCHED/ACKNOWLEDGED/UNKNOWN actions that need reconciliation (never auto-replayed)."""
        return self.list_actions(statuses=POTENTIALLY_EXECUTED)

    def transition_action(
        self, action_id: UUID, target: ActionStatus, *, expected_version: int | None = None, **updates: Any
    ) -> ActionRecord:
        self._writable()
        bad = set(updates) - _ACTION_UPDATABLE
        if bad:
            raise ValueError(f"fields not updatable via transition: {sorted(bad)}")
        row = self._get(ActionRow, str(action_id), "action")
        current = _load(ActionRecord, row.body, row.version)
        self._check_version("action", action_id, row.version, expected_version, {"status": row.status})
        transition_action(current.status, target)
        frozen = set(updates) & _ACTION_BINDING_FIELDS
        if frozen and current.status not in _ACTION_BINDING_MUTABLE_FROM:
            raise InvalidTransition(
                f"{sorted(frozen)} are immutable once the action is {current.status}",
                current_state={"status": current.status.value},
            )
        now = utc_now()
        new = ActionRecord.model_validate({**current.model_dump(), **updates, "status": target, "updated_at": now})
        row.status = target.value
        row.correlation_id = _s(new.correlation_id)
        row.updated_at = now
        row.body = _body(new)
        self._flush()
        self.append_event(
            EventType.ACTION_STATUS_CHANGED,
            run_id=new.run_id,
            device_id=new.device_id,
            action_id=action_id,
            payload={
                "from_status": current.status.value,
                "to_status": target.value,
                "kind": new.kind.value,
                "version": row.version,
            },
        )
        return _load(ActionRecord, row.body, row.version)

    def add_attempt(self, attempt: AttemptRecord) -> AttemptRecord:
        self._writable()
        row = AttemptRow(
            attempt_id=str(attempt.attempt_id),
            action_id=str(attempt.action_id),
            attempt_no=attempt.attempt_no,
            command_id=str(attempt.command_id),
            status=attempt.status.value if attempt.status else None,
            body=_body(attempt),
            created_at=attempt.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        return _load(AttemptRecord, row.body, row.version)

    def complete_attempt(
        self, attempt_id: UUID, result: ExecutionResult, *, expected_version: int | None = None
    ) -> AttemptRecord:
        self._writable()
        row = self._get(AttemptRow, str(attempt_id), "attempt")
        current = _load(AttemptRecord, row.body, row.version)
        self._check_version("attempt", attempt_id, row.version, expected_version, {"status": row.status})
        if current.result is not None:
            raise InvalidTransition("attempt already has a recorded result")
        new = current.model_copy(
            update={"result": result, "status": result.status, "started_at": result.started_at, "ended_at": result.ended_at}
        )
        row.status = result.status.value
        row.body = _body(new)
        self._flush()
        action = self.get_action(current.action_id)
        self.append_event(
            EventType.ATTEMPT_RECORDED,
            run_id=action.run_id,
            device_id=action.device_id,
            action_id=action.action_id,
            payload={"attempt_id": str(attempt_id), "attempt_no": current.attempt_no, "status": result.status.value},
        )
        return _load(AttemptRecord, row.body, row.version)

    def list_attempts(self, action_id: UUID) -> list[AttemptRecord]:
        stmt = select(AttemptRow).where(AttemptRow.action_id == str(action_id)).order_by(AttemptRow.attempt_no)
        return [_load(AttemptRecord, r.body, r.version) for r in self.session.scalars(stmt)]

    # -- oracle results ------------------------------------------------------------------------

    def add_oracle_result(self, result: OracleResult) -> OracleResult:
        """Append-only (allowed even on terminal runs as reconciliation evidence)."""
        self._writable()
        row = OracleResultRow(
            oracle_result_id=str(result.oracle_result_id),
            run_id=str(result.run_id),
            oracle_kind=result.oracle_kind,
            verdict=result.verdict.value,
            body=_body(result),
            created_at=result.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        self.append_event(
            EventType.ORACLE_RESULT,
            run_id=result.run_id,
            payload={
                "oracle_result_id": str(result.oracle_result_id),
                "verdict": result.verdict.value,
                "reason_code": result.reason_code,
            },
        )
        return _load(OracleResult, row.body, row.version)

    def list_oracle_results(self, run_id: UUID) -> list[OracleResult]:
        stmt = select(OracleResultRow).where(OracleResultRow.run_id == str(run_id)).order_by(OracleResultRow.created_at)
        return [_load(OracleResult, r.body, r.version) for r in self.session.scalars(stmt)]

    # -- control commands ----------------------------------------------------------------------

    def add_command(self, command: ControlCommand) -> ControlCommand:
        self._writable()
        now = command.updated_at or command.created_at
        row = CommandRow(
            command_id=str(command.command_id),
            kind=command.kind.value,
            run_id=_s(command.run_id),
            device_id=_s(command.device_id),
            status=command.status.value,
            updated_at=now,
            body=_body(command.model_copy(update={"updated_at": now})),
            created_at=command.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        saved = _load(ControlCommand, row.body, row.version)
        self.append_event(
            EventType.COMMAND_UPDATED,
            run_id=command.run_id,
            device_id=command.device_id,
            payload={"command_id": str(command.command_id), "kind": command.kind.value, "status": row.status},
        )
        return saved

    def get_command(self, command_id: UUID) -> ControlCommand:
        row = self._get(CommandRow, str(command_id), "command")
        return _load(ControlCommand, row.body, row.version)

    def update_command(
        self,
        command_id: UUID,
        status: CommandStatus,
        *,
        result: dict[str, Any] | None = None,
        error: MobilelabError | None = None,
        expected_version: int | None = None,
    ) -> ControlCommand:
        self._writable()
        row = self._get(CommandRow, str(command_id), "command")
        current = _load(ControlCommand, row.body, row.version)
        self._check_version("command", command_id, row.version, expected_version, {"status": row.status})
        if current.status in {CommandStatus.SUCCEEDED, CommandStatus.FAILED}:
            raise InvalidTransition(f"command {command_id} already finished ({current.status})")
        now = utc_now()
        new = ControlCommand.model_validate(
            {
                **current.model_dump(),
                "status": status,
                "result": result if result is not None else current.result,
                "error": error.to_envelope() if error else current.error,
                "updated_at": now,
            }
        )
        row.status = status.value
        row.updated_at = now
        row.body = _body(new)
        self._flush()
        self.append_event(
            EventType.COMMAND_UPDATED,
            run_id=new.run_id,
            device_id=new.device_id,
            payload={"command_id": str(command_id), "kind": new.kind.value, "status": status.value},
        )
        return _load(ControlCommand, row.body, row.version)

    # -- artifacts -----------------------------------------------------------------------------

    def add_artifact(self, meta: ArtifactMetadata) -> ArtifactMetadata:
        """Commit metadata only after the file was atomically written (see ArtifactStore.write_bytes)."""
        self._writable()
        row = ArtifactRow(
            artifact_id=str(meta.artifact_id),
            run_id=_s(meta.run_id),
            sha256=meta.sha256,
            size_bytes=meta.size_bytes,
            content_type=meta.content_type,
            relative_path=meta.relative_path,
            evidence_source=meta.evidence_source.value,
            created_at=meta.created_at,
            schema_version=1,
        )
        self.session.add(row)
        self._flush()
        self.append_event(
            EventType.ARTIFACT_CREATED,
            run_id=meta.run_id,
            payload={"artifact_id": str(meta.artifact_id), "content_type": meta.content_type},
        )
        return self._artifact(row)

    @staticmethod
    def _artifact(row: ArtifactRow) -> ArtifactMetadata:
        return ArtifactMetadata(
            artifact_id=row.artifact_id,  # type: ignore[arg-type]
            run_id=row.run_id,  # type: ignore[arg-type]
            sha256=row.sha256,
            size_bytes=row.size_bytes,
            content_type=row.content_type,
            relative_path=row.relative_path,
            evidence_source=row.evidence_source,  # type: ignore[arg-type]
            created_at=row.created_at,
            version=row.version,
        )

    def get_artifact(self, artifact_id: UUID) -> ArtifactMetadata:
        return self._artifact(self._get(ArtifactRow, str(artifact_id), "artifact"))

    def list_artifacts(
        self, *, run_id: UUID | None = None, after: tuple[datetime, str] | None = None, limit: int = 100
    ) -> list[ArtifactMetadata]:
        """Keyset pagination on (created_at, artifact_id); the API wraps ``after`` in an opaque cursor."""
        stmt = select(ArtifactRow).order_by(ArtifactRow.created_at, ArtifactRow.artifact_id).limit(limit)
        if run_id is not None:
            stmt = stmt.where(ArtifactRow.run_id == str(run_id))
        if after is not None:
            ts, aid = after
            stmt = stmt.where(
                (ArtifactRow.created_at > ts) | ((ArtifactRow.created_at == ts) & (ArtifactRow.artifact_id > aid))
            )
        return [self._artifact(r) for r in self.session.scalars(stmt)]

    # -- idempotency ---------------------------------------------------------------------------

    def check_idempotency(self, key: str, method: str, path: str, request_hash: str) -> IdempotencyRecord | None:
        """Return the stored response for an identical request (same key, method, path and body hash);
        raise IdempotencyConflict when the key was used for any other request; None when the key is new."""
        row = self.session.scalars(select(IdempotencyRow).where(IdempotencyRow.idempotency_key == key)).first()
        if row is None:
            return None
        if (row.method, row.path, row.request_hash) != (method, path, request_hash):
            raise IdempotencyConflict(
                "Idempotency-Key reused with a different method, path or request content",
                details={"key": key, "method": method, "path": path},
            )
        return IdempotencyRecord(
            row.idempotency_key, row.method, row.path, row.request_hash, row.status_code,
            row.response_body, row.resource_id, row.created_at,
        )

    def save_idempotency(
        self,
        key: str,
        method: str,
        path: str,
        request_hash: str,
        status_code: int,
        response_body: dict[str, Any],
        resource_id: str | None = None,
    ) -> None:
        self._writable()
        self.session.add(
            IdempotencyRow(
                idempotency_key=key,
                method=method,
                path=path,
                request_hash=request_hash,
                status_code=status_code,
                response_body=response_body,
                resource_id=resource_id,
                created_at=utc_now(),
            )
        )
        try:
            self._flush()
        except IntegrityError as err:
            raise IdempotencyConflict("Idempotency-Key already recorded", details={"key": key}) from err

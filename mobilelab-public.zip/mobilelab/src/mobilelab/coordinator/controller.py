"""Run controller: lease + worker authority, one decision/dispatch step, pause/stop/emergency stop
and restart recovery (CONTRACTS §5, §7, §11).

The controller never chooses actions itself; the injected provider proposes, the dispatch engine
validates/journals, the worker executes. Control paths never wait behind a driver operation:
fences use the worker's priority lane and are bounded by ``fence_budget_s``.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from collections.abc import Callable
from typing import Any
from uuid import UUID, uuid4

from mobilelab.candidates.scope import ScenarioScope
from mobilelab.coordinator.engine import (
    DEFAULT_COMMAND_MAX_DURATION_MS,
    DEFAULT_MAX_REPLANS,
    DispatchEngine,
    _default_correlation,
)
from mobilelab.coordinator.types import (
    CandidateGenerator,
    ControlResult,
    CorrelationFn,
    DeviceBinding,
    DispatchOutcome,
    HarnessFailure,
    OutcomeKind,
    Rebinder,
    Reconciler,
    RecoveredAction,
    RecoveryReport,
    reconcile_path,
)
from mobilelab.domain.base import utc_now
from mobilelab.domain.control import ControlCommand, DeviceFenceStatus, EmergencyStopResult
from mobilelab.domain.decisions import DecisionBudget, DecisionContext, DecisionRecord
from mobilelab.domain.devices import FenceResult
from mobilelab.domain.enums import (
    ActionKind,
    ActionStatus,
    CommandKind,
    CommandStatus,
    EvidenceCategory,
    EvidenceSource,
    LeaseKind,
    RunStatus,
    Verdict,
)
from mobilelab.domain.errors import ErrorEnvelope, InvalidTransition, MobilelabError
from mobilelab.domain.observations import CandidateAction
from mobilelab.domain.proposals import ProposedAction
from mobilelab.domain.runs import Run
from mobilelab.store import Store
from mobilelab.store.artifacts import ArtifactStore
from mobilelab.workers.client import WorkerClient

log = logging.getLogger(__name__)

DEFAULT_FENCE_BUDGET_S = 1.0
_PRE_PREPARED = (ActionStatus.PROPOSED, ActionStatus.VALIDATED, ActionStatus.SCHEDULED)


@dataclass
class _Slot:
    binding: DeviceBinding
    worker: WorkerClient
    idle: asyncio.Event = field(default_factory=asyncio.Event)
    cancel: asyncio.Event = field(default_factory=asyncio.Event)

    def __post_init__(self) -> None:
        self.idle.set()


class RunController:
    """One coordinator's control plane. Create one per process; call ``recover()`` at start-up."""

    def __init__(
        self,
        store: Store,
        artifacts: ArtifactStore,
        scope: ScenarioScope,
        *,
        generate: CandidateGenerator,
        rebind: Rebinder,
        provider: Any,
        reconciler: Reconciler,
        correlation: CorrelationFn = _default_correlation,
        holder: str = "coordinator",
        fence_budget_s: float = DEFAULT_FENCE_BUDGET_S,
        settle_timeout_s: float | None = None,
        max_replans: int = DEFAULT_MAX_REPLANS,
        command_max_duration_ms: int = DEFAULT_COMMAND_MAX_DURATION_MS,
    ) -> None:
        self.store = store
        self.provider = provider
        self.decisions_in_flight: dict[UUID, float] = {}
        """run_id -> monotonic start of a provider decision currently awaited (observability only)."""
        self.dwell_policy: Callable[[ProposedAction, CandidateAction], float | None] | None = None
        """Optional harness hook: the persona dwell (ms) for an accepted wait proposal, or None."""
        self.reconciler = reconciler
        self.holder = holder
        self.fence_budget_s = fence_budget_s
        self.settle_timeout_s = settle_timeout_s if settle_timeout_s is not None else command_max_duration_ms / 1000 + 3.0
        self.engine = DispatchEngine(
            store,
            artifacts,
            scope,
            generate=generate,
            rebind=rebind,
            correlation=correlation,
            max_replans=max_replans,
            command_max_duration_ms=command_max_duration_ms,
        )
        self._workers: dict[UUID, WorkerClient] = {}
        self._slots: dict[UUID, _Slot] = {}
        self.quarantined: set[UUID] = set()

    # -- workers and leases ------------------------------------------------------------------------

    def attach_worker(self, worker: WorkerClient) -> None:
        self._workers[worker.device_id] = worker

    def binding(self, run_id: UUID) -> DeviceBinding:
        return self._slots[run_id].binding

    def worker(self, run_id: UUID) -> WorkerClient:
        """The worker bound to a started run (for verification observations through ``engine.capture``)."""
        return self._slots[run_id].worker

    async def start(self, run_id: UUID, *, session_id: UUID | None = None) -> DeviceBinding:
        """READY -> RUNNING, or resume PAUSED -> RUNNING with a new lease epoch and control epoch.

        Acquires the automation lease, then authorizes the device worker for exactly that lease and
        control epoch (which opens the worker's own dispatch gate)."""
        with self.store.reader() as r:
            run = r.get_run(run_id)
        device_id = run.spec.device_id
        if device_id in self.quarantined:
            raise HarnessFailure("device is quarantined after an unconfirmed fence or unsettled command")
        worker = self._workers.get(device_id)
        if worker is None:
            raise HarnessFailure("no worker attached for the run's device", details={"device_id": str(device_id)})
        if run.status not in (RunStatus.READY, RunStatus.PAUSED):
            raise InvalidTransition(f"cannot start a run in {run.status}", current_state={"status": run.status.value})
        lease_id = uuid4()
        resuming = run.status is RunStatus.PAUSED
        with self.store.unit_of_work() as uow:
            uow.require_gate_open()
            old = uow.get_active_lease(device_id)
            previous: dict[str, Any] | None = None
            if old is not None and old.run_id == run_id and resuming:
                previous = {"lease_id": str(old.lease_id), "kind": old.kind.value, "epoch": old.epoch}
                why = "resume after operator takeover" if old.kind is LeaseKind.OPERATOR else "resume"
                uow.release_lease(old.lease_id, reason=f"{why}: automation lease reacquired with a new epoch")
            lease = uow.acquire_lease(device_id, LeaseKind.AUTOMATION, self.holder, lease_id=lease_id, run_id=run_id)
            run = uow.transition_run(run_id, RunStatus.RUNNING, reason="resume" if resuming else "start")
            if resuming:
                manual = previous is not None and previous["kind"] == LeaseKind.OPERATOR.value
                cmd = uow.add_command(ControlCommand(command_id=uuid4(), kind=CommandKind.RESUME, run_id=run_id, device_id=device_id))
                uow.update_command(
                    cmd.command_id,
                    CommandStatus.SUCCEEDED,
                    result={
                        "previous_lease": previous,
                        "new_lease_id": str(lease.lease_id),
                        "new_lease_epoch": lease.epoch,
                        "control_epoch": run.control_epoch,
                        "manual_intervention": manual,
                        "note": "fresh observation required: the worker invalidated every earlier observation",
                    },
                )
        binding = DeviceBinding(
            run_id=run_id,
            device_id=device_id,
            session_id=session_id or uuid4(),
            lease_id=lease.lease_id,
            lease_epoch=lease.epoch,
            control_epoch=run.control_epoch,
        )
        await worker.authorize(binding.lease_id, binding.lease_epoch, binding.control_epoch)
        self._slots[run_id] = _Slot(binding, worker)
        return binding

    # -- one decision + dispatch step --------------------------------------------------------------

    async def step(
        self,
        run_id: UUID,
        context: DecisionContext,
        budget: DecisionBudget,
        *,
        sampled_delay_ms: float | None = None,
    ) -> DispatchOutcome:
        """Observe, ask the provider (cancellable, epoch-checked) and dispatch at most one action."""
        slot = self._slots[run_id]
        if not slot.idle.is_set():
            raise HarnessFailure("a step is already running for this run (one command per device)")
        slot.idle.clear()
        try:
            return await self._step(slot, context, budget, sampled_delay_ms)
        finally:
            slot.idle.set()

    async def _step(
        self, slot: _Slot, context: DecisionContext, budget: DecisionBudget, sampled_delay_ms: float | None
    ) -> DispatchOutcome:
        b = slot.binding
        if slot.cancel.is_set():
            return DispatchOutcome(OutcomeKind.DISCARDED, "run control epoch has been superseded")
        observation = await self.engine.capture(slot.worker, b, "decision")
        ctx = context.model_copy(update={"control_epoch": b.control_epoch})
        bud = budget.model_copy(update={"cancel_event": slot.cancel})
        info = self.provider.provider_info
        t0 = time.monotonic()
        decide = asyncio.ensure_future(self.provider.decide(ctx, observation, list(observation.candidates), bud))
        cancelled = asyncio.ensure_future(slot.cancel.wait())
        self.decisions_in_flight[b.run_id] = t0
        try:
            done, _ = await asyncio.wait({decide, cancelled}, timeout=budget.timeout_ms / 1000, return_when=asyncio.FIRST_COMPLETED)
        finally:
            self.decisions_in_flight.pop(b.run_id, None)
        cancelled.cancel()
        latency_ms = (time.monotonic() - t0) * 1000

        def record(outcome: str, proposal: ProposedAction | None = None, error: MobilelabError | None = None) -> UUID:
            decision_id = proposal.decision_id if proposal is not None else uuid4()
            with self.store.unit_of_work() as uow:
                uow.add_decision(
                    DecisionRecord(
                        decision_id=decision_id,
                        run_id=b.run_id,
                        decision_observation_id=observation.observation_id,
                        provider_id=info.name,
                        model_identifier=info.model,
                        control_epoch=b.control_epoch,
                        outcome=outcome,  # type: ignore[arg-type]
                        proposal=proposal,
                        error=_envelope(error) if error else None,
                        latency_ms=latency_ms,
                    )
                )
            return decision_id

        if decide not in done:
            decide.cancel()  # best effort; a late result is discarded regardless
            # No result arrived: record ``cancelled`` (not ``discarded_stale``, which means a late result
            # was received and thrown away) and the reason class, so latency stats can exclude it.
            if slot.cancel.is_set():
                why, err_cls = "decision cancelled by pause/stop", "DecisionCancelled"
            else:
                why, err_cls = "decision budget expired", "DecisionTimeout"
            note = MobilelabError(why, details={"error_class": err_cls})
            return DispatchOutcome(OutcomeKind.DISCARDED, why, decision_id=record("cancelled", error=note))
        try:
            proposal = decide.result()
        except MobilelabError as err:
            return DispatchOutcome(OutcomeKind.PROVIDER_ERROR, err.message, error_code=err.code, decision_id=record("provider_error", error=err),
                                   error_class=type(err).__name__)  # fmt: skip
        except Exception as err:
            # The exception text may repeat provider/model input; keep only the class name.
            wrapped = MobilelabError(f"provider raised {type(err).__name__}", details={"error_class": type(err).__name__})
            return DispatchOutcome(OutcomeKind.PROVIDER_ERROR, wrapped.message, decision_id=record("provider_error", error=wrapped),
                                   error_class=type(err).__name__)  # fmt: skip

        with self.store.reader() as r:
            current_epoch = r.get_run(b.run_id).control_epoch
        if slot.cancel.is_set() or current_epoch != b.control_epoch or proposal.control_epoch not in (None, b.control_epoch):
            return DispatchOutcome(OutcomeKind.DISCARDED, "late decision for a superseded control epoch", decision_id=record("discarded_stale", proposal))
        try:
            chosen = self.engine.resolve_candidate(proposal, observation)
        except MobilelabError as err:
            record("rejected", proposal, err)
            return DispatchOutcome(OutcomeKind.REJECTED, err.message, error_code=err.code, decision_id=proposal.decision_id)
        record("accepted", proposal)
        if sampled_delay_ms is None and self.dwell_policy is not None and chosen.kind is ActionKind.WAIT:
            # Persona dwell sampled by the harness (never by the model); decision latency counts toward it.
            sampled_delay_ms = self.dwell_policy(proposal, chosen)
        return await self.engine.dispatch(
            slot.worker, b, proposal, observation, sampled_delay_ms=sampled_delay_ms, decision_latency_ms=latency_ms
        )

    # -- pause / stop ------------------------------------------------------------------------------

    async def pause(self, run_id: UUID) -> ControlResult:
        """RUNNING -> PAUSING (new control epoch) -> fence + settle -> PAUSED, or an explicit failure."""
        return await self._quiesce(run_id, CommandKind.PAUSE)

    async def stop(self, run_id: UUID) -> ControlResult:
        """-> STOPPING -> fence + settle -> ABORTED and release the lease, or an explicit failure."""
        return await self._quiesce(run_id, CommandKind.STOP)

    async def _quiesce(self, run_id: UUID, kind: CommandKind) -> ControlResult:
        pause = kind is CommandKind.PAUSE
        with self.store.reader() as r:
            run = r.get_run(run_id)
        settled_status = RunStatus.PAUSED if pause else RunStatus.ABORTED
        transitional = RunStatus.PAUSING if pause else RunStatus.STOPPING
        if run.status is settled_status:
            # Repeated request: report the current state; never issue new device commands.
            with self.store.unit_of_work() as uow:
                cmd = uow.add_command(ControlCommand(command_id=uuid4(), kind=kind, run_id=run_id, device_id=run.spec.device_id))
                uow.update_command(cmd.command_id, CommandStatus.SUCCEEDED, result={"run_status": run.status.value, "repeated": True})
            return ControlResult(
                command_id=cmd.command_id, run_id=run_id, kind=kind.value, ok=True,  # type: ignore[arg-type]
                run_status=run.status, fence_confirmed=False, in_flight_settled=True,
                detail=f"no-op: run already {run.status}",
            )  # fmt: skip
        if pause and run.status not in (RunStatus.RUNNING, RunStatus.PAUSING):
            raise InvalidTransition(f"cannot pause a run in {run.status}", current_state={"status": run.status.value})
        command_id = uuid4()
        with self.store.unit_of_work() as uow:
            uow.add_command(ControlCommand(command_id=command_id, kind=kind, run_id=run_id, device_id=run.spec.device_id, status=CommandStatus.RUNNING))
            if run.status is not transitional:
                run = uow.transition_run(run_id, transitional, reason=f"{kind.value} requested")
        slot = self._slots.get(run_id)
        fence: FenceResult | None = None
        settled = True
        if slot is not None:
            slot.cancel.set()  # pending decision requests are cancelled; late results discarded
            fence = await self._fence(slot.worker, slot.binding.control_epoch)
            settled = await self._settle(slot)
        fence_ok = slot is None or fence is not None
        ok = fence_ok and settled
        detail = "" if ok else ("fence not confirmed within budget; " if not fence_ok else "") + (
            "" if settled else "in-flight command did not settle; "
        )
        if not ok:
            self.quarantined.add(run.spec.device_id)
            detail += "device quarantined"
        with self.store.unit_of_work() as uow:
            if ok:
                run = uow.transition_run(run_id, settled_status, reason=f"{kind.value} settled")
                if not pause:
                    lease = uow.get_active_lease(run.spec.device_id)
                    if lease is not None and lease.run_id == run_id:
                        uow.release_lease(lease.lease_id, reason="run stopped")
            result = {
                "run_status": run.status.value,
                "fence_confirmed": fence is not None,
                "in_flight_settled": settled,
                "fence": fence.model_dump(mode="json") if fence else None,
            }
            uow.update_command(
                command_id,
                CommandStatus.SUCCEEDED if ok else CommandStatus.FAILED,
                result=result,
                error=None if ok else HarnessFailure(f"{kind.value} failed: {detail}"),
            )
        if ok and not pause:
            self._slots.pop(run_id, None)
        return ControlResult(
            command_id=command_id, run_id=run_id, kind=kind.value, ok=ok, run_status=run.status,  # type: ignore[arg-type]
            fence_confirmed=fence is not None, fence=fence, in_flight_settled=settled,
            quarantined=not ok, detail=detail,
        )  # fmt: skip

    async def _fence(self, worker: WorkerClient, control_epoch: int) -> FenceResult | None:
        try:
            return await asyncio.wait_for(worker.fence(control_epoch), self.fence_budget_s)
        except Exception as err:  # timeout, dead worker: fence is pending, not confirmed
            log.warning("fence of %s not confirmed: %s", worker.device_id, err)
            return None

    async def _settle(self, slot: _Slot) -> bool:
        """True once the step has returned *and* the worker reports no driver work in flight.

        A step returns UNKNOWN as soon as the driver call outlives ``max_duration_ms``, while the
        worker keeps executing that UI command until the driver coroutine exits; only the worker's
        own ``driver_busy``/``in_flight_state`` say when the device is really quiescent."""
        deadline = time.monotonic() + self.settle_timeout_s
        try:
            await asyncio.wait_for(slot.idle.wait(), self.settle_timeout_s)
        except TimeoutError:
            return False
        while True:
            remaining = deadline - time.monotonic()
            try:
                health = await asyncio.wait_for(slot.worker.health(), max(remaining, 0.1))
                if not health.driver_busy and health.in_flight_state == "none":
                    return True
            except Exception as err:  # no answer is not quiescence
                log.warning("worker health during settle failed: %s", err)
            if time.monotonic() >= deadline:
                return False
            await asyncio.sleep(min(0.1, max(deadline - time.monotonic(), 0)))

    # -- operator takeover -------------------------------------------------------------------------

    async def takeover(self, run_id: UUID, operator: str = "operator") -> ControlResult:
        """Manual control after a *confirmed* pause (CONTRACTS §7): the automation lease is released
        to an operator lease and outstanding observations are invalidated (worker fence). ``start``
        later resumes with a new automation lease epoch and records the manual intervention."""
        with self.store.reader() as r:
            run = r.get_run(run_id)
        command_id = uuid4()
        with self.store.unit_of_work() as uow:
            uow.add_command(ControlCommand(command_id=command_id, kind=CommandKind.TAKEOVER, run_id=run_id,
                                           device_id=run.spec.device_id, status=CommandStatus.RUNNING))  # fmt: skip
        if run.status is not RunStatus.PAUSED:
            detail = f"takeover refused: run is {run.status.value}, takeover needs a confirmed pause"
            with self.store.unit_of_work() as uow:
                uow.update_command(command_id, CommandStatus.FAILED, result={"run_status": run.status.value},
                                   error=InvalidTransition(detail))  # fmt: skip
            return ControlResult(command_id=command_id, run_id=run_id, kind="takeover", ok=False, run_status=run.status,
                                 fence_confirmed=False, in_flight_settled=False, detail=detail)  # fmt: skip
        slot = self._slots.get(run_id)
        fence = await self._fence(slot.worker, slot.binding.control_epoch) if slot is not None else None
        settled = await self._settle(slot) if slot is not None else True
        ok = (slot is None or fence is not None) and settled
        with self.store.unit_of_work() as uow:
            released: dict[str, Any] | None = None
            operator_lease = None
            if ok:
                old = uow.get_active_lease(run.spec.device_id)
                if old is not None and old.run_id == run_id and old.kind is LeaseKind.AUTOMATION:
                    uow.release_lease(old.lease_id, reason=f"takeover by {operator}")
                    released = {"lease_id": str(old.lease_id), "epoch": old.epoch}
                operator_lease = uow.acquire_lease(run.spec.device_id, LeaseKind.OPERATOR, operator,
                                                   lease_id=uuid4(), run_id=run_id)  # fmt: skip
            uow.update_command(
                command_id,
                CommandStatus.SUCCEEDED if ok else CommandStatus.FAILED,
                result={
                    "operator": operator,
                    "released_automation_lease": released,
                    "operator_lease_id": str(operator_lease.lease_id) if operator_lease else None,
                    "operator_lease_epoch": operator_lease.epoch if operator_lease else None,
                    "fence_confirmed": fence is not None,
                    "observations_invalidated": fence is not None,
                },
                error=None if ok else HarnessFailure("takeover: fence not confirmed or command unsettled"),
            )
        if not ok:
            self.quarantined.add(run.spec.device_id)
        return ControlResult(
            command_id=command_id, run_id=run_id, kind="takeover", ok=ok, run_status=run.status,
            fence_confirmed=fence is not None, fence=fence, in_flight_settled=settled, quarantined=not ok,
            detail=f"operator lease epoch {operator_lease.epoch}" if ok and operator_lease else "takeover failed; device quarantined",
        )  # fmt: skip

    # -- completion --------------------------------------------------------------------------------

    async def complete(
        self,
        run_id: UUID,
        *,
        verdict: Verdict,
        reason: str,
        obtained_evidence: EvidenceCategory | None = None,
        obtained_evidence_source: EvidenceSource | None = None,
        failed: bool = False,
    ) -> Run:
        """End a RUNNING run: fence the worker (no command may start afterwards), wait for the in-flight
        command to settle, then record COMPLETED (or FAILED) with its verdict and release the lease.

        The store refuses PASS/DUT_FAILURE without obtained device evidence of the planned category.
        If the fence is not confirmed or the command does not settle the run is FAILED with
        HARNESS_FAILURE instead and the device is quarantined."""
        slot = self._slots.get(run_id)
        fence: FenceResult | None = None
        settled = True
        if slot is not None:
            slot.cancel.set()
            fence = await self._fence(slot.worker, slot.binding.control_epoch)
            settled = await self._settle(slot)
        if slot is not None and (fence is None or not settled):
            with self.store.reader() as r:
                self.quarantined.add(r.get_run(run_id).spec.device_id)
            failed, verdict = True, Verdict.HARNESS_FAILURE
            obtained_evidence = obtained_evidence_source = None
            reason = f"completion fence not confirmed or command unsettled; device quarantined ({reason})"
        with self.store.unit_of_work() as uow:
            run = uow.transition_run(
                run_id,
                RunStatus.FAILED if failed else RunStatus.COMPLETED,
                reason=reason[:2000],
                verdict=verdict,
                obtained_evidence=obtained_evidence,
                obtained_evidence_source=obtained_evidence_source,
            )
            lease = uow.get_active_lease(run.spec.device_id)
            if lease is not None and lease.run_id == run_id:
                uow.release_lease(lease.lease_id, reason=f"run {run.status.value.lower()}")
        self._slots.pop(run_id, None)
        return run

    # -- emergency stop ----------------------------------------------------------------------------

    async def emergency_stop(self, reason: str = "emergency stop") -> EmergencyStopResult:
        """Persist the closed global gate first, then fence every worker concurrently.

        ``fully_fenced`` is True only when every worker confirmed within ``fence_budget_s``; otherwise
        the command is recorded FAILED (harness failure) and unconfirmed devices are quarantined."""
        command_id = uuid4()
        with self.store.unit_of_work() as uow:
            gate = uow.close_gate(reason)
            uow.add_command(ControlCommand(command_id=command_id, kind=CommandKind.EMERGENCY_STOP, status=CommandStatus.RUNNING))
        gate_persisted_at = gate.updated_at
        for slot in self._slots.values():
            slot.cancel.set()
        epochs = {s.binding.device_id: s.binding.control_epoch for s in self._slots.values()}
        workers = list(self._workers.values())

        async def fence_one(w: WorkerClient) -> tuple[WorkerClient, FenceResult | None, Any]:
            res = await self._fence(w, epochs.get(w.device_id, 0))
            return w, res, utc_now()

        results = await asyncio.gather(*(fence_one(w) for w in workers))
        devices: list[DeviceFenceStatus] = []
        acked: list[Any] = []
        for w, res, at in results:
            if res is None:
                self.quarantined.add(w.device_id)
                devices.append(DeviceFenceStatus(device_id=w.device_id, fenced=False, in_flight_state="unknown"))
            else:
                acked.append(at)
                devices.append(
                    DeviceFenceStatus(
                        device_id=w.device_id,
                        fenced=res.fenced,
                        acknowledged_at=at,
                        in_flight_command_id=res.in_flight_command_id,
                        in_flight_state=res.in_flight_state,  # type: ignore[arg-type]
                    )
                )
        fully = all(d.fenced for d in devices)
        out = EmergencyStopResult(
            command_id=command_id,
            global_epoch=gate.global_epoch,
            gate_persisted_at=gate_persisted_at,
            fence_acknowledged_at=max(acked) if fully and acked else None,
            fully_fenced=fully,
            devices=devices,
        )
        with self.store.unit_of_work() as uow:
            uow.update_command(
                command_id,
                CommandStatus.SUCCEEDED if fully else CommandStatus.FAILED,
                result=out.model_dump(mode="json"),
                error=None if fully else HarnessFailure("emergency-stop fence not confirmed within budget; status pending"),
            )
        return out

    # -- restart recovery --------------------------------------------------------------------------

    async def recover(self) -> RecoveryReport:
        """Coordinator start-up on an existing database. Never re-dispatches anything.

        Keeps the global gate closed, revokes old worker leases, moves RUNNING/PAUSING runs into
        recovery PAUSING, cancels never-sent actions, treats PREPARED-with-open-attempt as
        DISPATCHED, hands every potentially executed action to the reconciler and only then marks
        a run PAUSED (when all its actions were reconciled without error)."""
        cancelled: list[UUID] = []
        with self.store.unit_of_work() as uow:
            if uow.get_gate().gate_open:
                uow.close_gate("coordinator restart: gate kept closed until reconciliation")
            revoked = uow.revoke_all_active_leases("coordinator restart: old worker leases invalidated")
            recovered: list[UUID] = []
            for run in uow.list_runs(statuses=[RunStatus.RUNNING, RunStatus.PAUSING]):
                uow.transition_run(run.run_id, RunStatus.PAUSING, recovery=True, reason="coordinator restart recovery")
                recovered.append(run.run_id)
            for action in uow.list_actions(statuses=_PRE_PREPARED):
                uow.transition_action(action.action_id, ActionStatus.CANCELLED)
                cancelled.append(action.action_id)
            for action in uow.list_actions(statuses=[ActionStatus.PREPARED]):
                open_attempt = any(a.result is None for a in uow.list_attempts(action.action_id))
                if open_attempt:  # may have been written to the worker pipe before the crash
                    uow.transition_action(action.action_id, ActionStatus.DISPATCHED)
                else:
                    uow.transition_action(action.action_id, ActionStatus.CANCELLED)
                    cancelled.append(action.action_id)
            # Only runs that were active are recovered; a terminal run's journal is final (its
            # potentially executed actions were evaluated when it ended).
            pending = [a for a in uow.potentially_executed_actions() if a.run_id in recovered]

        reconciled: list[RecoveredAction] = []
        failed_runs: set[UUID] = set()
        for action in pending:
            entry = RecoveredAction(action_id=action.action_id, run_id=action.run_id, from_status=action.status, to_status=action.status)
            try:
                rec = await self.reconciler(action)
                if rec is None:
                    failed_runs.add(action.run_id)
                    reconciled.append(entry.model_copy(update={"error": "reconciler returned no decision"}))
                    continue
                with self.store.unit_of_work() as uow:
                    for target in reconcile_path(action.status, rec.resolution):
                        uow.transition_action(action.action_id, target)
                reconciled.append(
                    entry.model_copy(update={"to_status": ActionStatus(rec.resolution), "resolution": rec.resolution, "reason_code": rec.reason_code})
                )
            except Exception as err:
                failed_runs.add(action.run_id)
                reconciled.append(entry.model_copy(update={"error": f"{type(err).__name__}: {err}"[:500]}))
        paused: list[UUID] = []
        for run_id in recovered:
            if run_id in failed_runs:
                continue
            with self.store.unit_of_work() as uow:
                uow.transition_run(run_id, RunStatus.PAUSED, reason="recovery reconciled; awaiting operator resume")
            paused.append(run_id)
        with self.store.reader() as r:
            gate_closed = not r.get_gate().gate_open
        return RecoveryReport(
            gate_closed=gate_closed,
            revoked_lease_ids=[lease.lease_id for lease in revoked],
            recovered_run_ids=recovered,
            paused_run_ids=paused,
            cancelled_action_ids=cancelled,
            reconciled=reconciled,
            completed_at=utc_now(),
        )


def _envelope(error: MobilelabError) -> ErrorEnvelope:
    """Error envelope for a decision row, carrying the error class name (cancelled vs provider errors)."""
    env = error.to_envelope()
    if "error_class" not in env.details:
        env = env.model_copy(update={"details": {**env.details, "error_class": type(error).__name__}})
    return env

"""Coordinator value types and the injected collaborator signatures (CONTRACTS §4-§7, §11)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal, Protocol
from uuid import UUID

from pydantic import Field

from mobilelab.candidates.scope import ScenarioScope
from mobilelab.domain.base import StrictModel, UtcDatetime
from mobilelab.domain.devices import FenceResult
from mobilelab.domain.dispatch import ActionRecord, ExecutionResult
from mobilelab.domain.enums import ActionStatus, RunStatus
from mobilelab.domain.errors import ErrorCode, MobilelabError
from mobilelab.domain.observations import CandidateAction, Observation

CandidateGenerator = Callable[[Observation, ScenarioScope], list[CandidateAction]]
"""``mobilelab.candidates.generate_candidates``."""

Rebinder = Callable[[CandidateAction, Observation, ScenarioScope], CandidateAction | None]
"""``mobilelab.candidates.rebind``: a new candidate on the fresh observation, or None to replan."""

CorrelationFn = Callable[[CandidateAction, Observation], UUID]
"""Trusted draft identity for a send candidate (``mobilelab.candidates.client_message_id_for``)."""

Resolution = Literal["VERIFIED", "FAILED", "UNRESOLVED"]


class ReconciliationLike(Protocol):
    """Structural result of a reconciler (``mobilelab.oracles.SendReconciliation`` fits)."""

    @property
    def resolution(self) -> Resolution: ...

    @property
    def reason_code(self) -> str: ...


Reconciler = Callable[[ActionRecord], Awaitable[ReconciliationLike | None]]
"""Query independent evidence for a potentially executed action. ``None`` leaves it untouched.
A reconciler never re-dispatches anything."""


class HarnessFailure(MobilelabError):
    """The harness could not establish a safe state (unconfirmed fence, unsettled command)."""

    code = ErrorCode.INTERNAL_ERROR


@dataclass(frozen=True, slots=True)
class DeviceBinding:
    """Dispatch authority the coordinator holds for one run's device."""

    run_id: UUID
    device_id: UUID
    session_id: UUID
    lease_id: UUID
    lease_epoch: int
    control_epoch: int


class OutcomeKind(StrEnum):
    ACKNOWLEDGED = "acknowledged"
    """Driver call returned; the end-to-end outcome still needs an oracle."""
    FAILED = "failed"
    UNKNOWN = "unknown"
    """Possibly executed (timeout, crash, driver exception). Never retried automatically."""
    REJECTED = "rejected"
    """Refused before any device input (invalid proposal, worker authority/freshness check)."""
    CANCELLED = "cancelled"
    """Stopped before dispatch (gate closed, epoch changed, observation unavailable)."""
    REPLAN = "replan"
    """Semantic rebinding failed: request a new decision."""
    STUCK = "stuck"
    """Too many consecutive replans: report INCONCLUSIVE."""
    DISCARDED = "discarded"
    """Late/stale decision ignored (epoch changed, cancelled, run not running)."""
    PROVIDER_ERROR = "provider_error"


@dataclass(frozen=True, slots=True)
class DispatchOutcome:
    kind: OutcomeKind
    reason: str
    action_id: UUID | None = None
    status: ActionStatus | None = None
    result: ExecutionResult | None = None
    error_code: ErrorCode | None = None
    consecutive_replans: int = 0
    decision_id: UUID | None = None
    error_class: str | None = None
    """Provider error class name (e.g. ``ProviderRequestRejected``) for PROVIDER_ERROR outcomes."""


class ControlResult(StrictModel):
    """Outcome of pause/stop. ``ok`` is never True while a command is unresolved or unfenced."""

    command_id: UUID
    run_id: UUID
    kind: Literal["pause", "stop", "takeover"]
    ok: bool
    run_status: RunStatus
    fence_confirmed: bool
    fence: FenceResult | None = None
    in_flight_settled: bool
    quarantined: bool = False
    detail: str = Field(default="", max_length=2000)


class RecoveredAction(StrictModel):
    action_id: UUID
    run_id: UUID
    from_status: ActionStatus
    to_status: ActionStatus
    resolution: Resolution | None = None
    reason_code: str | None = None
    error: str | None = None


class RecoveryReport(StrictModel):
    gate_closed: bool
    revoked_lease_ids: list[UUID] = Field(default_factory=list)
    recovered_run_ids: list[UUID] = Field(default_factory=list)
    paused_run_ids: list[UUID] = Field(default_factory=list)
    cancelled_action_ids: list[UUID] = Field(default_factory=list)
    reconciled: list[RecoveredAction] = Field(default_factory=list)
    redispatched: Literal[0] = 0
    """Recovery never re-dispatches; kept explicit for reports."""
    completed_at: UtcDatetime


def reconcile_path(source: ActionStatus, resolution: Resolution) -> list[ActionStatus]:
    """Valid action-status steps from a potentially executed status to ``resolution`` (§6 graph)."""
    target = ActionStatus(resolution)
    if source is ActionStatus.UNKNOWN:
        return [target]
    if source is ActionStatus.ACKNOWLEDGED and target is not ActionStatus.UNRESOLVED:
        return [target]
    if source in (ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED):
        return [ActionStatus.UNKNOWN, target]
    raise ValueError(f"action status {source} is not reconcilable")

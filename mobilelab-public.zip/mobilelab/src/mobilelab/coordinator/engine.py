"""Dispatch engine: validates a proposal, journals the action and hands one command to the worker.

Journal order (CONTRACTS §6)::

    PROPOSED -> VALIDATED -> SCHEDULED -> (fresh observation + rebind) -> PREPARED [+ attempt row]
      -> IPC execute -> REJECTED (worker refused before any adapter call)
                      | DISPATCHED -> ACKNOWLEDGED [-> FAILED] | UNKNOWN

``PREPARED`` (with the dispatch observation/candidate, payload, correlation id and an attempt row
carrying the ``command_id``) is committed *before* the command is written to the worker pipe. The
worker's reply decides between a pre-input rejection and ``DISPATCHED``. If the coordinator dies
in between, restart recovery treats a PREPARED action with an open attempt as potentially executed
(PREPARED -> DISPATCHED) and hands it to the reconciler; it is never re-dispatched.
"""

from __future__ import annotations

import logging
from datetime import datetime
from uuid import UUID, uuid4

from mobilelab.candidates.scope import ScenarioScope
from mobilelab.coordinator.types import (
    CandidateGenerator,
    CorrelationFn,
    DeviceBinding,
    DispatchOutcome,
    OutcomeKind,
    Rebinder,
)
from mobilelab.domain.actions import MAX_WAIT_MS, ActionPayload, NavigateUrl, OpenApp, SendMessage, StartCall, TypeText, Wait, url_origin
from mobilelab.domain.base import utc_now
from mobilelab.domain.dispatch import ActionRecord, AttemptRecord, DispatchCommand, ExecutionResult
from mobilelab.domain.enums import ActionKind, ActionStatus, ExecutionStatus, RunStatus, SideEffectClass
from mobilelab.domain.errors import (
    CandidateNotFound,
    DispatchGateClosed,
    ErrorCode,
    ErrorEnvelope,
    IdempotencyConflict,
    InvalidParameters,
    MobilelabError,
    StaleEpoch,
)
from mobilelab.domain.observations import DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS, CandidateAction, Observation, ObserveRequest
from mobilelab.domain.proposals import ProposedAction, payload_from_candidate
from mobilelab.store import Store
from mobilelab.store.artifacts import ArtifactStore
from mobilelab.store.repository import UnitOfWork
from mobilelab.workers.client import WorkerClient

log = logging.getLogger(__name__)

DEFAULT_MAX_REPLANS = 2
DEFAULT_COMMAND_MAX_DURATION_MS = 10_000
_CORRELATED = frozenset({ActionKind.SEND_MESSAGE})
UNSETTLED_COMMIT_STATUSES = (
    ActionStatus.PREPARED,
    ActionStatus.DISPATCHED,
    ActionStatus.ACKNOWLEDGED,
    ActionStatus.UNKNOWN,
    ActionStatus.UNRESOLVED,
)
"""A non-idempotent commit in one of these states may have reached the device and is not yet
reconciled (VERIFIED/FAILED): no further commit may be dispatched in the run (CONTRACTS §6)."""


def _default_correlation(candidate: CandidateAction, observation: Observation) -> UUID:
    from mobilelab.candidates import client_message_id_for

    return client_message_id_for(candidate, observation)


def check_payload_scope(payload: ActionPayload, scope: ScenarioScope) -> None:
    """Second, independent allowlist check of the executor payload against the frozen scope."""
    match payload:
        case OpenApp(app_id=app) if app not in scope.allowed_app_ids:
            raise InvalidParameters("app not in scenario scope", details={"app_id": app})
        case NavigateUrl(url=url) if url_origin(url) not in scope.allowed_url_origins:
            raise InvalidParameters("url origin not in scenario scope", details={"origin": url_origin(url)})
        case SendMessage(contact_id=c) | StartCall(contact_id=c) if c not in scope.allowed_contact_ids:
            raise InvalidParameters("contact not in scenario scope", details={"contact_id": c})
        case TypeText(text=text, mode=mode):
            policy = scope.text_policy
            if len(text) > policy.max_length:
                raise InvalidParameters("text exceeds scenario max length", details={"max": policy.max_length})
            if not policy.allow_generated_text and text not in policy.allowed_texts:
                raise InvalidParameters("text not allowed by the scenario text policy")
            if mode not in scope.typing_modes:
                raise InvalidParameters("typing mode not allowed by scenario", details={"mode": mode})
        case Wait(duration_ms=ms) if ms > scope.max_wait_ms:
            raise InvalidParameters("wait exceeds scenario max_wait_ms", details={"max": scope.max_wait_ms})
        case _:
            pass


class DispatchEngine:
    """Owns the action journal for one coordinator. Database writes happen only here (and in the
    run controller); the worker only executes one already-journaled command."""

    def __init__(
        self,
        store: Store,
        artifacts: ArtifactStore,
        scope: ScenarioScope,
        *,
        generate: CandidateGenerator,
        rebind: Rebinder,
        correlation: CorrelationFn = _default_correlation,
        max_replans: int = DEFAULT_MAX_REPLANS,
        command_max_duration_ms: int = DEFAULT_COMMAND_MAX_DURATION_MS,
        max_observation_age_ms: int = DEFAULT_MAX_DISPATCH_OBSERVATION_AGE_MS,
    ) -> None:
        self.store = store
        self.artifacts = artifacts
        self.scope = scope
        self._generate = generate
        self._rebind = rebind
        self._correlation = correlation
        self.max_replans = max_replans
        self.command_max_duration_ms = command_max_duration_ms
        self.max_observation_age_ms = max_observation_age_ms
        self._replans: dict[UUID, int] = {}

    def consecutive_replans(self, run_id: UUID) -> int:
        return self._replans.get(run_id, 0)

    # -- observations ------------------------------------------------------------------------------

    async def capture(self, worker: WorkerClient, binding: DeviceBinding, purpose: str = "decision") -> Observation:
        """Observe through the owning worker, attach trusted candidates, persist artifacts + observation."""
        request = ObserveRequest(
            request_id=uuid4(),
            run_id=binding.run_id,
            device_id=binding.device_id,
            session_id=binding.session_id,
            lease_id=binding.lease_id,
            lease_epoch=binding.lease_epoch,
            purpose=purpose,  # type: ignore[arg-type]
        )
        raw = await worker.observe(request)
        blobs = worker.take_artifacts(raw.observation_id)
        observation = Observation.model_validate(
            {**raw.model_dump(), "candidates": [c.model_dump() for c in self._generate(raw, self.scope)]}
        )
        metas = [
            self.artifacts.write_bytes(
                b.data,
                filename=b.filename,
                content_type=b.content_type,
                evidence_source=b.evidence_source,
                run_id=binding.run_id,
                artifact_id=b.artifact_id,
            )
            for b in blobs
        ]
        with self.store.unit_of_work() as uow:
            for meta in metas:
                uow.add_artifact(meta)
            uow.add_observation(observation)
        return observation

    # -- validation --------------------------------------------------------------------------------

    def resolve_candidate(self, proposal: ProposedAction, observation: Observation) -> CandidateAction:
        """The proposal's candidate, which must be exactly one trusted code generates for the
        decision observation (an invented or altered candidate never reaches the journal)."""
        if proposal.decision_observation_id != observation.observation_id:
            raise CandidateNotFound("proposal refers to a different decision observation")
        offered = observation.candidate(proposal.candidate_id)
        bare = observation.model_copy(update={"candidates": []})
        trusted = {c.candidate_id: c for c in self._generate(bare, self.scope)}
        if trusted.get(offered.candidate_id) != offered:
            raise CandidateNotFound(
                "candidate was not generated by trusted code for this observation",
                details={"candidate_id": str(offered.candidate_id), "kind": offered.kind.value},
            )
        return offered

    def _payload(self, candidate: CandidateAction, proposal: ProposedAction, observation: Observation) -> tuple[ActionPayload, UUID | None]:
        cmid = self._correlation(candidate, observation) if candidate.kind in _CORRELATED else None
        payload = payload_from_candidate(candidate, proposal, client_message_id=cmid)
        check_payload_scope(payload, self.scope)
        return payload, cmid

    @staticmethod
    def check_no_unsettled_commit(uow: UnitOfWork, run_id: UUID, candidate: CandidateAction) -> None:
        """No blind side-effect retry, enforced here rather than trusted to the provider: a
        non-idempotent commit (send, call) is refused while an earlier commit in the same run is
        potentially executed and unreconciled. Only receipt reconciliation can move past it."""
        if candidate.side_effect_class is not SideEffectClass.NON_IDEMPOTENT_COMMIT:
            return
        pending = [
            a
            for a in uow.list_actions(run_id=run_id, statuses=UNSETTLED_COMMIT_STATUSES)
            if a.side_effect_class is SideEffectClass.NON_IDEMPOTENT_COMMIT
        ]
        if pending:
            raise IdempotencyConflict(
                "an earlier non-idempotent commit in this run is unreconciled; it is never resent",
                details={"action_id": str(pending[0].action_id), "kind": pending[0].kind.value, "status": pending[0].status.value},
            )

    @staticmethod
    def _check_authority(uow: UnitOfWork, binding: DeviceBinding) -> None:
        uow.require_gate_open()
        run = uow.get_run(binding.run_id)
        if run.status is not RunStatus.RUNNING:
            raise DispatchGateClosed(f"run is {run.status}, not RUNNING", current_state={"status": run.status.value})
        if run.control_epoch != binding.control_epoch:
            raise StaleEpoch(
                "run control epoch changed", details={"binding": binding.control_epoch, "current": run.control_epoch}
            )
        uow.check_lease(binding.lease_id, binding.lease_epoch, device_id=binding.device_id)

    # -- dispatch ----------------------------------------------------------------------------------

    async def dispatch(
        self,
        worker: WorkerClient,
        binding: DeviceBinding,
        proposal: ProposedAction,
        decision_observation: Observation,
        *,
        sampled_delay_ms: float | None = None,
        decision_latency_ms: float | None = None,
    ) -> DispatchOutcome:
        run_id = binding.run_id
        if proposal.control_epoch is not None and proposal.control_epoch != binding.control_epoch:
            return DispatchOutcome(OutcomeKind.DISCARDED, "proposal carries a stale control epoch", decision_id=proposal.decision_id)
        try:
            candidate = self.resolve_candidate(proposal, decision_observation)
        except MobilelabError as err:
            return DispatchOutcome(OutcomeKind.REJECTED, err.message, error_code=err.code, decision_id=proposal.decision_id)

        action_id = uuid4()
        try:
            with self.store.unit_of_work() as uow:
                uow.add_action(
                    ActionRecord(
                        action_id=action_id,
                        run_id=run_id,
                        device_id=binding.device_id,
                        decision_id=proposal.decision_id,
                        kind=candidate.kind,
                        semantic_key=candidate.semantic_key,
                        side_effect_class=candidate.side_effect_class,
                        decision_observation_id=decision_observation.observation_id,
                        original_candidate_id=candidate.candidate_id,
                        sampled_delay_ms=sampled_delay_ms,
                        decision_latency_ms=decision_latency_ms,
                    )
                )
        except MobilelabError as err:  # run no longer RUNNING: a late decision
            return DispatchOutcome(OutcomeKind.DISCARDED, err.message, error_code=err.code, decision_id=proposal.decision_id)

        def finish(kind: OutcomeKind, status: ActionStatus, reason: str, code: ErrorCode | None = None, **kw: object) -> DispatchOutcome:
            if kind is not OutcomeKind.REPLAN and kind is not OutcomeKind.STUCK:
                self._replans[run_id] = 0
            return DispatchOutcome(
                kind, reason, action_id=action_id, status=status, error_code=code,
                consecutive_replans=self._replans.get(run_id, 0), decision_id=proposal.decision_id, **kw,  # type: ignore[arg-type]
            )  # fmt: skip

        def exit_before_dispatch(target: ActionStatus, err: MobilelabError) -> None:
            with self.store.unit_of_work() as uow:
                uow.transition_action(action_id, target, reject_code=err.code)

        # VALIDATED: trusted transform + scope allowlists (decision observation's draft identity)
        # + no second commit while an earlier one is unreconciled.
        try:
            self._payload(candidate, proposal, decision_observation)
            with self.store.reader() as r:
                self.check_no_unsettled_commit(r, run_id, candidate)
        except MobilelabError as err:
            exit_before_dispatch(ActionStatus.REJECTED, err)
            return finish(OutcomeKind.REJECTED, ActionStatus.REJECTED, err.message, err.code)
        with self.store.unit_of_work() as uow:
            uow.transition_action(action_id, ActionStatus.VALIDATED)

        # SCHEDULED: authority still current.
        try:
            with self.store.unit_of_work() as uow:
                self._check_authority(uow, binding)
                uow.transition_action(action_id, ActionStatus.SCHEDULED, scheduled_at=utc_now())
        except MobilelabError as err:
            exit_before_dispatch(ActionStatus.CANCELLED, err)
            return finish(OutcomeKind.CANCELLED, ActionStatus.CANCELLED, err.message, err.code)

        # Fresh dispatch observation + deterministic semantic rebinding.
        try:
            fresh = await self.capture(worker, binding, "dispatch")
        except Exception as err:
            env = err if isinstance(err, MobilelabError) else MobilelabError(f"{type(err).__name__}: {err}")
            exit_before_dispatch(ActionStatus.CANCELLED, env)
            return finish(OutcomeKind.CANCELLED, ActionStatus.CANCELLED, f"dispatch observation failed: {env.message}", env.code)
        rebound = self._rebind(candidate, fresh, self.scope)
        payload: ActionPayload | None = None
        cmid: UUID | None = None
        replan_reason = "semantic rebinding failed: app, target, meaning or context changed"
        if rebound is not None:
            try:
                payload, cmid = self._payload(rebound, proposal, fresh)
            except MobilelabError as err:
                replan_reason = f"rebound candidate no longer valid: {err.message}"
        if rebound is None or payload is None:
            exit_before_dispatch(ActionStatus.CANCELLED, CandidateNotFound(replan_reason))
            self._replans[run_id] = self._replans.get(run_id, 0) + 1
            kind = OutcomeKind.STUCK if self._replans[run_id] > self.max_replans else OutcomeKind.REPLAN
            return finish(kind, ActionStatus.CANCELLED, replan_reason, ErrorCode.CANDIDATE_NOT_FOUND)
        if sampled_delay_ms is not None and isinstance(payload, Wait):
            payload = self.dwell_remainder(payload, decision_observation, sampled_delay_ms)

        # PREPARED + attempt row, committed before anything is written to the worker.
        command = DispatchCommand(
            command_id=uuid4(),
            action_id=action_id,
            run_id=run_id,
            device_id=binding.device_id,
            session_id=binding.session_id,
            lease_id=binding.lease_id,
            lease_epoch=binding.lease_epoch,
            control_epoch=binding.control_epoch,
            dispatch_observation_id=fresh.observation_id,
            dispatch_candidate_id=rebound.candidate_id,
            payload=payload,
            max_duration_ms=self.command_max_duration_ms,
            max_observation_age_ms=self.max_observation_age_ms,
            trace_id=f"run:{run_id}:action:{action_id}",
        )
        attempt_id = uuid4()
        try:
            with self.store.unit_of_work() as uow:
                self._check_authority(uow, binding)
                self.check_no_unsettled_commit(uow, run_id, rebound)
                uow.transition_action(
                    action_id,
                    ActionStatus.PREPARED,
                    dispatch_observation_id=fresh.observation_id,
                    dispatch_candidate_id=rebound.candidate_id,
                    payload=payload,
                    correlation_id=cmid,
                )
                attempt_no = len(uow.list_attempts(action_id)) + 1
                uow.add_attempt(AttemptRecord(attempt_id=attempt_id, action_id=action_id, attempt_no=attempt_no, command_id=command.command_id))
        except MobilelabError as err:
            exit_before_dispatch(ActionStatus.CANCELLED, err)
            return finish(OutcomeKind.CANCELLED, ActionStatus.CANCELLED, err.message, err.code)

        handed_at = utc_now()
        try:
            result = await worker.execute(command)
        except Exception as err:  # timeout / worker gone: the command may have started
            result = self._unknown(command, worker, handed_at, err)
        if result.command_id != command.command_id or result.action_id != action_id:
            result = self._unknown(command, worker, handed_at, MobilelabError("worker answered for another command"))
        timing = self._wait_timing(payload, decision_observation, result, handed_at, sampled_delay_ms)
        status = self._journal_result(action_id, attempt_id, result, handed_at, timing)
        kind = {
            ActionStatus.REJECTED: OutcomeKind.REJECTED,
            ActionStatus.ACKNOWLEDGED: OutcomeKind.ACKNOWLEDGED,
            ActionStatus.FAILED: OutcomeKind.FAILED,
            ActionStatus.UNKNOWN: OutcomeKind.UNKNOWN,
        }[status]
        return finish(kind, status, result.detail or status.value, result.rejection_code, result=result)

    @staticmethod
    def _unknown(command: DispatchCommand, worker: WorkerClient, handed_at: datetime, err: BaseException) -> ExecutionResult:
        message = err.message if isinstance(err, MobilelabError) else f"{type(err).__name__}: {err}"
        code = err.code if isinstance(err, MobilelabError) else ErrorCode.INTERNAL_ERROR
        return ExecutionResult(
            command_id=command.command_id,
            action_id=command.action_id,
            device_id=command.device_id,
            status=ExecutionStatus.UNKNOWN,
            evidence_source=worker.evidence_source,
            started_at=handed_at,
            ended_at=utc_now(),
            error=ErrorEnvelope(code=code, message=message[:2000]),
            detail=f"coordinator lost the command outcome ({message}); outcome unknown, not retried"[:4000],
        )

    @staticmethod
    def dwell_remainder(payload: Wait, decision_observation: Observation, sampled_delay_ms: float) -> Wait:
        """Persona dwell as a device wait for only the *remaining* interval (CONTRACTS §8).

        The screen has been visible since the decision observation was captured, so decision latency
        (model inference), validation and the dispatch observation already count toward the sampled
        dwell. The wait executes ``sampled - elapsed`` (at least 1 ms, the payload minimum), replacing
        the proposed duration (a model never sets human timing); when elapsed already exceeds the
        sample the excess is recorded as ``timing_overrun_ms``."""
        elapsed_ms = max(0.0, (utc_now() - decision_observation.capture_ended_at).total_seconds() * 1000)
        remaining = int(round(sampled_delay_ms - elapsed_ms))
        return Wait(kind="wait", duration_ms=max(1, min(remaining, MAX_WAIT_MS)))

    @staticmethod
    def _wait_timing(
        payload: ActionPayload,
        decision_observation: Observation,
        result: ExecutionResult,
        handed_at: datetime,
        sampled_delay_ms: float | None,
    ) -> dict[str, float]:
        """Timing record for a dwell executed as a device ``wait`` (CONTRACTS §8).

        The screen stays as observed from the decision observation until the wait ends, so the
        human-visible dwell is (decision + validation + dispatch observation) + the wait itself. The
        planned dwell is ``sampled_delay_ms`` (a persona dwell, whose wait was shortened to the
        remainder by :meth:`dwell_remainder`) or else the wait duration; ``timing_overrun_ms`` is
        by how much the visible dwell exceeded the planned one."""
        if not isinstance(payload, Wait):
            return {}
        planned = float(sampled_delay_ms if sampled_delay_ms is not None else payload.duration_ms)
        started = result.started_at or handed_at
        pre_ms = max(0.0, (started - decision_observation.capture_ended_at).total_seconds() * 1000)
        overrun = max(0.0, pre_ms + payload.duration_ms - planned)
        return {"sampled_delay_ms": planned, "timing_overrun_ms": round(overrun, 1)}

    def _journal_result(
        self,
        action_id: UUID,
        attempt_id: UUID,
        result: ExecutionResult,
        handed_at: datetime,
        timing: dict[str, float] | None = None,
    ) -> ActionStatus:
        with self.store.unit_of_work() as uow:
            uow.complete_attempt(attempt_id, result)
            if result.status is ExecutionStatus.REJECTED:
                uow.transition_action(action_id, ActionStatus.REJECTED, reject_code=result.rejection_code)
                return ActionStatus.REJECTED
            uow.transition_action(
                action_id, ActionStatus.DISPATCHED, actual_dispatch_at=result.started_at or handed_at, **(timing or {})
            )
            if result.status is ExecutionStatus.UNKNOWN:
                uow.transition_action(action_id, ActionStatus.UNKNOWN)
                return ActionStatus.UNKNOWN
            uow.transition_action(action_id, ActionStatus.ACKNOWLEDGED)
            if result.status is ExecutionStatus.FAILED:
                uow.transition_action(action_id, ActionStatus.FAILED)
                return ActionStatus.FAILED
            return ActionStatus.ACKNOWLEDGED

"""The browse_then_reply journey as a deterministic, data-driven step script for RulesProvider."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal
from uuid import UUID

from pydantic import Field

from mobilelab.candidates import keys
from mobilelab.domain.actions import url_origin, validate_http_url
from mobilelab.domain.base import FrozenModel, Identifier, ShortStr
from mobilelab.domain.enums import TypingMode
from mobilelab.domain.scenarios import ScenarioSpec

ParamKind = Literal["none", "start_url", "dwell", "reply", "status_wait"]
Shortcut = Literal["on_start_article", "messenger_foreground", "conversation_open", "on_allowed_page"]


@dataclass(frozen=True)
class Step:
    name: str
    semantic_key: str
    reason_code: str
    params: ParamKind = "none"
    optional: bool = False
    """If its candidate is absent, the step is skipped instead of signalling no progress."""
    only_after: str | None = None
    """Run only if the named (optional) step was executed."""
    shortcut: Shortcut | None = None
    """Observation that already satisfies the step (it is then not executed)."""
    requires: Shortcut | None = None
    """Observation that must hold before the step is proposed (e.g. a reading dwell only once the page
    is in front); otherwise the provider signals no progress yet and the loop re-observes."""
    commit: bool = False
    """Non-idempotent: done after any attempt that was not rejected/cancelled; never proposed again."""
    completion: bool = False


class BrowseThenReplyScript(FrozenModel):
    scenario_id: Identifier = "browse_then_reply"
    fixture_data_base_url: str
    start_article: Identifier = "article-01"
    start_article_title: ShortStr
    follow_link_label: ShortStr | None = None
    conversation_id: Identifier
    reply_text: str = Field(min_length=1, max_length=2000)
    typing_mode: TypingMode = TypingMode.FIELD_SET
    status_wait_ms: int = Field(default=5000, ge=1, le=60_000)
    dwell_category: Literal["reading_dwell", "reply_delay"] = "reading_dwell"
    safari_app_id: str = keys.SAFARI_BUNDLE_ID
    messenger_app_id: str = keys.LAB_MESSENGER_BUNDLE_ID

    @property
    def origin(self) -> str:
        return url_origin(validate_http_url(self.fixture_data_base_url))

    def start_url(self, run_id: UUID | None) -> str:
        url = f"{self.origin}/fixture/v1/articles/{self.start_article}"
        return f"{url}?run_id={run_id}" if run_id else url

    def steps(self) -> list[Step]:
        dwell = keys.WAIT_DWELL
        down = keys.safari_scroll("down")
        steps = [
            Step("open_article", keys.url_open(self.origin), "OPEN_START_ARTICLE", "start_url",
                 shortcut="on_start_article"),
            Step("read_top", dwell, "READ_DWELL", "dwell", requires="on_allowed_page"),
            Step("scroll_1", down, "SCROLL_READ"),
            Step("read_middle", dwell, "READ_DWELL", "dwell", requires="on_allowed_page"),
            Step("scroll_2", down, "SCROLL_READ"),
            Step("read_end", dwell, "READ_DWELL", "dwell", requires="on_allowed_page"),
        ]
        if self.follow_link_label:
            steps += [
                Step("follow_link", keys.safari_link(self.follow_link_label), "FOLLOW_ARTICLE_LINK", optional=True),
                Step("read_linked", dwell, "READ_DWELL", "dwell", only_after="follow_link", requires="on_allowed_page"),
            ]
        steps += [
            Step("open_messenger", keys.app_open(self.messenger_app_id), "SWITCH_TO_MESSENGER",
                 shortcut="messenger_foreground"),
            Step("open_conversation", keys.messenger_conversation(self.conversation_id), "OPEN_TEST_CONVERSATION",
                 shortcut="conversation_open"),
            Step("type_reply", keys.messenger_composer(self.conversation_id), "TYPE_REPLY", "reply"),
            Step("send_reply", keys.messenger_send(self.conversation_id), "REPLY_TO_TEST_CONTACT", commit=True),
            Step("await_status", dwell, "AWAIT_SEND_STATUS", "status_wait", requires="messenger_foreground"),
            Step("return_to_browser", keys.app_open(self.safari_app_id), "RETURN_TO_BROWSER", completion=True),
        ]
        return steps

    @classmethod
    def from_scenario(cls, spec: ScenarioSpec, *, fixture_data_base_url: str) -> BrowseThenReplyScript:
        setup = spec.fixture_setup
        fields = ("start_article", "start_article_title", "follow_link_label", "conversation_id", "reply_text",
                  "status_wait_ms")
        data = {k: setup[k] for k in fields if k in setup}
        return cls.model_validate(
            {"scenario_id": spec.scenario_id, "fixture_data_base_url": fixture_data_base_url, **data}
        )

"""Decision-provider contract (CONTRACTS §5) and shared helpers.

Providers choose one supplied candidate (by ID) plus permitted parameters. They never receive worker
handles, database access or device-executing tools, and never invent candidate IDs or selectors.
"""

from __future__ import annotations

from typing import Literal, Protocol, runtime_checkable
from uuid import UUID, uuid4

from pydantic import Field

from mobilelab.domain.base import FrozenModel, Identifier
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.enums import ActionKind
from mobilelab.domain.errors import MobilelabError
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposalParameters, ProposedAction, payload_from_candidate
from mobilelab.providers.errors import InvalidProposal, ProviderCancelled, ProviderInputError


_CORRELATED_KINDS = frozenset({ActionKind.SEND_MESSAGE, ActionKind.START_CALL, ActionKind.END_CALL})


class ProviderInfo(FrozenModel):
    name: Identifier
    kind: Literal["rules", "replay", "openai", "jev", "local"]
    version: str = Field(min_length=1, max_length=64)
    model: str | None = Field(default=None, max_length=256)
    deployment: Literal["local", "cloud"] = "local"
    supports_images: bool = False
    structured_output: bool = True


@runtime_checkable
class DecisionProvider(Protocol):
    provider_info: ProviderInfo

    async def decide(
        self,
        context: DecisionContext,
        observation: Observation,
        candidates: list[CandidateAction],
        budget: DecisionBudget,
    ) -> ProposedAction: ...


def check_inputs(observation: Observation, candidates: list[CandidateAction], budget: DecisionBudget) -> None:
    if budget.cancelled:
        raise ProviderCancelled("decision cancelled before start")
    foreign = [str(c.candidate_id) for c in candidates if c.observation_id != observation.observation_id]
    if foreign:
        raise ProviderInputError("candidates do not belong to the decision observation", details={"ids": foreign})


def build_proposal(
    context: DecisionContext,
    observation: Observation,
    candidate: CandidateAction,
    parameters: ProposalParameters,
    *,
    reason_code: str,
    completion: bool = False,
    explanation: str | None = None,
) -> ProposedAction:
    """Assemble a proposal for a supplied candidate and check its parameters against PermittedParameters."""
    proposal = ProposedAction(
        decision_id=uuid4(),
        decision_observation_id=observation.observation_id,
        candidate_id=candidate.candidate_id,
        parameters=parameters,
        reason_code=reason_code,
        completion=completion,
        explanation=explanation,
        control_epoch=context.control_epoch,
    )
    # A placeholder correlation ID lets the trusted transform check shape only; the coordinator
    # supplies the real draft identity at dispatch.
    placeholder: UUID | None = uuid4() if candidate.kind in _CORRELATED_KINDS else None
    try:
        payload_from_candidate(candidate, proposal, client_message_id=placeholder, call_correlation_id=placeholder)
    except MobilelabError as exc:
        raise InvalidProposal(
            "provider produced parameters outside the candidate's permitted set",
            details={"semantic_key": candidate.semantic_key, "error": exc.message},
        ) from exc
    except (ValueError, TypeError):
        # pydantic ValidationError is a ValueError. Its text can repeat the provider's input, so a
        # fixed message is used and the original exception is not chained.
        raise InvalidProposal(
            "provider produced parameters that failed validation",
            details={"semantic_key": candidate.semantic_key},
        ) from None
    return proposal

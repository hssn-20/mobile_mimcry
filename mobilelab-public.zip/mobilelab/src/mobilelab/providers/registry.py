"""Provider factory: switching providers changes configuration, not device execution (CONTRACTS §5)."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any, Literal

from mobilelab.budget import DEFAULT_LEDGER_DB, BudgetLedger, resolve_ledger_path
from mobilelab.providers.base import DecisionProvider
from mobilelab.providers.errors import ProviderUnavailable

ProviderName = Literal["rules", "replay", "luna"]
DEFAULT_DB_PATH = DEFAULT_LEDGER_DB
"""Absolute, repo-anchored spend ledger; never resolved against the current directory."""


def create_provider(name: ProviderName, config: dict[str, Any] | None = None) -> DecisionProvider:
    """Build a provider from configuration.

    * ``rules``: ``{"script": BrowseThenReplyScript, "scope": ScenarioScope, "sampler"?: PersonaSampler}``
    * ``replay``: ``{"recorded": Iterable[RecordedDecision]}``
    * ``luna``: ``{"config_path"?: path, "overrides"?: dict, "ledger"?: BudgetLedger, "db_path"?: absolute path
      (default: the repo ledger ``artifacts/mobilelab.db``; a per-run ``--db`` never starts a new budget),
      "backend"?: PolicyBackend, "client"?: AsyncOpenAI-like, "api_key"?: SecretValue,
      "epoch_probe"?: Callable[[], int], "base_url"?: str, "http_client"?: httpx.AsyncClient}``. Without ``backend``/``client``/``api_key`` the key is read
      from ``OPENAI_API_KEY`` or the macOS Keychain inside this process.
    """
    cfg = dict(config or {})
    if name == "rules":
        from mobilelab.providers.rules import RulesProvider

        return RulesProvider(cfg["script"], cfg["scope"], sampler=cfg.get("sampler"))
    if name == "replay":
        from mobilelab.providers.replay import ReplayProvider

        recorded: Iterable[Any] = cfg.get("recorded", [])
        return ReplayProvider(recorded)
    if name == "luna":
        return _create_luna(cfg)
    raise ProviderUnavailable("unknown provider", details={"name": str(name)})


def _create_luna(cfg: dict[str, Any]) -> DecisionProvider:
    from mobilelab.providers.luna import LunaProvider, load_luna_config
    from mobilelab.providers.openai_backend import AgentsSdkBackend

    luna_cfg = cfg.get("luna_config") or load_luna_config(cfg.get("config_path"), **cfg.get("overrides", {}))
    ledger: BudgetLedger = cfg.get("ledger") or BudgetLedger.open(
        resolve_ledger_path(cfg.get("db_path")), global_cap_usd=luna_cfg.global_cap_usd, run_cap_usd=luna_cfg.run_cap_usd
    )
    backend = cfg.get("backend")
    if backend is None:
        client = cfg.get("client")
        api_key = cfg.get("api_key")
        if client is None and api_key is None:
            from mobilelab.secrets import get_openai_api_key

            api_key = get_openai_api_key()
        # ``base_url``/``http_client`` are code-supplied transport options (tests point the real SDK
        # path at a local fake server); they never come from model output or scenario files.
        backend = AgentsSdkBackend(model=luna_cfg.model, reasoning_effort=luna_cfg.reasoning_effort,
                                   api_key=api_key, client=client, base_url=cfg.get("base_url"),
                                   http_client=cfg.get("http_client"))  # fmt: skip
    epoch_probe: Callable[[], int] | None = cfg.get("epoch_probe")
    return LunaProvider(luna_cfg, backend=backend, ledger=ledger, epoch_probe=epoch_probe)


__all__ = ["ProviderName", "create_provider"]

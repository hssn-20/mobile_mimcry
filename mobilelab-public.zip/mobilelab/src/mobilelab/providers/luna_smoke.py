"""Live GPT-6 Luna smoke on RECORDED real-Simulator observations, with no device (T08 step 7).

``uv run python -m mobilelab.providers.luna_smoke [--run-id ID] [--db PATH] [--ledger-db ABS_PATH] [--max-calls N]``

It loads observations (and their real candidate lists) recorded by a previous Simulator run, asks
Luna to choose, and checks the choice is one of the supplied candidates. Every request is reserved in
the shared ledger first. Redacted evidence goes to ``artifacts/provider/luna-smoke-<ts>.json``. The
API key is read inside this process only and never printed or written.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from mobilelab.budget import DEFAULT_LEDGER_DB, BudgetLedger, resolve_ledger_path
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.errors import ProviderError
from mobilelab.domain.observations import Observation
from mobilelab.personas import get_persona
from mobilelab.providers.luna import LunaProvider, load_luna_config

DEFAULT_RUN = "46c41fa6-6a85-4939-9fdb-a20e95a4defa"
GOAL = "Read a fixture article and reply to the designated test contact."
# (observation-id prefix, scenario stage) pairs: a Safari article page and the Messenger reply screen.
DEFAULT_PICKS = (("cb9d34db", "read_article"), ("8e8c6814", "reply_to_contact"))


def load_recorded_observations(db: Path, run_id: str, prefixes: list[str]) -> list[Observation]:
    conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        out = []
        for prefix in prefixes:
            row = conn.execute(
                "SELECT body FROM observations WHERE run_id = ? AND observation_id LIKE ? LIMIT 1",
                (run_id, prefix + "%"),
            ).fetchone()
            if row is None:
                raise SystemExit(f"observation {prefix}* not found for run {run_id}")
            body = json.loads(row[0])
            body.pop("version", None)
            out.append(Observation.model_validate(body))
        return out
    finally:
        conn.close()


async def run_smoke(
    db: Path, run_id: str, out_dir: Path, max_calls: int, ledger_db: Path | None = None
) -> dict[str, Any]:
    cfg = load_luna_config()
    from mobilelab.providers.openai_backend import AgentsSdkBackend
    from mobilelab.secrets import get_openai_api_key

    observations = load_recorded_observations(db, run_id, [p for p, _ in DEFAULT_PICKS][:max_calls])
    ledger = BudgetLedger.open(resolve_ledger_path(ledger_db), global_cap_usd=cfg.global_cap_usd, run_cap_usd=cfg.run_cap_usd)
    smoke_run = uuid4()
    started = datetime.now(UTC)
    results: list[dict[str, Any]] = []
    record: dict[str, Any] = {
        "evidence_kind": "real_model_on_recorded_real_simulator_observations_no_device",
        "source_run_id": run_id,
        "smoke_ledger_run_id": str(smoke_run),
        "started_at": started.isoformat(),
        "provider_config": cfg.frozen,
        "results": results,
    }
    try:
        key = get_openai_api_key()
    except ProviderError as exc:
        record["blocked"] = {"error_class": type(exc).__name__, "message": exc.message}
        return record
    provider = LunaProvider(cfg, backend=AgentsSdkBackend(model=cfg.model, reasoning_effort=cfg.reasoning_effort,
                                                          api_key=key), ledger=ledger)  # fmt: skip
    record["key_source"] = key.source
    del key
    budget = DecisionBudget(timeout_ms=60_000, max_input_tokens=cfg.max_input_tokens,
                            max_output_tokens=cfg.max_output_tokens, max_cost_usd=0.01)  # fmt: skip
    for obs, (_, stage) in zip(observations, DEFAULT_PICKS, strict=False):
        origins = sorted({o for c in obs.candidates for o in c.permitted.url_origins})
        ctx = DecisionContext(
            run_id=smoke_run, persona=get_persona("task_focused", 1), scenario_id="browse_then_reply",
            scenario_version=1, scenario_stage=stage, goal=GOAL, authorized_url_origins=origins, control_epoch=0,
        )  # fmt: skip
        entry: dict[str, Any] = {"observation_id": str(obs.observation_id), "foreground_app": obs.foreground_app,
                                 "stage": stage, "offered": [c.semantic_key for c in obs.candidates]}  # fmt: skip
        try:
            proposal = await provider.decide(ctx, obs, list(obs.candidates), budget)
            chosen = obs.candidate(proposal.candidate_id)
            entry.update(valid_candidate=True, chosen_semantic_key=chosen.semantic_key, chosen_kind=chosen.kind.value,
                         parameters=proposal.parameters.model_dump(exclude_none=True, mode="json"),
                         reason_code=proposal.reason_code, completion_hint=proposal.completion)  # fmt: skip
        except ProviderError as exc:
            entry.update(valid_candidate=False, error_class=type(exc).__name__, error=exc.to_envelope().model_dump(mode="json"))
        ev = provider.last_evidence
        entry["provider_evidence"] = ev.model_dump(mode="json") if ev else None
        results.append(entry)
        if entry.get("error_class") in {"ProviderRequestRejected", "BudgetExceeded", "ProviderTransportError"}:
            break  # do not keep trying after a denial or a cap refusal
    record["ledger_rows"] = ledger.rows(str(smoke_run))
    record["ledger_summary_smoke_run"] = ledger.summary(str(smoke_run)).model_dump()
    record["ledger_summary_global"] = ledger.summary().model_dump()
    ledger.engine.dispose()
    return record


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-id", default=DEFAULT_RUN)
    ap.add_argument("--db", type=Path, default=DEFAULT_LEDGER_DB, help="DB holding the recorded run")
    ap.add_argument("--ledger-db", type=Path, default=DEFAULT_LEDGER_DB, help="absolute spend ledger DB")
    ap.add_argument("--out", type=Path, default=Path("artifacts/provider"))
    ap.add_argument("--max-calls", type=int, default=2, choices=[1, 2])
    args = ap.parse_args(argv)
    record = asyncio.run(run_smoke(args.db.resolve(), args.run_id, args.out, args.max_calls, args.ledger_db))
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / f"luna-smoke-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}.json"
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=2, default=str))
    tmp.replace(path)
    summary = {
        "evidence": str(path),
        "blocked": record.get("blocked"),
        "results": [{k: r.get(k) for k in ("observation_id", "valid_candidate", "chosen_semantic_key", "error_class")}
                    for r in record["results"]],
        "global": record.get("ledger_summary_global"),
    }  # fmt: skip
    print(json.dumps(summary, indent=2, default=str))
    return 0 if record["results"] and all(r.get("valid_candidate") for r in record["results"]) else 1


if __name__ == "__main__":
    sys.exit(main())


__all__ = ["load_recorded_observations", "run_smoke"]

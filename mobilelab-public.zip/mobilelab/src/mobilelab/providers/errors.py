"""Typed provider failures (all ``ProviderError``, persisted separately from device failures)."""

from __future__ import annotations

from mobilelab.domain.errors import ProviderError


class ProviderCancelled(ProviderError):
    """The budget's cancel signal was set (pause/stop/epoch change)."""


class ProviderInputError(ProviderError):
    """The provider was handed inputs that violate the contract (e.g. candidates of another observation)."""


class InvalidProposal(ProviderError):
    """The provider's own output failed candidate/parameter validation."""


class ExpectedCandidateMissing(ProviderError):
    """No-progress signal: the scripted next step's candidate is not offered in this observation."""

    retryable = True


class ReplayDivergence(ProviderError):
    """A recorded decision cannot be revalidated against the current candidates."""


class ReplayExhausted(ProviderError):
    """All recorded decisions have been replayed."""


# ---------------------------------------------------------------- cloud-provider failures (T08)
class ProviderUnavailable(ProviderError):
    """The provider cannot be used in this process (missing key, SDK, or configuration)."""


class ProviderTimeout(ProviderError):
    """The model request exceeded its time budget. Its cost reservation stays counted (unresolved)."""

    retryable = True


class ProviderTransportError(ProviderError):
    """Network/HTTP failure talking to the model API (never a device failure)."""

    retryable = True


class ProviderRequestRejected(ProviderError):
    """The API rejected the request before generation (e.g. 400/401/403/404/429)."""


class ProviderOutputInvalid(ProviderError):
    """The model's output failed schema/candidate validation, including after the bounded repair."""


class ProviderStaleResult(ProviderError):
    """A result arrived after the control epoch changed; it was discarded (CONTRACTS §5)."""

"""Deterministic RulesProvider baseline for browse_then_reply (CONTRACTS §5, SPEC §7).

It selects among the supplied candidates by semantic key only and fills parameters from the script,
checked against each candidate's PermittedParameters. Progress comes from what actually happened
(``DecisionContext.session_history``) plus observation shortcuts, never from its own proposals, so a
rejected or replanned proposal is simply proposed again. The send step is a commit: once any attempt
exists that was not rejected/cancelled it is never proposed again (no blind resend after UNKNOWN).

A stage whose precondition is not observed yet (e.g. the article page still loading behind the home
screen) gets a short explicit wait proposal (``AWAIT_STAGE_PRECONDITION``), not a provider error; that
wait never counts as the stage's own dwell. Only after ``MAX_PRECONDITION_WAITS`` consecutive waits is
it reported as a no-progress provider error.

The coordinator must append a HistoryEntry (semantic_key + latest status) for each action it journals.
A RulesProvider is a labelled baseline; it is not evidence of model-driven adaptation.
"""

from __future__ import annotations

from collections import Counter

from mobilelab.candidates import keys, open_conversation_id, page_origin_allowed, page_origin_verified
from mobilelab.candidates.scope import ScenarioScope
from mobilelab.candidates.safari import LINK_ROLE, has_role
from mobilelab.domain.decisions import DecisionBudget, DecisionContext, HistoryEntry
from mobilelab.domain.enums import ActionStatus
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposalParameters, ProposedAction
from mobilelab.personas.sampling import PersonaSampler
from mobilelab.providers.base import ProviderInfo, build_proposal, check_inputs
from mobilelab.providers.errors import ExpectedCandidateMissing
from mobilelab.providers.script import BrowseThenReplyScript, Step

SUCCESS = frozenset({ActionStatus.ACKNOWLEDGED, ActionStatus.VERIFIED})
NOT_ATTEMPTED = frozenset({ActionStatus.REJECTED, ActionStatus.CANCELLED})
COMPLETE_WAIT_MS = 1000
PRECONDITION_WAIT_MS = 750
MAX_PRECONDITION_WAITS = 12


class RulesProvider:
    provider_info = ProviderInfo(name="RulesProvider", kind="rules", version="1", model=None, deployment="local")

    def __init__(
        self, script: BrowseThenReplyScript, scope: ScenarioScope, *, sampler: PersonaSampler | None = None
    ) -> None:
        self.script = script
        self.scope = scope
        self.sampler = sampler
        self._steps = script.steps()
        self._cursor = 0
        self._outcomes: dict[str, str] = {}  # step name -> executed | satisfied | skipped
        self._seen: set[tuple[object, str]] = set()
        self._succeeded: Counter[str] = Counter()  # semantic_key -> successful actions not yet consumed
        self._attempted_commits: set[str] = set()
        self._dwell_ms: dict[str, int] = {}
        self._precondition_waits = 0  # consecutive
        self._skip_wait_once = False  # the last proposal was a precondition wait, not a stage dwell

    @property
    def stage(self) -> str:
        return self._steps[self._cursor].name if self._cursor < len(self._steps) else "complete"

    @property
    def outcomes(self) -> dict[str, str]:
        return dict(self._outcomes)

    # ------------------------------------------------------------------ progress
    def _ingest(self, history: list[HistoryEntry]) -> None:
        # One decision yields at most one action, so a newly seen wait right after a precondition-wait
        # proposal is that wait: it must not satisfy the next reading dwell.
        skip_wait, self._skip_wait_once = self._skip_wait_once, False
        for entry in history:
            if entry.status not in NOT_ATTEMPTED:
                self._attempted_commits.add(entry.semantic_key)
            ident = (entry.at, entry.semantic_key)
            if entry.status in SUCCESS and ident not in self._seen:
                self._seen.add(ident)
                if skip_wait and entry.semantic_key == keys.WAIT_DWELL:
                    skip_wait = False
                    continue
                self._succeeded[entry.semantic_key] += 1

    def _shortcut(self, step: Step, obs: Observation) -> bool:
        return self._holds(step.shortcut, obs)

    def _holds(self, condition: str | None, obs: Observation) -> bool:
        match condition:
            case "on_allowed_page":
                return obs.foreground_app == self.script.safari_app_id and page_origin_allowed(obs, self.scope)
            case "on_start_article":  # skipping the navigation needs the full origin, not a host match
                return (
                    obs.foreground_app == self.script.safari_app_id
                    and page_origin_verified(obs, self.scope)
                    and any(
                        e.visible and not has_role(e, LINK_ROLE) and e.label == self.script.start_article_title
                        for e in obs.ui_tree
                    )
                )
            case "messenger_foreground":
                return obs.foreground_app == self.script.messenger_app_id
            case "conversation_open":
                return (
                    obs.foreground_app == self.script.messenger_app_id
                    and open_conversation_id(obs, self.scope) == self.script.conversation_id
                )
        return False

    def _advance(self, obs: Observation, offered: set[str]) -> None:
        while self._cursor < len(self._steps):
            step = self._steps[self._cursor]
            if step.only_after is not None and self._outcomes.get(step.only_after) != "executed":
                outcome = "skipped"
            elif step.commit and step.semantic_key in self._attempted_commits:
                outcome = "executed"
            elif not step.commit and self._succeeded[step.semantic_key] > 0:
                self._succeeded[step.semantic_key] -= 1
                outcome = "executed"
            elif self._shortcut(step, obs):
                outcome = "satisfied"
            elif step.optional and step.semantic_key not in offered:
                outcome = "skipped"
            else:
                return
            self._outcomes[step.name] = outcome
            self._cursor += 1

    # ------------------------------------------------------------------ parameters
    def _dwell(self, step: Step, context: DecisionContext) -> int:
        # Sampled once per step: re-deciding after a freshness refresh never resamples (CONTRACTS §4).
        if step.name not in self._dwell_ms:
            if self.sampler is not None:
                ms = self.sampler.sample_dwell(self.script.dwell_category).sampled_ms
            else:
                ms = round(getattr(context.persona, self.script.dwell_category).median_seconds * 1000)
            self._dwell_ms[step.name] = max(1, ms)
        return self._dwell_ms[step.name]

    def _parameters(self, step: Step, candidate: CandidateAction, context: DecisionContext) -> ProposalParameters:
        match step.params:
            case "start_url":
                return ProposalParameters(url=self.script.start_url(context.run_id))
            case "dwell":
                return ProposalParameters(duration_ms=min(self._dwell(step, context), candidate.permitted.max_wait_ms))
            case "status_wait":
                return ProposalParameters(duration_ms=min(self.script.status_wait_ms, candidate.permitted.max_wait_ms))
            case "reply":
                return ProposalParameters(text=self.script.reply_text, typing_mode=self.script.typing_mode)
        return ProposalParameters()

    # ------------------------------------------------------------------ contract
    async def decide(
        self,
        context: DecisionContext,
        observation: Observation,
        candidates: list[CandidateAction],
        budget: DecisionBudget,
    ) -> ProposedAction:
        check_inputs(observation, candidates, budget)
        by_key = {c.semantic_key: c for c in candidates}
        self._ingest(context.session_history)
        self._advance(observation, set(by_key))

        if self._cursor >= len(self._steps):
            wait = by_key.get(keys.WAIT_DWELL)
            if wait is None:
                raise ExpectedCandidateMissing("journey complete but no wait candidate offered",
                                               details={"stage": "complete"})
            return build_proposal(context, observation, wait, ProposalParameters(duration_ms=COMPLETE_WAIT_MS),
                                  reason_code="JOURNEY_COMPLETE", completion=True, explanation="stage=complete")

        step = self._steps[self._cursor]
        if step.requires is not None and not self._holds(step.requires, observation):
            wait = by_key.get(keys.WAIT_DWELL)
            if wait is None or self._precondition_waits >= MAX_PRECONDITION_WAITS:
                raise ExpectedCandidateMissing(
                    "stage precondition not observed",
                    details={"stage": step.name, "requires": step.requires, "foreground_app": observation.foreground_app,
                             "waits": self._precondition_waits},
                )  # fmt: skip
            self._precondition_waits += 1
            self._skip_wait_once = True
            return build_proposal(
                context, observation, wait,
                ProposalParameters(duration_ms=min(PRECONDITION_WAIT_MS, wait.permitted.max_wait_ms)),
                reason_code="AWAIT_STAGE_PRECONDITION",
                explanation=f"stage={step.name} waiting for {step.requires}",
            )  # fmt: skip
        self._precondition_waits = 0
        candidate = by_key.get(step.semantic_key)
        if candidate is None:
            raise ExpectedCandidateMissing(
                "expected candidate for the current stage is not offered",
                details={"stage": step.name, "semantic_key": step.semantic_key, "offered": sorted(by_key)},
            )
        return build_proposal(
            context,
            observation,
            candidate,
            self._parameters(step, candidate, context),
            reason_code=step.reason_code,
            completion=step.completion,
            explanation=f"stage={step.name}",
        )

"""OpenAI transport for cloud policy providers: a bounded Agents SDK run over the Responses API (T08).

CONTRACTS §5: one ``Runner.run`` with ``max_turns=1``, **no tools and no handoffs**, a per-call strict
JSON output schema, ``store=False``, tracing disabled (globally and per run), SDK/client retries off
(each retry must hold its own budget reservation), and an explicit per-request timeout. The outer
coordinator keeps the action loop; the model has nothing it can execute.

The API key is passed only to the ``AsyncOpenAI`` client constructor. It is never logged, stored or
put into exceptions; exceptions are re-raised as typed :class:`BackendError` carrying only the
exception *class name*, HTTP status and request id.
"""

from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Protocol

from mobilelab.budget.rates import TokenUsage
from mobilelab.secrets import SecretValue

#: HTTP statuses for which the request is rejected before generation (not billed).
NOT_BILLED_STATUSES = frozenset({400, 401, 403, 404, 413, 415, 422, 429})


@dataclass(frozen=True)
class BackendResult:
    output_text: str
    usage: TokenUsage | None
    request_id: str | None
    response_id: str | None
    model: str | None
    latency_ms: float


class BackendError(Exception):
    """Transport-level failure. ``billed`` is False only when the API provably rejected the request
    before generation; None means unknown (keep the reservation)."""

    def __init__(
        self,
        kind: str,
        *,
        error_class: str,
        status_code: int | None = None,
        request_id: str | None = None,
        billed: bool | None = None,
        usage: TokenUsage | None = None,
    ) -> None:
        super().__init__(f"{kind}: {error_class}" + (f" (HTTP {status_code})" if status_code else ""))
        self.kind = kind  # timeout | transport | rejected | output
        self.error_class = error_class
        self.status_code = status_code
        self.request_id = request_id
        self.billed = billed
        self.usage = usage


class PolicyBackend(Protocol):
    model: str

    async def complete(
        self,
        *,
        instructions: str,
        user_input: str,
        schema: dict[str, Any],
        schema_name: str,
        max_output_tokens: int,
        timeout_s: float,
    ) -> BackendResult: ...


_KEYLIKE = re.compile(r"sk-[A-Za-z0-9_\-*.]{4,}")


class _RedactKeyLike(logging.Filter):
    """Masks key-like tokens (OpenAI 401 bodies echo a masked key fragment) in SDK log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            text = record.getMessage()
        except Exception:  # noqa: BLE001 - never let logging break the call
            return True
        if _KEYLIKE.search(text):
            record.msg, record.args = _KEYLIKE.sub("[redacted-key]", text), None
        if record.exc_info:
            record.exc_info, record.exc_text = None, None
        return True


_FILTER = _RedactKeyLike()


def install_log_redaction() -> None:
    for name in ("openai", "openai._base_client", "openai.agents", "httpx", "httpcore"):
        lg = logging.getLogger(name)
        if _FILTER not in lg.filters:
            lg.addFilter(_FILTER)


def disable_agents_tracing() -> None:
    """Turn Agents SDK tracing/export off process-wide (in addition to per-run ``tracing_disabled``)."""
    os.environ["OPENAI_AGENTS_DISABLE_TRACING"] = "1"
    from agents import set_tracing_disabled

    set_tracing_disabled(True)
    install_log_redaction()


def _usage_from_agents(usage: Any) -> TokenUsage | None:
    if usage is None or getattr(usage, "requests", 0) == 0:
        return None
    in_details = getattr(usage, "input_tokens_details", None)
    out_details = getattr(usage, "output_tokens_details", None)
    return TokenUsage(
        input_tokens=int(usage.input_tokens or 0),
        output_tokens=int(usage.output_tokens or 0),
        cached_input_tokens=int(getattr(in_details, "cached_tokens", 0) or 0),
        reasoning_tokens=int(getattr(out_details, "reasoning_tokens", 0) or 0),
        cache_write_tokens=_opt_int(getattr(in_details, "cache_write_tokens", None)),
    )


def _opt_int(value: Any) -> int | None:
    return None if value is None else int(value)


class AgentsSdkBackend:
    """Agents SDK backend. ``client`` may be injected (tests use a labelled fake ``AsyncOpenAI``)."""

    def __init__(
        self,
        *,
        model: str,
        reasoning_effort: str | None,
        api_key: SecretValue | None = None,
        client: Any | None = None,
        store: bool = False,
        base_url: str | None = None,
        http_client: Any | None = None,
    ) -> None:
        if store:
            raise ValueError("store=True is not permitted for mobilelab providers")
        if client is None and api_key is None:
            raise ValueError("an API key or an injected client is required")
        disable_agents_tracing()
        self.model = model
        self.reasoning_effort = reasoning_effort
        self._api_key = api_key
        self._client = client
        self._base_url = base_url
        self._http_client = http_client

    def _get_client(self) -> Any:
        if self._client is None:
            from openai import AsyncOpenAI

            assert self._api_key is not None
            # max_retries=0: a retry is a new request that needs its own reservation.
            self._client = AsyncOpenAI(
                api_key=self._api_key.reveal(), max_retries=0, base_url=self._base_url, http_client=self._http_client
            )
        return self._client

    async def complete(
        self,
        *,
        instructions: str,
        user_input: str,
        schema: dict[str, Any],
        schema_name: str,
        max_output_tokens: int,
        timeout_s: float,
    ) -> BackendResult:
        from agents import Agent, ModelSettings, RunConfig, Runner
        from agents.agent_output import AgentOutputSchemaBase
        from agents.exceptions import AgentsException
        from agents.models.openai_responses import OpenAIResponsesModel
        from openai import APIConnectionError, APIStatusError, APITimeoutError
        from openai.types.shared import Reasoning

        class _RawJsonOutput(AgentOutputSchemaBase):
            """Per-call strict schema; validation is done by mobilelab, not the SDK."""

            def is_plain_text(self) -> bool:
                return False

            def name(self) -> str:
                return schema_name

            def json_schema(self) -> dict[str, Any]:
                return schema

            def is_strict_json_schema(self) -> bool:
                return True

            def validate_json(self, json_str: str) -> Any:
                return json_str

        client = self._get_client()
        client = client.with_options(timeout=timeout_s, max_retries=0) if hasattr(client, "with_options") else client
        settings = ModelSettings(
            max_tokens=max_output_tokens,
            store=False,
            reasoning=Reasoning(effort=self.reasoning_effort) if self.reasoning_effort else None,  # type: ignore[arg-type]
            parallel_tool_calls=None,
            timeout=timeout_s,
        )
        agent = Agent(
            name="mobilelab_policy",
            instructions=instructions,
            model=OpenAIResponsesModel(model=self.model, openai_client=client),
            model_settings=settings,
            output_type=_RawJsonOutput(),
            tools=[],
            handoffs=[],
        )
        run_config = RunConfig(tracing_disabled=True, trace_include_sensitive_data=False,
                               workflow_name="mobilelab_policy")  # fmt: skip
        started = time.perf_counter()
        try:
            result = await Runner.run(agent, input=user_input, max_turns=1, run_config=run_config)
        except APITimeoutError as exc:
            raise BackendError("timeout", error_class=type(exc).__name__) from None
        except APIStatusError as exc:
            status = int(getattr(exc, "status_code", 0) or 0)
            billed = False if status in NOT_BILLED_STATUSES else None
            kind = "rejected" if billed is False else "transport"
            raise BackendError(kind, error_class=type(exc).__name__, status_code=status,
                               request_id=getattr(exc, "request_id", None), billed=billed) from None  # fmt: skip
        except APIConnectionError as exc:
            raise BackendError("transport", error_class=type(exc).__name__) from None
        except AgentsException as exc:  # e.g. incomplete response, max turns, model behaviour
            raise BackendError("output", error_class=type(exc).__name__) from None
        latency_ms = (time.perf_counter() - started) * 1000.0
        raw = result.raw_responses[-1] if result.raw_responses else None
        usage = _usage_from_agents(getattr(result.context_wrapper, "usage", None))
        output = result.final_output
        if not isinstance(output, str):
            raise BackendError("output", error_class="NonTextFinalOutput", usage=usage,
                               request_id=getattr(raw, "request_id", None))  # fmt: skip
        return BackendResult(
            output_text=output,
            usage=usage,
            request_id=getattr(raw, "request_id", None),
            response_id=getattr(raw, "response_id", None),
            model=self.model,
            latency_ms=latency_ms,
        )


__all__ = [
    "NOT_BILLED_STATUSES",
    "AgentsSdkBackend",
    "BackendError",
    "BackendResult",
    "PolicyBackend",
    "disable_agents_tracing",
]

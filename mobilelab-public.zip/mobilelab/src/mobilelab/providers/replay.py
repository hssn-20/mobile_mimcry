"""ReplayProvider: replays a recorded decision trace by semantic choice (CONTRACTS §8 decision_trace replay).

Recorded candidate IDs are observation-scoped and meaningless later, so each record keeps the chosen
candidate's semantic key and parameters. Replay re-selects the candidate with the same key from the
*current* candidates and revalidates the parameters against its PermittedParameters; any divergence
aborts with ReplayDivergence rather than guessing. Replay is not exact reproduction of a device run.
"""

from __future__ import annotations

from collections.abc import Iterable

from pydantic import Field, StrictBool, StrictStr

from mobilelab.domain.base import FrozenModel, ShortStr
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.enums import ActionKind
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposalParameters, ProposedAction
from mobilelab.providers.base import ProviderInfo, build_proposal, check_inputs
from mobilelab.providers.errors import InvalidProposal, ReplayDivergence, ReplayExhausted


class RecordedDecision(FrozenModel):
    semantic_key: ShortStr
    kind: ActionKind
    parameters: ProposalParameters = Field(default_factory=ProposalParameters)
    reason_code: StrictStr = Field(min_length=1, max_length=64, pattern=r"^[A-Z][A-Z0-9_]*$")
    completion: StrictBool = False

    @classmethod
    def from_proposal(cls, proposal: ProposedAction, candidate: CandidateAction) -> RecordedDecision:
        if proposal.candidate_id not in {candidate.candidate_id, candidate.rebound_from_candidate_id}:
            raise ValueError("proposal does not reference this candidate")
        return cls(
            semantic_key=candidate.semantic_key,
            kind=candidate.kind,
            parameters=proposal.parameters,
            reason_code=proposal.reason_code,
            completion=proposal.completion,
        )


class ReplayProvider:
    provider_info = ProviderInfo(name="ReplayProvider", kind="replay", version="1", model=None, deployment="local")

    def __init__(self, recorded: Iterable[RecordedDecision]) -> None:
        self._records = list(recorded)
        self._cursor = 0

    @property
    def position(self) -> int:
        return self._cursor

    @property
    def remaining(self) -> int:
        return len(self._records) - self._cursor

    async def decide(
        self,
        context: DecisionContext,
        observation: Observation,
        candidates: list[CandidateAction],
        budget: DecisionBudget,
    ) -> ProposedAction:
        check_inputs(observation, candidates, budget)
        if self._cursor >= len(self._records):
            raise ReplayExhausted("recorded decision trace exhausted", details={"position": self._cursor})
        record = self._records[self._cursor]
        candidate = next((c for c in candidates if c.semantic_key == record.semantic_key), None)
        if candidate is None or candidate.kind is not record.kind:
            raise ReplayDivergence(
                "recorded choice is not offered in the current observation",
                details={"position": self._cursor, "semantic_key": record.semantic_key, "kind": record.kind.value},
            )
        try:
            proposal = build_proposal(
                context,
                observation,
                candidate,
                record.parameters,
                reason_code=record.reason_code,
                completion=record.completion,
                explanation=f"replay#{self._cursor}",
            )
        except InvalidProposal as exc:
            raise ReplayDivergence(
                "recorded parameters are no longer permitted", details={"position": self._cursor, **exc.details}
            ) from exc
        self._cursor += 1
        return proposal

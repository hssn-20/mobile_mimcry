"""LunaProvider: OpenAI GPT-6 Luna decision provider (T08, FR-05, CONTRACTS §5).

Flow of one ``decide`` call:

1. Validate inputs; build a compact text prompt + per-call strict schema (``policy_io``). Images are
   never sent (text-only by default).
2. Reserve the request's worst-case cost in the persistent ledger (frozen rate card x measured prompt
   bound x max output tokens). Refused reservations raise ``BudgetExceeded``; nothing is sent.
3. Call the backend (bounded Agents SDK run) under the remaining ``DecisionBudget`` time, racing the
   budget's cancel event. Timeout/cancel -> the reservation stays counted as *unresolved*; the HTTP
   call is cancelled best effort and any late answer is discarded.
4. Reconcile usage (confirmed cost), validate the answer, and map ``candidate_index`` back to the
   real candidate. Invalid answers get ONE repair request with its own reservation.
5. Discard the result if the control epoch moved or the budget was cancelled meanwhile.

The returned :class:`ProposedAction` carries ``decision_observation_id`` and ``control_epoch`` so the
coordinator can discard it as well. Model output never sets a verdict or completes a run.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, Literal
from uuid import UUID

import yaml
from pydantic import Field

from mobilelab.budget import BudgetExceeded, BudgetLedger, RateCard, Reservation, TokenUsage, micro_to_usd
from mobilelab.budget.ledger import HARD_GLOBAL_CAP_USD, Purpose
from mobilelab.domain.base import FrozenModel, Identifier, utc_now
from mobilelab.domain.decisions import DecisionBudget, DecisionContext
from mobilelab.domain.errors import ProviderError
from mobilelab.domain.observations import CandidateAction, Observation
from mobilelab.domain.proposals import ProposedAction
from mobilelab.providers.base import ProviderInfo, build_proposal, check_inputs
from mobilelab.providers.errors import (
    InvalidProposal,
    ProviderCancelled,
    ProviderInputError,
    ProviderOutputInvalid,
    ProviderRequestRejected,
    ProviderStaleResult,
    ProviderTimeout,
    ProviderTransportError,
)
from mobilelab.providers.openai_backend import BackendError, BackendResult, PolicyBackend
from mobilelab.providers.policy_io import (
    SCHEMA_NAME,
    OutputValidationError,
    PolicyRequest,
    build_policy_request,
    parse_policy_output,
    repair_input,
    utf8_token_bound,
)

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[3] / "configs" / "providers" / "luna.yaml"
CANCEL_GRACE_S = 0.25
"""How long to wait for a cancelled HTTP task to unwind before abandoning it."""
ReasoningEffort = Literal["none", "low", "medium", "high", "xhigh", "max"]


class LunaConfig(FrozenModel):
    schema_version: Literal[1] = 1
    provider_id: Identifier = "luna"
    model: str = Field(min_length=1, max_length=256)
    api: Literal["agents_sdk_responses"] = "agents_sdk_responses"
    reasoning_effort: ReasoningEffort | None = "low"
    store: Literal[False] = False
    tracing_disabled: Literal[True] = True
    request_timeout_s: float = Field(default=20.0, gt=0, le=300)
    max_input_tokens: int = Field(default=8000, ge=512, le=200_000)
    max_output_tokens: int = Field(default=1500, ge=16, le=32_000)
    max_schema_repairs: int = Field(default=1, ge=0, le=1)
    run_cap_usd: float = Field(default=0.25, gt=0)
    global_cap_usd: float = Field(default=HARD_GLOBAL_CAP_USD, gt=0, le=HARD_GLOBAL_CAP_USD)
    max_elements: int = Field(default=60, ge=0, le=400)
    max_element_text: int = Field(default=160, ge=16, le=1000)
    send_images: Literal[False] = False
    reason_codes: list[str] = Field(min_length=1)
    rate_card: RateCard

    @property
    def frozen(self) -> dict[str, Any]:
        """The config as frozen into a run (JSON-safe; contains no secrets)."""
        return {**self.model_dump(mode="json"), "rate_card_id": self.rate_card.rate_card_id}


def load_luna_config(path: Path | str | None = None, **overrides: Any) -> LunaConfig:
    data = yaml.safe_load(Path(path or DEFAULT_CONFIG_PATH).read_text())
    data.update(overrides)
    cfg = LunaConfig.model_validate(data)
    if cfg.rate_card.model != cfg.model:
        raise ValueError("rate card model does not match the configured model")
    return cfg


# ---------------------------------------------------------------- evidence
class CallAttempt(FrozenModel):
    purpose: Purpose
    reservation_id: UUID | None = None
    ledger_status: Literal["confirmed", "unresolved", "released", "not_reserved"]
    reserved_usd: float = 0.0
    confirmed_usd: float | None = None
    input_token_bound: int
    max_output_tokens: int
    latency_ms: float | None = None
    request_id: str | None = Field(default=None, max_length=256)
    response_id: str | None = Field(default=None, max_length=256)
    input_tokens: int | None = None
    cached_input_tokens: int | None = None
    output_tokens: int | None = None
    reasoning_tokens: int | None = None
    error_class: str | None = Field(default=None, max_length=128)
    validation_problems: list[str] = Field(default_factory=list)


class ProviderCallEvidence(FrozenModel):
    """Redacted per-decision provider evidence: no key, no headers, prompts only as digests."""

    provider_id: str
    model_identifier: str
    run_id: UUID
    decision_observation_id: UUID
    control_epoch: int
    started_at: str
    outcome: Literal["accepted", "provider_error", "discarded_stale", "cancelled", "budget_refused"]
    error_class: str | None = None
    latency_ms: float
    retry_count: int
    attempts: list[CallAttempt]
    chosen_index: int | None = None
    chosen_semantic_key: str | None = None
    reason_code: str | None = None
    completion_hint: bool | None = None
    decision_id: UUID | None = None
    candidate_count: int
    elements_included: int
    elements_total: int
    prompt_sha256: str
    schema_sha256: str
    images_sent: bool = False
    reasoning_effort: str | None
    rate_card_id: str

    @property
    def confirmed_usd(self) -> float:
        return sum(a.confirmed_usd or 0.0 for a in self.attempts)

    @property
    def reserved_usd(self) -> float:
        return sum(a.reserved_usd for a in self.attempts)


# ---------------------------------------------------------------- provider
class LunaProvider:
    def __init__(
        self,
        config: LunaConfig,
        *,
        backend: PolicyBackend,
        ledger: BudgetLedger,
        epoch_probe: Callable[[], int] | None = None,
    ) -> None:
        if backend.model != config.model:
            raise ValueError("backend model does not match the configured model")
        self.config = config
        self.backend = backend
        self.ledger = ledger
        self.epoch_probe = epoch_probe
        self.provider_info = ProviderInfo(
            name="LunaProvider",
            kind="openai",
            version="1",
            model=config.model,
            deployment="cloud",
            supports_images=False,  # adapter is text-only by default; the model itself accepts images
            structured_output=True,
        )
        self.evidence: list[ProviderCallEvidence] = []

    @property
    def last_evidence(self) -> ProviderCallEvidence | None:
        return self.evidence[-1] if self.evidence else None

    # ------------------------------------------------------------ one bounded request
    async def _race(self, coro: Any, timeout_s: float, cancel_event: asyncio.Event | None) -> BackendResult:
        task = asyncio.ensure_future(coro)
        waiters: set[asyncio.Future[Any]] = {task}
        cancel_waiter = asyncio.ensure_future(cancel_event.wait()) if cancel_event is not None else None
        if cancel_waiter is not None:
            waiters.add(cancel_waiter)
        try:
            done, _ = await asyncio.wait(waiters, timeout=max(0.0, timeout_s), return_when=asyncio.FIRST_COMPLETED)
        except asyncio.CancelledError:
            task.cancel()
            raise
        finally:
            if cancel_waiter is not None:
                cancel_waiter.cancel()
        if task in done:
            return task.result()
        task.cancel()  # best effort; any late answer is discarded with the task
        await asyncio.wait({task}, timeout=CANCEL_GRACE_S)
        if not task.done():
            task.add_done_callback(_swallow)
        elif not task.cancelled():
            task.exception()  # retrieve so asyncio does not log it; the result is discarded
        if cancel_event is not None and cancel_event.is_set():
            raise ProviderCancelled("decision cancelled while the model request was in flight")
        raise ProviderTimeout("model request exceeded its time budget", details={"timeout_s": round(timeout_s, 3)})

    async def _attempt(
        self,
        *,
        purpose: Purpose,
        request: PolicyRequest,
        user_input: str,
        context: DecisionContext,
        observation: Observation,
        budget: DecisionBudget,
        deadline: float,
        attempts: list[CallAttempt],
    ) -> BackendResult:
        cfg = self.config
        bound = utf8_token_bound(request.instructions, user_input, _schema_text(request))
        max_in = min(cfg.max_input_tokens, budget.max_input_tokens)
        max_out = min(cfg.max_output_tokens, budget.max_output_tokens)
        if bound > max_in:
            raise ProviderInputError("prompt exceeds the input token budget", details={"bound": bound, "max": max_in})
        spent = sum(a.reserved_usd if a.ledger_status != "confirmed" else (a.confirmed_usd or 0.0) for a in attempts)
        reservation: Reservation = self.ledger.reserve(
            run_id=str(context.run_id),
            provider_id=cfg.provider_id,
            rate_card=cfg.rate_card,
            max_input_tokens=bound,
            max_output_tokens=max_out,
            purpose=purpose,
            correlation_id=str(observation.observation_id),
            max_cost_usd=max(0.0, budget.max_cost_usd - spent),
        )
        base = {"purpose": purpose, "reservation_id": reservation.reservation_id, "reserved_usd": reservation.reserved_usd,
                "input_token_bound": bound, "max_output_tokens": max_out}  # fmt: skip
        remaining = deadline - time.monotonic()
        timeout_s = min(cfg.request_timeout_s, remaining)
        started = time.perf_counter()
        try:
            if timeout_s <= 0:
                raise ProviderTimeout("decision time budget exhausted before the request")
            result = await self._race(
                self.backend.complete(
                    instructions=request.instructions,
                    user_input=user_input,
                    schema=request.schema,
                    schema_name=SCHEMA_NAME,
                    max_output_tokens=max_out,
                    timeout_s=timeout_s,
                ),
                timeout_s,
                budget.cancel_event,
            )
        except (ProviderTimeout, ProviderCancelled, asyncio.CancelledError) as exc:
            latency = (time.perf_counter() - started) * 1000.0
            if timeout_s <= 0:
                self.ledger.release(reservation, reason="not_sent_deadline")
                attempts.append(CallAttempt(**base, ledger_status="released", error_class="DeadlineBeforeSend"))
            else:
                self.ledger.mark_unresolved(reservation, error_class=type(exc).__name__)
                attempts.append(CallAttempt(**base, ledger_status="unresolved", latency_ms=latency,
                                            error_class=type(exc).__name__))  # fmt: skip
            raise
        except BackendError as exc:
            latency = (time.perf_counter() - started) * 1000.0
            fields = {**base, "latency_ms": latency, "request_id": exc.request_id, "error_class": exc.error_class}
            if exc.usage is not None:
                cost = self.ledger.confirm(reservation, exc.usage, cfg.rate_card, request_id=exc.request_id,
                                           error_class=exc.error_class)  # fmt: skip
                attempts.append(CallAttempt(**fields, ledger_status="confirmed", confirmed_usd=micro_to_usd(cost),
                                            **_usage_fields(exc.usage)))  # fmt: skip
            elif exc.billed is False:
                self.ledger.release(reservation, reason=f"rejected:{exc.status_code}")
                attempts.append(CallAttempt(**fields, ledger_status="released"))
            else:
                self.ledger.mark_unresolved(reservation, error_class=exc.error_class, request_id=exc.request_id)
                attempts.append(CallAttempt(**fields, ledger_status="unresolved"))
            details = {"error_class": exc.error_class, "status_code": exc.status_code, "request_id": exc.request_id}
            if exc.kind == "timeout":
                raise ProviderTimeout("model API request timed out", details=details) from None
            if exc.kind == "rejected":
                raise ProviderRequestRejected("model API rejected the request", details=details) from None
            if exc.kind == "output":
                raise ProviderOutputInvalid("model returned no usable structured output", details=details) from None
            raise ProviderTransportError("model API transport failure", details=details) from None
        if result.usage is not None:
            cost = self.ledger.confirm(reservation, result.usage, cfg.rate_card, request_id=result.request_id)
            attempts.append(CallAttempt(**base, ledger_status="confirmed", confirmed_usd=micro_to_usd(cost),
                                        latency_ms=result.latency_ms, request_id=result.request_id,
                                        response_id=result.response_id, **_usage_fields(result.usage)))  # fmt: skip
        else:  # answered but usage unknown: keep the full reservation counted
            self.ledger.mark_unresolved(reservation, error_class="UsageNotReported", request_id=result.request_id)
            attempts.append(CallAttempt(**base, ledger_status="unresolved", latency_ms=result.latency_ms,
                                        request_id=result.request_id, response_id=result.response_id,
                                        error_class="UsageNotReported"))  # fmt: skip
        return result

    def _check_still_current(self, context: DecisionContext, budget: DecisionBudget) -> None:
        if budget.cancelled:
            raise ProviderCancelled("decision cancelled; late model result discarded")
        if self.epoch_probe is not None:
            current = self.epoch_probe()
            if current != context.control_epoch:
                raise ProviderStaleResult(
                    "control epoch changed while the model was deciding; result discarded",
                    details={"request_epoch": context.control_epoch, "current_epoch": current},
                )

    # ------------------------------------------------------------ contract
    async def decide(
        self,
        context: DecisionContext,
        observation: Observation,
        candidates: list[CandidateAction],
        budget: DecisionBudget,
    ) -> ProposedAction:
        check_inputs(observation, candidates, budget)
        if not candidates:
            raise ProviderInputError("no candidates supplied")
        cfg = self.config
        started_at = utc_now()
        t0 = time.monotonic()
        deadline = t0 + budget.timeout_ms / 1000.0
        try:
            request = build_policy_request(
                context, observation, candidates,
                reason_codes=cfg.reason_codes,
                max_elements=cfg.max_elements,
                text_limit=cfg.max_element_text,
                max_input_tokens=min(cfg.max_input_tokens, budget.max_input_tokens),
            )  # fmt: skip
        except OverflowError as exc:
            raise ProviderInputError("observation summary cannot fit the input token budget",
                                     details={"error": str(exc)}) from None  # fmt: skip

        attempts: list[CallAttempt] = []
        outcome: str = "provider_error"
        error_class: str | None = None
        chosen = None
        proposal: ProposedAction | None = None
        try:
            user_input = request.user_input
            purpose: Purpose = "decision"
            for round_no in range(1 + cfg.max_schema_repairs):
                result = await self._attempt(purpose=purpose, request=request, user_input=user_input, context=context,
                                             observation=observation, budget=budget, deadline=deadline,
                                             attempts=attempts)  # fmt: skip
                self._check_still_current(context, budget)
                try:
                    chosen = parse_policy_output(result.output_text, request)
                    proposal = build_proposal(
                        context, observation, chosen.candidate, chosen.parameters,
                        reason_code=chosen.reason_code, completion=chosen.completion,
                        explanation=f"luna model={cfg.model} index={chosen.index} repairs={round_no}",
                    )  # fmt: skip
                    break
                except (OutputValidationError, InvalidProposal) as exc:
                    problems = exc.problems if isinstance(exc, OutputValidationError) else [
                        f"parameters rejected by candidate policy: {exc.details.get('error', exc.message)}"]
                    attempts[-1] = attempts[-1].model_copy(update={"validation_problems": problems[:8]})
                    chosen, proposal = None, None
                    if round_no >= cfg.max_schema_repairs:
                        raise ProviderOutputInvalid(
                            "model output failed validation after the bounded repair",
                            details={"problems": problems[:8], "repairs": round_no},
                        ) from None
                    user_input = repair_input(request, problems)
                    purpose = "repair"
            assert proposal is not None and chosen is not None
            outcome = "accepted"
            return proposal
        except BudgetExceeded as exc:
            outcome, error_class = "budget_refused", type(exc).__name__
            raise
        except ProviderStaleResult as exc:
            outcome, error_class = "discarded_stale", type(exc).__name__
            raise
        except (ProviderCancelled, asyncio.CancelledError) as exc:
            outcome, error_class = "cancelled", type(exc).__name__
            raise
        except ProviderError as exc:
            error_class = type(exc).__name__
            raise
        finally:
            self.evidence.append(
                ProviderCallEvidence(
                    provider_id=cfg.provider_id,
                    model_identifier=cfg.model,
                    run_id=context.run_id,
                    decision_observation_id=observation.observation_id,
                    control_epoch=context.control_epoch,
                    started_at=started_at.isoformat(),
                    outcome=outcome,  # type: ignore[arg-type]
                    error_class=error_class,
                    latency_ms=(time.monotonic() - t0) * 1000.0,
                    retry_count=max(0, len(attempts) - 1),
                    attempts=attempts,
                    chosen_index=chosen.index if chosen and proposal else None,
                    chosen_semantic_key=chosen.candidate.semantic_key if chosen and proposal else None,
                    reason_code=chosen.reason_code if chosen and proposal else None,
                    completion_hint=chosen.completion if chosen and proposal else None,
                    decision_id=proposal.decision_id if proposal else None,
                    candidate_count=len(candidates),
                    elements_included=request.elements_included,
                    elements_total=request.elements_total,
                    prompt_sha256=request.prompt_sha256,
                    schema_sha256=request.schema_sha256,
                    images_sent=False,
                    reasoning_effort=cfg.reasoning_effort,
                    rate_card_id=cfg.rate_card.rate_card_id,
                )
            )


def _swallow(task: asyncio.Future[Any]) -> None:
    if not task.cancelled():
        task.exception()


def _usage_fields(usage: TokenUsage) -> dict[str, int]:
    return {
        "input_tokens": usage.input_tokens,
        "cached_input_tokens": usage.cached_input_tokens,
        "output_tokens": usage.output_tokens,
        "reasoning_tokens": usage.reasoning_tokens,
    }


def _schema_text(request: PolicyRequest) -> str:
    import json

    return json.dumps(request.schema, separators=(",", ":"))


__all__ = [
    "DEFAULT_CONFIG_PATH",
    "CallAttempt",
    "LunaConfig",
    "LunaProvider",
    "ProviderCallEvidence",
    "load_luna_config",
]

"""Fixture message receipt oracle (CONTRACTS §6, §9, §12; ACCEPTANCE AC-02, AC-06).

Verdict rules (M1):

* ``PASS`` only when the fixture server reports a receiver-delivered timestamp recorded by the
  authenticated scripted receiver (and, if required, a displayed timestamp). A sender-side "Sent"
  UI state or server acceptance alone is never a pass.
* Accepted but not acknowledged by the deadline -> ``INCONCLUSIVE`` / ``DELIVERY_UNCONFIRMED``.
* No receipt by the deadline -> ``INCONCLUSIVE`` / ``NO_RECEIPT`` (lack of a receipt is not proof
  of non-delivery), unless the caller supplies observation evidence proving the send was never
  executed -> ``HARNESS_FAILURE`` / ``SEND_NOT_EXECUTED`` (the acting harness did not perform the
  step; no DUT expectation was exercised).
* Fixture unreachable at the deadline, or malformed fixture responses -> ``ENVIRONMENT_FAILURE``.
* Oracle credentials rejected, invalid oracle definition or any unexpected exception ->
  ``HARNESS_FAILURE``.
* ``DUT_FAILURE`` is never produced: M1 defines no trustworthy expectation whose violation this
  oracle can attribute to the device under test.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from uuid import UUID, uuid4

from pydantic import JsonValue

from mobilelab.domain.base import FrozenModel, UtcDatetime
from mobilelab.domain.enums import ActionStatus, EvidenceCategory, Verdict
from mobilelab.domain.scenarios import OracleDefinition, OracleResult
from mobilelab.fixtures.models import MessageStatus, Receipt, ReceiverType, ack_timings
from mobilelab.oracles.polling import PollError, PollOutcome, PollSettings, ReceiptSource, poll_receipt

ORACLE_KIND = "fixture_message_receipt"
REQUIREMENT_REFS: tuple[str, ...] = ("BR-07", "AC-02")
SUPPORTED_REQUIRED_STATUSES = frozenset({MessageStatus.DELIVERED.value, MessageStatus.DISPLAYED.value})


class OracleWindow(FrozenModel):
    """Start of the observation window (e.g. the send action's ``actual_dispatch_at``).

    The polling deadline itself is ``definition.timeout_seconds`` measured on this process's
    monotonic clock from the start of evaluation.
    """

    start: UtcDatetime


def receipt_evidence_id(client_message_id: UUID) -> str:
    return f"fixture-receipt:{client_message_id}"


def receipt_json(receipt: Receipt) -> dict[str, JsonValue]:
    data: dict[str, JsonValue] = receipt.model_dump(mode="json")
    return data


def _receiver_confirmed(receipt: Receipt, required_status: str) -> bool:
    if receipt.receiver_type is not ReceiverType.SCRIPTED_RECEIVER or receipt.receiver_delivered_at is None:
        return False
    if required_status == MessageStatus.DISPLAYED.value:
        return receipt.receiver_displayed_at is not None
    return True


class FixtureMessageReceiptOracle:
    kind = ORACLE_KIND

    def __init__(self, oracle_client: ReceiptSource, *, settings: PollSettings | None = None) -> None:
        self._client = oracle_client
        self._settings = settings or PollSettings()

    async def evaluate(
        self,
        run_id: UUID,
        client_message_id: UUID,
        definition: OracleDefinition,
        window: OracleWindow | None = None,
        *,
        scenario_id: str,
        action_status: ActionStatus | None = None,
        evidence_ids: Sequence[str] = (),
        non_execution_evidence_ids: Sequence[str] = (),
    ) -> OracleResult:
        """Evaluate one send. Never raises for oracle/fixture problems: they become verdicts."""
        started = self._settings.now()
        window_start = window.start if window is not None and window.start <= started else started
        base_evidence = list(dict.fromkeys(evidence_ids))
        required = definition.required_status or MessageStatus.DELIVERED.value
        expected: dict[str, JsonValue] = {
            "client_message_id": str(client_message_id),
            "required_status": required,
            "receiver_type": ReceiverType.SCRIPTED_RECEIVER.value,
            "timeout_seconds": definition.timeout_seconds,
            "evidence": list(definition.evidence),
        }

        def result(
            verdict: Verdict,
            reason: str,
            observed: dict[str, JsonValue],
            *,
            extra_evidence: Sequence[str] = (),
            obtained: EvidenceCategory | None = None,
        ) -> OracleResult:
            end = self._settings.now()
            return OracleResult(
                oracle_result_id=uuid4(),
                run_id=run_id,
                scenario_id=scenario_id,
                oracle_kind=ORACLE_KIND,
                verdict=verdict,
                reason_code=reason,
                expected=expected,
                observed={**observed, "action_status": action_status.value if action_status else None},
                evidence_ids=list(dict.fromkeys([*base_evidence, *extra_evidence])),
                obtained_evidence=obtained,
                observation_window_start=window_start,
                observation_window_end=max(end, window_start),
                requirement_refs=list(REQUIREMENT_REFS),
            )

        if definition.kind != ORACLE_KIND or required not in SUPPORTED_REQUIRED_STATUSES:
            return result(
                Verdict.HARNESS_FAILURE,
                "ORACLE_DEFINITION_INVALID",
                {"detail": f"unsupported oracle definition kind={definition.kind} required_status={required}"},
            )
        try:
            outcome = await poll_receipt(
                self._client,
                run_id=run_id,
                client_message_id=client_message_id,
                deadline_s=definition.timeout_seconds,
                satisfied=lambda r: _receiver_confirmed(r, required),
                settings=self._settings,
            )
            return self._classify(outcome, required, client_message_id, non_execution_evidence_ids, result)
        except Exception as exc:  # noqa: BLE001 - oracle exceptions are harness failures (§9)
            return result(Verdict.HARNESS_FAILURE, "ORACLE_EXCEPTION", {"error": f"{type(exc).__name__}: {exc}"[:500]})

    @staticmethod
    def _classify(
        outcome: PollOutcome,
        required: str,
        client_message_id: UUID,
        non_execution_evidence_ids: Sequence[str],
        result: Callable[..., OracleResult],
    ) -> OracleResult:
        receipt = outcome.receipt
        observed: dict[str, JsonValue] = {
            "receipt": receipt_json(receipt) if receipt else None,
            "ack_timings": [t.model_dump(mode="json") for t in ack_timings(receipt)] if receipt else [],
            "polls": outcome.polls,
            "poll_started_at": outcome.started_at.isoformat(),
            "poll_ended_at": outcome.ended_at.isoformat(),
            "last_error": outcome.last_error.value if outcome.last_error else None,
            "errors": list(outcome.errors),
        }
        receipt_evidence: list[str] = (
            [receipt_evidence_id(client_message_id), *receipt.correlation_evidence_ids] if receipt else []
        )
        fixture = EvidenceCategory.FIXTURE if receipt else None

        if outcome.satisfied:
            return result(Verdict.PASS, "RECEIPT_DELIVERED", observed, extra_evidence=receipt_evidence, obtained=fixture)
        match outcome.last_error:
            case PollError.AUTH:
                return result(Verdict.HARNESS_FAILURE, "ORACLE_AUTH_FAILED", observed, extra_evidence=receipt_evidence)
            case PollError.EXCEPTION:
                return result(Verdict.HARNESS_FAILURE, "ORACLE_EXCEPTION", observed, extra_evidence=receipt_evidence)
            case PollError.PROTOCOL:
                return result(
                    Verdict.ENVIRONMENT_FAILURE, "FIXTURE_PROTOCOL_ERROR", observed, extra_evidence=receipt_evidence
                )
            case PollError.UNAVAILABLE:
                return result(
                    Verdict.ENVIRONMENT_FAILURE, "FIXTURE_UNAVAILABLE", observed, extra_evidence=receipt_evidence
                )
            case None:
                pass
        if receipt is not None:
            reason = (
                "DISPLAY_UNCONFIRMED"
                if required == MessageStatus.DISPLAYED.value and receipt.receiver_delivered_at is not None
                else "DELIVERY_UNCONFIRMED"
            )
            return result(Verdict.INCONCLUSIVE, reason, observed, extra_evidence=receipt_evidence, obtained=fixture)
        if non_execution_evidence_ids:
            observed["non_execution_evidence_ids"] = list(non_execution_evidence_ids)
            return result(
                Verdict.HARNESS_FAILURE, "SEND_NOT_EXECUTED", observed, extra_evidence=list(non_execution_evidence_ids)
            )
        return result(Verdict.INCONCLUSIVE, "NO_RECEIPT", observed)

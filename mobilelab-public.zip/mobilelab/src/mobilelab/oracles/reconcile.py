"""Reconciliation of potentially executed fixture sends (CONTRACTS §6, §11; ACCEPTANCE AC-06).

A send whose outcome is uncertain (DISPATCHED after a restart, ACKNOWLEDGED, or UNKNOWN) is
reconciled by querying the fixture receipt for its ``client_message_id``. This module is read-only
and never resends: ``resend_permitted`` is always False.

* Receipt exists (accepted or later) -> ``VERIFIED``: the send was executed. Delivery is assessed
  separately by the receipt oracle.
* Server authoritatively has no receipt by the deadline *and* the caller supplies observation
  evidence proving non-execution -> ``FAILED``.
* Otherwise -> ``UNRESOLVED`` (the run reports an INCONCLUSIVE result; lack of a receipt is not
  proof of non-delivery, and an outage is not proof of anything).
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Literal
from uuid import UUID

from pydantic import Field, JsonValue

from mobilelab.domain.base import FrozenModel, UtcDatetime
from mobilelab.domain.dispatch import ActionRecord
from mobilelab.domain.enums import ActionKind, ActionStatus
from mobilelab.oracles.polling import PollError, PollSettings, ReceiptSource, poll_receipt
from mobilelab.oracles.receipt import receipt_evidence_id, receipt_json

Resolution = Literal["VERIFIED", "FAILED", "UNRESOLVED"]

RECONCILABLE_STATUSES = frozenset({ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED, ActionStatus.UNKNOWN})


class SendReconciliation(FrozenModel):
    action_id: UUID
    run_id: UUID
    client_message_id: UUID
    from_status: ActionStatus
    resolution: Resolution
    reason_code: str = Field(pattern=r"^[A-Z][A-Z0-9_]*$")
    transition_path: list[ActionStatus]
    """Valid action-status steps from ``from_status`` to the resolution (CONTRACTS §6 graph)."""
    receipt: dict[str, JsonValue] | None = None
    evidence_ids: list[str] = Field(default_factory=list)
    polls: int = Field(ge=0)
    errors: list[str] = Field(default_factory=list)
    started_at: UtcDatetime
    ended_at: UtcDatetime
    resend_permitted: Literal[False] = False


def transition_path(from_status: ActionStatus, resolution: Resolution) -> list[ActionStatus]:
    target = ActionStatus(resolution)
    if from_status is ActionStatus.UNKNOWN:
        return [target]
    if from_status is ActionStatus.ACKNOWLEDGED and target is not ActionStatus.UNRESOLVED:
        return [target]
    if from_status in (ActionStatus.DISPATCHED, ActionStatus.ACKNOWLEDGED):
        return [ActionStatus.UNKNOWN, target]
    raise ValueError(f"action status {from_status} is not reconcilable")


async def reconcile_unknown_send(
    source: ReceiptSource,
    action: ActionRecord,
    *,
    deadline_s: float,
    non_execution_evidence_ids: Sequence[str] = (),
    settings: PollSettings | None = None,
) -> SendReconciliation:
    """Query the receipt for ``action.correlation_id`` until found or ``deadline_s`` elapses."""
    if action.kind is not ActionKind.SEND_MESSAGE or action.correlation_id is None:
        raise ValueError("only send_message actions with a client_message_id can be reconciled by receipt")
    if action.status not in RECONCILABLE_STATUSES:
        raise ValueError(f"action status {action.status} is not potentially executed")
    cmid = action.correlation_id
    outcome = await poll_receipt(
        source,
        run_id=action.run_id,
        client_message_id=cmid,
        deadline_s=deadline_s,
        satisfied=lambda _receipt: True,
        settings=settings or PollSettings(),
    )
    evidence: list[str] = []
    resolution: Resolution
    if outcome.receipt is not None:
        resolution, reason = "VERIFIED", f"RECEIPT_{outcome.receipt.status.value.upper()}"
        evidence = [receipt_evidence_id(cmid), *outcome.receipt.correlation_evidence_ids]
    elif outcome.last_error is None and non_execution_evidence_ids:
        resolution, reason = "FAILED", "NON_EXECUTION_OBSERVED"
        evidence = list(non_execution_evidence_ids)
    else:
        resolution = "UNRESOLVED"
        reason = {
            None: "NO_RECEIPT",
            PollError.UNAVAILABLE: "FIXTURE_UNAVAILABLE",
            PollError.AUTH: "ORACLE_AUTH_FAILED",
            PollError.PROTOCOL: "FIXTURE_PROTOCOL_ERROR",
            PollError.EXCEPTION: "RECONCILIATION_ERROR",
        }[outcome.last_error]
    return SendReconciliation(
        action_id=action.action_id,
        run_id=action.run_id,
        client_message_id=cmid,
        from_status=action.status,
        resolution=resolution,
        reason_code=reason,
        transition_path=transition_path(action.status, resolution),
        receipt=receipt_json(outcome.receipt) if outcome.receipt else None,
        evidence_ids=evidence,
        polls=outcome.polls,
        errors=outcome.errors,
        started_at=outcome.started_at,
        ended_at=outcome.ended_at,
    )

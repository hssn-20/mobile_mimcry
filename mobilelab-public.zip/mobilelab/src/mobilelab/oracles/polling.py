"""Bounded receipt polling shared by the receipt oracle and unknown-send reconciliation.

Read-only: polling only queries ``GET /fixture/v1/receipts/{client_message_id}``. It never sends,
retries or otherwise causes a message (CONTRACTS §6: no blind side-effect retry).
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Protocol
from uuid import UUID

from mobilelab.domain.base import utc_now
from mobilelab.fixtures.clients import FixtureAuthError, FixtureProtocolError, FixtureUnavailableError
from mobilelab.fixtures.models import Receipt

Monotonic = Callable[[], float]
Sleep = Callable[[float], Awaitable[None]]
WallClock = Callable[[], datetime]


class ReceiptSource(Protocol):
    """What the oracle needs from ``FixtureOracleClient`` (read-only receipt lookup)."""

    async def get_receipt(self, client_message_id: UUID, run_id: UUID) -> Receipt | None: ...


class PollError(StrEnum):
    UNAVAILABLE = "unavailable"  # transport failure / timeout / 5xx: transient, keep polling
    AUTH = "auth"  # 401/403: credentials wrong or expired; terminal
    PROTOCOL = "protocol"  # malformed fixture response; terminal
    EXCEPTION = "exception"  # anything else (oracle/harness bug); terminal


@dataclass(slots=True)
class PollOutcome:
    started_at: datetime
    ended_at: datetime
    polls: int = 0
    receipt: Receipt | None = None
    """The most recent receipt seen (None if the server never had one)."""
    satisfied: bool = False
    last_error: PollError | None = None
    """Error of the final poll (None if the final poll got an authoritative answer)."""
    error_detail: str | None = None
    terminal: bool = False
    """Polling stopped early on a non-transient error."""
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class PollSettings:
    poll_interval_s: float = 0.5
    monotonic: Monotonic = time.monotonic
    sleep: Sleep = asyncio.sleep
    now: WallClock = utc_now


async def poll_receipt(
    source: ReceiptSource,
    *,
    run_id: UUID,
    client_message_id: UUID,
    deadline_s: float,
    satisfied: Callable[[Receipt], bool],
    settings: PollSettings,
) -> PollOutcome:
    """Poll until ``satisfied(receipt)``, a terminal error, or the deadline (monotonic clock).

    Always polls at least once and once more at/after the deadline, so a receipt that arrives
    just before the deadline is not missed.
    """
    out = PollOutcome(started_at=settings.now(), ended_at=settings.now())
    deadline = settings.monotonic() + max(deadline_s, 0.0)
    while True:
        out.polls += 1
        try:
            receipt = await source.get_receipt(client_message_id, run_id)
        except FixtureUnavailableError as exc:
            _error(out, PollError.UNAVAILABLE, exc)
        except FixtureAuthError as exc:
            _error(out, PollError.AUTH, exc, terminal=True)
        except FixtureProtocolError as exc:
            _error(out, PollError.PROTOCOL, exc, terminal=True)
        except Exception as exc:  # noqa: BLE001 - classified as an oracle/harness failure by callers
            _error(out, PollError.EXCEPTION, exc, terminal=True)
        else:
            out.last_error = None
            out.error_detail = None
            if receipt is not None:
                if receipt.client_message_id != client_message_id or receipt.run_id != run_id:
                    _error(out, PollError.PROTOCOL, ValueError("receipt identity does not match the query"), terminal=True)
                else:
                    out.receipt = receipt
                    if satisfied(receipt):
                        out.satisfied = True
        if out.satisfied or out.terminal:
            break
        remaining = deadline - settings.monotonic()
        if remaining <= 0:
            break
        await settings.sleep(min(settings.poll_interval_s, remaining))
    out.ended_at = settings.now()
    return out


def _error(out: PollOutcome, kind: PollError, exc: BaseException, *, terminal: bool = False) -> None:
    detail = f"{type(exc).__name__}: {exc}"[:500]
    out.last_error = kind
    out.error_detail = detail
    out.terminal = terminal
    if len(out.errors) < 20:
        out.errors.append(f"{kind.value}: {detail}")

"""Milestone readiness gates derived from individual checks.

Strict preflight: anything not ``ready`` (including ``unknown``) blocks a gate.
"""

from __future__ import annotations

from dataclasses import dataclass

from mobilelab.doctor.models import CheckResult, CheckStatus, GateResult, GateStatus


@dataclass(frozen=True, slots=True)
class GateSpec:
    id: str
    title: str
    required_checks: tuple[str, ...]


_CORE = ("python", "uv", "port_8781", "port_8782")
_XCODE = ("macos_version", "host_memory", "host_disk", "xcode_select", "xcode_full", "xcode_license",
          "xcode_first_launch", "simctl", "ios_runtime", "swift")

GATES: tuple[GateSpec, ...] = (
    GateSpec("m1_core", "M1 fixture/coordinator core (no device)", _CORE),
    GateSpec("m1_ios_simulator", "M1 iOS Simulator slice",
             (*_CORE, *_XCODE, "node", "npm", "appium", "appium_driver_xcuitest", "port_4723")),
    GateSpec("physical_iphone_smoke", "Later: physical iPhone fixture-only smoke (O-05)",
             (*_XCODE, "node", "npm", "appium", "appium_driver_xcuitest", "physical_devices",
              "signing_identities")),
)


def evaluate_gates(checks: list[CheckResult], gates: tuple[GateSpec, ...] = GATES) -> list[GateResult]:
    by_id = {check.id: check for check in checks}
    results: list[GateResult] = []
    for gate in gates:
        blockers = [cid for cid in gate.required_checks
                    if cid not in by_id or by_id[cid].status is not CheckStatus.READY]
        if not blockers:
            summary = f"{gate.title}: READY"
            status = GateStatus.READY
        else:
            parts = [f"{by_id[cid].title} [{by_id[cid].status}]" if cid in by_id else f"{cid} [not run]"
                     for cid in blockers]
            summary = f"{gate.title}: BLOCKED by " + "; ".join(parts)
            status = GateStatus.BLOCKED
        results.append(GateResult(id=gate.id, title=gate.title, status=status, blocked_by=blockers,
                                  summary=summary))
    return results

"""Read-only physical device inventory and signing-identity presence.

Never pairs, trusts, installs helpers, or records personal device names,
serial numbers or certificate subjects; only counts and generic product names.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from mobilelab.doctor.context import DoctorContext, first_line
from mobilelab.doctor.models import CheckResult, CheckStatus

_IOS_PRODUCTS = ("iphone", "ipad")
_IDENTITIES_RE = re.compile(r"(\d+)\s+valid identit")
_REACHABLE_TUNNEL_STATES = frozenset({"connected", "disconnected"})
# '--json-output -' writes the JSON document to stdout (no file is created).
DEVICECTL_ARGV = ("xcrun", "devicectl", "list", "devices", "--json-output", "-")


def _walk_usb(items: Any, found: list[str]) -> None:
    if isinstance(items, list):
        for item in items:
            _walk_usb(item, found)
    elif isinstance(items, dict):
        name = str(items.get("_name", ""))
        if any(product in name.lower() for product in _IOS_PRODUCTS):
            found.append("iPad" if "ipad" in name.lower() else "iPhone")
        for value in items.values():
            if isinstance(value, list):
                _walk_usb(value, found)


def _usb_inventory(ctx: DoctorContext) -> tuple[list[str] | None, str]:
    found: list[str] = []
    ran = False
    for data_type in ("SPUSBHostDataType", "SPUSBDataType"):
        res = ctx.run(["system_profiler", data_type, "-json"], timeout=30.0)
        if not res.ok:
            continue
        try:
            data = json.loads(res.stdout)
        except json.JSONDecodeError:
            continue
        ran = True
        _walk_usb(data, found)
        if found:
            break
    return (found if ran else None), "system_profiler (USB, read-only)"


@dataclass(frozen=True, slots=True)
class Inventory:
    """Generic product names of reachable iOS devices plus counts of what was excluded."""

    connected: list[str]
    method: str
    offline_ios: int = 0
    other_devices: int = 0


def _product(device: dict[str, Any]) -> str | None:
    """'iPhone' / 'iPad' for iOS devices, None for Watch, TV, Mac, Vision etc."""
    hw = device.get("hardwareProperties") or {}
    kind = str(hw.get("deviceType") or "").lower()
    if "iphone" in kind:
        return "iPhone"
    if "ipad" in kind:
        return "iPad"
    if not kind and str(hw.get("platform") or "").lower() == "ios":
        return "iOS device"
    return None


def _reachable(device: dict[str, Any]) -> bool:
    """CoreDevice tunnelState: 'connected'/'disconnected' = reachable now, 'unavailable' = paired but offline."""
    conn = device.get("connectionProperties") or {}
    return str(conn.get("tunnelState") or "").lower() in _REACHABLE_TUNNEL_STATES


def _devicectl_inventory(ctx: DoctorContext) -> Inventory | None:
    res = ctx.run(list(DEVICECTL_ARGV), env=ctx.xcode.probe_env, timeout=30.0)
    if not res.ok:
        return None
    try:
        data = json.loads(res.stdout)
    except json.JSONDecodeError:
        return None
    devices = ((data.get("result") or {}).get("devices") if isinstance(data, dict) else None)
    if not isinstance(devices, list):
        return None
    connected: list[str] = []
    offline = other = 0
    for device in devices:
        if not isinstance(device, dict):
            continue
        product = _product(device)
        if product is None:
            other += 1
        elif _reachable(device):
            connected.append(product)
        else:
            offline += 1
    return Inventory(connected, "xcrun devicectl list devices --json-output - (read-only)", offline, other)


def _excluded_note(inv: Inventory) -> str:
    parts = []
    if inv.offline_ios:
        parts.append(f"{inv.offline_ios} paired iOS device(s) offline")
    if inv.other_devices:
        parts.append(f"{inv.other_devices} non-iOS device(s) ignored")
    return f" ({'; '.join(parts)})" if parts else ""


def check_physical_devices(ctx: DoctorContext) -> CheckResult:
    inv = _devicectl_inventory(ctx) if ctx.xcode.usable else None
    if inv is None:
        found, method = _usb_inventory(ctx)
        inv = Inventory(found, method) if found is not None else None
    title, required = "Physical iOS devices (inventory only)", "optional for M1"
    if inv is None:
        return CheckResult(id="physical_devices", category="devices", title=title, status=CheckStatus.UNKNOWN,
                           observed="inventory failed", required=required,
                           remedy="Physical inventory is optional; nothing was installed or paired.")
    details = {"method": inv.method, "devices": inv.connected, "offline_ios": inv.offline_ios,
               "other_devices": inv.other_devices, "redacted": "names, serials and UDIDs not recorded"}
    if not inv.connected:
        return CheckResult(id="physical_devices", category="devices", title=title, status=CheckStatus.MISSING,
                           observed=f"none connected{_excluded_note(inv)}", required=required, details=details,
                           remedy=("Optional. The everyday iPhone stays inventory-only (D-06/D-14); "
                                   "dedicated handsets and signing are outstanding decision O-05."))
    return CheckResult(id="physical_devices", category="devices", title=title, status=CheckStatus.READY,
                       observed=f"{len(inv.connected)} connected: {', '.join(inv.connected)}{_excluded_note(inv)}",
                       required=required, details=details,
                       remedy="Inventory only: automation stays disabled until signing/WDA provisioning succeeds.")


def check_signing(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["security", "find-identity", "-v", "-p", "codesigning"])
    title, required = "Code-signing identities (physical devices only)", ">=1 for physical-device WDA"
    match = _IDENTITIES_RE.search(res.output) if res.returncode is not None else None
    if match is None:
        return CheckResult(id="signing_identities", category="devices", title=title, status=CheckStatus.UNKNOWN,
                           observed=res.error or first_line(res.output), required=required,
                           remedy="Could not query the keychain read-only; check Xcode > Settings > Accounts.")
    count = int(match.group(1))
    if count == 0:
        return CheckResult(id="signing_identities", category="devices", title=title,
                           status=CheckStatus.MISSING, observed="0 valid identities", required=required,
                           manual_action_required=True,
                           remedy=("Not needed for the Simulator. For physical devices a developer team must be "
                                   "configured manually in Xcode (D-04/O-05); mobilelab never alters signing."))
    return CheckResult(id="signing_identities", category="devices", title=title, status=CheckStatus.READY,
                       observed=f"{count} valid identities (subjects not recorded)", required=required)


def device_checks(ctx: DoctorContext) -> list[CheckResult]:
    return [check_physical_devices(ctx), check_signing(ctx)]

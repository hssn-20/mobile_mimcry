"""Xcode, licence, Simulator runtime, Swift and XcodeGen checks.

Nothing here changes system state: the active developer directory is never
switched (a candidate bundle is probed with a per-process DEVELOPER_DIR), the
licence is never accepted and runtimes are never downloaded.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mobilelab.doctor import requirements as req
from mobilelab.doctor.context import (
    DoctorContext,
    at_least,
    first_line,
    mentions_license,
    parse_version,
    version_str,
)
from mobilelab.doctor.models import CheckResult, CheckStatus

LICENSE_REMEDY = (
    "Requires manual completion: run `sudo xcodebuild -license` in Terminal, read and accept it "
    "yourself. mobilelab never accepts licences."
)
INSTALL_XCODE_REMEDY = (
    "Install full Xcode (manual, large download) from the Mac App Store or developer.apple.com, "
    "then re-run `mobilelab doctor`. Command Line Tools alone cannot run Simulators or XCUITest."
)


def _bundle_of(developer_path: str) -> str | None:
    marker = ".app/Contents/Developer"
    idx = developer_path.find(marker)
    return developer_path[: idx + len(".app")] if idx >= 0 else None


def _bundle_version(ctx: DoctorContext, bundle: Path) -> tuple[int, ...] | None:
    for name in ("version.plist", "Info.plist"):
        plist = ctx.host.read_plist(bundle / "Contents" / name)
        if plist and isinstance(plist.get("CFBundleShortVersionString"), str):
            return parse_version(plist["CFBundleShortVersionString"])
    return None


def check_xcode_select(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["xcode-select", "-p"])
    path = res.stdout.strip() if res.ok else None
    state = ctx.xcode
    state.selected_path = path
    bundle = _bundle_of(path) if path else None
    state.selected_is_full_xcode = bundle is not None
    if bundle:
        state.bundle_path = bundle
        state.developer_dir = path
    else:
        candidates = ctx.host.xcode_bundles()
        preferred = [c for c in candidates if c.name == "Xcode.app"] or sorted(
            candidates, key=lambda c: _bundle_version(ctx, c) or (0,), reverse=True
        )
        if preferred:
            state.bundle_path = str(preferred[0])
            state.developer_dir = str(preferred[0] / "Contents" / "Developer")
    required = "a full Xcode.app/Contents/Developer"
    if path is None:
        return CheckResult(id="xcode_select", category="xcode", title="Active developer directory",
                           status=CheckStatus.MISSING, observed=res.error or first_line(res.output),
                           required=required, remedy=INSTALL_XCODE_REMEDY)
    if bundle:
        return CheckResult(id="xcode_select", category="xcode", title="Active developer directory",
                           status=CheckStatus.READY, observed=path, required=required)
    if state.bundle_path:
        remedy = (
            f"Active developer directory is Command Line Tools although {state.bundle_path} exists. "
            f"Requires manual completion: `sudo xcode-select -s {state.developer_dir}` "
            f"(or export DEVELOPER_DIR={state.developer_dir} for mobilelab/Appium processes). "
            "doctor probes the bundle via DEVELOPER_DIR and never switches it."
        )
        return CheckResult(id="xcode_select", category="xcode", title="Active developer directory",
                           status=CheckStatus.INCOMPATIBLE, observed=path, required=required,
                           remedy=remedy, manual_action_required=True,
                           details={"candidate_bundle": state.bundle_path})
    return CheckResult(id="xcode_select", category="xcode", title="Active developer directory",
                       status=CheckStatus.MISSING, observed=f"{path} (Command Line Tools only)",
                       required=required, remedy=INSTALL_XCODE_REMEDY, manual_action_required=True)


def check_xcode_full(ctx: DoctorContext) -> CheckResult:
    state = ctx.xcode
    if not state.bundle_path:
        return CheckResult(id="xcode_full", category="xcode", title="Full Xcode installed",
                           status=CheckStatus.MISSING, observed="Command Line Tools only",
                           required=req.XCODE_REQUIRED, remedy=INSTALL_XCODE_REMEDY,
                           manual_action_required=True)
    plist_version = _bundle_version(ctx, Path(state.bundle_path))
    res = ctx.run(["xcodebuild", "-version"], env=state.probe_env)
    version = parse_version(res.stdout) if res.ok else plist_version
    state.version = version
    details: dict[str, Any] = {"bundle": state.bundle_path, "bundle_version": version_str(plist_version),
                               "xcodebuild_output": res.output[:400], "probe_env": state.probe_env}
    if not res.ok and not mentions_license(res):
        return CheckResult(id="xcode_full", category="xcode", title="Full Xcode installed",
                           status=CheckStatus.UNKNOWN, observed=version_str(version),
                           required=req.XCODE_REQUIRED, details=details,
                           remedy=("`xcodebuild -version` failed for the bundle; the installation may be "
                                   "incomplete (e.g. still downloading). Finish installing Xcode and re-run."))
    if not at_least(version, req.XCODE_MIN):
        return CheckResult(id="xcode_full", category="xcode", title="Full Xcode installed",
                           status=CheckStatus.INCOMPATIBLE, observed=version_str(version),
                           required=req.XCODE_REQUIRED, details=details,
                           remedy="Install Xcode 16.0 or later (manual).", manual_action_required=True)
    return CheckResult(id="xcode_full", category="xcode", title="Full Xcode installed",
                       status=CheckStatus.READY, observed=f"Xcode {version_str(version)}",
                       required=req.XCODE_REQUIRED, details=details)


def check_xcode_license(ctx: DoctorContext) -> CheckResult:
    state = ctx.xcode
    if not state.bundle_path:
        return CheckResult(id="xcode_license", category="xcode", title="Xcode licence accepted",
                           status=CheckStatus.UNKNOWN, observed="no full Xcode", required="accepted",
                           remedy="Install full Xcode first; then " + LICENSE_REMEDY)
    res = ctx.run(["xcodebuild", "-license", "check"], env=state.probe_env)
    if res.ok:
        state.license_accepted = True
        state.usable = state.version is not None and at_least(state.version, req.XCODE_MIN)
        return CheckResult(id="xcode_license", category="xcode", title="Xcode licence accepted",
                           status=CheckStatus.READY, observed="accepted", required="accepted")
    if mentions_license(res) or res.returncode == 69:
        state.license_accepted = False
        return CheckResult(id="xcode_license", category="xcode", title="Xcode licence accepted",
                           status=CheckStatus.MISSING, observed="not accepted", required="accepted",
                           remedy=LICENSE_REMEDY, manual_action_required=True,
                           details={"output": res.output[:400]})
    return CheckResult(id="xcode_license", category="xcode", title="Xcode licence accepted",
                       status=CheckStatus.UNKNOWN, observed=res.error or first_line(res.output),
                       required="accepted", remedy="Run `xcodebuild -license check` manually to inspect.")


def check_first_launch(ctx: DoctorContext) -> CheckResult:
    state = ctx.xcode
    title = "Xcode first-launch components"
    if not state.usable:
        return CheckResult(id="xcode_first_launch", category="xcode", title=title,
                           status=CheckStatus.UNKNOWN, observed="not checked", required="installed",
                           remedy="Re-run doctor after full Xcode is installed and its licence accepted.")
    res = ctx.run(["xcodebuild", "-checkFirstLaunchStatus"], env=state.probe_env)
    if res.ok:
        return CheckResult(id="xcode_first_launch", category="xcode", title=title,
                           status=CheckStatus.READY, observed="installed", required="installed")
    return CheckResult(id="xcode_first_launch", category="xcode", title=title,
                       status=CheckStatus.MISSING, observed=res.error or f"exit {res.returncode}",
                       required="installed", manual_action_required=True,
                       remedy="Requires manual completion: `sudo xcodebuild -runFirstLaunch` (or open Xcode once).")


def _simctl_json(ctx: DoctorContext, what: str) -> tuple[dict[str, Any] | None, str | None]:
    res = ctx.run(["xcrun", "simctl", "list", what, "--json"], env=ctx.xcode.probe_env, timeout=60.0)
    if not res.ok:
        return None, res.error or first_line(res.output) or f"exit {res.returncode}"
    try:
        data = json.loads(res.stdout)
    except json.JSONDecodeError as exc:
        return None, f"invalid simctl JSON: {exc}"
    return (data, None) if isinstance(data, dict) else (None, "unexpected simctl JSON")


def _simctl_blocked(check_id: str, title: str, ctx: DoctorContext, required: str) -> CheckResult:
    if not ctx.xcode.bundle_path:
        return CheckResult(id=check_id, category="simulator", title=title, status=CheckStatus.MISSING,
                           observed="simctl unavailable (Command Line Tools only)", required=required,
                           remedy=INSTALL_XCODE_REMEDY, manual_action_required=True)
    return CheckResult(id=check_id, category="simulator", title=title, status=CheckStatus.UNKNOWN,
                       observed="not checked: Xcode not usable yet", required=required,
                       remedy="Blocked by the Xcode licence/installation checks above; resolve them and re-run.")


def simulator_checks(ctx: DoctorContext) -> list[CheckResult]:
    runtime_required = req.IOS_RUNTIME_REQUIRED
    if not ctx.xcode.usable:
        return [
            _simctl_blocked("simctl", "simctl available", ctx, "xcrun simctl"),
            _simctl_blocked("ios_runtime", "iOS Simulator runtime", ctx, runtime_required),
            _simctl_blocked("project_simulators", "Project-owned Simulators", ctx,
                            f"name prefix '{req.SIMULATOR_NAME_PREFIX}'"),
        ]
    runtimes_data, err = _simctl_json(ctx, "runtimes")
    if runtimes_data is None:
        failed = CheckResult(id="simctl", category="simulator", title="simctl available",
                             status=CheckStatus.MISSING, observed=err, required="xcrun simctl",
                             remedy="simctl failed; open Xcode once to finish component installation.")
        return [failed,
                _simctl_blocked("ios_runtime", "iOS Simulator runtime", ctx, runtime_required),
                _simctl_blocked("project_simulators", "Project-owned Simulators", ctx,
                                f"name prefix '{req.SIMULATOR_NAME_PREFIX}'")]
    results = [CheckResult(id="simctl", category="simulator", title="simctl available",
                           status=CheckStatus.READY, observed="ok", required="xcrun simctl")]
    results.append(_runtime_check(runtimes_data, runtime_required))
    devices_data, err = _simctl_json(ctx, "devices")
    results.append(_project_sim_check(devices_data, err))
    return results


def runtime_supported(version: tuple[int, ...] | None) -> bool:
    """iOS 18.x or >= 26.4 per the XCUITest driver compatibility table."""
    if version is None:
        return False
    return version[0] == req.IOS_RUNTIME_18[0] or at_least(version, req.IOS_RUNTIME_MODERN_MIN)


def _runtime_check(data: dict[str, Any], required: str) -> CheckResult:
    ios: list[dict[str, Any]] = []
    for rt in data.get("runtimes", []):
        if not isinstance(rt, dict):
            continue
        platform = str(rt.get("platform") or rt.get("name") or rt.get("identifier") or "")
        if "ios" not in platform.lower():
            continue
        version = parse_version(str(rt.get("version")))
        ios.append({"name": rt.get("name"), "version": rt.get("version"),
                    "identifier": rt.get("identifier"), "available": bool(rt.get("isAvailable")),
                    "supported": runtime_supported(version)})
    usable = [r for r in ios if r["available"] and r["supported"]]
    usable.sort(key=lambda r: parse_version(str(r["version"])) or (0,), reverse=True)
    if usable:
        return CheckResult(id="ios_runtime", category="simulator", title="iOS Simulator runtime",
                           status=CheckStatus.READY, observed=", ".join(str(r["name"]) for r in usable),
                           required=required, details={"runtimes": ios})
    if ios:
        return CheckResult(
            id="ios_runtime", category="simulator", title="iOS Simulator runtime",
            status=CheckStatus.INCOMPATIBLE,
            observed=", ".join(f"{r['name']}{'' if r['available'] else ' (unavailable)'}" for r in ios),
            required=required, manual_action_required=True, details={"runtimes": ios},
            remedy=("Installed iOS runtime(s) are unavailable or unsupported by the pinned XCUITest driver "
                    "(supported: iOS 18.x or >=26.4). Requires manual update: install an iOS 18.x or "
                    ">=26.4 runtime via Xcode > Settings > Components (updating Xcode if needed). "
                    "doctor never downloads runtimes."),
        )
    return CheckResult(
        id="ios_runtime", category="simulator", title="iOS Simulator runtime", status=CheckStatus.MISSING,
        observed="none installed", required=required, manual_action_required=True, details={"runtimes": ios},
        remedy=("Requires manual download (~8 GB): Xcode > Settings > Components > iOS, or "
                "`xcodebuild -downloadPlatform iOS`. doctor never downloads runtimes."),
    )


def _project_sim_check(data: dict[str, Any] | None, err: str | None) -> CheckResult:
    title, required = "Project-owned Simulators", f"name prefix '{req.SIMULATOR_NAME_PREFIX}'"
    if data is None:
        return CheckResult(id="project_simulators", category="simulator", title=title,
                           status=CheckStatus.UNKNOWN, observed=err, required=required,
                           remedy="`xcrun simctl list devices --json` failed; re-run doctor.")
    owned: list[dict[str, Any]] = []
    for runtime_id, devices in (data.get("devices") or {}).items():
        for dev in devices or []:
            if isinstance(dev, dict) and str(dev.get("name", "")).startswith(req.SIMULATOR_NAME_PREFIX):
                owned.append({"name": dev.get("name"), "udid": dev.get("udid"), "state": dev.get("state"),
                              "available": bool(dev.get("isAvailable")), "runtime": runtime_id})
    if owned:
        return CheckResult(id="project_simulators", category="simulator", title=title,
                           status=CheckStatus.READY, observed=f"{len(owned)} found", required=required,
                           details={"simulators": owned})
    return CheckResult(id="project_simulators", category="simulator", title=title,
                       status=CheckStatus.MISSING, observed="none", required=required,
                       remedy=("None yet. The Simulator adapter (T03) creates its own "
                               f"'{req.SIMULATOR_NAME_PREFIX}*' devices; personal Simulators are never used."))


def _toolchain_label(developer_dir: str | None) -> str:
    if developer_dir and ".app/Contents/Developer" in developer_dir:
        return f"Xcode: {_bundle_of(developer_dir)}"
    if developer_dir and "CommandLineTools" in developer_dir:
        return "Command Line Tools"
    return developer_dir or "unknown developer directory"


def check_swift(ctx: DoctorContext) -> CheckResult:
    state = ctx.xcode
    env = state.probe_env
    res = ctx.run(["swift", "--version"], env=env)
    source_dir = env.get("DEVELOPER_DIR") or state.selected_path
    blocked_by_license = mentions_license(res)
    if blocked_by_license and env:
        # Xcode's swift is blocked by the licence; report what the active directory offers instead.
        res = ctx.run(["swift", "--version"])
        source_dir = state.selected_path
    label = _toolchain_label(source_dir)
    details = {"developer_dir": source_dir, "blocked_by_license": blocked_by_license}
    title = "Swift toolchain"
    if not res.ok:
        if state.bundle_path:
            return CheckResult(id="swift", category="toolchain", title=title, status=CheckStatus.UNKNOWN,
                               observed=res.error or first_line(res.output), required=req.SWIFT_REQUIRED,
                               details=details,
                               remedy="Blocked by the Xcode checks above (licence/installation); resolve and re-run.")
        return CheckResult(id="swift", category="toolchain", title=title, status=CheckStatus.MISSING,
                           observed=res.error or first_line(res.output), required=req.SWIFT_REQUIRED,
                           details=details, remedy=INSTALL_XCODE_REMEDY)
    line = next((ln for ln in res.output.splitlines() if "Swift version" in ln), first_line(res.output)).strip()
    observed = f"{line} ({label})"
    if state.usable:
        return CheckResult(id="swift", category="toolchain", title=title, status=CheckStatus.READY,
                           observed=observed, required=req.SWIFT_REQUIRED, details=details)
    if state.bundle_path:
        return CheckResult(id="swift", category="toolchain", title=title, status=CheckStatus.UNKNOWN,
                           observed=observed, required=req.SWIFT_REQUIRED, details=details,
                           remedy=("Full Xcode is present but not usable yet; blocked by the Xcode "
                                   "licence/installation checks above. Resolve them and re-run."))
    return CheckResult(id="swift", category="toolchain", title=title, status=CheckStatus.INCOMPATIBLE,
                       observed=observed, required=req.SWIFT_REQUIRED, details=details,
                       remedy="Swift from Command Line Tools cannot build/sign iOS Simulator apps; install full Xcode.")


def check_xcodegen(ctx: DoctorContext) -> CheckResult:
    if ctx.host.which("xcodegen") is None:
        return CheckResult(id="xcodegen", category="toolchain", title="XcodeGen (optional)",
                           status=CheckStatus.MISSING, observed="not on PATH", required="optional",
                           remedy=("Only needed if the LabMessenger fixture is generated from an XcodeGen "
                                   "spec; not installed automatically."))
    res = ctx.run(["xcodegen", "--version"])
    return CheckResult(id="xcodegen", category="toolchain", title="XcodeGen (optional)",
                       status=CheckStatus.READY if res.ok else CheckStatus.UNKNOWN,
                       observed=first_line(res.output) or res.error, required="optional")


def xcode_checks(ctx: DoctorContext) -> list[CheckResult]:
    results = [check_xcode_select(ctx), check_xcode_full(ctx), check_xcode_license(ctx),
               check_first_launch(ctx)]
    results += simulator_checks(ctx)
    results += [check_swift(ctx), check_xcodegen(ctx)]
    return results

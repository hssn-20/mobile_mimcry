"""Host hardware, OS, Python/Node toolchain and port checks."""

from __future__ import annotations

from mobilelab.doctor import requirements as req
from mobilelab.doctor.context import DoctorContext, at_least, first_line, parse_version, version_str
from mobilelab.doctor.models import CheckResult, CheckStatus

GIB = 1024**3


def check_arch(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["uname", "-m"])
    arch = res.stdout.strip() if res.ok else None
    if arch is None:
        status, remedy = CheckStatus.UNKNOWN, "Could not run `uname -m`."
    elif arch == "arm64":
        status, remedy = CheckStatus.READY, None
    elif arch == "x86_64":
        status, remedy = CheckStatus.READY, "Intel Mac: supported, but Simulator capacity will be lower."
    else:
        status, remedy = CheckStatus.INCOMPATIBLE, "A macOS host (arm64 or x86_64) is required."
    return CheckResult(id="host_arch", category="host", title="CPU architecture", status=status,
                       observed=arch, required="arm64 (Apple silicon) preferred", remedy=remedy)


def check_macos(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["sw_vers", "-productVersion"])
    build = ctx.run(["sw_vers", "-buildVersion"])
    version = parse_version(res.stdout) if res.ok else None
    observed = version_str(version)
    if version is None:
        status, remedy = CheckStatus.UNKNOWN, "Could not read the macOS version (`sw_vers`); is this a Mac?"
    elif at_least(version, req.MACOS_MIN):
        status, remedy = CheckStatus.READY, None
    else:
        status, remedy = (CheckStatus.INCOMPATIBLE,
                          "Update macOS (manual): current Xcode releases need macOS 15.6 or later.")
    return CheckResult(id="macos_version", category="host", title="macOS version", status=status,
                       observed=observed, required=f">={version_str(req.MACOS_MIN)}", remedy=remedy,
                       details={"build": build.stdout.strip() if build.ok else None})


def _sysctl_int(ctx: DoctorContext, key: str) -> int | None:
    res = ctx.run(["sysctl", "-n", key])
    try:
        return int(res.stdout.strip()) if res.ok else None
    except ValueError:
        return None


def check_memory(ctx: DoctorContext) -> CheckResult:
    mem = _sysctl_int(ctx, "hw.memsize")
    if mem is None:
        status, remedy = CheckStatus.UNKNOWN, "Could not read hw.memsize."
    elif mem >= req.RAM_MIN_BYTES:
        status, remedy = CheckStatus.READY, None
    else:
        status, remedy = (CheckStatus.INCOMPATIBLE,
                          "Less than 16 GiB RAM: run one Simulator only and close other apps.")
    return CheckResult(id="host_memory", category="host", title="Physical memory", status=status,
                       observed=f"{mem / GIB:.1f} GiB" if mem else None,
                       required=f">={req.RAM_MIN_BYTES // GIB} GiB", remedy=remedy,
                       details={"bytes": mem})


def check_cpu(ctx: DoctorContext) -> CheckResult:
    cpus = _sysctl_int(ctx, "hw.ncpu")
    if cpus is None:
        status, remedy = CheckStatus.UNKNOWN, "Could not read hw.ncpu."
    elif cpus >= req.CPU_MIN:
        status, remedy = CheckStatus.READY, None
    else:
        status, remedy = CheckStatus.INCOMPATIBLE, "Fewer than 8 CPUs: multi-device capacity (D-10) unlikely."
    return CheckResult(id="host_cpu", category="host", title="Logical CPUs", status=status,
                       observed=str(cpus) if cpus is not None else None,
                       required=f">={req.CPU_MIN}", remedy=remedy)


def check_disk(ctx: DoctorContext) -> CheckResult:
    free = ctx.host.disk_free_bytes(ctx.project_root)
    if free is None:
        status, remedy = CheckStatus.UNKNOWN, "Could not read free disk space."
    elif free >= req.DISK_FREE_MIN_BYTES:
        status, remedy = CheckStatus.READY, None
    else:
        status, remedy = (CheckStatus.INCOMPATIBLE,
                          "Free disk space before downloading an iOS Simulator runtime (manual cleanup).")
    return CheckResult(id="host_disk", category="host", title="Free disk space (project volume)",
                       status=status, observed=f"{free / GIB:.1f} GiB" if free is not None else None,
                       required=f">={req.DISK_FREE_MIN_BYTES // GIB} GiB", remedy=remedy,
                       details={"bytes": free})


def check_python(ctx: DoctorContext) -> CheckResult:
    observed = ctx.host.python_version()
    version = parse_version(observed)
    ok = version is not None and version[:2] == (3, 12)
    return CheckResult(
        id="python", category="toolchain", title="Python interpreter", observed=observed,
        status=CheckStatus.READY if ok else CheckStatus.INCOMPATIBLE, required=req.PYTHON_REQUIRED,
        remedy=None if ok else "Run through `uv run mobilelab ...` so uv selects the pinned Python 3.12.",
    )


def check_uv(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["uv", "--version"])
    if not res.ok:
        return CheckResult(id="uv", category="toolchain", title="uv", status=CheckStatus.MISSING,
                           required="any recent uv", observed=res.error,
                           remedy="Install uv (https://docs.astral.sh/uv/) then run `uv sync`.")
    return CheckResult(id="uv", category="toolchain", title="uv", status=CheckStatus.READY,
                       observed=first_line(res.stdout), required="any recent uv")


def node_version_ok(version: tuple[int, ...] | None) -> bool:
    if version is None:
        return False
    major = version[0]
    if major == 20:
        return at_least(version, (20, 19, 0))
    if major == 22:
        return at_least(version, (22, 12, 0))
    return major >= 24


def check_node(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["node", "--version"])
    if not res.ok:
        return CheckResult(id="node", category="toolchain", title="Node.js", status=CheckStatus.MISSING,
                           required=req.NODE_REQUIRED, observed=res.error,
                           remedy="Install Node.js 24 LTS (e.g. via nvm) for the project-local Appium.")
    version = parse_version(res.stdout)
    ok = node_version_ok(version)
    return CheckResult(id="node", category="toolchain", title="Node.js", observed=version_str(version),
                       status=CheckStatus.READY if ok else CheckStatus.INCOMPATIBLE,
                       required=req.NODE_REQUIRED,
                       remedy=None if ok else "Switch to Node.js 24 LTS (`nvm install 24`).")


def check_npm(ctx: DoctorContext) -> CheckResult:
    res = ctx.run(["npm", "--version"])
    if not res.ok:
        return CheckResult(id="npm", category="toolchain", title="npm", status=CheckStatus.MISSING,
                           required=req.NPM_REQUIRED, observed=res.error,
                           remedy="npm ships with Node.js; reinstall Node.js 24 LTS.")
    version = parse_version(res.stdout)
    ok = at_least(version, (10,))
    return CheckResult(id="npm", category="toolchain", title="npm", observed=version_str(version),
                       status=CheckStatus.READY if ok else CheckStatus.INCOMPATIBLE,
                       required=req.NPM_REQUIRED, remedy=None if ok else "Upgrade npm to >=10.")


def check_port(ctx: DoctorContext, port: int, purpose: str) -> CheckResult:
    available = ctx.host.port_available(port)
    if available is None:
        status, observed, remedy = CheckStatus.UNKNOWN, "could not test", "Check the port manually."
    elif available:
        status, observed, remedy = CheckStatus.READY, "free", None
    else:
        status, observed = CheckStatus.INCOMPATIBLE, "in use"
        remedy = (f"Port {port} is already bound on loopback (127.0.0.1 or ::1). Find the owner with "
                  f"`lsof -nP -iTCP:{port} -sTCP:LISTEN` and stop it, or configure another port.")
    return CheckResult(id=f"port_{port}", category="ports", title=f"Port {port} ({purpose})",
                       status=status, observed=observed, required="free on 127.0.0.1 and ::1", remedy=remedy)


def host_checks(ctx: DoctorContext) -> list[CheckResult]:
    results = [check_arch(ctx), check_macos(ctx), check_memory(ctx), check_cpu(ctx), check_disk(ctx),
               check_python(ctx), check_uv(ctx), check_node(ctx), check_npm(ctx)]
    purposes = {8781: "fixture data server", 8782: "fixture receiver", req.APPIUM_PORT: "Appium server"}
    results += [check_port(ctx, port, purposes[port]) for port in (*req.FIXTURE_PORTS, req.APPIUM_PORT)]
    return results

"""Human-readable rendering of a doctor report."""

from __future__ import annotations

from mobilelab.doctor.models import CheckStatus, DoctorReport, GateStatus

_MARK = {CheckStatus.READY: "ok", CheckStatus.MISSING: "MISSING",
         CheckStatus.INCOMPATIBLE: "INCOMPAT", CheckStatus.UNKNOWN: "unknown"}


def _clip(text: str | None, width: int) -> str:
    text = (text or "-").replace("\n", " ")
    return text if len(text) <= width else text[: width - 1] + "…"


def render_table(report: DoctorReport) -> str:
    lines = [f"mobilelab doctor  ({report.created_at.isoformat()}, evidence: {report.evidence_source}, "
             "read-only)", ""]
    header = f"{'STATUS':<9} {'CHECK':<44} {'OBSERVED':<44} REQUIRED"
    lines += [header, "-" * len(header)]
    for check in report.checks:
        lines.append(f"{_MARK[check.status]:<9} {_clip(check.title, 44):<44} "
                     f"{_clip(check.observed, 44):<44} {_clip(check.required, 40)}")
    remedies = [c for c in report.checks if c.status is not CheckStatus.READY and c.remedy]
    if remedies:
        lines += ["", "Actions:"]
        for check in remedies:
            manual = " [manual]" if check.manual_action_required else ""
            lines.append(f"  - {check.id}{manual}: {check.remedy}")
    lines += ["", "Readiness:"]
    for gate in report.gates:
        mark = "READY  " if gate.status is GateStatus.READY else "BLOCKED"
        lines.append(f"  [{mark}] {gate.summary}")
    return "\n".join(lines)

"""Project-local Appium server and XCUITest driver checks (read-only)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mobilelab.doctor import requirements as req
from mobilelab.doctor.context import DoctorContext, first_line, parse_version
from mobilelab.doctor.models import CheckResult, CheckStatus

XCUITEST_PACKAGE = "appium-xcuitest-driver"


@dataclass(frozen=True, slots=True)
class AppiumPins:
    appium: str | None
    xcuitest: str | None
    node_engines: str | None


def read_json(ctx: DoctorContext, path: Path) -> dict[str, Any] | None:
    text = ctx.host.read_text(path)
    if text is None:
        return None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def read_pins(ctx: DoctorContext) -> AppiumPins:
    pkg = read_json(ctx, ctx.appium_dir / "package.json") or {}
    drivers = (pkg.get("mobilelab") or {}).get("drivers") or {}
    return AppiumPins(
        appium=(pkg.get("dependencies") or {}).get("appium"),
        xcuitest=(drivers.get("xcuitest") or {}).get("version"),
        node_engines=(pkg.get("engines") or {}).get("node"),
    )


def install_driver_command(pin: str | None) -> str:
    return (f"cd tools/appium && APPIUM_HOME=$PWD/.appium ./node_modules/.bin/appium driver install "
            f"--source=npm {XCUITEST_PACKAGE}@{pin or '<pinned>'}")


def check_appium(ctx: DoctorContext, pins: AppiumPins) -> CheckResult:
    local_bin = ctx.appium_local_bin
    required = f"appium {pins.appium or '3.x'} (project-local, tools/appium)"
    if ctx.host.is_file(local_bin):
        binary, source, resolved = str(local_bin), "project-local", str(local_bin)
    elif (on_path := ctx.host.which("appium")) is not None:
        # Run the bare name (resolved through PATH by the OS); only the project-local path is trusted.
        binary, source, resolved = "appium", "PATH", on_path
    else:
        return CheckResult(id="appium", category="appium", title="Appium server", status=CheckStatus.MISSING,
                           observed="not installed", required=required,
                           remedy="Project-local install: `cd tools/appium && npm ci` (see tools/appium/README.md).")
    res = ctx.run([binary, "--version"], env={"APPIUM_HOME": str(ctx.appium_home)}, timeout=30.0)
    observed = first_line(res.stdout) if res.ok else None
    details = {"binary": resolved, "source": source, "pinned": pins.appium}
    if observed is None:
        return CheckResult(id="appium", category="appium", title="Appium server", status=CheckStatus.UNKNOWN,
                           observed=res.error or first_line(res.output), required=required, details=details,
                           remedy="`appium --version` failed; check the Node.js check and reinstall with `npm ci`.")
    version = parse_version(observed)
    if version is None or version[0] != req.APPIUM_MAJOR_REQUIRED:
        return CheckResult(id="appium", category="appium", title="Appium server",
                           status=CheckStatus.INCOMPATIBLE, observed=f"{observed} ({source})",
                           required=required, details=details,
                           remedy="appium-xcuitest-driver >=10 requires Appium 3: `cd tools/appium && npm ci`.")
    if pins.appium and observed != pins.appium:
        return CheckResult(id="appium", category="appium", title="Appium server",
                           status=CheckStatus.INCOMPATIBLE, observed=f"{observed} ({source})",
                           required=required, details=details,
                           remedy=f"Use the pinned project-local Appium {pins.appium}: `cd tools/appium && npm ci`.")
    return CheckResult(id="appium", category="appium", title="Appium server", status=CheckStatus.READY,
                       observed=f"{observed} ({source})", required=required, details=details)


def check_xcuitest_driver(ctx: DoctorContext, pins: AppiumPins) -> CheckResult:
    required = f"{XCUITEST_PACKAGE} {pins.xcuitest or '(unpinned)'} in APPIUM_HOME=tools/appium/.appium"
    pkg = read_json(ctx, ctx.appium_home / "node_modules" / XCUITEST_PACKAGE / "package.json")
    if pkg is None:
        return CheckResult(id="appium_driver_xcuitest", category="appium", title="Appium XCUITest driver",
                           status=CheckStatus.MISSING, observed="not installed in project APPIUM_HOME",
                           required=required, remedy=install_driver_command(pins.xcuitest))
    installed = pkg.get("version")
    peer = (pkg.get("peerDependencies") or {}).get("appium")
    details = {"installed": installed, "appium_peer": peer, "appium_home": str(ctx.appium_home)}
    if pins.xcuitest and installed != pins.xcuitest:
        return CheckResult(id="appium_driver_xcuitest", category="appium", title="Appium XCUITest driver",
                           status=CheckStatus.INCOMPATIBLE, observed=str(installed), required=required,
                           details=details,
                           remedy=("Reinstall the pinned driver: first `APPIUM_HOME=$PWD/.appium "
                                   "./node_modules/.bin/appium driver uninstall xcuitest` in tools/appium, then "
                                   + install_driver_command(pins.xcuitest)))
    return CheckResult(id="appium_driver_xcuitest", category="appium", title="Appium XCUITest driver",
                       status=CheckStatus.READY, observed=str(installed), required=required, details=details)


def appium_checks(ctx: DoctorContext) -> list[CheckResult]:
    pins = read_pins(ctx)
    return [check_appium(ctx, pins), check_xcuitest_driver(ctx, pins)]

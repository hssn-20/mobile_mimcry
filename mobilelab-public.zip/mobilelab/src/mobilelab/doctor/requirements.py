"""Version requirements resolved for M1 (research snapshot 2026-10-03).

Appium and driver pins are read from ``tools/appium/package.json`` (single
source of truth); the values here are the documented compatibility ranges.
"""

from __future__ import annotations

RESOLVED_ON = "2026-10-03"

PYTHON_REQUIRED = ">=3.12,<3.13"
NODE_REQUIRED = "^20.19.0 || ^22.12.0 || >=24.0.0"  # appium@3.8.0 engines
NPM_REQUIRED = ">=10"
APPIUM_MAJOR_REQUIRED = 3  # appium-xcuitest-driver >=10 requires Appium 3
XCODE_MIN = (16, 0)  # driver >= 11.1.2 supports Xcode 16.0+
XCODE_REQUIRED = ">=16.0 (driver aims to fully support the latest two Xcode majors)"
# Supported iOS Simulator runtimes per the driver compatibility table:
# 18.x (driver >= 7.24.15) or >= 26.4 (driver >= 10.23.2). 26.0-26.3 are not supported.
IOS_RUNTIME_18 = (18,)
IOS_RUNTIME_MODERN_MIN = (26, 4)
IOS_RUNTIME_REQUIRED = "iOS 18.x or >=26.4 (driver compatibility table; 26.0-26.3 unsupported)"
MACOS_MIN = (15, 6)  # minimum host for Xcode 26; newer Xcode may require newer macOS
SWIFT_REQUIRED = "bundled with the selected full Xcode (CLT Swift cannot build iOS apps)"

RAM_MIN_BYTES = 16 * 1024**3  # one Simulator + Appium + coordinator
CPU_MIN = 8
DISK_FREE_MIN_BYTES = 40 * 1024**3  # iOS runtime (~8-10 GB) + DerivedData + artifacts

FIXTURE_PORTS = (8781, 8782)
APPIUM_PORT = 4723
SIMULATOR_NAME_PREFIX = "mobilelab-"

SOURCES = {
    "xcuitest_system_requirements": (
        "https://appium.github.io/appium-xcuitest-driver/latest/getting-started/system-requirements/"
    ),
    "appium_npm": "https://www.npmjs.com/package/appium",
    "xcuitest_npm": "https://www.npmjs.com/package/appium-xcuitest-driver",
}

"""FIXTURE host/runner fakes for tests. Never host evidence.

Reports produced with these fakes must use ``EvidenceSource.FIXTURE``.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mobilelab.doctor.runner import DEFAULT_TIMEOUT_S, CommandResult, normalise_argv

LICENSE_TEXT = ("You have not agreed to the Xcode license agreements. Please run 'sudo xcodebuild -license' "
                "from within a Terminal window to review and agree to the Xcode and Apple SDKs license.")
XCODE_DEV = "/Applications/Xcode.app/Contents/Developer"
CLT_DEV = "/Library/Developer/CommandLineTools"
FIXED_NOW = datetime(2026, 10, 3, 12, 0, tzinfo=UTC)


@dataclass
class FakeRunner:
    """Maps normalised argv tuples to canned results; unknown argv -> not_found."""

    responses: dict[tuple[str, ...], tuple[int | None, str, str]] = field(default_factory=dict)
    calls: list[tuple[tuple[str, ...], dict[str, str]]] = field(default_factory=list)

    def set(self, argv: Sequence[str], returncode: int | None = 0, stdout: str = "", stderr: str = "") -> None:
        self.responses[tuple(argv)] = (returncode, stdout, stderr)

    def remove(self, argv: Sequence[str]) -> None:
        self.responses.pop(tuple(argv), None)

    def run(self, argv: Sequence[str], *, timeout: float = DEFAULT_TIMEOUT_S,
            env: Mapping[str, str] | None = None) -> CommandResult:
        key = normalise_argv(argv)
        self.calls.append((key, dict(env or {})))
        if key not in self.responses:
            return CommandResult(tuple(argv), None, error="not_found", env=dict(env or {}))
        rc, out, err = self.responses[key]
        return CommandResult(tuple(argv), rc, out, err, None if rc is not None else "timeout", 1,
                             dict(env or {}))


@dataclass
class FakeHost:
    files: dict[str, str] = field(default_factory=dict)
    plists: dict[str, dict[str, Any]] = field(default_factory=dict)
    bundles: list[str] = field(default_factory=list)
    on_path: set[str] = field(default_factory=set)
    busy_ports: set[int] = field(default_factory=set)
    disk_free: int | None = 500 * 1024**3
    python: str = "3.12.13"

    def which(self, name: str) -> str | None:
        return f"/usr/local/bin/{name}" if name in self.on_path else None

    def is_file(self, path: Path) -> bool:
        return str(path) in self.files

    def is_dir(self, path: Path) -> bool:
        return any(key.startswith(str(path) + "/") for key in self.files)

    def read_text(self, path: Path) -> str | None:
        return self.files.get(str(path))

    def read_plist(self, path: Path) -> dict[str, Any] | None:
        return self.plists.get(str(path))

    def xcode_bundles(self) -> list[Path]:
        return [Path(b) for b in self.bundles]

    def port_available(self, port: int) -> bool | None:
        return port not in self.busy_ports

    def disk_free_bytes(self, path: Path) -> int | None:
        return self.disk_free

    def python_version(self) -> str:
        return self.python

    def now(self) -> datetime:
        return FIXED_NOW


def fake_device(device_type: str, tunnel_state: str, name: str = "Test Phone") -> dict[str, Any]:
    """FIXTURE CoreDevice entry shaped like `devicectl list devices --json-output -` (deprecated keys)."""
    platform = "iOS" if device_type.lower() in ("iphone", "ipad") else "watchOS" if device_type == "appleWatch" else "macOS"
    return {"identifier": "FIXTURE-COREDEVICE-ID",
            "deviceProperties": {"name": name},
            "hardwareProperties": {"deviceType": device_type, "platform": platform, "udid": "FIXTURE-UDID",
                                   "serialNumber": "FIXTURE-SERIAL"},
            "connectionProperties": {"pairingState": "paired", "tunnelState": tunnel_state}}


def devicectl_json(devices: list[dict[str, Any]]) -> str:
    return json.dumps({"info": {"outcome": "success", "jsonVersion": 5}, "result": {"devices": devices}})


def healthy_fixture(project_root: Path) -> tuple[FakeRunner, FakeHost]:
    """A fully ready host: selected Xcode 26.4, licence accepted, iOS 26.4 runtime, pinned Appium."""
    runner = FakeRunner()
    runner.set(["uname", "-m"], stdout="arm64\n")
    runner.set(["sw_vers", "-productVersion"], stdout="26.6.2\n")
    runner.set(["sw_vers", "-buildVersion"], stdout="25G83\n")
    runner.set(["sysctl", "-n", "hw.memsize"], stdout=f"{24 * 1024**3}\n")
    runner.set(["sysctl", "-n", "hw.ncpu"], stdout="10\n")
    runner.set(["uv", "--version"], stdout="uv 0.11.2\n")
    runner.set(["node", "--version"], stdout="v24.14.1\n")
    runner.set(["npm", "--version"], stdout="11.11.0\n")
    runner.set(["xcode-select", "-p"], stdout=XCODE_DEV + "\n")
    runner.set(["xcodebuild", "-version"], stdout="Xcode 26.4\nBuild version 17E100\n")
    runner.set(["xcodebuild", "-license", "check"])
    runner.set(["xcodebuild", "-checkFirstLaunchStatus"])
    runner.set(["xcrun", "simctl", "list", "runtimes", "--json"], stdout=json.dumps({"runtimes": [
        {"name": "iOS 26.4", "version": "26.4", "platform": "iOS", "isAvailable": True,
         "identifier": "com.apple.CoreSimulator.SimRuntime.iOS-26-4"}]}))
    runner.set(["xcrun", "simctl", "list", "devices", "--json"], stdout=json.dumps({"devices": {
        "com.apple.CoreSimulator.SimRuntime.iOS-26-4": [
            {"name": "mobilelab-iphone-1", "udid": "SIM-UDID-1", "state": "Shutdown", "isAvailable": True},
            {"name": "iPhone 17", "udid": "SIM-UDID-2", "state": "Shutdown", "isAvailable": True}]}}))
    runner.set(["xcrun", "devicectl", "list", "devices", "--json-output", "-"],
               stdout=devicectl_json([fake_device("iPhone", "connected")]))
    runner.set(["security", "find-identity", "-v", "-p", "codesigning"],
               stdout='  1) ABCDEF "Apple Development: Test (TEAMID)"\n     1 valid identities found\n')
    runner.set(["swift", "--version"], stdout="Apple Swift version 6.3 (swiftlang-6.3)\nTarget: arm64-apple-macosx26.0\n")
    runner.set(["appium", "--version"], stdout="3.8.0\n")

    appium_dir = project_root / "tools" / "appium"
    host = FakeHost()
    host.plists[f"{XCODE_DEV.removesuffix('/Contents/Developer')}/Contents/version.plist"] = {
        "CFBundleShortVersionString": "26.4"}
    host.bundles.append(XCODE_DEV.removesuffix("/Contents/Developer"))
    host.files[str(appium_dir / "package.json")] = json.dumps({
        "dependencies": {"appium": "3.8.0"},
        "engines": {"node": "^20.19.0 || ^22.12.0 || >=24.0.0", "npm": ">=10"},
        "mobilelab": {"drivers": {"xcuitest": {"version": "12.14.0"}}}})
    host.files[str(appium_dir / "node_modules" / ".bin" / "appium")] = "#!/usr/bin/env node\n"
    host.files[str(appium_dir / ".appium" / "node_modules" / "appium-xcuitest-driver" / "package.json")] = (
        json.dumps({"version": "12.14.0", "peerDependencies": {"appium": "^3.0.0-rc.2"}}))
    host.on_path.update({"node", "npm", "uv", "swift"})
    return runner, host

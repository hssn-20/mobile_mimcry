"""`mobilelab doctor` CLI subcommand."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from mobilelab.doctor import GATES, find_project_root, run_doctor
from mobilelab.doctor.manifest import build_manifest, write_manifest
from mobilelab.doctor.models import DoctorReport, GateStatus
from mobilelab.doctor.render import render_table

DEFAULT_MANIFEST = Path("configs/runtime_manifest.json")


def register(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    parser = subparsers.add_parser(
        "doctor", help="Read-only host/toolchain preflight",
        description="Read-only host preflight. Never installs, accepts licences, switches Xcode or "
                    "touches devices.")
    parser.add_argument("--json", action="store_true", help="print the JSON report instead of a table")
    parser.add_argument("--output", type=Path, metavar="PATH", help="also write the JSON report to PATH")
    parser.add_argument("--save", action="store_true",
                        help="also write artifacts/doctor/doctor-<UTC timestamp>.json")
    parser.add_argument("--write-manifest", nargs="?", const=DEFAULT_MANIFEST, type=Path, metavar="PATH",
                        help=f"write the resolved runtime manifest (default {DEFAULT_MANIFEST})")
    parser.add_argument("--require-gate", action="append", default=[], metavar="GATE",
                        choices=[gate.id for gate in GATES],
                        help="exit 1 if this readiness gate is blocked (repeatable)")
    parser.add_argument("--project-root", type=Path, help=argparse.SUPPRESS)
    parser.set_defaults(func=run)


def _write_json(report: DoctorReport, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(report.model_dump_json(indent=2) + "\n", encoding="utf-8")


def run(args: argparse.Namespace) -> int:
    root = (args.project_root or find_project_root()).resolve()
    report = run_doctor(project_root=root)
    print(report.model_dump_json(indent=2) if args.json else render_table(report))
    written: list[Path] = []
    if args.output:
        _write_json(report, args.output)
        written.append(args.output)
    if args.save:
        stamp = report.created_at.strftime("%Y%m%dT%H%M%SZ")
        path = root / "artifacts" / "doctor" / f"doctor-{stamp}.json"
        _write_json(report, path)
        written.append(path)
    if args.write_manifest is not None:
        path = args.write_manifest if args.write_manifest.is_absolute() else root / args.write_manifest
        write_manifest(build_manifest(report, root), path)
        written.append(path)
    for path in written:
        print(f"wrote {path}", file=sys.stderr)
    blocked = [g for g in report.gates if g.id in args.require_gate and g.status is GateStatus.BLOCKED]
    return 1 if blocked else 0

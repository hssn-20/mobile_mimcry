"""Runtime manifest: the resolved, pinned version set plus host verification flags."""

from __future__ import annotations

import json
import re
import tomllib
from importlib import metadata
from pathlib import Path
from typing import Any

from mobilelab.doctor import requirements as req
from mobilelab.doctor.checks_appium import XCUITEST_PACKAGE
from mobilelab.doctor.models import CheckStatus, DoctorReport

XCODE_CHECKS = ("xcode_select", "xcode_full", "xcode_license", "xcode_first_launch")
_NAME_RE = re.compile(r"^\s*([A-Za-z0-9_.\-]+)\s*(.*)$")


def _normalise(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _direct_requirements(pyproject: dict[str, Any]) -> dict[str, str]:
    specs: list[str] = list(pyproject.get("project", {}).get("dependencies", []))
    for group in pyproject.get("dependency-groups", {}).values():
        specs += [s for s in group if isinstance(s, str)]
    out: dict[str, str] = {}
    for spec in specs:
        match = _NAME_RE.match(spec)
        if match:
            out[_normalise(match.group(1))] = match.group(2).strip() or "*"
    return out


def _locked_versions(lock: dict[str, Any]) -> dict[str, str]:
    return {_normalise(pkg["name"]): pkg["version"] for pkg in lock.get("package", [])
            if "name" in pkg and "version" in pkg}


def _installed(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def python_packages(project_root: Path) -> dict[str, dict[str, Any]]:
    pyproject = tomllib.loads((project_root / "pyproject.toml").read_text(encoding="utf-8"))
    lock_path = project_root / "uv.lock"
    locked = _locked_versions(tomllib.loads(lock_path.read_text(encoding="utf-8"))) if lock_path.exists() else {}
    packages: dict[str, dict[str, Any]] = {}
    for name, spec in sorted(_direct_requirements(pyproject).items()):
        installed = _installed(name)
        packages[name] = {"required": spec, "locked": locked.get(name), "installed": installed,
                          "verified_on_host": installed is not None and installed == locked.get(name)}
    return packages


def build_manifest(report: DoctorReport, project_root: Path) -> dict[str, Any]:
    def entry(check_id: str, required: str | None, **extra: Any) -> dict[str, Any]:
        check = report.check(check_id)
        return {"required": required, "observed": check.observed, "status": str(check.status),
                "verified_on_host": check.status is CheckStatus.READY, **extra}

    appium_pkg = json.loads((project_root / "tools" / "appium" / "package.json").read_text(encoding="utf-8"))
    pins = appium_pkg.get("mobilelab", {}).get("drivers", {}).get("xcuitest", {})
    driver = report.check("appium_driver_xcuitest")
    python_pin = (project_root / ".python-version")
    select = report.check("xcode_select")
    xcode_entry = entry(
        "xcode_full", req.XCODE_REQUIRED,
        active_developer_dir={"observed": select.observed, "status": str(select.status)},
        licence=str(report.check("xcode_license").status),
        first_launch=str(report.check("xcode_first_launch").status),
    )
    # Installed is not enough: the active developer dir, licence and first-launch must all be ready.
    xcode_entry["verified_on_host"] = all(report.check(cid).status is CheckStatus.READY for cid in XCODE_CHECKS)
    return {
        "schema_version": 1,
        "manifest_date": report.created_at.date().isoformat(),
        "requirements_resolved_on": req.RESOLVED_ON,
        "generated_by": "mobilelab doctor --write-manifest",
        "note": ("verified_on_host means doctor observed an installed version satisfying the pin on the "
                 "reference host. It is not a smoke test: no Appium session or Simulator has been driven."),
        "smoke_tested": False,
        "gates": {gate.id: {"status": str(gate.status), "blocked_by": gate.blocked_by}
                  for gate in report.gates},
        "reference_host": {"arch": report.check("host_arch").observed,
                           "macos": report.check("macos_version").observed,
                           "memory": report.check("host_memory").observed,
                           "cpus": report.check("host_cpu").observed},
        "python": entry("python", req.PYTHON_REQUIRED,
                        pinned=python_pin.read_text().strip() if python_pin.exists() else None),
        "python_packages": python_packages(project_root),
        "uv": entry("uv", "any recent uv"),
        "node": entry("node", appium_pkg.get("engines", {}).get("node", req.NODE_REQUIRED)),
        "npm": entry("npm", appium_pkg.get("engines", {}).get("npm", req.NPM_REQUIRED)),
        "appium": entry("appium", appium_pkg.get("dependencies", {}).get("appium"),
                        install="project-local: tools/appium (npm ci)"),
        "appium_xcuitest_driver": {
            "package": XCUITEST_PACKAGE, "required": pins.get("version"),
            "appium_peer": driver.details.get("appium_peer"), "observed": driver.observed,
            "status": str(driver.status), "verified_on_host": driver.status is CheckStatus.READY,
            "appium_home": "tools/appium/.appium",
            "xcode_support": "Xcode 16.0+ (driver >= 11.1.2)",
            "ios_support": "iOS 18.x (driver >= 7.24.15); iOS >= 26.4 (driver >= 10.23.2)",
        },
        "xcode": xcode_entry,
        "ios_simulator_runtime": entry("ios_runtime", req.IOS_RUNTIME_REQUIRED),
        "swift": entry("swift", req.SWIFT_REQUIRED),
        "sources": req.SOURCES,
    }


def write_manifest(manifest: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(manifest, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    tmp.replace(path)

"""Injectable read-only access to host facts that do not need a subprocess."""

from __future__ import annotations

import errno
import plistlib
import shutil
import socket
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol


class HostAccess(Protocol):
    def which(self, name: str) -> str | None: ...
    def is_file(self, path: Path) -> bool: ...
    def is_dir(self, path: Path) -> bool: ...
    def read_text(self, path: Path) -> str | None: ...
    def read_plist(self, path: Path) -> dict[str, Any] | None: ...
    def xcode_bundles(self) -> list[Path]: ...
    def port_available(self, port: int) -> bool | None: ...
    def disk_free_bytes(self, path: Path) -> int | None: ...
    def python_version(self) -> str: ...
    def now(self) -> datetime: ...


class RealHostAccess:
    """Real implementation. Every method is read-only."""

    def __init__(self, applications_dir: Path = Path("/Applications")) -> None:
        self._applications_dir = applications_dir

    def which(self, name: str) -> str | None:
        return shutil.which(name)

    def is_file(self, path: Path) -> bool:
        return path.is_file()

    def is_dir(self, path: Path) -> bool:
        return path.is_dir()

    def read_text(self, path: Path) -> str | None:
        try:
            return path.read_text(encoding="utf-8")
        except OSError:
            return None

    def read_plist(self, path: Path) -> dict[str, Any] | None:
        try:
            with path.open("rb") as handle:
                data = plistlib.load(handle)
        except (OSError, plistlib.InvalidFileException, ValueError):
            return None
        return data if isinstance(data, dict) else None

    def xcode_bundles(self) -> list[Path]:
        try:
            return sorted(p for p in self._applications_dir.glob("Xcode*.app") if p.is_dir())
        except OSError:
            return []

    def port_available(self, port: int) -> bool | None:
        """Bind-and-release on IPv4 and IPv6 loopback; True if free, False if in use on either."""
        v4 = _probe_bind(socket.AF_INET, "127.0.0.1", port)
        v6 = _probe_bind(socket.AF_INET6, "::1", port)
        if v4 is False or v6 is False:
            return False
        if v4 is None:
            return None
        return True  # v6 None means IPv6 loopback unavailable on this host; IPv4 result stands

    def disk_free_bytes(self, path: Path) -> int | None:
        try:
            return shutil.disk_usage(path).free
        except OSError:
            return None

    def python_version(self) -> str:
        return ".".join(str(part) for part in sys.version_info[:3])

    def now(self) -> datetime:
        return datetime.now(UTC)


def _probe_bind(family: socket.AddressFamily, address: str, port: int) -> bool | None:
    """True if ``address:port`` can be bound, False if in use, None if the probe itself failed."""
    try:
        sock = socket.socket(family, socket.SOCK_STREAM)
    except OSError:
        return None
    try:
        if family == socket.AF_INET6:
            sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
        sock.bind((address, port))
    except OSError as exc:
        if exc.errno in (errno.EADDRINUSE, errno.EACCES):
            return False
        return None
    finally:
        sock.close()
    return True

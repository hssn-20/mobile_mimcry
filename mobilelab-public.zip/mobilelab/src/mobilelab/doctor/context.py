"""Shared state for one doctor run plus small parsing helpers."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path

from mobilelab.doctor.host import HostAccess
from mobilelab.doctor.runner import DEFAULT_TIMEOUT_S, CommandResult, GuardedRunner

LICENSE_MARKERS = ("agreed to the xcode license", "xcodebuild -license")
_VERSION_RE = re.compile(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?")


@dataclass(slots=True)
class XcodeState:
    """Facts discovered by the Xcode checks and reused by later checks."""

    selected_path: str | None = None
    selected_is_full_xcode: bool = False
    bundle_path: str | None = None  # full Xcode bundle used for probes
    developer_dir: str | None = None  # <bundle>/Contents/Developer
    version: tuple[int, ...] | None = None
    license_accepted: bool | None = None
    usable: bool = False  # xcodebuild runs and licence accepted

    @property
    def probe_env(self) -> dict[str, str]:
        """DEVELOPER_DIR override so probes use the bundle without xcode-select -s."""
        if self.developer_dir and not self.selected_is_full_xcode:
            return {"DEVELOPER_DIR": self.developer_dir}
        return {}


@dataclass(slots=True)
class DoctorContext:
    runner: GuardedRunner
    host: HostAccess
    project_root: Path
    xcode: XcodeState = field(default_factory=XcodeState)

    def run(
        self,
        argv: Sequence[str],
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult:
        return self.runner.run(argv, timeout=timeout, env=env)

    @property
    def appium_dir(self) -> Path:
        return self.project_root / "tools" / "appium"

    @property
    def appium_home(self) -> Path:
        return self.appium_dir / ".appium"

    @property
    def appium_local_bin(self) -> Path:
        return project_appium_bin(self.project_root)


def project_appium_bin(project_root: Path) -> Path:
    """The only absolute executable path the doctor trusts (project-local Appium)."""
    return project_root / "tools" / "appium" / "node_modules" / ".bin" / "appium"


def parse_version(text: str | None) -> tuple[int, ...] | None:
    if not text:
        return None
    match = _VERSION_RE.search(text)
    if not match:
        return None
    return tuple(int(group) for group in match.groups() if group is not None)


def version_str(version: tuple[int, ...] | None) -> str | None:
    return ".".join(str(part) for part in version) if version else None


def at_least(version: tuple[int, ...] | None, minimum: tuple[int, ...]) -> bool:
    if version is None:
        return False
    width = max(len(version), len(minimum))
    pad = lambda v: v + (0,) * (width - len(v))  # noqa: E731
    return pad(version) >= pad(minimum)


def mentions_license(result: CommandResult) -> bool:
    text = result.output.lower()
    return any(marker in text for marker in LICENSE_MARKERS)


def first_line(text: str) -> str:
    return text.strip().splitlines()[0].strip() if text.strip() else ""

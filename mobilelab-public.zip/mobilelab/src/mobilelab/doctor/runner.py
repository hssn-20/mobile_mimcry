"""Injectable, allowlisted, read-only command execution for the doctor.

Every command is a typed argv list (never ``shell=True``) with a timeout. The
:class:`GuardedRunner` refuses anything that is not on the read-only allowlist,
so a coding mistake cannot make the doctor accept a licence, switch the active
developer directory, install a driver or touch a device.
"""

from __future__ import annotations

import os
import subprocess
import time
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import PurePath
from typing import Protocol
from mobilelab.secrets import child_env

DEFAULT_TIMEOUT_S = 20.0

# Exact argv the doctor may run. argv[0] must be a bare name (resolved through
# PATH) unless it is an absolute path explicitly trusted by the GuardedRunner
# (the project-local Appium binary); the basename must then still match.
READ_ONLY_COMMANDS: frozenset[tuple[str, ...]] = frozenset(
    {
        ("uname", "-m"),
        ("sw_vers", "-productVersion"),
        ("sw_vers", "-buildVersion"),
        ("sysctl", "-n", "hw.memsize"),
        ("sysctl", "-n", "hw.ncpu"),
        ("xcode-select", "-p"),
        ("xcodebuild", "-version"),
        ("xcodebuild", "-license", "check"),
        ("xcodebuild", "-checkFirstLaunchStatus"),
        ("xcrun", "simctl", "list", "runtimes", "--json"),
        ("xcrun", "simctl", "list", "devices", "--json"),
        ("xcrun", "devicectl", "list", "devices", "--json-output", "-"),
        ("system_profiler", "SPUSBDataType", "-json"),
        ("system_profiler", "SPUSBHostDataType", "-json"),
        ("security", "find-identity", "-v", "-p", "codesigning"),
        ("uv", "--version"),
        ("node", "--version"),
        ("npm", "--version"),
        ("appium", "--version"),
        ("swift", "--version"),
        ("xcodegen", "--version"),
    }
)

# Environment overrides the doctor may set. DEVELOPER_DIR selects an Xcode
# bundle for one probe without changing the system-wide xcode-select setting.
ALLOWED_ENV_KEYS: frozenset[str] = frozenset({"DEVELOPER_DIR", "APPIUM_HOME"})


def normalise_argv(argv: Sequence[str]) -> tuple[str, ...]:
    if not argv:
        return ()
    return (PurePath(argv[0]).name, *argv[1:])


def is_read_only(
    argv: Sequence[str],
    env: Mapping[str, str] | None = None,
    trusted_executables: Collection[str] = (),
) -> bool:
    """True if argv is allowlisted, argv[0] is a bare name or a trusted path, and env keys are allowed."""
    if not argv:
        return False
    executable = argv[0]
    if executable != PurePath(executable).name and executable not in trusted_executables:
        return False
    if normalise_argv(argv) not in READ_ONLY_COMMANDS:
        return False
    return all(key in ALLOWED_ENV_KEYS for key in (env or {}))


@dataclass(frozen=True, slots=True)
class CommandResult:
    argv: tuple[str, ...]
    returncode: int | None
    stdout: str = ""
    stderr: str = ""
    error: str | None = None  # "not_found" | "timeout" | "os_error: ..."
    duration_ms: int = 0
    env: Mapping[str, str] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and self.error is None

    @property
    def output(self) -> str:
        return "\n".join(part for part in (self.stdout.strip(), self.stderr.strip()) if part)


class CommandRunner(Protocol):
    def run(
        self,
        argv: Sequence[str],
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult: ...


class CommandNotAllowedError(PermissionError):
    pass


class SubprocessRunner:
    """Runs real commands. Use only through :class:`GuardedRunner`."""

    def run(
        self,
        argv: Sequence[str],
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult:
        args = tuple(argv)
        overrides = dict(env or {})
        full_env = child_env(None, **overrides)
        start = time.monotonic()
        try:
            proc = subprocess.run(  # noqa: S603 - typed argv, allowlisted by GuardedRunner
                list(args),
                capture_output=True,
                text=True,
                timeout=timeout,
                env=full_env,
                stdin=subprocess.DEVNULL,
                check=False,
            )
        except FileNotFoundError:
            return CommandResult(args, None, error="not_found", env=overrides,
                                 duration_ms=_elapsed_ms(start))
        except subprocess.TimeoutExpired:
            return CommandResult(args, None, error="timeout", env=overrides,
                                 duration_ms=_elapsed_ms(start))
        except OSError as exc:
            return CommandResult(args, None, error=f"os_error: {exc}", env=overrides,
                                 duration_ms=_elapsed_ms(start))
        return CommandResult(args, proc.returncode, proc.stdout, proc.stderr, None,
                             _elapsed_ms(start), overrides)


class GuardedRunner:
    """Enforces the read-only allowlist and records every executed command."""

    def __init__(self, inner: CommandRunner, trusted_executables: Collection[str] = ()) -> None:
        self._inner = inner
        self._trusted = frozenset(trusted_executables)
        self.history: list[CommandResult] = []

    def run(
        self,
        argv: Sequence[str],
        *,
        timeout: float = DEFAULT_TIMEOUT_S,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult:
        if not is_read_only(argv, env, self._trusted):
            raise CommandNotAllowedError(f"doctor refused non-allowlisted command: {list(argv)!r}")
        result = self._inner.run(argv, timeout=timeout, env=env)
        self.history.append(result)
        return result


def _elapsed_ms(start: float) -> int:
    return int((time.monotonic() - start) * 1000)

"""Typed result models for the read-only host preflight (`mobilelab doctor`)."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class CheckStatus(StrEnum):
    READY = "ready"
    MISSING = "missing"
    INCOMPATIBLE = "incompatible"
    UNKNOWN = "unknown"


class GateStatus(StrEnum):
    READY = "ready"
    BLOCKED = "blocked"


class EvidenceSource(StrEnum):
    """Where the observed values came from. Fixtures are never host evidence."""

    HOST = "host"
    FIXTURE = "fixture"


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class CommandRecord(_Model):
    """One read-only command the doctor executed (for audit)."""

    argv: list[str]
    env: dict[str, str] = Field(default_factory=dict)
    returncode: int | None
    error: str | None = None
    duration_ms: int


class CheckResult(_Model):
    id: str
    category: str
    title: str
    status: CheckStatus
    observed: str | None = None
    required: str | None = None
    remedy: str | None = None
    manual_action_required: bool = False
    details: dict[str, Any] = Field(default_factory=dict)


class GateResult(_Model):
    id: str
    title: str
    status: GateStatus
    blocked_by: list[str] = Field(default_factory=list)
    summary: str


class DoctorReport(_Model):
    schema_version: int = 1
    created_at: datetime
    evidence_source: EvidenceSource
    project_root: str
    checks: list[CheckResult]
    gates: list[GateResult]
    commands: list[CommandRecord]
    read_only: bool = True

    def check(self, check_id: str) -> CheckResult:
        for result in self.checks:
            if result.id == check_id:
                return result
        raise KeyError(check_id)

    def gate(self, gate_id: str) -> GateResult:
        for result in self.gates:
            if result.id == gate_id:
                return result
        raise KeyError(gate_id)

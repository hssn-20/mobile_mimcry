"""Read-only host preflight (`mobilelab doctor`, FR-01 / AC-01)."""

from __future__ import annotations

from pathlib import Path

from mobilelab.doctor.checks_appium import appium_checks
from mobilelab.doctor.checks_devices import device_checks
from mobilelab.doctor.checks_host import host_checks
from mobilelab.doctor.checks_xcode import xcode_checks
from mobilelab.doctor.context import DoctorContext, project_appium_bin
from mobilelab.doctor.gates import GATES, evaluate_gates
from mobilelab.doctor.host import HostAccess, RealHostAccess
from mobilelab.doctor.models import (
    CheckResult,
    CheckStatus,
    CommandRecord,
    DoctorReport,
    EvidenceSource,
    GateResult,
    GateStatus,
)
from mobilelab.doctor.runner import (
    READ_ONLY_COMMANDS,
    CommandResult,
    CommandRunner,
    GuardedRunner,
    SubprocessRunner,
    is_read_only,
)

__all__ = [
    "GATES", "READ_ONLY_COMMANDS", "CheckResult", "CheckStatus", "CommandRecord", "CommandResult",
    "CommandRunner", "DoctorReport", "EvidenceSource", "GateResult", "GateStatus", "GuardedRunner",
    "HostAccess", "RealHostAccess", "SubprocessRunner", "find_project_root", "is_read_only", "run_doctor",
]


def find_project_root(start: Path | None = None) -> Path:
    """Nearest ancestor containing tools/appium or pyproject.toml naming mobilelab."""
    candidates = [start or Path.cwd(), Path(__file__).resolve().parents[3]]
    for base in candidates:
        for directory in (base, *base.parents):
            pyproject = directory / "pyproject.toml"
            if pyproject.is_file() and 'name = "mobilelab"' in pyproject.read_text(encoding="utf-8"):
                return directory
    return candidates[0]


def run_doctor(
    *,
    runner: CommandRunner | None = None,
    host: HostAccess | None = None,
    project_root: Path | None = None,
    evidence_source: EvidenceSource = EvidenceSource.HOST,
) -> DoctorReport:
    """Run every read-only check. Inject ``runner``/``host`` fakes in tests and pass
    ``evidence_source=EvidenceSource.FIXTURE`` so fixture output is never mistaken for host evidence."""
    host = host or RealHostAccess()
    root = project_root or find_project_root()
    guarded = GuardedRunner(runner or SubprocessRunner(), trusted_executables={str(project_appium_bin(root))})
    ctx = DoctorContext(runner=guarded, host=host, project_root=root)
    checks = [*host_checks(ctx), *xcode_checks(ctx), *appium_checks(ctx), *device_checks(ctx)]
    commands = [CommandRecord(argv=list(r.argv), env=dict(r.env), returncode=r.returncode, error=r.error,
                              duration_ms=r.duration_ms) for r in guarded.history]
    return DoctorReport(created_at=host.now(), evidence_source=evidence_source,
                        project_root=str(ctx.project_root), checks=checks,
                        gates=evaluate_gates(checks), commands=commands)
